package io.kixo.sdk.internal.attribution

import android.content.SharedPreferences
import android.util.Log
import io.kixo.sdk.KixoDeferredLink
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Owns the **read-once + bounded-retry + in-flight-guard** state machine for
 * the Play Install Referrer, persisted to a dedicated `kixo_attribution`
 * SharedPreferences file (sibling of `IdentityManager.PREFS_NAME`).
 *
 * State model (`referrer_read_state`):
 *  - `UNREAD`               (default) — eligible to read.
 *  - `READ_OK_POST_PENDING` — read succeeded, POST not yet 2xx-acked. A cached
 *                             `referrer_snapshot` blob means a re-POST on next
 *                             launch needs NO re-read (§3.2.1, idempotent via
 *                             the backend `@@unique(projectId, deviceId)` upsert).
 *  - `DONE`                 — never read/POST again (POST-acked, OR terminal
 *                             read failure, OR read attempts exhausted, OR POST
 *                             attempts exhausted).
 *
 * Two **distinct** bounded counters (the §3.2.1 fix — a failed POST must NOT
 * burn read attempts):
 *  - `referrer_read_attempts`  cap [MAX_READ_ATTEMPTS]  (transient read fails).
 *  - `referrer_post_attempts`  cap [MAX_POST_ATTEMPTS]  (5xx/network POST fails).
 *
 * In-process **in-flight guard** ([readInFlight] AtomicBoolean) closes the
 * `fetchInstallReferrer()` race: both the auto-read on `configure()` and a
 * manual `fetchInstallReferrer()` must `compareAndSet(false,true)` before
 * binding; a second concurrent call returns immediately. The persisted `DONE`
 * guard alone is insufficient (two concurrent binds could otherwise occur).
 *
 * **Consent (§0 §6 / §8):** while opted out we do NOT read the referrer at all
 * and leave state `UNREAD` (the referrer is immutable for 90d, so reading later
 * loses nothing — and we must NOT consume the one-shot read while we can't POST
 * it). The caller passes the consent decision in via [start].
 *
 * **Threading:** the read + POST happen on the injected [executor] (production:
 * a background dispatcher). The persisted state writes use SharedPreferences
 * `apply()` (non-blocking). [readInFlight] is reset in the `finally` of the
 * read+POST cycle.
 */
internal class InstallReferrerController(
    private val prefs: SharedPreferences,
    private val wrapper: ReferrerFetcher,
    private val poster: ReferrerPoster,
    private val contextProvider: () -> ReferrerPoster.Context?,
    private val executor: (Runnable) -> Unit,
) {

    private val readInFlight = AtomicBoolean(false)

    /** Listener set by the host. Fires once with the resolved link (or null). */
    private val listener = AtomicReference<io.kixo.sdk.DeferredDeepLinkListener?>(null)

    /** Cached resolved link, so a late listener registration fires immediately. */
    private val cachedLink = AtomicReference<KixoDeferredLink?>(null)

    /** Whether the listener has already been fired this process (one-shot). */
    private val listenerFired = AtomicBoolean(false)

    /** Whether the deferred resolution has completed (so a late register can fire). */
    private val resolved = AtomicBoolean(false)

    // ─── Public-facade-facing entry points ──────────────────────────

    /**
     * Auto-read entry on `configure()`. No-op when [consentAllows] is false
     * (we leave state UNREAD), when state is already DONE, or when a read is
     * in flight. [fetchInstallReferrer] is the explicit opt-in re-trigger.
     */
    fun start(consentAllows: Boolean) {
        if (!consentAllows) {
            // Do NOT read while opted out — leave UNREAD (§8). The referrer is
            // immutable for 90d; fetchInstallReferrer() reads on opt-in.
            return
        }
        attemptReadOrRepost()
    }

    /** Force a (re-)attempt. No-op if DONE or a read/post is in flight. */
    fun fetchInstallReferrer() {
        attemptReadOrRepost()
    }

    /**
     * Register the deferred-deep-link listener. If resolution already happened,
     * fire immediately with the cached result (race-safe).
     */
    fun setDeferredDeepLinkListener(l: io.kixo.sdk.DeferredDeepLinkListener) {
        listener.set(l)
        if (resolved.get() && listenerFired.compareAndSet(false, true)) {
            safeFire(l, cachedLink.get())
        }
    }

    /**
     * Fire the registered [io.kixo.sdk.DeferredDeepLinkListener] for a DIRECT /
     * warm App-Link or custom-scheme open (`isDeferred=false`) — NOT a deferred
     * install-referrer resolution.
     *
     * A direct open is a discrete user action that may happen many times in a
     * session, so — unlike the one-shot DEFERRED resolution which the
     * [listenerFired] CAS latches exactly once — this fires every time the host
     * surfaces a new open. It deliberately does NOT consume [listenerFired] /
     * mutate [cachedLink] / [resolved] (those belong to the deferred path), so a
     * later deferred resolution still reaches a late-registering listener.
     *
     * No-op when no listener is registered (the host opted out of the callback);
     * `Kixo.handleDeepLink` still emits the `deep_link` event + opens the window
     * regardless. The listener convention (`null` == organic/unattributed) holds:
     * a [link] of `null` means the open carried no `kixo_link_id`/`kixo_click_id`.
     */
    fun fireDirectDeepLink(link: KixoDeferredLink?) {
        val l = listener.get() ?: return
        safeFire(l, link)
    }

    // ─── State machine ──────────────────────────────────────────────

    private fun attemptReadOrRepost() {
        val state = readState()
        if (state == STATE_DONE) {
            // Already finished — but if a listener is waiting and we resolved,
            // make sure it fired (covers register-after-DONE in the same run).
            fireIfPendingAndResolved()
            return
        }
        if (!readInFlight.compareAndSet(false, true)) return

        // Persist IN_FLIGHT intent before the async call so a mid-read crash is
        // recoverable — we bump the read-attempt counter here for the read path.
        if (state == STATE_UNREAD) {
            val attempts = prefs.getInt(KEY_READ_ATTEMPTS, 0)
            if (attempts >= MAX_READ_ATTEMPTS) {
                // Exhausted before we even started (e.g. set from a prior crash
                // loop) — terminal.
                markDone(postFailed = false)
                readInFlight.set(false)
                return
            }
            prefs.edit().putInt(KEY_READ_ATTEMPTS, attempts + 1).apply()
        }

        executor.run {
            try {
                if (state == STATE_READ_OK_POST_PENDING) {
                    // We already have a cached snapshot — skip the read, re-POST.
                    val cached = loadCachedSnapshot()
                    if (cached == null) {
                        // Snapshot blob lost/corrupt (extremely rare — SharedPrefs
                        // wipe). The one-shot read is already consumed, so we
                        // can't safely re-read; terminate rather than risk an
                        // infinite POST_PENDING loop across launches.
                        Log.w(TAG, "POST_PENDING but cached snapshot missing; terminating.")
                        markDone(postFailed = true)
                    } else {
                        doPost(cached.first, cached.second)
                    }
                } else {
                    doReadThenPost()
                }
            } catch (t: Throwable) {
                Log.w(TAG, "referrer read/post cycle threw", t)
            } finally {
                readInFlight.set(false)
            }
        }
    }

    private fun doReadThenPost() {
        wrapper.fetch { result ->
            when (result) {
                is ReferrerFetcher.FetchResult.Success -> {
                    val snapshot = result.snapshot
                    val parsed = ReferrerParser.parse(snapshot.referrerUrl)
                    // Cache snapshot + flip to POST-pending BEFORE the POST so a
                    // crash mid-POST re-POSTs (not re-reads) next launch.
                    persistSnapshot(snapshot)
                    setReadState(STATE_READ_OK_POST_PENDING)
                    doPost(snapshot, parsed)
                }

                is ReferrerFetcher.FetchResult.TransientFailure -> {
                    // Leave UNREAD (counter already bumped) so the next launch
                    // retries, up to MAX_READ_ATTEMPTS. If exhausted, DONE.
                    val attempts = prefs.getInt(KEY_READ_ATTEMPTS, 0)
                    if (attempts >= MAX_READ_ATTEMPTS) {
                        Log.w(TAG, "referrer read exhausted (${result.reason}); giving up.")
                        markDone(postFailed = false)
                    }
                    // else: stay UNREAD; natural next-launch retry.
                }

                is ReferrerFetcher.FetchResult.TerminalFailure -> {
                    // Old/absent Play Store or lib stripped — never retry.
                    markDone(postFailed = false)
                }
            }
        }
    }

    private fun doPost(snapshot: ReferrerSnapshot, parsed: ParsedReferrer) {
        val ctx = contextProvider()
        if (ctx == null) {
            // Creds not ready (shouldn't happen post-configure) — leave
            // POST_PENDING so next launch re-POSTs the cached snapshot.
            Log.w(TAG, "referrer POST context unavailable; will retry next launch.")
            return
        }
        when (val r = poster.post(ctx, snapshot, parsed)) {
            is ReferrerPoster.Result.Acked -> {
                markDone(postFailed = false)
                clearSnapshot()
                resolveAndFire(parsed, r.deferredLink)
            }
            is ReferrerPoster.Result.Terminal -> {
                // 4xx won't fix itself — terminal immediately. §4.5 (June 2026):
                // a 4xx is an auth/validation REJECTION. The open-redirect /
                // click_id-integrity (§3) contract rests on the backend's
                // server-side existence + ownership + single-use check, which on
                // a 4xx NEVER RAN. We must NOT attribute on a server-rejected
                // install: fire `null` (not the locally-parsed, unvalidated
                // campaign/source) and do NOT open the attribution window. The
                // host gets the unambiguous "unattributed" signal rather than a
                // navigable-looking object whose backend write was rejected.
                Log.w(TAG, "referrer POST terminal (${r.code}); rejecting attribution.")
                markDone(postFailed = true)
                clearSnapshot()
                resolveRejected()
            }
            is ReferrerPoster.Result.Retryable -> {
                val attempts = prefs.getInt(KEY_POST_ATTEMPTS, 0) + 1
                prefs.edit().putInt(KEY_POST_ATTEMPTS, attempts).apply()
                if (attempts >= MAX_POST_ATTEMPTS) {
                    // Retries exhausted: the backend never returned a verdict, so
                    // — like a 4xx — there is no server-validated link to
                    // attribute to. Fire `null`, no window. (Same §4.5 rationale:
                    // attribution rests on backend validation, never on
                    // locally-parsed unvalidated referrer metadata.)
                    Log.w(TAG, "referrer POST exhausted (${r.reason}); rejecting attribution.")
                    markDone(postFailed = true)
                    clearSnapshot()
                    resolveRejected()
                }
                // else: stay READ_OK_POST_PENDING; re-POST cached snapshot next launch.
            }
        }
    }

    // ─── Listener resolution ─────────────────────────────────────────

    private fun resolveAndFire(parsed: ParsedReferrer, deferredLink: ReferrerPoster.ResolvedDeferredLink?) {
        val link: KixoDeferredLink? = buildDeferredLink(parsed, deferredLink)
        cachedLink.set(link)
        resolved.set(true)
        // Open the attribution window so the dashboard can attribute downstream
        // conversions without a backend join (first-write-wins, 30-min window).
        if (link != null) {
            InstallAttributionStore.recordOpen(
                linkId = link.linkId,
                clickId = parsed.clickId,
                campaign = link.campaign,
                source = link.source,
                medium = link.medium,
                kind = AttributionContract.ATTR_KIND_INSTALL_REFERRER,
            )
        }
        val l = listener.get()
        if (l != null && listenerFired.compareAndSet(false, true)) {
            safeFire(l, link)
        }
    }

    /**
     * Resolve as UNATTRIBUTED after a server rejection (4xx) or exhausted POST
     * retries. Caches + fires `null` and — crucially — does NOT open the
     * attribution window (§4.5): nothing should inherit `attribution_*` for an
     * install the backend never validated. Idempotent via the same
     * [listenerFired] CAS as [resolveAndFire].
     */
    private fun resolveRejected() {
        cachedLink.set(null)
        resolved.set(true)
        val l = listener.get()
        if (l != null && listenerFired.compareAndSet(false, true)) {
            safeFire(l, null)
        }
    }

    private fun fireIfPendingAndResolved() {
        val l = listener.get() ?: return
        if (resolved.get() && listenerFired.compareAndSet(false, true)) {
            safeFire(l, cachedLink.get())
        }
    }

    /**
     * Build the host-facing link FOR AN ACKED (backend-validated) install only.
     * The 4xx-reject + exhausted-retry paths bypass this and call
     * [resolveRejected] (fire `null`, no window) — so this is reached ONLY when
     * the backend accepted the POST. Organic (no link id, no resolved link) =>
     * `null` (the listener convention for an unattributed install). When the
     * backend returned a validated `deferred_link`, its `target_url` wins;
     * otherwise (Acked but no `deferred_link`, yet a `kixo_link_id` was on the
     * referrer) we surface the locally-parsed campaign metadata WITHOUT a
     * target_url (the host must not navigate to an unvalidated target, but the
     * backend DID accept the install so the campaign labels are trustworthy).
     */
    private fun buildDeferredLink(
        parsed: ParsedReferrer,
        resolvedLink: ReferrerPoster.ResolvedDeferredLink?,
    ): KixoDeferredLink? {
        if (resolvedLink == null && (parsed.isOrganic || parsed.linkId == null)) {
            return null
        }
        return KixoDeferredLink(
            targetUrl = resolvedLink?.targetUrl, // backend-validated; null otherwise
            linkId = resolvedLink?.linkId ?: parsed.linkId,
            campaign = resolvedLink?.campaign ?: parsed.campaign,
            source = resolvedLink?.source ?: parsed.source,
            medium = resolvedLink?.medium ?: parsed.medium,
            params = if (resolvedLink?.params?.isNotEmpty() == true) resolvedLink.params else parsed.params,
            isDeferred = true,
        )
    }

    private fun safeFire(l: io.kixo.sdk.DeferredDeepLinkListener, link: KixoDeferredLink?) {
        try {
            l.onDeferredDeepLink(link)
        } catch (t: Throwable) {
            // R6 — a buggy host listener can never crash the SDK.
            Log.w(TAG, "DeferredDeepLinkListener threw; swallowed", t)
        }
    }

    // ─── Persistence helpers ─────────────────────────────────────────

    private fun readState(): String = prefs.getString(KEY_READ_STATE, STATE_UNREAD) ?: STATE_UNREAD

    private fun setReadState(state: String) {
        prefs.edit().putString(KEY_READ_STATE, state).apply()
    }

    private fun markDone(postFailed: Boolean) {
        val editor = prefs.edit().putString(KEY_READ_STATE, STATE_DONE)
        if (postFailed) editor.putBoolean(KEY_POST_FAILED, true)
        editor.apply()
    }

    private fun persistSnapshot(s: ReferrerSnapshot) {
        prefs.edit().putString(KEY_SNAPSHOT, ReferrerSnapshot.toJson(s)).apply()
    }

    private fun clearSnapshot() {
        prefs.edit().remove(KEY_SNAPSHOT).apply()
    }

    /** Load the cached snapshot + its parsed referrer, or null if absent/corrupt. */
    private fun loadCachedSnapshot(): Pair<ReferrerSnapshot, ParsedReferrer>? {
        val blob = prefs.getString(KEY_SNAPSHOT, null) ?: return null
        return try {
            val obj = kotlinx.serialization.json.Json.parseToJsonElement(blob)
                as? kotlinx.serialization.json.JsonObject ?: return null
            fun s(k: String): String? =
                (obj[k] as? kotlinx.serialization.json.JsonPrimitive)
                    ?.content
                    ?.takeIf { it != "null" }
            fun l(k: String): Long =
                (obj[k] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toLongOrNull() ?: 0L
            fun b(k: String): Boolean =
                (obj[k] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toBoolean() ?: false
            val snapshot = ReferrerSnapshot(
                referrerUrl = s("referrer_url").orEmpty(),
                clickTsSeconds = l("click_seconds"),
                installBeginTsSeconds = l("install_begin_seconds"),
                installVersion = s("install_version"),
                googlePlayInstantParam = b("google_play_instant"),
            )
            snapshot to ReferrerParser.parse(snapshot.referrerUrl)
        } catch (t: Throwable) {
            Log.w(TAG, "cached snapshot parse failed", t)
            null
        }
    }

    // ─── Diagnostics (AC-7) ─────────────────────────────────────────

    /** Current persisted read state, for [io.kixo.sdk.KixoDiagnostics]. */
    fun stateForDiagnostics(): String = readState()

    /** Whether the POST permanently failed (4xx or exhausted retries). */
    fun postFailedForDiagnostics(): Boolean = prefs.getBoolean(KEY_POST_FAILED, false)

    companion object {
        private const val TAG = "Kixo.InstallReferrer"

        /**
         * FIX 4 — build the install-event referrer bag from the persisted
         * `referrer_snapshot` blob (the "InstallReferrerController result"),
         * keyed under the FROZEN §0 [AttributionContract] constants so the
         * backend can detect Play-referrer match / click-injection from the
         * canonical `app_install` event itself.
         *
         * Returns a single-entry map `{ INSTALL_REFERRER_PROP -> { referrer_url,
         * referrer_click_ts, install_begin_ts, [install_version],
         * google_play_instant } }` (the §0 nested-object shape — `INSTALL_REFERRER_PROP`
         * is the bag key, the inner keys are the frozen [REFERRER_PROP_*]
         * field names), OR empty when no referrer snapshot has been persisted
         * (a true first-run install that fires before the async read completes —
         * in that case the SEPARATE synthetic `install_referrer` event still
         * carries the bag once the read lands).
         *
         * Reads from the SAME `kixo_attribution` prefs the controller persists
         * to ([KEY_SNAPSHOT]); the persisted blob's internal field names
         * (`referrer_url` / `click_seconds` / `install_begin_seconds` /
         * `install_version` / `google_play_instant`) are an implementation
         * detail of [ReferrerSnapshot.toJson] — the OUTPUT keys here are the
         * frozen wire contract constants, never re-spelled. Never throws (a
         * corrupt blob yields an empty bag, exactly like a fresh install).
         */
        fun referrerBagFromPrefs(prefs: SharedPreferences): Map<String, Any?> {
            val blob = prefs.getString(KEY_SNAPSHOT, null) ?: return emptyMap()
            return try {
                val obj = kotlinx.serialization.json.Json.parseToJsonElement(blob)
                    as? kotlinx.serialization.json.JsonObject ?: return emptyMap()
                fun prim(k: String): kotlinx.serialization.json.JsonPrimitive? =
                    obj[k] as? kotlinx.serialization.json.JsonPrimitive
                fun str(k: String): String? = prim(k)?.content?.takeIf { it != "null" }
                fun long(k: String): Long = prim(k)?.content?.toLongOrNull() ?: 0L
                fun bool(k: String): Boolean = prim(k)?.content?.toBoolean() ?: false

                val referrerUrl = str("referrer_url").orEmpty()
                // An empty referrer carries no Play payload worth attaching.
                if (referrerUrl.isEmpty()) return emptyMap()

                val bag = LinkedHashMap<String, Any?>(5)
                bag[AttributionContract.REFERRER_PROP_REFERRER_URL] = referrerUrl
                bag[AttributionContract.REFERRER_PROP_REFERRER_CLICK_TS] = long("click_seconds")
                bag[AttributionContract.REFERRER_PROP_INSTALL_BEGIN_TS] = long("install_begin_seconds")
                str("install_version")?.let {
                    bag[AttributionContract.REFERRER_PROP_INSTALL_VERSION] = it
                }
                bag[AttributionContract.REFERRER_PROP_GOOGLE_PLAY_INSTANT] = bool("google_play_instant")

                mapOf(AttributionContract.INSTALL_REFERRER_PROP to bag)
            } catch (t: Throwable) {
                Log.w(TAG, "referrer bag read failed; install fires without it", t)
                emptyMap()
            }
        }

        /** Dedicated SharedPreferences file — sibling of `kixo_identity`. */
        const val PREFS_NAME = "kixo_attribution"

        const val KEY_READ_STATE = "referrer_read_state"
        const val KEY_READ_ATTEMPTS = "referrer_read_attempts"
        const val KEY_POST_ATTEMPTS = "referrer_post_attempts"
        const val KEY_SNAPSHOT = "referrer_snapshot"
        const val KEY_POST_FAILED = "referrer_post_failed"

        const val STATE_UNREAD = "UNREAD"
        const val STATE_READ_OK_POST_PENDING = "READ_OK_POST_PENDING"
        const val STATE_DONE = "DONE"

        const val MAX_READ_ATTEMPTS = 3
        const val MAX_POST_ATTEMPTS = 5
    }
}
