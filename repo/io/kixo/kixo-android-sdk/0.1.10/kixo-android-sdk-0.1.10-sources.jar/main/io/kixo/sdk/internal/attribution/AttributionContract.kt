package io.kixo.sdk.internal.attribution

/**
 * §0 — Attribution Wire Contract, Android (Kotlin) mirror.
 *
 * **SOURCE OF TRUTH:** `kixo-backend/apps/web/src/lib/links/attribution-contract.ts`
 * (the FROZEN §0 module, the KIX-DL-00 merge gate). A Kotlin SDK cannot
 * literally `import` the TypeScript module, so — exactly as the iOS SDK does
 * for its own cross-language constants — this file **mirrors** the subset of
 * the §0 wire keys / event names / match-method literals the Android SDK
 * PRODUCES on the wire. Every value here MUST be byte-identical to the TS
 * export it shadows; [AttributionContractConformanceTest] pins each one so a
 * future edit to either side fails CI rather than silently killing the
 * deterministic Android join.
 *
 * The Android SDK is the **producer** of these keys (it stamps them onto the
 * referrer POST + the `deep_link` event); the backend
 * (`lib/attribution/play-referrer.ts`, the resolve route) is the consumer.
 * NEVER re-spell any of these inline in the controller / parser / poster —
 * reference the constant here so there is ONE spelling per the §0 mandate.
 */
internal object AttributionContract {

    // ─── §1 — Canonical wire keys ────────────────────────────────────
    //   Mirror of attribution-contract.ts KIXO_LINK_ID_KEY / KIXO_CLICK_ID_KEY
    //   / KIXO_CAMPAIGN_KEY / KIXO_CLICK_ID_PLAY_ALIAS.

    /** CUID — the Link entity id. Carried in the Play referrer query-string
     *  + echoed on the install / deep_link events. */
    const val KIXO_LINK_ID_KEY = "kixo_link_id"

    /** UUID string — the load-bearing cross-section join key, carried VERBATIM
     *  in the Play referrer query-string + echoed by the SDK. */
    const val KIXO_CLICK_ID_KEY = "kixo_click_id"

    /** Slug — human channel/source label. */
    const val KIXO_CAMPAIGN_KEY = "kixo_campaign"

    /**
     * The compact ALIAS for [KIXO_CLICK_ID_KEY] carried ONLY in the Play
     * `referrer` query-string (`?kxc=<uuid>`), where the canonical key is too
     * long for the length-sensitive Play param. The parser accepts BOTH the
     * canonical key (preferred) and this alias; both decode to the one
     * `kixo_click_id` UUID. No other wire surface uses the alias.
     */
    const val KIXO_CLICK_ID_PLAY_ALIAS = "kxc"

    // ─── §2 — The canonical install signal ───────────────────────────
    //   Mirror of INSTALL_EVENT_TYPE / APP_INSTALL_EVENT_NAME /
    //   INSTALL_REFERRER_PROP. Install discovery keys on event_type==='install'
    //   (NOT standard_kind) — the SDK stamps event_type="install".

    /** On-the-wire `event_type` discovery key for a fresh install. */
    const val INSTALL_EVENT_TYPE = "install"

    /** Public SDK-side event NAME emitted verbatim, EXACTLY ONCE, per fresh
     *  install (KIX-ATTR-00 / KIX-DL-01). */
    const val APP_INSTALL_EVENT_NAME = "app_install"

    /** Property-bag key holding the nested Play Install Referrer payload. The
     *  fields below are the ONLY ones the public `ReferrerDetails` API exposes
     *  (developer.android.com) — there are NO `*ServerSeconds` variants
     *  (§0 §15). */
    const val INSTALL_REFERRER_PROP = "install_referrer"

    // ─── §2 (cont.) — The synthetic Install-Referrer EVENT envelope + keys ──
    //   Mirror of REFERRER_EVENT_TYPE / REFERRER_EVENT_NAME / REFERRER_PROP_KEYS.
    //   The Android SDK is the PRODUCER: it emits a synthetic event with these
    //   (event_type, event_name) + properties into /api/sdk/batch (NOT a
    //   dedicated route — the BLOCKER-B resolution). The backend
    //   `referrer-post-processor.ts` is the CONSUMER. Before the freeze the
    //   writer emitted `referrer_click_seconds` / `install_begin_seconds` while
    //   the reader looked for `referrer_click_ts` / `install_begin_ts` — a silent
    //   byte-mismatch (BLOCKER-B(c)). These constants are the ONE spelling both
    //   sides import; [AttributionContractConformanceTest] pins them.

    /** `event_type` of the synthetic install_referrer event. `attribution`
     *  (the referrer enrichment) — DISTINCT from [INSTALL_EVENT_TYPE]. */
    const val REFERRER_EVENT_TYPE = "attribution"

    /** `event_name` of the synthetic install_referrer event. The backend keys
     *  `processReferrerEvents` on the (REFERRER_EVENT_TYPE, REFERRER_EVENT_NAME)
     *  tuple. */
    const val REFERRER_EVENT_NAME = "install_referrer"

    /** FROZEN property key — raw Play `getInstallReferrer()` query-string. */
    const val REFERRER_PROP_REFERRER_URL = "referrer_url"

    /** FROZEN property key — Play `getReferrerClickTimestampSeconds()` (UNIX
     *  seconds). The backend click-injection ordering gate reads THIS exact
     *  key. (Was `referrer_click_seconds` pre-freeze — the BLOCKER-B(c) bug.) */
    const val REFERRER_PROP_REFERRER_CLICK_TS = "referrer_click_ts"

    /** FROZEN property key — Play `getInstallBeginTimestampSeconds()` (UNIX
     *  seconds). (Was `install_begin_seconds` pre-freeze.) */
    const val REFERRER_PROP_INSTALL_BEGIN_TS = "install_begin_ts"

    /** FROZEN property key — Play `getInstallVersion()`. */
    const val REFERRER_PROP_INSTALL_VERSION = "install_version"

    /** FROZEN property key — Play `getGooglePlayInstantParam()` (boolean). */
    const val REFERRER_PROP_GOOGLE_PLAY_INSTANT = "google_play_instant"

    // ─── §11 — match_method taxonomy (the subset the Android spine sets) ──
    //   Mirror of MATCH_METHOD.{INSTALL_REFERRER,ORGANIC}. The full taxonomy +
    //   match_confidence + SET A/B firewall is owned server-side by
    //   attribution-engine; the SDK only labels the deterministic-referrer /
    //   organic outcome it produces so the smoke test can assert it.

    /** Deterministic Play Install Referrer match (match_confidence 1.0 server-side). */
    const val MATCH_METHOD_INSTALL_REFERRER = "install_referrer"

    /** Organic install (no campaign / no link). */
    const val MATCH_METHOD_ORGANIC = "organic"

    // ─── Organic-referrer detection (§4.3 / research finding 1) ──────────
    //   The verbatim Play "no campaign" sentinel utm tuple. Detection is also
    //   server-side (authoritative), but the SDK uses it to classify the
    //   listener callback (null link == organic) without a round-trip.

    /** `utm_source` value Play stamps for an organic (store-browse) install. */
    const val ORGANIC_UTM_SOURCE = "google-play"

    /** `utm_medium` value Play stamps for an organic install. */
    const val ORGANIC_UTM_MEDIUM = "organic"

    // ─── attribution_* decorate-window keys (align with PushAttributionStore) ─
    //   The InstallAttributionStore stamps these on downstream events inside the
    //   window so the dashboard attributes conversions without a backend join.
    //   `attribution_kind` shares the push/link/referrer namespace.

    const val ATTR_LINK_ID = "attribution_link_id"
    const val ATTR_CLICK_ID = "attribution_click_id"
    const val ATTR_CAMPAIGN = "attribution_campaign"
    const val ATTR_SOURCE = "attribution_source"
    const val ATTR_MEDIUM = "attribution_medium"
    const val ATTR_KIND = "attribution_kind"
    const val ATTR_AGE_MS = "attribution_age_ms"

    /** `attribution_kind` value for a deferred deep link resolved via the
     *  Play Install Referrer. */
    const val ATTR_KIND_INSTALL_REFERRER = "install_referrer"

    /** `attribution_kind` value for a deferred deep link surfaced on first run. */
    const val ATTR_KIND_DEFERRED_DEEPLINK = "deferred_deeplink"

    /** `attribution_kind` value for a direct/warm App-Link open. */
    const val ATTR_KIND_APPLINK = "applink"

    // ─── deep_link event wire keys (§5.3) ────────────────────────────────

    /** Event type + name for a deep-link open (the slot already wired:
     *  KixoEventType.DeepLink → "deep_link"). */
    const val DEEP_LINK_EVENT = "deep_link"

    const val DL_PROP_URI = "uri"
    const val DL_PROP_SOURCE = "deep_link_source"
    const val DL_PROP_IS_DEFERRED = "is_deferred"

    /**
     * The §5.3 enumerated `deep_link_source` values. Mirror of the TS contract's
     * documented enumeration "applink|push|manual|deferred". `applink` (cold/warm
     * App-Link) and `push` (push-tap routing) are SDK-CONTROLLED — the SDK passes
     * them itself at the call site. `manual` is the public-API default a host gets
     * when it calls `handleDeepLink(uri)` with no explicit source. `deferred` is
     * reserved for the deferred-install resolution path (the listener stream, not
     * the `deep_link` event — kept here so the allow-list is the complete §5.3 set
     * and the conformance test pins it).
     */
    const val DL_SOURCE_APPLINK = "applink"
    const val DL_SOURCE_PUSH = "push"
    const val DL_SOURCE_MANUAL = "manual"
    const val DL_SOURCE_DEFERRED = "deferred"

    /**
     * The closed set of accepted `deep_link_source` values (§5.3). The public
     * `Kixo.handleDeepLink(uri, source)` param is HOST-SUPPLIED, so an arbitrary
     * string could otherwise pollute the `deep_link_source` analytics dimension
     * the dashboards key off. [coerceDeepLinkSource] folds any value outside this
     * set back to [DL_SOURCE_MANUAL] (the warm/host-open default) so the dimension
     * stays a clean, finite enum. The SDK-controlled call sites (cold `applink`,
     * push `push`) always pass an in-set value, so coercion only ever touches a
     * host's free-form override.
     */
    val DEEP_LINK_SOURCES: Set<String> =
        setOf(DL_SOURCE_APPLINK, DL_SOURCE_PUSH, DL_SOURCE_MANUAL, DL_SOURCE_DEFERRED)

    /**
     * Coerce a host-supplied `deep_link_source` to the §5.3 enum: an exact
     * (case-sensitive — the wire values are fixed lowercase literals) member of
     * [DEEP_LINK_SOURCES] passes through; anything else (a typo, an arbitrary
     * label, `null`/blank) folds to [DL_SOURCE_MANUAL]. This keeps the
     * `deep_link_source` dimension a finite, dashboard-safe enum regardless of
     * what a host stamps into the public `handleDeepLink(uri, source)` param.
     */
    fun coerceDeepLinkSource(source: String?): String =
        if (source != null && source in DEEP_LINK_SOURCES) source else DL_SOURCE_MANUAL

    // ─── Standard UTM param keys parsed off the referrer query-string ────
    const val UTM_SOURCE = "utm_source"
    const val UTM_MEDIUM = "utm_medium"
    const val UTM_CAMPAIGN = "utm_campaign"
    const val UTM_CONTENT = "utm_content"
    const val UTM_TERM = "utm_term"
}
