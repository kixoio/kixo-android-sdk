package io.kixo.sdk.internal.attribution

import android.content.SharedPreferences
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Emits the canonical **install signal** (§0 §2, KIX-DL-01) EXACTLY ONCE per
 * fresh install — the Android half of the cross-platform install spine the MMP
 * attribution platform keys off. Mirrors iOS `InstallTracker.swift`.
 *
 * **Why this exists (BLOCKER A).** Before this, the Android SDK emitted NO
 * canonical install event — `KixoEventType` had no `Install` case and nothing
 * fired `app_install`. The backend keys install discovery on
 * `event_type === 'install'` ([AttributionContract.INSTALL_EVENT_TYPE]); with
 * Android never emitting it, `Link.installCount`, organic detection, and the
 * FREE-cap dedup unit were 100% dark on Android. This emitter closes that gap.
 *
 * Per the FROZEN §0 wire-contract:
 *   - The event NAME is `app_install`
 *     ([AttributionContract.APP_INSTALL_EVENT_NAME]).
 *   - The on-the-wire `event_type` is `install`
 *     ([AttributionContract.INSTALL_EVENT_TYPE], i.e. `KixoEventType.Install`)
 *     — install discovery keys on `event_type == 'install'`, NOT on
 *     `standard_kind` and NOT on the legacy `app_launch{is_first_launch}`
 *     lifecycle event.
 *   - It carries the `install_referrer` payload + `kixo_link_id`/`kixo_click_id`
 *     echo when a resolver/referrer-read supplies them (best-effort via the
 *     [propsProvider]; the deterministic join is also carried by the SEPARATE
 *     synthetic `install_referrer` event, so a fresh-run install that fires
 *     before the async referrer read still attributes).
 *
 * ### Why a dedicated once-flag (not `app_launch{is_first_launch}`)
 * `ProcessLifecycleObserver` already stamps `is_first_launch` on `app_launch`.
 * We deliberately do NOT reuse that flag: the install signal must fire exactly
 * once with `event_type=install` independent of the lifecycle stream, and
 * coupling the two flags would risk a lifecycle change silently double- or
 * never-firing the install. This emitter owns its OWN persistent once-flag
 * ([KEY_EMITTED]) so the contract is enforced in one place — exactly as iOS
 * `InstallTracker` owns `kixo_install_emitted`.
 *
 * Thread-safety: [markAndEmitIfFirstInstall] is intended to be called once
 * during `configure`; an in-process [AtomicBoolean] CAS plus the persisted
 * once-flag mean it emits at most once per process AND at most once across
 * launches even under a double-`configure`.
 */
internal class InstallEmitter(
    private val prefs: SharedPreferences,
    /**
     * Emits the event into the queue (→ /api/sdk/batch). The 3-arg shape mirrors
     * `EventQueueRef.enqueueCustom(eventType, eventName, properties)`.
     */
    private val onEvent: (eventType: String, eventName: String, properties: Map<String, Any?>) -> Unit,
    /**
     * Supplies the extra install properties known at emit time: the resolved
     * `kixo_click_id`/`kixo_link_id` echo + the `install_referrer` payload, when
     * available. Mirrors the iOS `clickIdProvider` seam. Default: none (a fresh
     * first-run install fires with no echo; the SEPARATE synthetic
     * `install_referrer` event carries the deterministic join regardless).
     */
    private val propsProvider: () -> Map<String, Any?> = { emptyMap() },
    private val appVersion: String = "unknown",
    private val appBuild: String = "unknown",
) {

    private val inProcessEmitted = AtomicBoolean(false)

    /** True iff the install signal has already been emitted (persisted). */
    fun hasEmitted(): Boolean = prefs.getBoolean(KEY_EMITTED, false)

    /**
     * Emit the canonical `app_install` signal IFF this is a fresh install (the
     * persisted once-flag is unset). Persists the flag BEFORE emitting so a
     * crash mid-emit cannot double-fire on the next launch — an install we never
     * recorded is a far better failure mode than a double-counted install
     * corrupting CPI.
     *
     * @return true if the install signal was emitted on THIS call, false if it
     *   had already been emitted (idempotent no-op).
     */
    fun markAndEmitIfFirstInstall(): Boolean {
        // In-process CAS first (cheap, closes the double-configure race within a
        // single process before touching prefs).
        if (!inProcessEmitted.compareAndSet(false, true)) return false
        if (prefs.getBoolean(KEY_EMITTED, false)) return false
        // Persist the once-flag BEFORE emitting (fire-once-at-MOST).
        prefs.edit().putBoolean(KEY_EMITTED, true).apply()

        val props = LinkedHashMap<String, Any?>(8)
        props["app_version"] = appVersion
        props["build_number"] = appBuild
        props["platform"] = "android"
        // Merge resolver/referrer-supplied echo + install_referrer payload. The
        // canonical wire keys (kixo_click_id / kixo_link_id / install_referrer)
        // are §0-FROZEN and supplied by the provider verbatim — never re-spelled.
        try {
            for ((k, v) in propsProvider()) {
                if (v != null) props[k] = v
            }
        } catch (_: Throwable) {
            // R6 — a buggy provider must never block the install signal.
        }

        onEvent(
            AttributionContract.INSTALL_EVENT_TYPE,
            AttributionContract.APP_INSTALL_EVENT_NAME,
            props,
        )
        return true
    }

    companion object {
        /** Persisted once-flag key. Sibling of the install-referrer prefs file. */
        const val KEY_EMITTED = "kixo_install_emitted"
    }
}
