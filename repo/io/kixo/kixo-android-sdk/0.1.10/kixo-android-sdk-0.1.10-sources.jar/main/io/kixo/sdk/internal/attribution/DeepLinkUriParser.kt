package io.kixo.sdk.internal.attribution

import android.net.Uri
import android.util.Log

/**
 * Parses a deep-link URI (an App-Link `https://my.kixo.cc/link/abc?kixo_link_id=…`
 * or a custom-scheme `myapp://…?kixo_link_id=…`) into the canonical §0 params
 * the warm-open / cold-start path needs.
 *
 * Distinct from [ReferrerParser] (which parses a Play referrer *query-string
 * fragment*); this handles a FULL URI (scheme + host + path + query). Keys
 * reference [AttributionContract] — never re-spelled inline.
 *
 * Uses `android.net.Uri` (the standard Android parser). In plain-JVM unit tests
 * `android.net.Uri` is stubbed to return-default-values, so [parse] falls back
 * to a hand-rolled query split when the platform parser yields nothing — the
 * fallback IS the unit-tested path; the platform path is exercised on-device.
 */
internal object DeepLinkUriParser {

    fun parse(uri: String?): ParsedReferrer {
        val raw = uri?.trim().orEmpty()
        if (raw.isEmpty()) return ReferrerParser.parse(null)

        // Try android.net.Uri first (on-device). Fall back to manual query
        // extraction (unit tests + any parse failure). Both yield an
        // already-decoded param map.
        val params = parseWithPlatform(raw) ?: parseQueryFallback(raw)

        // Reuse ReferrerParser's canonicalisation so the organic / linkId /
        // clickId / utm logic lives in ONE place.
        return ReferrerParser.canonicalise(rawReferrer = raw, params = params)
    }

    private fun parseWithPlatform(raw: String): Map<String, String>? = try {
        val u = Uri.parse(raw)
        val names = u.queryParameterNames
        if (names.isNullOrEmpty()) {
            null
        } else {
            val out = LinkedHashMap<String, String>()
            for (n in names) {
                u.getQueryParameter(n)?.let { out[n] = it }
            }
            if (out.isEmpty()) null else out
        }
    } catch (t: Throwable) {
        Log.d(TAG, "platform Uri parse failed; using fallback", t)
        null
    }

    /** Hand-rolled `?a=b&c=d` extraction (the unit-tested path). */
    private fun parseQueryFallback(raw: String): Map<String, String> {
        val q = raw.substringAfter('?', "")
        if (q.isEmpty()) return emptyMap()
        val out = LinkedHashMap<String, String>()
        for (pair in q.split("&")) {
            if (pair.isEmpty()) continue
            val eq = pair.indexOf('=')
            if (eq < 0) {
                out[decode(pair)] = ""
            } else {
                out[decode(pair.substring(0, eq))] = decode(pair.substring(eq + 1))
            }
        }
        return out
    }

    private fun decode(v: String): String = try {
        java.net.URLDecoder.decode(v, "UTF-8")
    } catch (_: Throwable) {
        v
    }

    /**
     * `deepLinkHosts` allow-list gate — the SINGLE implementation shared by the
     * cold-start [AppLinkHandler] and the direct [io.kixo.sdk.Kixo.handleDeepLink]
     * callers (host onNewIntent / push routing) so the accept/reject decision is
     * identical on every entry path (no second spelling).
     *
     * Empty [hosts] (the default) ⇒ accept ANY URI (we still only *attribute*
     * ones carrying a Kixo id; the window-open gate lives in `handleDeepLink`).
     * A non-empty set ⇒ the URI's HOST (for `http(s)`) OR its SCHEME (for a
     * custom scheme with no host, e.g. `myapp:/route`) must be in the set,
     * compared case-insensitively (DNS is case-insensitive; schemes per RFC 3986
     * are too). A malformed / un-parseable URI ⇒ `false` (NOT attributed —
     * a deep link we can't parse a host/scheme out of is not trusted). Never throws.
     */
    fun hostAllowed(uri: String, hosts: Set<String>): Boolean {
        if (hosts.isEmpty()) return true
        // Try android.net.Uri first (on-device); fall back to the pure-JVM parse
        // (unit tests where android.net.Uri is stubbed, or any parse failure).
        val (host, scheme) = parseHostScheme(uri)
        if (!host.isNullOrEmpty()) {
            return hosts.any { it.equals(host, ignoreCase = true) }
        }
        if (!scheme.isNullOrEmpty()) {
            return hosts.any { it.equals(scheme, ignoreCase = true) }
        }
        return false
    }

    /** Extract (host, scheme) from a URI, platform-first with a pure-JVM fallback. */
    private fun parseHostScheme(uri: String): Pair<String?, String?> {
        val viaPlatform = try {
            val u = Uri.parse(uri)
            val h = u.host
            val s = u.scheme
            if (h.isNullOrEmpty() && s.isNullOrEmpty()) null else (h to s)
        } catch (_: Throwable) {
            null
        }
        return viaPlatform ?: parseHostSchemeFallback(uri)
    }

    /**
     * Pure-JVM (host, scheme) extraction. Handles `scheme://host[:port]/path`,
     * `scheme://user@host/path`, and `scheme:/path` (no authority). Never throws.
     */
    private fun parseHostSchemeFallback(uri: String): Pair<String?, String?> {
        val schemeSep = uri.indexOf(':')
        if (schemeSep <= 0) return null to null
        val scheme = uri.substring(0, schemeSep)
        val rest = uri.substring(schemeSep + 1)
        if (rest.startsWith("//")) {
            val authority = rest.substring(2).substringBefore('/').substringBefore('?')
            val afterUserInfo = if (authority.contains('@')) authority.substringAfter('@') else authority
            val host = afterUserInfo.substringBefore(':')
            return (host.takeIf { it.isNotEmpty() }) to scheme
        }
        // No authority (custom scheme, no host).
        return null to scheme
    }

    private const val TAG = "Kixo.DeepLinkUri"
}
