package io.kixo.sdk

/**
 * A resolved deferred deep link, surfaced to the host via
 * [DeferredDeepLinkListener] exactly once on first run after the Play Install
 * Referrer resolves (deferred) OR when an App Link / custom-scheme intent is
 * handled (direct).
 *
 * The SDK does **NOT** navigate for you — the host owns routing. [targetUrl]
 * is BACKEND-VALIDATED to be same-app-scoped (the App's registered
 * `deepLinkScheme://…`, its universal-link host, or a relative path) before
 * it is surfaced, closing the open-redirect surface; the host should still
 * route it through its own navigation allow-list (B2B: the customer-controller
 * owns final navigation policy).
 *
 * Mirrors the iOS `KixoDeferredLink` shape for cross-platform parity.
 */
public data class KixoDeferredLink(
    /** The link's configured app target path (backend-validated), or `null`
     *  if the resolved target was not same-app-scoped / not present. */
    public val targetUrl: String?,
    /** `kixo_link_id` (CUID), or `null` for an organic / id-less open. */
    public val linkId: String?,
    /** `utm_campaign` / link campaign label. */
    public val campaign: String?,
    /** `utm_source` / media source. */
    public val source: String?,
    /** `utm_medium`. */
    public val medium: String?,
    /** All parsed query params (verbatim) for advanced host routing. */
    public val params: Map<String, String>,
    /** `true` when resolved via the Play Install Referrer (deferred); `false`
     *  for a direct/warm App-Link or custom-scheme open. */
    public val isDeferred: Boolean,
)

/**
 * Callback fired exactly once when a deferred deep link resolves on first run,
 * or immediately (with the cached result) if it already resolved before the
 * listener was registered.
 *
 * `fun interface` so Kotlin callers can pass a lambda and Java callers a
 * single-method instance.
 */
public fun interface DeferredDeepLinkListener {
    /**
     * @param link the resolved deferred deep link, or `null` if the install was
     *   organic / unattributed.
     */
    public fun onDeferredDeepLink(link: KixoDeferredLink?)
}
