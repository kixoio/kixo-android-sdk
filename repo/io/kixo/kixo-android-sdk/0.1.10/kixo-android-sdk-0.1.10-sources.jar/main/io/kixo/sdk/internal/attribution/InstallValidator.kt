package io.kixo.sdk.internal.attribution

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.atomic.AtomicReference

/**
 * Deterministic install-receipt validation (KIX-MMP-FRAUD-01) — the Android side.
 *
 * On first run, acquire a **Play Integrity** token and POST it to
 * `/api/sdk/install/validate`. The backend verifies the device-integrity verdict
 * + package, enforces single-use, and stamps the install `validated`
 * (anti-replay / anti-spoof).
 *
 * ### Honesty ceiling
 * A verified Play Integrity token proves the install is REAL (genuine binary on a
 * recognized device) — it does NOT prove the attribution SOURCE.
 *
 * ### Safety invariants
 *   - **Non-blocking:** runs on the queue's coroutine scope; NEVER delays/blocks
 *     event ingest or the existing Install Referrer flow. A failure is logged at
 *     debug and skipped.
 *   - **Opt-out:** honored — when [isOptedOut] is true nothing is acquired/sent.
 *   - **Graceful degradation:** the Play Integrity API (`com.google.android.play
 *     :integrity`) is an OPTIONAL host dependency. We acquire the token via
 *     reflection so the SDK builds + runs even when the host didn't add it; if
 *     the classes aren't present we record `unavailable` and skip (the backend
 *     fail-opens to `unvalidated`, never a fraud reject on absence).
 *   - **DEV routing:** the POST target uses [baseUrl] (already resolved with the
 *     hidden `kixo.internal.dev` switch) — no new switch surface.
 *   - **No PII:** the Play Integrity token is Google's signed blob; the only
 *     correlation key we send is the SDK's stable `install_id` (single-use scope).
 *
 *   - ⚠️ **SDK CONTRACT — install_id should be per-install (KIX-MMP-FRAUD-01
 *     follow-up):** the backend single-use claim is scoped to
 *     `(projectId, txnId, install_id)`. We currently pass the STABLE device id
 *     (`im.deviceId()` in Kixo.kt) as `install_id`, so a reinstall on the same
 *     device could collide with the first claim. The backend degrades safely (an
 *     EMPTY install_id skips the claim), but the CORRECT fix is to mint + persist a
 *     fresh per-install UUID and send THAT (TODO: a SharedPreferences install token,
 *     regenerated on every fresh install). Until then reinstall dedup on the same
 *     device is best-effort.
 */
internal class InstallValidator(
    private val context: Context,
    private val httpClient: OkHttpClient,
    private val scope: CoroutineScope,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val installId: String,
    private val cloudProjectNumber: Long?,
    /** Persisted once-flag store (the SDK passes the attribution prefs). */
    private val prefs: SharedPreferences? = null,
    private val isOptedOut: () -> Boolean,
    private val debug: Boolean,
    /** Injectable token acquirer (tests substitute a fake). Returns the Play
     *  Integrity token or null when unavailable. */
    private val tokenProvider: suspend (Context, Long?) -> String? = ::acquirePlayIntegrityToken,
) {
    /** Validation statuses (mirrors the iOS contract + the backend vocabulary). */
    enum class Status(val wire: String) {
        NOT_RUN("not_run"),
        DISABLED("disabled"),
        OPTED_OUT("opted_out"),
        UNAVAILABLE("unavailable"),
        VALIDATED("validated"),
        REPLAYED("replayed"),
        INVALID_SIG("invalid_sig"),
        WRONG_BUNDLE("wrong_bundle"),
        ABSENT("absent"),
        ERROR("error"),
    }

    private val statusRef = AtomicReference(Status.NOT_RUN)
    val lastStatus: Status get() = statusRef.get()

    /**
     * Kick off validation in the background. Returns immediately; the result is
     * recorded into [lastStatus]. Safe to call once during configure — never
     * blocks the caller.
     */
    fun validateInBackground() {
        if (isOptedOut()) {
            statusRef.set(Status.OPTED_OUT)
            return
        }
        // Once-flag: validate at most once per install (the receipt is single-use
        // server-side; a relaunch re-POST would needlessly read `replayed`).
        if (prefs?.getBoolean(KEY_VALIDATED_ONCE, false) == true) {
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val token = tokenProvider(context, cloudProjectNumber)
                if (token.isNullOrEmpty()) {
                    statusRef.set(Status.UNAVAILABLE)
                    if (debug) Log.d(TAG, "Play Integrity unavailable — skipping validation (fail-open).")
                    return@launch
                }
                post(token)
            } catch (t: Throwable) {
                statusRef.set(Status.ERROR)
                if (debug) Log.d(TAG, "install validation failed (non-fatal): ${t.message}")
            }
        }
    }

    private suspend fun post(token: String) {
        val payload = buildString {
            append("{")
            append("\"project_id\":").append(jsonStr(projectId)).append(",")
            append("\"api_key\":").append(jsonStr(apiKey)).append(",")
            append("\"platform\":\"android\",")
            append("\"install_id\":").append(jsonStr(installId)).append(",")
            append("\"device_id\":").append(jsonStr(installId)).append(",")
            append("\"bundle_id\":").append(jsonStr(context.packageName)).append(",")
            append("\"integrity_token\":").append(jsonStr(token))
            append("}")
        }
        val url = Endpoints.url(baseUrl, Endpoints.INSTALL_VALIDATE)
        val request = Request.Builder()
            .url(url)
            .post(payload.toRequestBody(JSON_MEDIA))
            .build()
        withContext(Dispatchers.IO) {
            try {
                httpClient.newCall(request).execute().use { resp ->
                    val bodyStr = resp.body?.string().orEmpty()
                    val status = parseStatus(bodyStr)
                    statusRef.set(status)
                    // A definitive backend verdict (anything but a transport
                    // error) means the install was recorded — burn the once-flag
                    // so relaunches don't re-POST. A transport error leaves the
                    // flag unset so the next launch retries.
                    if (status != Status.ERROR) {
                        prefs?.edit()?.putBoolean(KEY_VALIDATED_ONCE, true)?.apply()
                    }
                }
            } catch (e: IOException) {
                statusRef.set(Status.ERROR)
            }
        }
    }

    private fun parseStatus(body: String): Status {
        return try {
            val obj = Json.parseToJsonElement(body) as? JsonObject ?: return Status.ERROR
            val s = (obj["validation_status"] as? JsonPrimitive)?.contentOrNull ?: return Status.ERROR
            Status.entries.firstOrNull { it.wire == s } ?: Status.ERROR
        } catch (_: Throwable) {
            Status.ERROR
        }
    }

    companion object {
        private const val TAG = "Kixo"
        private const val KEY_VALIDATED_ONCE = "kixo_install_validated_once"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()

        private fun jsonStr(v: String): String =
            "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

        /**
         * Acquire a Play Integrity token via REFLECTION so the SDK doesn't hard-
         * depend on `com.google.android.play:integrity`. Returns null when the
         * API isn't on the classpath or the request fails (caller treats null as
         * `unavailable` → backend fail-open). Uses the classic IntegrityManager
         * (`IntegrityManagerFactory.create` → `requestIntegrityToken`).
         *
         * NOTE: a real production integration should use the STANDARD request
         * (warm-up + per-request) for lower latency; the classic request kept
         * here is the dependency-light path that works without a server warm-up
         * round-trip and is adequate for a one-shot first-run install proof.
         */
        suspend fun acquirePlayIntegrityToken(context: Context, cloudProjectNumber: Long?): String? {
            return try {
                val factoryClass = Class.forName(
                    "com.google.android.play.core.integrity.IntegrityManagerFactory",
                )
                val manager = factoryClass
                    .getMethod("create", Context::class.java)
                    .invoke(null, context.applicationContext)

                val requestBuilderClass = Class.forName(
                    "com.google.android.play.core.integrity.IntegrityTokenRequest\$Builder",
                )
                val builder = requestBuilderClass.getConstructor().newInstance()
                // setNonce(String) — a per-request nonce; use a fresh random value.
                val nonce = java.util.UUID.randomUUID().toString().replace("-", "")
                requestBuilderClass.getMethod("setNonce", String::class.java).invoke(builder, nonce)
                if (cloudProjectNumber != null) {
                    runCatching {
                        requestBuilderClass
                            .getMethod("setCloudProjectNumber", Long::class.javaPrimitiveType)
                            .invoke(builder, cloudProjectNumber)
                    }
                }
                val request = requestBuilderClass.getMethod("build").invoke(builder)

                val requestMethod = manager.javaClass.methods.firstOrNull {
                    it.name == "requestIntegrityToken"
                } ?: return null
                val task = requestMethod.invoke(manager, request) ?: return null

                // Await the Play Task<IntegrityTokenResponse> via Tasks.await(task).
                val tasksClass = Class.forName("com.google.android.gms.tasks.Tasks")
                val taskClass = Class.forName("com.google.android.gms.tasks.Task")
                val response = withContext(Dispatchers.IO) {
                    tasksClass.getMethod("await", taskClass).invoke(null, task)
                } ?: return null

                response.javaClass.getMethod("token").invoke(response) as? String
            } catch (_: Throwable) {
                // ClassNotFound (dependency absent) / any reflection / API failure
                // → null → caller records `unavailable` and skips (fail-open).
                null
            }
        }
    }
}
