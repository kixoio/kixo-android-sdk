package io.kixo.sdk.internal.crash

import android.content.Context
import android.os.Build
import android.os.Process
import android.util.Log
import io.kixo.sdk.internal.context.BreadcrumbTrail
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Crash auto-tracker. Mirrors
 * `kixo-ios-sdk/Sources/Kixo/AutoTrack/CrashTracker.swift` but adapted
 * to Android's exception model:
 *  - Android JVM crashes flow through
 *    [Thread.UncaughtExceptionHandler]. There is no NSException-style
 *    distinction between exceptions and signals on the JVM tier (NDK
 *    SIGSEGV crashes from native code DON'T flow through this handler
 *    — those would need a JNI signal handler installed via NDK, which
 *    is out of scope for this v1).
 *  - We CHAIN to the previous handler (must NOT replace) so any host-
 *    app crash reporter (Crashlytics, Sentry, Bugsnag) still gets the
 *    exception. iOS does the same with `previousExceptionHandler`.
 *
 * # Why a separate file (not an in-memory enqueue)?
 *
 * When the uncaught handler fires, the process is dying. We have:
 *  - no guarantee the SDK's coroutine scope can flush before death
 *  - no guarantee the SQLite event store hasn't already lost its
 *    `commit()` — the WAL might not be checkpointed yet
 *  - ~50ms of grace before Android kills the process
 *
 * The right shape is the iOS-proven one: write the crash details to
 * a SEPARATE small file synchronously (tiny payload, single
 * `FileOutputStream.fd.sync()`), then re-throw to the previous
 * handler. On the NEXT process start, an SDK initializer reads the
 * file, ingests it as a `KixoEvent(event_type=crash)` through the
 * normal queue, then deletes it. If the next start also crashes
 * before draining, the file persists — eventual delivery is
 * guaranteed.
 *
 * # Why JSON, not a binary format?
 *
 * The crash is small (single event, breadcrumbs, stack trace = ~5-20
 * KB). The encode is dirt cheap and the file is human-readable for
 * post-mortem debugging from `adb pull`. A binary format would buy
 * us nothing and complicate the cold-start ingest path.
 *
 * **Why kotlinx.serialization and not org.json**: same rationale as
 * [io.kixo.sdk.internal.identity.UserPropertyStore] — kotlinx is in
 * the dep list, works in JVM unit tests, no Android-stub-jar quirks.
 *
 * # Why fsync (`fd.sync()`) and not `flush()`?
 *
 * `OutputStream.flush()` only pushes the buffer down to the kernel
 * — the file might still be in the page cache when the process dies
 * and a power loss / OOM kill could lose it. `FileOutputStream.fd.sync()`
 * issues an `fsync(2)` which forces a disk-level commit. The
 * 5-10ms cost is acceptable inside a crash handler — we have ~50ms
 * before Android kills us.
 *
 * # Anti-crash discipline (briefing R6)
 *
 * Every error path in the crash handler ITSELF is swallowed:
 *  - If we fail to write the crash file, we log a warning and chain.
 *  - If we fail to read a previous-launch crash file, we log + delete.
 * A bug IN the crash handler must NEVER prevent the previous handler
 * from firing — that would silently disable the host's crash reporter.
 *
 * # File location
 *
 * `<filesDir>/kixo/pending-crash.json`. Survives uninstall (no — it
 * doesn't, but it does survive process death and app upgrades, which
 * is what we need). Same parent dir as the SQLite event store
 * (`<filesDir>/kixo/events.db`) so a developer poking around with
 * `run-as` finds everything in one place.
 */
internal object CrashTracker {

    private const val TAG = "Kixo"

    /** Subdirectory under `filesDir` — matches the storage convention. */
    private const val DIR_NAME = "kixo"

    /** File name. Single in-flight crash record at a time. */
    private const val FILE_NAME = "pending-crash.json"

    /** Idempotent install guard. */
    private val installed = AtomicBoolean(false)

    /**
     * The handler we displaced when [install] ran. Captured so we can
     * chain on top — the host's crash reporter still fires.
     *
     * Marked `Volatile` because [install] runs on whatever thread
     * called `Kixo.configure()`, and the chained crash callback runs
     * on the thread that crashed — those are different threads.
     */
    @Volatile
    private var previousHandler: Thread.UncaughtExceptionHandler? = null

    /** The directory where we write [FILE_NAME]. Captured at install. */
    @Volatile
    private var crashDir: File? = null

    /**
     * Encoder used for both the crash file write and the read-back
     * parse. Lenient so a future SDK version that adds new fields
     * doesn't break the cold-start ingest.
     */
    private val JSON = Json {
        encodeDefaults = true
        explicitNulls = true
        ignoreUnknownKeys = true
    }

    /**
     * Install the uncaught-exception handler. Idempotent.
     *
     * @param appContext Application context — used to resolve the
     *   `filesDir` for the pending-crash file. Application-scoped so
     *   we don't leak an Activity reference.
     * @param enqueueAnr Optional callback that routes a
     *   property map for an ANR event into the EventQueue (as
     *   `event_type=crash, event_name=anr`). When non-null, the
     *   companion [AnrWatchdog] is installed alongside the uncaught
     *   handler so main-thread freezes are also captured. When null
     *   (rare — only when `QueueWiring.build` itself failed, or in
     *   pre-Wave-5 callers) the watchdog is skipped; the JVM
     *   uncaught-handler still installs unchanged.
     * @param enqueueNativeCrash Optional callback that routes a
     *   property map for a NATIVE (C/C++) crash drained from a prior
     *   process into the EventQueue (as `event_type=crash,
     *   event_name=native_crash`). When non-null, [NativeCrashDrain]
     *   runs once at install on API 30+ and replays any
     *   [ApplicationExitInfo.REASON_CRASH_NATIVE] exits we haven't
     *   seen before. When null (same rare conditions as
     *   `enqueueAnr`) the drain is skipped. There is no LIVE
     *   companion here — catching a native SIGSEGV in flight would
     *   need a JNI signal handler, which is a separate workstream.
     *
     *   Why a lambda and not a queue handle: `CrashTracker` lives in
     *   `internal/crash/` and has no dependency on the queue
     *   package. Passing in the narrowest possible callable keeps
     *   the coupling one-way + minimal.
     */
    fun install(
        appContext: Context,
        enqueueAnr: ((Map<String, Any?>) -> Unit)? = null,
        enqueueNativeCrash: ((Map<String, Any?>) -> Unit)? = null,
    ) {
        if (!installed.compareAndSet(false, true)) return
        try {
            val dir = File(appContext.filesDir, DIR_NAME).apply { mkdirs() }
            crashDir = dir

            // CHAIN to the existing handler — must capture before
            // replacing or the host's crash reporter is silently
            // killed. Some hosts install Crashlytics from
            // Application.onCreate; we install AFTER configure() so
            // capture is safe.
            previousHandler = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
                handleUncaught(thread, throwable)
            }

            // Companion ANR watchdog — gates on the same install
            // success as the uncaught handler. R6: failure isolated
            // inside AnrWatchdog.install (its own try/catch), but we
            // wrap here too so even an OOM on construction can't
            // tear down CrashTracker's main install path.
            if (enqueueAnr != null) {
                try {
                    AnrWatchdog.install(appContext, enqueueAnr)
                } catch (t: Throwable) {
                    Log.w(TAG, "AnrWatchdog install failed; ANR detection disabled", t)
                }
            }

            // Companion native-crash drain — same R6 posture as the
            // ANR watchdog. No live half (yet), so this is just a
            // one-shot replay of ApplicationExitInfo entries from
            // prior processes. No-op on API < 30 (handled inside).
            if (enqueueNativeCrash != null) {
                try {
                    NativeCrashDrain.drainHistoricalNativeCrashes(appContext, enqueueNativeCrash)
                } catch (t: Throwable) {
                    Log.w(TAG, "NativeCrashDrain install failed; native-crash detection disabled", t)
                }
            }
        } catch (t: Throwable) {
            // R6: never crash the host on install failure.
            Log.w(TAG, "CrashTracker install failed; continuing without crash capture", t)
            installed.set(false)
        }
    }

    /**
     * The crash callback. Runs on the thread that crashed — typically
     * the main thread, but can be any thread that threw an unchecked
     * exception.
     *
     * Must always chain to [previousHandler] regardless of whether
     * our own write succeeded. Silently dropping a crash from the
     * host's reporter would be much worse than dropping our own.
     */
    private fun handleUncaught(thread: Thread, throwable: Throwable) {
        try {
            // Coverage fix (May 2026): honour
            // `data_collection.core.errors == false`. Default-allow on
            // pre-init / missing field. Reflective lookup keeps this
            // file free of a compile-time dep on the queue package
            // (CrashTracker lives in internal/crash/ which doesn't
            // import queue/ — same isolation as the PII filter
            // resolver below).
            if (errorsAllowedByDataCollection()) {
                writeCrashFile(thread, throwable)
            } else if (previousHandler != null) {
                // No-op crash capture but DO NOT swallow the chain —
                // the host's crash reporter must still fire even when
                // we're disabled. Handled by the finally below.
            }
        } catch (t: Throwable) {
            // Don't let a crash-handler bug suppress the host's chain.
            try {
                Log.w(TAG, "crash file write failed", t)
            } catch (_: Throwable) { /* logger itself failed; we tried */ }
        } finally {
            // CHAIN to the previous handler — host's crash reporter
            // (Crashlytics / Sentry / Bugsnag) still fires.
            val prev = previousHandler
            try {
                prev?.uncaughtException(thread, throwable)
            } catch (_: Throwable) {
                // Ultimate fallback — nothing we can do.
            }
        }
    }

    /**
     * Synchronously serialise the crash + breadcrumbs to the pending
     * crash file. Write + fsync MUST complete before we return; the
     * process will die immediately after.
     */
    private fun writeCrashFile(thread: Thread, throwable: Throwable) {
        val dir = crashDir ?: return
        val file = File(dir, FILE_NAME)

        val payload: JsonObject = buildJsonObject {
            put("event_id", UUID.randomUUID().toString())
            put("timestamp_ms", System.currentTimeMillis())
            put("event_type", "crash")
            put("event_name", throwable.javaClass.simpleName ?: "UnknownException")
            put("thread_name", thread.name ?: "unknown")
            put("thread_id", thread.id)
            put("process_id", Process.myPid())
            put("exception_class", throwable.javaClass.name)
            put("message", throwable.message ?: "")
            put("stack_trace", buildStackTrace(throwable))
            put("breadcrumbs", encodeBreadcrumbs())

            // Best-effort context — host-side enrichers will fold this
            // into the full Kixo event when the next process drains the file.
            put("os_version", Build.VERSION.RELEASE ?: "unknown")
            put("device_model", "${Build.MANUFACTURER} ${Build.MODEL}")
            put("api_level", Build.VERSION.SDK_INT)
        }

        // CRITICAL: write + fsync. Plain flush() leaves the file in
        // the page cache; the process dies in milliseconds and the
        // kernel never gets a chance to commit. fd.sync() forces an
        // fsync(2), which is the only reliable durability signal on
        // Android.
        FileOutputStream(file).use { fos ->
            fos.write(JSON.encodeToString(JsonElement.serializer(), payload).toByteArray(Charsets.UTF_8))
            fos.flush()
            try {
                fos.fd.sync()
            } catch (_: Throwable) {
                // Some filesystems (tmpfs in tests) don't support fsync.
                // The flush() above is the best we can do then.
            }
        }
    }

    private fun buildStackTrace(throwable: Throwable): String {
        val sb = StringBuilder(2048)
        var t: Throwable? = throwable
        var depth = 0
        while (t != null && depth < 8) {
            if (depth > 0) {
                sb.append("\nCaused by: ")
            }
            sb.append(t.javaClass.name)
            t.message?.let { sb.append(": ").append(it) }
            sb.append('\n')
            for (frame in t.stackTrace) {
                sb.append("  at ").append(frame.toString()).append('\n')
                // Cap per-frame to keep crash file bounded.
                if (sb.length > 16384) {
                    sb.append("  ... (truncated)\n")
                    return sb.toString()
                }
            }
            t = t.cause
            depth++
        }
        return sb.toString()
    }

    /**
     * Best-effort breadcrumb snapshot. The trail is a singleton so
     * we can read it directly. Failures fall through to an empty
     * array — the breadcrumbs are nice-to-have, never load-bearing.
     *
     * **PII filter (Critic 4 BLOCKER).** Customer-supplied breadcrumb
     * `data` arrives via [io.kixo.sdk.Kixo.addBreadcrumb] with no
     * sanitisation at the point of capture (we cannot afford regex on
     * every breadcrumb add). Crash assembly is the right place to
     * scrub: it runs at most once per process death, on a thread that
     * is already gated by fsync + handler-chain cost. We route every
     * `message` and every value of `data` through
     * [io.kixo.sdk.internal.privacy.PiiFilter.redact] before the
     * payload is serialised to disk → uploaded next-launch → ingested.
     *
     * **Why reflection, not a direct import.** CrashTracker has no
     * existing dependency on the privacy package; pulling PiiFilter
     * into the crash-handler classpath via reflection keeps the
     * coupling loose so a stripped-down build that excluded the
     * privacy module would still write a (slightly leakier) crash
     * file rather than failing to install the handler. If reflection
     * fails, we fall through to passing the raw values — best-effort
     * redaction is the contract documented on
     * [BreadcrumbTrail.add].
     */
    private fun encodeBreadcrumbs(): JsonArray {
        val redact = piiRedactor()
        return try {
            val crumbs = BreadcrumbTrail.snapshot()
            buildJsonArray {
                for (c in crumbs) {
                    addJsonObject {
                        put("timestamp_ms", c.timestamp.toEpochMilli())
                        put("category", c.category)
                        // Sanitise the message — customer-supplied
                        // strings can carry email/phone/SSN/JWT/etc.
                        put("message", redact(c.message))
                        put("level", c.level)
                        // The breadcrumb's data is already a JsonObject.
                        // Walk it and run redact() on every JsonPrimitive
                        // string value. Non-string primitives (numbers,
                        // booleans) are passed through unchanged. If the
                        // sanitised tree is identical, embed the
                        // original; otherwise embed the rewritten copy.
                        c.data?.let { put("data", sanitiseJsonObject(it, redact)) }
                    }
                }
            }
        } catch (_: Throwable) {
            JsonArray(emptyList())
        }
    }

    /**
     * Resolve a `(String) -> String` redaction callable from the
     * privacy package via reflection. Cached after first lookup so the
     * crash path doesn't pay the lookup cost more than once. Returns
     * the identity function if the privacy module is absent / the
     * reflection fails (best-effort contract).
     */
    @Volatile
    private var cachedRedactor: ((String) -> String)? = null

    private fun piiRedactor(): (String) -> String {
        cachedRedactor?.let { return it }
        val resolved: (String) -> String = try {
            val cls = Class.forName("io.kixo.sdk.internal.privacy.PiiFilter")
            val ctor = cls.getDeclaredConstructor(
                Class.forName("io.kixo.sdk.internal.privacy.EntityTagger"),
            )
            ctor.isAccessible = true
            // Pass null for the optional NER tagger — regex-only
            // redaction is fine here (no allocation of ML Kit models
            // inside a crash handler).
            val instance = ctor.newInstance(null as Any?)
            val redactMethod = cls.getMethod("redact", String::class.java)
            val fn: (String) -> String = { input ->
                try {
                    (redactMethod.invoke(instance, input) as? String) ?: input
                } catch (_: Throwable) {
                    input
                }
            }
            fn
        } catch (_: Throwable) {
            // Fall back to identity — better to ship a slightly
            // leakier crash than to crash the crash handler.
            { it }
        }
        cachedRedactor = resolved
        return resolved
    }

    /**
     * Walk a [JsonObject] and run [redact] over every nested string
     * primitive (recursing into nested objects + arrays). Returns the
     * input reference unchanged when no replacements happened, so the
     * common no-PII path stays zero-allocation past the recursion.
     */
    private fun sanitiseJsonObject(obj: JsonObject, redact: (String) -> String): JsonElement {
        return buildJsonObject {
            for ((k, v) in obj) {
                put(k, sanitiseJsonElement(v, redact))
            }
        }
    }

    private fun sanitiseJsonElement(el: JsonElement, redact: (String) -> String): JsonElement {
        return when (el) {
            is JsonObject -> sanitiseJsonObject(el, redact)
            is JsonArray -> JsonArray(el.map { sanitiseJsonElement(it, redact) })
            is JsonPrimitive -> if (el.isString) JsonPrimitive(redact(el.content)) else el
            else -> el
        }
    }

    /**
     * Coverage check for `data_collection.core.errors`. Default-allow
     * on pre-init / missing field so a stripped-down build that
     * doesn't reach /init still writes crash files.
     */
    private fun errorsAllowedByDataCollection(): Boolean {
        return try {
            io.kixo.sdk.internal.queue.DataCollectionHolder
                .isAllowed { it.core?.errors }
        } catch (_: Throwable) {
            true
        }
    }

    // ─── Pending-crash drain (called on next process start) ─────────

    /**
     * Read + delete the pending-crash file from a previous process.
     * Returns the parsed JSON (the caller — typically Agent 5's
     * `EventQueue` bootstrap — converts it to a `KixoEvent` and
     * enqueues it through the normal queue).
     *
     * Returns `null` when there's no pending crash. Returns `null`
     * on parse failure too — corrupted blobs are dropped silently
     * to keep the host crash-free at boot.
     */
    fun drainPendingCrash(appContext: Context): JsonObject? {
        return try {
            val dir = File(appContext.filesDir, DIR_NAME)
            val file = File(dir, FILE_NAME)
            if (!file.exists()) return null
            val raw = file.readText(Charsets.UTF_8)

            // ALWAYS delete the file, even on parse failure. A
            // permanently-stuck corrupt file would prevent every
            // future crash from being captured.
            try {
                file.delete()
            } catch (_: Throwable) { /* swallow */ }

            try {
                val element = JSON.parseToJsonElement(raw)
                element as? JsonObject
                    ?: run {
                        Log.w(TAG, "pending crash root element was not an object; dropped")
                        null
                    }
            } catch (e: Exception) {
                Log.w(TAG, "pending crash file parse failed; dropped", e)
                null
            }
        } catch (t: Throwable) {
            Log.w(TAG, "drainPendingCrash failed", t)
            null
        }
    }

    /**
     * Test-only — peek without deleting. Returns the file path if
     * present so a test can assert on its contents.
     */
    @androidx.annotation.VisibleForTesting
    fun pendingCrashFile(appContext: Context): File {
        val dir = File(appContext.filesDir, DIR_NAME).apply { mkdirs() }
        return File(dir, FILE_NAME)
    }

    /**
     * Test-only — reset install state so a fresh `install` re-wires
     * the handler chain. Production code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        synchronized(this) {
            installed.set(false)
            // Restore the previous handler so subsequent tests see a
            // clean slate. `null` is a valid value (no-handler).
            try {
                Thread.setDefaultUncaughtExceptionHandler(previousHandler)
            } catch (_: Throwable) { /* swallow */ }
            previousHandler = null
            crashDir = null
            // Watchdog rides on the same install lifecycle — tear
            // it down too so the next install() rewires cleanly.
            try {
                AnrWatchdog.resetForTesting()
            } catch (_: Throwable) { /* swallow */ }
        }
    }
}
