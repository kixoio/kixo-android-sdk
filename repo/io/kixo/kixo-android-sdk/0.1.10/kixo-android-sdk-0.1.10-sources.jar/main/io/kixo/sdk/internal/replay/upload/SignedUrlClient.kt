package io.kixo.sdk.internal.replay.upload

import android.util.Log
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume

/**
 * Talks to `/api/sdk/replay/{session/start, frames/sign,
 * session/end}`. Mirrors the iOS `SignedURLClient` (see iOS
 * `SignedURLClient.swift` for full rationale on why this exists
 * separately from [io.kixo.sdk.internal.transport.Transport]).
 *
 * **Why a dedicated client, not [io.kixo.sdk.internal.transport.Transport]:**
 *  - Replay's API surface is distinct enough — signed-URL leases +
 *    per-tap metadata batches, not the standard event-batch ack
 *    contract. Folding it into Transport would muddle two contracts.
 *  - The actual binary frame uploads (PUT to GCS) DO go through the
 *    shared OkHttpClient — but via [UploadWorker], not via this
 *    client. This file only handles the small JSON RPCs.
 *
 * **Auth:** project_id + api_key in the JSON body (no header), same
 * pattern as the rest of the api/sdk routes (see `Transport.postBatch`
 * which also sends Authorization header but the body fields are the
 * canonical source of truth — backend verifies body, header is
 * forward-compat).
 *
 * **Lease management:** [startSession] returns the first batch of
 * signed URLs (16 by default — 8 events × pre+post). When the local
 * pool drops below the threshold, [signMore] refills. URLs expire
 * 10 min after issue; expiring URLs are filtered out by [SignedUrlPool].
 *
 * **Failure semantics:** every method returns `null` on failure
 * (network or non-2xx). The pool will simply re-attempt on the next
 * trigger; replay is best-effort per briefing R6.
 */
internal class SignedUrlClient(
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val json: Json = Json { ignoreUnknownKeys = true; encodeDefaults = false },
) {

    // ─── DTOs ─────────────────────────────────────────────────

    /**
     * One signed URL keyed by `(seq, kind)`. Mirrors iOS
     * `SignedURLClient.SignedURL`. `expiresAt` is an ISO-8601 UTC
     * timestamp; the pool uses it to drop URLs that aged out before
     * the SDK got a chance to use them.
     *
     * **Wave 9 — `contentType` + `maxBytes`** are returned by the
     * backend's sign routes (alpha9+ servers) so the SDK PUTs with
     * the EXACT content-type the backend signed for. Without this
     * the V4 signature mismatches on every Android pre/post upload
     * (backend pre-Wave-9 hardcoded `image/heic` while Android
     * encodes JPEG → 4xx). Both fields are nullable — older
     * backends that don't echo them get the `FrameKind` enum
     * defaults via the [resolveContentType] helper.
     */
    @Serializable
    internal data class SignedUrl(
        @SerialName("seq") val seq: Long,
        @SerialName("kind") val kind: String,
        @SerialName("url") val url: String,
        @SerialName("expires_at") val expiresAt: String,
        @SerialName("gcs_path") val gcsPath: String,
        @SerialName("content_type") val contentType: String? = null,
        @SerialName("max_bytes") val maxBytes: Long? = null,
    )

    /**
     * Response from `/api/sdk/replay/session/start`. The
     * `metadata_only` flag is the daily-quota / plan-disabled
     * kill-switch — when `true`, the SDK ships ZERO frames (no PUTs
     * to GCS) but keeps shipping tap metadata. The dashboard player
     * renders these sessions in metadata-only mode.
     *
     * `metadataOnlyReason` is currently `"daily_quota"` /
     * `"plan_disabled"` / `"project_paused"` — surfaced on
     * [io.kixo.sdk.KixoDiagnostics] so a confused host engineer can
     * see why frames aren't uploading.
     *
     * The `framesRetainUntil` / `metadataRetainUntil` / `retainUntil`
     * trio is forward/backward-compat: older backends only return
     * `retain_until`; newer ones split the two retention tiers.
     * SDK doesn't act on these directly — they're echoed back into
     * diagnostics for support cases.
     */
    @Serializable
    internal data class SessionStartResponse(
        @SerialName("ok") val ok: Boolean = true,
        @SerialName("session_id") val sessionId: String,
        @SerialName("gcs_prefix") val gcsPrefix: String? = null,
        @SerialName("frames_retain_until") val framesRetainUntil: String? = null,
        @SerialName("metadata_retain_until") val metadataRetainUntil: String? = null,
        @SerialName("retain_until") val retainUntil: String? = null,
        @SerialName("metadata_only") val metadataOnly: Boolean = false,
        @SerialName("metadata_only_reason") val metadataOnlyReason: String? = null,
        @SerialName("signed_urls") val signedUrls: List<SignedUrl> = emptyList(),
    )

    @Serializable
    internal data class SignMoreResponse(
        @SerialName("ok") val ok: Boolean = true,
        @SerialName("signed_urls") val signedUrls: List<SignedUrl> = emptyList(),
    )

    @Serializable
    internal data class EndResponse(
        @SerialName("ok") val ok: Boolean = true,
        @SerialName("sealed") val sealed: Boolean = false,
        @SerialName("retain_until") val retainUntil: String? = null,
    )

    // ─── Request bodies (kept private to this client) ──────────

    @Serializable
    private data class SessionStartRequest(
        @SerialName("project_id") val projectId: String,
        @SerialName("api_key") val apiKey: String,
        @SerialName("session_id") val sessionId: String,
        @SerialName("installation_id") val installationId: String,
        @SerialName("user_id") val userId: String? = null,
        @SerialName("release_id") val releaseId: String,
        @SerialName("started_at") val startedAt: String,
        @SerialName("triggers") val triggers: List<String>,
        @SerialName("region") val region: String,
        @SerialName("initial_url_count") val initialUrlCount: Int,
        @SerialName("flags") val flags: Map<String, Boolean>? = null,
        // KIX-UNI-01 resume contract (v2, F6) — seq to pre-sign URLs
        // from when this start RESUMES a prior stint of the same
        // analytics session. The backend's resume signal is the KEY
        // BEING PRESENT (any value ≥ 0), NOT `> 0`: a zero-tap stint
        // resumes with watermark 0 and must still reopen the SEALED
        // row. Nullable default `null` + `encodeDefaults = false` →
        // omitted on fresh opens, SERIALIZED whenever explicitly set
        // — including 0.
        @SerialName("next_seq") val nextSeq: Long? = null,
        // `@EncodeDefault(ALWAYS)` — the SDK's Json instance has
        // `encodeDefaults = false` (matching the rest of the wire
        // contract) which would otherwise drop `"android"` and
        // hand the backend the historical iOS-default behavior.
        // Same lesson as Wave 6's `BatchPayload.platform` /
        // `InitRequest.platform` fixes: any field with a default
        // that the wire contract treats as required must be
        // `@EncodeDefault(ALWAYS)`.
        @EncodeDefault(EncodeDefault.Mode.ALWAYS)
        @SerialName("platform") val platform: String = "android",
    )

    @Serializable
    private data class SignMoreRequest(
        @SerialName("project_id") val projectId: String,
        @SerialName("api_key") val apiKey: String,
        @SerialName("session_id") val sessionId: String,
        @SerialName("from_seq") val fromSeq: Long,
        @SerialName("count") val count: Int,
        // Refill calls MUST send the same platform the session was
        // opened with so all URLs in the pool sign for the same
        // content-type.
        @EncodeDefault(EncodeDefault.Mode.ALWAYS)
        @SerialName("platform") val platform: String = "android",
    )

    @Serializable
    private data class EndSessionRequest(
        @SerialName("project_id") val projectId: String,
        @SerialName("api_key") val apiKey: String,
        @SerialName("session_id") val sessionId: String,
        @SerialName("ended_at") val endedAt: String,
        @SerialName("frame_count") val frameCount: Int,
        @SerialName("total_bytes") val totalBytes: Long,
        @SerialName("end_reason") val endReason: String,
        /**
         * Wave 14 #6 — frame-drop telemetry. Total PRE+POST frames
         * the SDK tried to ship but couldn't (encode busted cap,
         * sign-API outage, disk write failure). Always emitted
         * (default 0) so the backend can compute drop_rate =
         * frames_dropped / (frame_count + frames_dropped).
         */
        @SerialName("frames_dropped") val framesDropped: Int = 0,
        /**
         * Per-reason breakdown for [framesDropped]. Keys:
         * `encode_failed` / `pool_empty` / `staging_failed`.
         * Null when total is 0 (slim payload on healthy sessions).
         */
        @SerialName("drop_reasons") val dropReasons: Map<String, Int>? = null,
    )

    // ─── Endpoints ────────────────────────────────────────────

    /**
     * Open a new replay session and prime the signed-URL pool with
     * `initialUrlCount × 4` URLs (4 kinds per seq). Returns `null`
     * on network failure — caller's responsibility to back off and
     * retry, replay capture stays paused until then.
     */
    suspend fun startSession(
        sessionId: String,
        installationId: String,
        userId: String?,
        releaseId: String,
        startedAtIso: String,
        triggers: List<String>,
        region: String,
        initialUrlCount: Int = 8,
        flags: Map<String, Boolean>? = null,
        nextSeq: Long? = null,
    ): SessionStartResponse? {
        val body = SessionStartRequest(
            projectId = projectId,
            apiKey = apiKey,
            sessionId = sessionId,
            installationId = installationId,
            userId = userId,
            releaseId = releaseId,
            startedAt = startedAtIso,
            triggers = triggers,
            region = region,
            initialUrlCount = initialUrlCount,
            flags = flags,
            nextSeq = nextSeq,
        )
        return post(Endpoints.REPLAY_SESSION_START, json.encodeToString(SessionStartRequest.serializer(), body),
            SessionStartResponse.serializer())
    }

    /**
     * Top up the signed-URL pool starting at sequence number
     * [fromSeq]. The backend issues `count` × 4 URLs (one per
     * [FrameKind] per seq) by default.
     */
    suspend fun signMore(
        sessionId: String,
        fromSeq: Long,
        count: Int = 10,
    ): SignMoreResponse? {
        val body = SignMoreRequest(
            projectId = projectId,
            apiKey = apiKey,
            sessionId = sessionId,
            fromSeq = fromSeq,
            count = count,
        )
        return post(Endpoints.REPLAY_FRAMES_SIGN, json.encodeToString(SignMoreRequest.serializer(), body),
            SignMoreResponse.serializer())
    }

    /**
     * Seal the session. Backend marks the session as terminated
     * (no more frames accepted), records the totals, and starts the
     * server-side retention cron's clock.
     *
     * **endReason** values mirror iOS: `"foreground_to_background"`,
     * `"app_terminated"`, `"explicit_opt_out"`, `"timeout"`,
     * `"low_memory"`, `"abandoned_no_frames"`. Backend has a 30-min
     * idle-sweep cron that calls this server-side if the client
     * never gets a chance (process killed mid-session) — so this
     * call is best-effort and a `null` return is recoverable.
     */
    suspend fun endSession(
        sessionId: String,
        endedAtIso: String,
        frameCount: Int,
        totalBytes: Long,
        endReason: String,
        /** Wave 14 #6 — see [EndSessionRequest] kdoc. Defaults so
         * crash-recovery (which doesn't have access to the dead
         * process's counters) can omit them.
         */
        framesDropped: Int = 0,
        dropReasons: Map<String, Int>? = null,
    ): EndResponse? {
        val body = EndSessionRequest(
            projectId = projectId,
            apiKey = apiKey,
            sessionId = sessionId,
            endedAt = endedAtIso,
            frameCount = frameCount,
            totalBytes = totalBytes,
            endReason = endReason,
            framesDropped = framesDropped,
            dropReasons = dropReasons,
        )
        return post(Endpoints.REPLAY_SESSION_END, json.encodeToString(EndSessionRequest.serializer(), body),
            EndResponse.serializer())
    }

    // ─── Internals ────────────────────────────────────────────

    private suspend fun <T> post(
        path: String,
        bodyJson: String,
        deserializer: kotlinx.serialization.DeserializationStrategy<T>,
    ): T? = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url(Endpoints.url(baseUrl, path))
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json; charset=utf-8")
            .build()

        val response: Response = try {
            executeAsync(httpClient.newCall(req))
        } catch (e: IOException) {
            // Transient network error — the pool will retry on its
            // next trigger. We don't burn a log line here because
            // sustained-offline sessions would spam logcat.
            return@withContext null
        } catch (t: Throwable) {
            Log.w(TAG, "POST $path failed unexpectedly", t)
            return@withContext null
        }

        response.use { resp ->
            if (!resp.isSuccessful) {
                if (resp.code in 400..499 && resp.code != 429) {
                    // Permanent — log loudly so a misconfigured
                    // project_id surfaces in dev logs immediately.
                    Log.w(TAG, "POST $path returned ${resp.code} (permanent)")
                }
                return@withContext null
            }
            val text = resp.body?.string().orEmpty()
            if (text.isBlank()) return@withContext null
            try {
                json.decodeFromString(deserializer, text)
            } catch (t: Throwable) {
                Log.w(TAG, "POST $path response decode failed", t)
                null
            }
        }
    }

    /**
     * Adapter from OkHttp's [Call.enqueue] callback to a coroutine.
     * Cancelling the surrounding scope cancels the [Call] so that
     * `withTimeout` actually frees the socket. Throws on failure.
     * (Same pattern as `Transport.executeAsync`, intentionally
     * duplicated to keep this client zero-coupled to Transport
     * internals — Transport could theoretically swap to e.g. ktor
     * without breaking us.)
     */
    private suspend fun executeAsync(call: Call): Response =
        suspendCancellableCoroutine { cont ->
            cont.invokeOnCancellation {
                runCatching { call.cancel() }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWith(Result.failure(e))
                }
                override fun onResponse(call: Call, response: Response) {
                    if (cont.isActive) cont.resume(response)
                }
            })
        }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val TAG = "Kixo.SignedUrlClient"
    }
}
