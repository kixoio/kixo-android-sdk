package io.kixo.sdk.internal.attribution

import android.util.Log
import io.kixo.sdk.BuildConfig
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * Deferred-attribution resolver (BLOCKER-B resolution, KIX-DL Wave 2).
 *
 * **What changed + why.** The old `ReferrerPoster` POSTed the Play referrer to
 * `/api/sdk/attribution/referrer` — a route that NEVER existed on the backend
 * (every POST 404'd → terminal → deferred deep-linking was 100% dark on
 * Android). Per the judge's resolution, the deferred deep link is now resolved
 * via the SAME `/api/sdk/link/resolve` endpoint iOS uses, and the Play Install
 * Referrer ENRICHMENT (utm_* + click-injection ordering timestamps) is emitted
 * as a SYNTHETIC `install_referrer` event into `/api/sdk/batch` (the path the
 * backend `processReferrerEvents` already consumes). Both wire surfaces use the
 * FROZEN [AttributionContract] keys, so writer + reader agree byte-for-byte.
 *
 * This class owns the RESOLVE call (the retry-state-bearing half). The synthetic
 * batch event is emitted via the injected [eventEmitter] (fire-and-forget into
 * the queue) so it inherits the same identity/PII/transport path as every other
 * event.
 *
 * Tri-state outcome (drives the controller's POST-retry state machine, §3.2.1):
 *   - [Result.Acked]    — the resolve call returned 2xx. Carries the parsed
 *                         resolved link (null for organic / unresolved).
 *   - [Result.Terminal] — 4xx (auth/validation). DO NOT retry.
 *   - [Result.Retryable]— 5xx / 429 / network. Re-resolve next launch.
 *
 * The HTTP call is delegated to a [Sender] so unit tests substitute a fake.
 */
internal class ReferrerPoster(
    private val sender: Sender,
    /**
     * Emits the synthetic `install_referrer` event into the event queue
     * (→ /api/sdk/batch). Fire-and-forget; default is a no-op so tests that only
     * exercise the resolve tri-state don't need a queue. The controller wires
     * the real queue emitter.
     */
    private val eventEmitter: (eventType: String, eventName: String, properties: Map<String, Any?>) -> Unit =
        { _, _, _ -> },
) {

    /** Identity + project context the resolve needs (snapshotted by the caller). */
    data class Context(
        val baseUrl: String,
        val projectId: String,
        val apiKey: String,
        val deviceId: String,
        val anonymousId: String,
        val userId: String?,
        val packageName: String,
        val releaseId: String?,
    )

    sealed class Result {
        /** Backend resolved (or organically declined to resolve) the install.
         *  [deferredLink] is the resolved same-app target (null for organic /
         *  unresolved). */
        data class Acked(val deferredLink: ResolvedDeferredLink?) : Result()

        /** 4xx — terminal, do not retry. */
        data class Terminal(val code: Int) : Result()

        /** 5xx / 429 / network — retry next launch. */
        data class Retryable(val reason: String) : Result()
    }

    /** The resolved link parsed off a 2xx `/api/sdk/link/resolve` response. */
    data class ResolvedDeferredLink(
        val targetUrl: String?,
        val linkId: String?,
        val campaign: String?,
        val source: String?,
        val medium: String?,
        val params: Map<String, String>,
    )

    /** Injection seam for the network call. Returns the raw HTTP outcome. */
    fun interface Sender {
        /** @return [HttpOutcome] — never throws. */
        fun send(url: String, body: String, apiKey: String, sdkVersion: String): HttpOutcome
    }

    sealed class HttpOutcome {
        data class Ok(val responseBody: String) : HttpOutcome()
        data class Http(val code: Int) : HttpOutcome()
        data class Network(val reason: String) : HttpOutcome()
    }

    /**
     * (1) Emit the synthetic `install_referrer` enrichment event into the batch
     * queue, then (2) resolve the deferred link via `/api/sdk/link/resolve`.
     *
     * The synthetic event is emitted UNCONDITIONALLY on a successful read (so
     * the backend gets the utm_* + click-injection ordering inputs for organic
     * AND deterministic installs). The resolve call only fires when the referrer
     * carried a `kixo_click_id`/`kxc` — an organic install has nothing to claim,
     * so it short-circuits to `Acked(null)` after emitting the event.
     */
    fun post(ctx: Context, snapshot: ReferrerSnapshot, parsed: ParsedReferrer): Result {
        // (1) Synthetic enrichment event → /api/sdk/batch. Fire-and-forget; a
        //     failure here must never affect the resolve retry state.
        try {
            eventEmitter(
                AttributionContract.REFERRER_EVENT_TYPE,
                AttributionContract.REFERRER_EVENT_NAME,
                buildReferrerEventProperties(snapshot, parsed),
            )
        } catch (t: Throwable) {
            Log.w(TAG, "synthetic install_referrer emit threw (swallowed)", t)
        }

        // (2) Resolve. Organic (no click_id) → nothing to claim deterministically.
        val clickId = parsed.clickId
        if (clickId.isNullOrBlank()) {
            return Result.Acked(null)
        }

        val body = buildResolveBody(ctx, clickId)
        val url = Endpoints.url(ctx.baseUrl, Endpoints.LINK_RESOLVE)
        val outcome = try {
            sender.send(url, body, ctx.apiKey, SDK_VERSION)
        } catch (t: Throwable) {
            // Defensive — Sender contract says "never throws", but R6.
            Log.w(TAG, "resolve sender threw", t)
            return Result.Retryable("sender_threw")
        }
        return when (outcome) {
            is HttpOutcome.Ok -> Result.Acked(parseResolvedLink(outcome.responseBody, parsed))
            is HttpOutcome.Http -> {
                val code = outcome.code
                when {
                    code in 400..499 && code != 429 -> Result.Terminal(code)
                    // 429 + 5xx + anything else non-2xx → retry.
                    else -> Result.Retryable("http_$code")
                }
            }
            is HttpOutcome.Network -> Result.Retryable(outcome.reason)
        }
    }

    /**
     * Build the synthetic `install_referrer` event's `properties` using the
     * FROZEN [AttributionContract.REFERRER_PROP_*] keys — the SAME spelling the
     * backend `referrer-post-processor.ts::parsePlaintextReferrer` reads (the
     * BLOCKER-B(c) byte-alignment). Carries ONLY the four public ReferrerDetails
     * fields (§0 §15 — NO server-seconds) + the install version. The click_id is
     * NOT a property here — it round-trips via the resolve POST body + the
     * canonical install event echo.
     */
    private fun buildReferrerEventProperties(
        s: ReferrerSnapshot,
        parsed: ParsedReferrer,
    ): Map<String, Any?> {
        val props = LinkedHashMap<String, Any?>(8)
        props[AttributionContract.REFERRER_PROP_REFERRER_URL] = s.referrerUrl
        props[AttributionContract.REFERRER_PROP_REFERRER_CLICK_TS] = s.clickTsSeconds
        props[AttributionContract.REFERRER_PROP_INSTALL_BEGIN_TS] = s.installBeginTsSeconds
        if (s.installVersion != null) {
            props[AttributionContract.REFERRER_PROP_INSTALL_VERSION] = s.installVersion
        }
        props[AttributionContract.REFERRER_PROP_GOOGLE_PLAY_INSTANT] = s.googlePlayInstantParam
        // Carry the canonical link/click ids when present so the backend can
        // join the enrichment touch to the click record (organic omits them).
        parsed.linkId?.let { props[AttributionContract.KIXO_LINK_ID_KEY] = it }
        parsed.clickId?.let { props[AttributionContract.KIXO_CLICK_ID_KEY] = it }
        return props
    }

    /**
     * Build the `/api/sdk/link/resolve` request JSON. Mirrors the iOS resolve
     * body: `{project_id, api_key, kixo_click_id}`. The click-id key is the
     * FROZEN [AttributionContract.KIXO_CLICK_ID_KEY] (NEVER re-spelled).
     */
    private fun buildResolveBody(ctx: Context, clickId: String): String {
        val sb = StringBuilder(160)
        sb.append('{')
        field(sb, "project_id", ctx.projectId); sb.append(',')
        field(sb, "api_key", ctx.apiKey); sb.append(',')
        field(sb, AttributionContract.KIXO_CLICK_ID_KEY, clickId)
        sb.append('}')
        return sb.toString()
    }

    private fun field(sb: StringBuilder, k: String, v: String) {
        sb.append('"').append(k).append("\":").append(jsonStr(v))
    }

    /**
     * Parse the `/api/sdk/link/resolve` 2xx response into a [ResolvedDeferredLink].
     * The resolve shape is `{success, resolved, link:{id,target_path,data},
     * media_source, campaign, match_method, ...}`. Returns null when
     * `resolved=false` (organic / forged / already-consumed) so the listener
     * fires `null`. Never throws (malformed → treat as unresolved).
     */
    private fun parseResolvedLink(
        responseBody: String,
        parsed: ParsedReferrer,
    ): ResolvedDeferredLink? {
        if (responseBody.isBlank()) return null
        return try {
            val root = JSON.parseToJsonElement(responseBody) as? JsonObject ?: return null
            val resolved = (root["resolved"] as? JsonPrimitive)?.booleanOrNull ?: false
            if (!resolved) return null
            val link = root["link"] as? JsonObject
            ResolvedDeferredLink(
                // The resolve endpoint returns the in-app destination as
                // `link.target_path`; surface it as the host-navigable target.
                targetUrl = link?.str("target_path"),
                linkId = link?.str("id") ?: parsed.linkId,
                campaign = root.str("campaign") ?: parsed.campaign,
                source = root.str("media_source") ?: parsed.source,
                medium = parsed.medium,
                params = parsed.params,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "resolve response parse failed; treating as unresolved", t)
            null
        }
    }

    private fun JsonObject.str(key: String): String? =
        (this[key] as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() && it != "null" }

    companion object {
        private const val TAG = "Kixo.ReferrerPoster"
        private val SDK_VERSION: String = runCatching { BuildConfig.SDK_VERSION }.getOrDefault("")
        private val JSON = Json { ignoreUnknownKeys = true; isLenient = true }

        private fun jsonStr(v: String): String {
            val sb = StringBuilder(v.length + 2)
            sb.append('"')
            for (c in v) {
                when (c) {
                    '"' -> sb.append("\\\"")
                    '\\' -> sb.append("\\\\")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
                }
            }
            sb.append('"')
            return sb.toString()
        }

        /**
         * The real OkHttp-backed [Sender]. Synchronous (blocking) — the
         * controller runs it on a background dispatcher, never the main thread.
         * Sends the SDK version in `X-Kixo-Sdk-Version`. UA stays `okhttp/4.12.0`.
         */
        fun okHttpSender(httpClient: OkHttpClient): Sender = Sender { url, body, apiKey, sdkVersion ->
            val request = Request.Builder()
                .url(url)
                .post(body.toRequestBody(JSON_MEDIA_TYPE))
                .header("Authorization", "Bearer $apiKey")
                .header("Content-Type", "application/json; charset=utf-8")
                .header("X-Kixo-Sdk-Version", sdkVersion)
                .build()
            try {
                httpClient.newCall(request).execute().use { resp ->
                    if (resp.isSuccessful) {
                        HttpOutcome.Ok(resp.body?.string().orEmpty())
                    } else {
                        HttpOutcome.Http(resp.code)
                    }
                }
            } catch (e: IOException) {
                HttpOutcome.Network(e.message ?: "io_error")
            } catch (t: Throwable) {
                HttpOutcome.Network(t.message ?: "unknown")
            }
        }

        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
