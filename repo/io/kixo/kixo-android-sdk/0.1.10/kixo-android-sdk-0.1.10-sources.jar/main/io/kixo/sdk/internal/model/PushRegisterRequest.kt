package io.kixo.sdk.internal.model

import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Request body for `POST /api/sdk/push/register`.
 *
 * **The ONLY place a plaintext push token leaves the device.** Per
 * AGENT_BRIEFING.md R10 + the iOS-parity contract: every other event
 * carrying a token-derived field uses SHA-256(token); the raw
 * `token` field below is the single exception, intentional, and
 * routes only to this endpoint (which itself stores the token
 * encrypted at rest server-side for delivery).
 *
 * **Wave 6 lesson** (`@EncodeDefault(ALWAYS)` on `platform`): the
 * SDK's Json instance is configured with `encodeDefaults = false`
 * to keep batches small. Without the explicit encode-default
 * directive, the `platform = "android"` default value gets dropped
 * from the wire. Backend then 400's because `platform` is required.
 * Same defensive pattern applied here as in [InitRequest] +
 * [BatchPayload].
 *
 * Wire shape (snake_case, matches `kixo-backend/apps/web/src/app/api/sdk/push/register/route.ts`):
 * ```json
 * {
 *   "project_id":  "kx_proj_…",
 *   "api_key":     "kx_key_…",
 *   "device_id":   "uuid",
 *   "user_id":     "alex@example.com" | null,
 *   "token":       "<plaintext FCM/APNs token>",
 *   "platform":    "android",
 *   "release_id":  "<from /api/sdk/init>" | "",
 *   "bundle_id":   "com.example.myapp",
 *   "environment": "production",
 *   "sdk_version": "0.1.0"
 * }
 * ```
 *
 * **App-approval gate identity (2026-06-28).** The backend pauses
 * `push/register` for an unrecognised app — a token may only be stored
 * once the caller resolves an APPROVED + active app for this project
 * (see `register/route.ts` `gateResolved` arms + the fail-closed final
 * `app_identity_required` branch). The gate resolves an app from, in
 * order: `app_id` → `release_id` (cross-checked against the
 * `{platform, bundle_id}` envelope via `appMatchesEnvelope`) →
 * `registerSdkApp({platform: body.platform, bundleId: body.bundle_id})`.
 * So this request now ships `release_id` + `bundle_id` (+ top-level
 * `platform`, already present) so a standalone push-token register
 * isn't paused. `environment` + `sdk_version` ride along as detection
 * metadata for `registerSdkApp` (`lastDetectedEnvironment` /
 * `lastDetectedSdkVersion`). Mirrors the iOS commit `b31c7a1`
 * (`platform:"ios"`, `bundle_id`, `release_id`, `environment`,
 * `sdk_version`). Android has no stored `app_id` (only `release_id` is
 * stamped into `ConfigHolder` from `/api/sdk/init`), so `app_id` is
 * intentionally omitted — `release_id`/`bundle_id` cover the gate.
 */
@OptIn(ExperimentalSerializationApi::class)
@Serializable
internal data class PushRegisterRequest(
    @SerialName("project_id")
    val projectId: String,

    @SerialName("api_key")
    val apiKey: String,

    @SerialName("device_id")
    val deviceId: String,

    @SerialName("user_id")
    val userId: String? = null,

    /**
     * Plaintext push token. Bearer-class secret — DO NOT log, DO NOT
     * stash in any [KixoEvent], DO NOT include in any other endpoint's
     * payload. The endpoint stores it encrypted server-side.
     */
    @SerialName("token")
    val token: String,

    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("platform")
    val platform: String = "android",

    /**
     * Resolved `release_id` from `/api/sdk/init` (empty string until
     * the first init response lands). The backend's `else if
     * (body.release_id)` arm treats an empty string as falsy (matches
     * `/batch` + `/replay`) and falls through to the `bundle_id`
     * envelope, so an empty value is safe — never a `release_not_found`
     * pause. `@EncodeDefault(ALWAYS)` because the SDK's Json instance
     * runs `encodeDefaults = false`.
     */
    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("release_id")
    val releaseId: String = "",

    /**
     * App package name (`context.packageName`). The backend builds the
     * approval envelope from `{platform, bundle_id}` and self-registers
     * the app on first sight, so this is what unblocks a brand-new
     * project's first push register. `@EncodeDefault(ALWAYS)` for the
     * same `encodeDefaults = false` reason.
     */
    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("bundle_id")
    val bundleId: String = "",

    /**
     * `"development" | "staging" | "production"`. Detection metadata
     * stored on the App row (`lastDetectedEnvironment`) by
     * `registerSdkApp`.
     */
    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("environment")
    val environment: String = "production",

    /** This SDK module's version (`BuildConfig.SDK_VERSION`). */
    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("sdk_version")
    val sdkVersion: String = "",
)
