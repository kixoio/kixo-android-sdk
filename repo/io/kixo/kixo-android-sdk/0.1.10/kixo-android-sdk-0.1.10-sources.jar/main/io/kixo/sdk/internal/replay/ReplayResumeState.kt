package io.kixo.sdk.internal.replay

/**
 * In-memory, process-lifetime resume state for replay stints
 * (Wave 1, KIX-UNI-01 cross-SDK contract — mirrors iOS).
 *
 * **The problem:** replay sessions end on every stint boundary
 * (app background / server pause) while the ANALYTICS session
 * survives backgrounds shorter than the session timeout (~30 s). One
 * analytics session therefore spans N replay "stints" sharing ONE
 * `session_id`. Naively restarting `seq` at 0 per stint collides:
 * GCS frame objects (`<seq>_<kind>` under one gcs_prefix) get
 * overwritten and the backend receives duplicate `(session_id, seq)`
 * rows.
 *
 * **The contract (v2, F6):** when a stint opens with the SAME session
 * id as the last ended stint, the SDK continues the seq counter from
 * where it left off AND ALWAYS sends `next_seq` in the `session/start`
 * body — INCLUDING 0 (a zero-tap stint still has a watermark of 0) —
 * so the backend reopens the SEALED row and pre-signs URLs starting
 * there. The resume signal is the KEY BEING PRESENT, not its value:
 * a different (or absent) session id opens fresh (`seq` from 0,
 * `next_seq` omitted entirely). [resumeSeqFor]/[onStintOpen] therefore
 * return `null` for "fresh" vs a non-null watermark (possibly 0) for
 * "resume" — the two must never be conflated on the wire.
 *
 * **Split ownership on Android:** the seq counter is minted by
 * [ReplayController] but the session id sent on the wire is minted
 * by the uploader adapter's `sessionIdProvider` at `beginSession`
 * time. This object is the shared, lock-free meeting point:
 *  - the adapter records the stint's session id via [onStintOpen]
 *    and gets back the seq to resume from;
 *  - the controller seeds its counter from [resumeSeqFor] BEFORE the
 *    stint can capture, and saves the counter via [onStintEnd]
 *    BEFORE resetting it in `stop()`.
 *
 * The controller and adapter read the session id independently
 * (microseconds apart). If the analytics session rolls inside that
 * window the controller may seed a non-zero counter for a stint the
 * adapter opens fresh — seqs then start above 0 under a brand-new
 * session id, which wastes a few pre-signed URLs but can never
 * collide. The reverse skew (fresh counter, resumed start body) is
 * impossible: session ids never roll back to a previous value.
 *
 * Deliberately NOT persisted — a process kill ends both the
 * analytics session and the resume window (same as iOS).
 */
internal object ReplayResumeState {

    /** Session id of the stint currently/last opened via [onStintOpen]. */
    @Volatile
    private var openSessionId: String? = null

    /** Session id of the last ENDED stint. */
    @Volatile
    private var lastSessionId: String? = null

    /** Continued seq counter of the last ENDED stint. */
    @Volatile
    private var lastNextSeq: Long = 0L

    /** Session id the cumulative stint totals below belong to (F11). */
    @Volatile
    private var totalsSessionId: String? = null

    /** Cumulative frames staged across all ended stints of [totalsSessionId]. */
    @Volatile
    private var totalsFrameCount: Int = 0

    /** Cumulative bytes staged across all ended stints of [totalsSessionId]. */
    @Volatile
    private var totalsBytes: Long = 0L

    /**
     * Cumulative `/session/end` counters carried across stints of one
     * session id (F11 — the end route absolute-overwrites, so each
     * stint must report session-cumulative totals, not stint-local).
     */
    internal data class StintTotals(val frameCount: Int, val totalBytes: Long)

    /**
     * Seq to resume from when a stint opens with [sessionId]:
     * the saved counter (possibly 0 — F6) when it matches the last
     * ended stint's id, `null` (fresh) otherwise. `null` vs `0` is
     * load-bearing: `null` omits `next_seq` from the wire body, `0`
     * serializes it so the backend reopens the SEALED row.
     */
    fun resumeSeqFor(sessionId: String?): Long? {
        if (sessionId == null) return null
        return if (sessionId == lastSessionId) lastNextSeq else null
    }

    /**
     * Record that a stint is opening with [sessionId] and return the
     * seq it must resume from (`null` = fresh). Called by the uploader
     * adapter right before `session/start` so the same value lands
     * in the request's `next_seq` (omitted when `null`).
     */
    fun onStintOpen(sessionId: String): Long? {
        val resume = resumeSeqFor(sessionId)
        openSessionId = sessionId
        return resume
    }

    /**
     * Save the ending stint's continued seq counter, paired with the
     * session id recorded at [onStintOpen]. No-op when no stint was
     * ever opened. `maxOf` guards against a shrunk counter when the
     * same session resumes repeatedly.
     */
    fun onStintEnd(nextSeq: Long) {
        val sid = openSessionId ?: return
        lastNextSeq = if (sid == lastSessionId) maxOf(lastNextSeq, nextSeq) else nextSeq
        lastSessionId = sid
    }

    /**
     * Cumulative totals to carry into a RESUMED stint of [sessionId]
     * (F11). Zero for any other session id — a fresh stint starts its
     * counters at 0.
     */
    fun carriedTotalsFor(sessionId: String): StintTotals =
        if (sessionId == totalsSessionId) StintTotals(totalsFrameCount, totalsBytes)
        else StintTotals(0, 0L)

    /**
     * Save the session-cumulative `/session/end` counters for
     * [sessionId] (F11). Called by the lifecycle at stint close with
     * `carried + staged-this-stint` so the NEXT stint of the same
     * session id can keep accumulating; overwritten wholesale on a
     * session roll (the old carry is unreachable by design).
     */
    fun onStintTotals(sessionId: String, frameCount: Int, totalBytes: Long) {
        totalsSessionId = sessionId
        totalsFrameCount = frameCount
        totalsBytes = totalBytes
    }

    /** Test seam — production code never calls this. */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        openSessionId = null
        lastSessionId = null
        lastNextSeq = 0L
        totalsSessionId = null
        totalsFrameCount = 0
        totalsBytes = 0L
    }
}
