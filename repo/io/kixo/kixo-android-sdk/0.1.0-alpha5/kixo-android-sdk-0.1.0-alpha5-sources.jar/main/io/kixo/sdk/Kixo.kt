@file:JvmName("Kixo")

package io.kixo.sdk

import android.content.Context
import android.util.Log
import io.kixo.sdk.internal.context.BreadcrumbTrail
import io.kixo.sdk.internal.crash.CrashTracker
import io.kixo.sdk.internal.goal.GoalEventSink
import io.kixo.sdk.internal.goal.GoalMarker
import io.kixo.sdk.internal.identity.IdentityManager
import io.kixo.sdk.internal.identity.SuperPropertyStore
import io.kixo.sdk.internal.identity.UserPropertyStore
import io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap
import io.kixo.sdk.internal.lifecycle.LifecycleEvent
import io.kixo.sdk.internal.lifecycle.LifecycleEventBus
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.privacy.ConsentManager
import io.kixo.sdk.internal.push.EventQueueBridge
import io.kixo.sdk.internal.push.IdentityDedupBridge
import io.kixo.sdk.internal.push.PushBridges
import io.kixo.sdk.internal.push.PushTracker
import io.kixo.sdk.internal.push.PushTransportBridge
import io.kixo.sdk.internal.replay.ReplayController
import kotlinx.serialization.json.JsonObject
import java.util.ArrayDeque
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Public facade — the Kixo Android SDK's only entry point. Every
 * customer-facing call goes through this `object`.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Kixo.swift`. iOS uses a
 * `final class` with a `static let shared` property; Kotlin `object`
 * is the idiomatic equivalent and keeps single-instance discipline
 * a compile-time invariant.
 *
 * **Design rationale (why this is a facade, not the actual SDK):**
 * Kixo's internals are 14+ subsystems (queue, transport, identity,
 * push, replay, …) owned by separate teams. Each lives behind a
 * narrow `internal` API. This facade does NOT contain SDK logic —
 * it does idempotency gating, the pre-configure ring buffer, and
 * fan-out to the internal singletons. Adding a new public method
 * costs ~10 lines here and is critic-blocked from leaking
 * complexity into the public surface.
 *
 * **Thread safety:** every public method is safe to call from any
 * thread. The internal subsystems are themselves thread-safe (each
 * agent's contract). Where ordering matters (e.g. `configure → track`
 * in the same thread), we rely on the host using the SDK normally,
 * but we don't crash on weird call orders — early calls buffer.
 *
 * **Pre-configure buffer:** `track`/`identify`/`screen`/etc. called
 * BEFORE [configure] do NOT crash and do NOT silently no-op. They
 * land in a small bounded ring buffer ([PRE_CONFIG_BUFFER_CAP] = 50)
 * and replay onto the queue when [configure] finally lands. This
 * matters because customer code often calls `Kixo.identify(userId)`
 * from a global auth singleton that initialises before
 * `Application.onCreate` finishes the SDK setup.
 *
 * **Idempotency:** [configure] is idempotent. A second call from the
 * same process is a no-op with WARN log — matches iOS
 * `Kixo.swift::setup(... isConfigured guard …)`. We do NOT support
 * "reconfigure" — there's no clean way to tear down running
 * subsystems mid-process.
 *
 * **Wave 4 fix #17 — direct imports replace reflection.** An earlier
 * revision routed every fan-out call through `Class.forName(...)` so
 * this file would compile in any agent-merge order. With all peer
 * agents shipped (Wave 3 integration drop), the reflection paid
 * pure overhead AND silently swallowed signature drift. The fan-out
 * is now direct. The one remaining indirection is the
 * [Wiring.queueRef] slot which holds an EventQueue facade — the
 * queue's internal `Transport` interface and the real
 * `transport.Transport` have NOT been reconciled, so the EventQueue
 * is not constructed in this drop. See the TODO in [configure].
 */
public object Kixo {

    private const val TAG = "Kixo"
    private val SDK_VERSION: String = io.kixo.sdk.BuildConfig.SDK_VERSION

    /**
     * Cap for the pre-configure event buffer. Picked to cover the
     * common cold-start flow:
     *   - `Application.onCreate` → some init code calls
     *     `Kixo.identify(...)` + a few `Kixo.track(...)`s before
     *     `Kixo.configure(...)` lands.
     *   - 50 is enough to cover that without becoming a leak vector
     *     if the host NEVER calls [configure] (e.g. integration
     *     forgotten in a feature flag rollback).
     */
    private const val PRE_CONFIG_BUFFER_CAP = 50

    /**
     * Frozen on first [configure] success. Subsequent reads see the
     * `KixoConfiguration` from that first call. `null` until
     * configure lands — every public method polls this to decide
     * whether to fan out to internals or land in [preConfigBuffer].
     *
     * `AtomicReference` so the visibility of the `null → non-null`
     * transition is publication-safe across threads without a lock.
     */
    private val configRef: AtomicReference<KixoConfiguration?> = AtomicReference(null)

    /**
     * One-shot guard ensuring the configure handshake happens once.
     * Distinct from [configRef] because the configure flow does
     * cross-thread work (start internal subsystems, fetch
     * `/api/sdk/init`, …) and we need a CAS-style winner-takes-all
     * gate before any of that fires.
     */
    private val configured: AtomicBoolean = AtomicBoolean(false)

    /**
     * Pre-configure ring buffer for `track`/`identify`/etc calls.
     * Bounded at [PRE_CONFIG_BUFFER_CAP] — overflow drops the
     * OLDEST queued action (FIFO), matching the queue's overflow
     * policy. Drained onto the real queue after [configure].
     *
     * Stored as opaque lambdas so each entry replays itself with
     * its original args. We capture by value (Kotlin closures
     * close over locals by reference, but we make new locals for
     * the closure to capture so post-call mutation by the caller
     * is impossible).
     *
     * Synchronisation: `synchronized(preConfigBuffer)` for every
     * read/write. Negligible cost — pre-config is the ~milliseconds
     * before [configure] lands, and the queue is touched at most
     * 50 times.
     */
    private val preConfigBuffer: ArrayDeque<() -> Unit> = ArrayDeque()

    /**
     * Counter of pre-configure calls dropped due to overflow. Logged
     * once on configure-time replay so a host engineer can see "your
     * SDK init lagged so long that 17 events were lost".
     */
    private var preConfigDropped: Int = 0

    /**
     * Live wiring set on first [configure]. `null` before configure;
     * read by every public method post-configure.
     *
     * Held as an `AtomicReference` so the publish-once handshake is
     * visible to all threads without locking. The aggregate is
     * frozen — fields inside are themselves stateful but the
     * reference identity never changes for the SDK's lifetime.
     */
    private val wiringRef: AtomicReference<Wiring?> = AtomicReference(null)

    // ════════════════════════════════════════════════════════════
    // Configuration
    // ════════════════════════════════════════════════════════════

    /**
     * Configure Kixo with explicit project ID + API key. Convenience
     * sugar over [configure] with a default-built [KixoConfiguration].
     * Use this for the simplest happy-path integration:
     *
     * ```kotlin
     * class MyApp : Application() {
     *     override fun onCreate() {
     *         super.onCreate()
     *         Kixo.configure(this, projectId = "kx_proj_…", apiKey = "kx_key_…")
     *     }
     * }
     * ```
     */
    @JvmStatic
    public fun configure(context: Context, projectId: String, apiKey: String) {
        configure(
            context,
            KixoConfiguration.Builder(projectId, apiKey).build(context.applicationContext),
        )
    }

    /**
     * Configure Kixo with a fully-built [KixoConfiguration] — use
     * the [KixoConfiguration.Builder] for fine-grained tunables.
     *
     * **Idempotent:** call this exactly once per process. A second
     * call (e.g. from a UI test that reuses the Application)
     * is a WARN-logged no-op — the SDK keeps the FIRST configuration.
     * Matches iOS `Kixo.swift::setup` `guard !isConfigured` early-return.
     *
     * **Threading:** safe to call from any thread, but the typical
     * call site is `Application.onCreate` on the main thread.
     * Internal subsystem startup (network init, SQLite open, etc.)
     * is dispatched off the main thread by the agents' own
     * implementations.
     *
     * **Recovery from missed pre-config events:** any
     * `track`/`identify`/etc calls made BEFORE this method lands
     * are buffered in [preConfigBuffer] (cap 50) and replayed onto
     * the real queue here. If more than 50 events fired pre-config,
     * the oldest are dropped FIFO and the count is logged.
     */
    @JvmStatic
    public fun configure(context: Context, config: KixoConfiguration) {
        // CAS guard: only the first thread/call wins. Compare iOS:
        //   guard !isConfigured else { return }
        if (!configured.compareAndSet(false, true)) {
            Log.w(TAG, "configure() called more than once — ignoring (Kixo is already configured).")
            return
        }
        configRef.set(config)
        val appContext = context.applicationContext

        // ─── 1. Lifecycle bootstrap (idempotent). Installs activity
        //       callbacks + ProcessLifecycleOwner observer + memory
        //       observer. The applicationContext is normally the
        //       Application instance, but some test environments wrap
        //       it — defensively cast and skip the bootstrap if the
        //       cast fails (a no-op SDK is better than a crashed host).
        val app = appContext as? android.app.Application
        if (app != null) {
            runSafely("KixoInternalBootstrap.attach") {
                KixoInternalBootstrap.attach(app)
            }
        } else {
            Log.w(TAG, "applicationContext is not an Application; lifecycle bootstrap skipped.")
        }

        // ─── 2. Identity, properties, breadcrumbs. All `object` /
        //       singleton-construction. The first call is the
        //       expensive one (SharedPreferences read + ANDROID_ID
        //       lookup); subsequent reads are cached.
        val identityManager: IdentityManager? = runOrNull("IdentityManager.getOrCreate") {
            IdentityManager.getOrCreate(appContext)
        }
        val userPropertyStore: UserPropertyStore? = runOrNull("UserPropertyStore.getOrCreate") {
            UserPropertyStore.getOrCreate(appContext)
        }
        val superPropertyStore: SuperPropertyStore? = runOrNull("SuperPropertyStore.getOrCreate") {
            SuperPropertyStore.getOrCreate(appContext)
        }
        // BreadcrumbTrail is an `object` — ready to use directly.

        // ─── 3. Consent manager — wires SharedPreferences for opt-out
        //       persistence. Init is idempotent.
        runSafely("ConsentManager.init") { ConsentManager.init(appContext) }

        // ─── 4. EventQueue + Transport + EventStore + PayloadAssembler
        //       integration. WIRED in v0.1.0-alpha2 via QueueWiring.build,
        //       which constructs:
        //         - SqliteEventStore (real, with recoverInFlight)
        //         - OkHttpClient + Transport (real, returns BatchOutcome)
        //         - BatchPayloadAssembler (with DeviceInfo adapter)
        //         - EventQueue (queue's stub types satisfied by
        //           EventStoreAdapter / TransportAdapter / DeviceInfo
        //           Adapter wrappers in QueueWiring)
        //         - KixoEventQueueRef (public-facade-facing wrapper)
        //
        //       The Wave 1 parallel-build left queue/ with its own
        //       narrow stub types (KixoEvent / Transport / EventStore /
        //       BatchPayload) that the real types from agents 2/3/4/6
        //       don't satisfy. QueueWiring is the boundary translator.
        //       Long-term the queue should drop its stubs and import
        //       the real types directly; that refactor lives in Wave 6.
        val queueAdapter: EventQueueRef? = identityManager
            ?.let { im ->
                runOrNull("QueueWiring.build") {
                    val deviceInfo = io.kixo.sdk.internal.context.DeviceInfo(appContext)
                    val wiringQueue = io.kixo.sdk.internal.queue.QueueWiring.build(
                        context = appContext,
                        config = config,
                        identity = im,
                        deviceInfo = deviceInfo,
                        releaseId = null, // populated post-init in a follow-up
                    )
                    object : EventQueueRef {
                        override fun enqueueCustom(
                            eventType: String,
                            eventName: String,
                            properties: Map<String, Any?>,
                        ) = wiringQueue.enqueueCustom(eventType, eventName, properties)
                        override fun flush() = wiringQueue.flush()
                        override fun flushBlocking(timeoutMs: Long): Boolean =
                            wiringQueue.flushBlocking(timeoutMs)
                        override fun stop(reason: String) = wiringQueue.stop(reason)
                    }
                }
            }
        val identityDedupAdapter: IdentityDedupRef? = null

        // ─── 5. LifecycleEventBus sink — WIRED FIRST so the lifecycle
        //       observers that fire moments after KixoInternalBootstrap
        //       had a chance to install have a destination. Buffered
        //       events from before this point are drained inside
        //       bindSink (Critic 16 fix). Until [queueAdapter] lands,
        //       the sink just logs in debug builds — the event would
        //       have nowhere to go anyway.
        runSafely("LifecycleEventBus.bindSink") {
            LifecycleEventBus.bindSink { event -> routeLifecycleEvent(event, queueAdapter) }
        }

        // ─── 6. Push subsystem — bind bridges so logPush*() routes
        //       into the queue + dedup + transport. With queueAdapter
        //       null in this drop, the bridges return cheap no-ops
        //       (matches the prior reflection-failure behaviour).
        runSafely("PushTracker.bind") {
            PushTracker.bind(
                PushBridges(
                    eventQueue = NoopEventQueueBridge(queueAdapter),
                    identityDedup = NoopIdentityDedupBridge(identityDedupAdapter),
                    transport = NoopPushTransportBridge(),
                )
            )
        }

        // ─── 7. Goal marker — install the sink so markGoal() routes
        //       into the queue. Same no-op pattern as push above.
        runSafely("GoalMarker.installSink") {
            GoalMarker.installSink(GoalSink(queueAdapter))
        }

        // ─── 8. Replay controller — gated on config.replayEnabled.
        //       The real wiring needs OkHttp + ReplaySessionLifecycle +
        //       ReplayUploader + ReplayUploaderAdapter. Same TODO
        //       boundary as the EventQueue wiring above — the OkHttp
        //       singleton is constructable (HttpClientFactory.create)
        //       but not wired here because the upstream queue isn't
        //       wired either (a no-op queue + a fully-wired replay
        //       upload pipeline would post events the queue can't
        //       receive).
        // TODO(wave-5): wire ReplayController.start with a real
        //       ReplayUploaderAdapter once the queue boundary is
        //       reconciled. For now, replay capture stays dormant.
        if (config.replayEnabled) {
            if (config.debug) Log.d(TAG, "Replay enabled in config but uploader integration is deferred to Wave 5; replay stays dormant.")
        }

        // ─── 9. Crash tracker — install the uncaught exception handler
        //       (chains to the previous handler) and drain any pending
        //       crash from a prior process. The drained crash needs to
        //       be ingested via the queue; without queueAdapter we log
        //       in debug and discard (lossy until Wave 5).
        runSafely("CrashTracker.install") { CrashTracker.install(appContext) }
        if (queueAdapter == null) {
            // Drain & discard so the file doesn't keep growing across
            // launches. Once the queue is wired, the drained payload
            // should be enqueued as a crash event instead of dropped.
            runSafely("CrashTracker.drainPendingCrash") {
                val pending = CrashTracker.drainPendingCrash(appContext)
                if (pending != null && config.debug) {
                    Log.d(TAG, "Drained pending crash from previous process; ingest path is dormant in this drop.")
                }
            }
        }

        // ─── 10. Publish the wiring aggregate. Subsequent public-API
        //       calls see this and route directly to the wired
        //       subsystems instead of the pre-config buffer.
        val wiring = Wiring(
            appContext = appContext,
            identityManager = identityManager,
            userPropertyStore = userPropertyStore,
            superPropertyStore = superPropertyStore,
            queueRef = queueAdapter,
            identityDedupRef = identityDedupAdapter,
        )
        wiringRef.set(wiring)

        // ─── 11. Drain the pre-config ring buffer onto the now-live
        //       subsystems. Snapshot under the lock, then replay
        //       OUTSIDE the lock so a slow internal call doesn't
        //       block other threads from reaching the public API.
        val pending: List<() -> Unit>
        val droppedCount: Int
        synchronized(preConfigBuffer) {
            pending = ArrayList(preConfigBuffer)
            droppedCount = preConfigDropped
            preConfigBuffer.clear()
            preConfigDropped = 0
        }
        if (droppedCount > 0) {
            Log.w(TAG, "Pre-configure buffer overflowed — dropped $droppedCount earliest events.")
        }
        pending.forEach { action ->
            // Per-event try/catch — a single bad replay shouldn't
            // poison the rest. Matches the SDK-wide R6 anti-crash
            // posture.
            try {
                action()
            } catch (t: Throwable) {
                if (config.debug) Log.w(TAG, "Pre-configure replay failed", t)
            }
        }

        if (config.debug) {
            Log.d(
                TAG,
                "configured (env=${config.environment}, host=${config.apiHost}, sdk=$SDK_VERSION)",
            )
        }
    }

    // ════════════════════════════════════════════════════════════
    // Tracking
    // ════════════════════════════════════════════════════════════

    /**
     * Track a custom event. The [event] name is stored verbatim
     * server-side; convention is `snake_case`. Custom event names
     * are case-sensitive — `"Login"` and `"login"` are distinct
     * series in dashboards.
     *
     * @param event Event name. Snake_case recommended.
     * @param properties Free-form map of property keys to values.
     *   Values are JSON-serialised on the wire. Nested maps and
     *   lists are supported. PII is regex-redacted in transit
     *   (briefing R2 layer 2).
     */
    @JvmStatic
    @JvmOverloads
    public fun track(event: String, properties: Map<String, Any?> = emptyMap()) {
        runOrBuffer { wiring()?.queueRef?.enqueueCustom("custom", event, properties) }
    }

    /**
     * Manual screen tracking. Recommended for Compose / SwiftUI-
     * style declarative UIs where the auto-tracker can't cleanly
     * detect navigation. Fires a `screen_view` event AND records a
     * navigation breadcrumb for crash attribution.
     *
     * On Activity/Fragment-based apps, [KixoConfiguration.autoTrackScreens]
     * (default `true`) handles this for you.
     */
    @JvmStatic
    @JvmOverloads
    public fun screen(name: String, properties: Map<String, Any?> = emptyMap()) {
        runOrBuffer {
            // Record a breadcrumb so a crash inside this screen's
            // logic surfaces "user just navigated to <name>" in the
            // crash event payload. Mirrors iOS Kixo.screenView.
            BreadcrumbTrail.add(
                category = "navigation",
                message = "Screen: $name",
                data = mapOf("screen_class" to "manual"),
                level = "info",
            )
            val merged = LinkedHashMap<String, Any?>(properties.size + 1)
            merged["screen_class"] = "manual"
            merged.putAll(properties)
            wiring()?.queueRef?.enqueueCustom("screen_view", name, merged)
        }
    }

    /**
     * Mark a conversion goal — cross-platform parity with the iOS
     * `Kixo.markGoal()` and the web SDK's `Kixo.markGoal()`. Fires
     * `event_type=goal` + `event_name=<name>`. The backend's
     * auto-goals detector treats these as ground truth — any
     * AI-detected candidate matching the same name is suppressed.
     *
     * @param name Goal identifier. Must match `^[a-z0-9_-]{3,64}$` —
     *   lowercase letters, digits, underscore, hyphen, 3–64 chars.
     *   Same regex enforced by web SDK + iOS to prevent
     *   `${user.email}`-style template-injection attacks landing in
     *   goal names server-side. Invalid names are dropped with a
     *   WARN log rather than thrown so misuse doesn't crash.
     * @param value Optional revenue value (e.g. `49.99`). Stored
     *   under `goal_value`.
     * @param currency Optional ISO-4217 currency. Stored under
     *   `goal_currency`.
     * @param properties Free-form extras merged with goal_value /
     *   goal_currency.
     */
    @JvmStatic
    @JvmOverloads
    public fun markGoal(
        name: String,
        value: Double? = null,
        currency: String? = null,
        properties: Map<String, Any?> = emptyMap(),
    ) {
        if (!isValidGoalName(name)) {
            Log.w(TAG, "markGoal: invalid name '$name' — must match ^[a-z0-9_-]{3,64}$. Event dropped.")
            return
        }
        runOrBuffer {
            // Defer to GoalMarker (Agent 12) so the dedup window +
            // session-once contract live in one place. GoalMarker also
            // does its own validation + dedup; passing the value /
            // currency through directly lets it apply its
            // currency-regex + non-negative-value guards.
            GoalMarker.mark(
                name = name,
                value = value,
                currency = currency,
                properties = properties,
            )
        }
    }

    /**
     * Match the iOS / web SDK validator — `^[a-z0-9_-]{3,64}$`.
     * Inline scan, no regex allocation per call.
     */
    private fun isValidGoalName(name: String): Boolean {
        val len = name.length
        if (len < 3 || len > 64) return false
        for (c in name) {
            val ok = (c in 'a'..'z') || (c in '0'..'9') || c == '-' || c == '_'
            if (!ok) return false
        }
        return true
    }

    /**
     * Add a manual breadcrumb to the trail. Breadcrumbs are
     * attached to crash events and provide a Sentry-style trail of
     * user actions (last ~30 by default).
     *
     * @param category Breadcrumb category. Common values:
     *   `"navigation"`, `"ui"`, `"http"`, `"user"`, `"info"`.
     * @param message Human-readable description.
     * @param data Optional dict of extra structured data.
     * @param level Severity — `"info"` (default), `"warning"`, `"error"`.
     */
    @JvmStatic
    @JvmOverloads
    public fun addBreadcrumb(
        category: String,
        message: String,
        data: Map<String, Any?>? = null,
        level: String = "info",
    ) {
        runOrBuffer { BreadcrumbTrail.add(category, message, data, level) }
    }

    // ════════════════════════════════════════════════════════════
    // Identity
    // ════════════════════════════════════════════════════════════

    /**
     * Identify the current end-user (the customer's app user — see
     * the three-actor model in CLAUDE.md). Call after login.
     *
     * @param userId Stable user identifier from the customer's
     *   auth system. Goes into the `user_id` ClickHouse column on
     *   every subsequent event from this device.
     * @param traits Optional traits dictionary — `$email`,
     *   `$plan`, etc. Use [StandardProperty]-prefixed keys for
     *   first-class dashboard fields, plain keys for custom
     *   traits.
     */
    @JvmStatic
    @JvmOverloads
    public fun identify(userId: String, traits: Map<String, Any?> = emptyMap()) {
        runOrBuffer {
            val w = wiring() ?: return@runOrBuffer
            // Persist the user_id in IdentityManager so it stamps
            // every future event's user_id column.
            w.identityManager?.setUserId(userId)
            // Merge traits into the user-property store so a re-launch
            // sees the same identity context.
            if (traits.isNotEmpty()) {
                w.userPropertyStore?.setAll(traits)
            }
            // Emit the identify event. Queue handles dedup via
            // IdentityDedup (matches iOS — duplicate identify with
            // same traits is a no-op).
            val props = LinkedHashMap<String, Any?>(traits.size + 1)
            props.putAll(traits)
            props["user_id"] = userId
            w.queueRef?.enqueueCustom("identify", "identify", props)
        }
    }

    /**
     * Associate the current user with a group / company (B2B).
     * Customer's analytics dashboard can then segment by group.
     */
    @JvmStatic
    @JvmOverloads
    public fun group(groupId: String, traits: Map<String, Any?> = emptyMap()) {
        runOrBuffer {
            val w = wiring() ?: return@runOrBuffer
            val props = LinkedHashMap<String, Any?>(traits.size + 1)
            props.putAll(traits)
            props["group_id"] = groupId
            w.queueRef?.enqueueCustom("group", "group", props)
        }
    }

    /**
     * Reset identity. Call on logout. Generates a new anonymous ID,
     * clears the identify-event dedup cache, and clears push
     * attribution state (otherwise a stale `kixo_campaign_id` would
     * decorate the next user's events).
     *
     * Super-properties survive [reset] by default — they describe
     * the SESSION, not the IDENTITY. Use [clearSuperProperties] in
     * addition if you want a clean slate. Matches iOS
     * `Kixo.swift::reset` semantics.
     *
     * **Wave 4 fix #30:** also stops the EventQueue (cancels the
     * periodic flush coroutine, drains the durable buffer). Without
     * this, the queue would keep ticking after the user explicitly
     * walked away from the SDK.
     */
    @JvmStatic
    public fun reset() {
        runOrBuffer {
            val w = wiring() ?: return@runOrBuffer
            // Clear identity (regenerates anonymous_id, clears user_id).
            w.identityManager?.reset()
            // Wipe the identity-dedup cache so a re-identify with the
            // prior user's traits emits fresh.
            w.identityDedupRef?.reset()
            // Push attribution windows MUST clear so the next user's
            // events don't carry the prior user's kixo_campaign_id.
            // PushTracker.reset() handles this internally.
            PushTracker.reset()
            // Goal dedup — clear so the next user's first goal mark
            // fires.  GoalMarker doesn't expose a reset; the dedup
            // lives in GoalDedup which is session-scoped (auto-clears
            // on session boundary). No-op here intentionally.
            // User properties: leave intact by default — the host can
            // call clearSuperProperties separately for a deeper wipe.
            // Critic 30 (HIGH) — stop the EventQueue. Cancels the
            // periodic flush coroutine + drains the durable buffer
            // (lifecycle pivots to PausedByServer with reason="reset").
            w.queueRef?.stop("reset")
        }
    }

    // ════════════════════════════════════════════════════════════
    // Properties
    // ════════════════════════════════════════════════════════════

    /**
     * Set a single user property. Standard property keys use the
     * `$`-prefix convention (e.g. `$email`); custom traits use any
     * key without `$`. See [StandardProperty] for the catalogue of
     * recognised standard keys.
     */
    @JvmStatic
    public fun setUserProperty(key: String, value: Any?) {
        runOrBuffer {
            val w = wiring() ?: return@runOrBuffer
            w.userPropertyStore?.set(key, value)
            // Emit a user_property event so the backend's User.traits
            // row stays in sync. Queue applies per-key dedup.
            w.queueRef?.enqueueCustom(
                "user_property",
                "user_property",
                mapOf("key" to key, "value" to value),
            )
        }
    }

    /** Set multiple user properties in one call. */
    @JvmStatic
    public fun setUserProperties(properties: Map<String, Any?>) {
        runOrBuffer {
            val w = wiring() ?: return@runOrBuffer
            w.userPropertyStore?.setAll(properties)
            // Fan out one user_property event per (key, value) so the
            // queue's per-key dedup does the right thing.
            for ((k, v) in properties) {
                w.queueRef?.enqueueCustom(
                    "user_property",
                    "user_property",
                    mapOf("key" to k, "value" to v),
                )
            }
        }
    }

    /**
     * Set a session-wide "super-property" — auto-attached to every
     * subsequent event. Distinct from [setUserProperty] which
     * describes the IDENTITY (and goes to `User.traits` server-
     * side); super-properties describe the SESSION CONTEXT and
     * are local to the current device.
     *
     * Common uses:
     *   - Active A/B variant (set once on bucket assignment)
     *   - Build flavour, app version channel
     *   - Affiliate / referrer ids
     *   - Opted-in feature flag overrides
     *
     * Per-event `properties` passed to [track] always win on key
     * collision — super-properties are defaults the caller can
     * override per event.
     */
    @JvmStatic
    public fun setSuperProperty(key: String, value: Any?) {
        runOrBuffer { wiring()?.superPropertyStore?.set(key, value) }
    }

    /** Bulk-set super-properties. */
    @JvmStatic
    public fun setSuperProperties(properties: Map<String, Any?>) {
        runOrBuffer { wiring()?.superPropertyStore?.setAll(properties) }
    }

    /** Remove a single super-property. */
    @JvmStatic
    public fun unsetSuperProperty(key: String) {
        runOrBuffer { wiring()?.superPropertyStore?.unset(key) }
    }

    /**
     * Drop ALL super-properties. Less surgical than
     * [unsetSuperProperty]; reasonable for "user logged out, forget
     * the active A/B variants" without doing a full identity
     * [reset]. Note that [reset] does NOT clear super-properties
     * — they survive logout by design.
     */
    @JvmStatic
    public fun clearSuperProperties() {
        runOrBuffer { wiring()?.superPropertyStore?.clear() }
    }

    /**
     * Tag every future event with the experiment assignment for
     * [experimentId]. Sugar over [setSuperProperty] with the
     * `experiment_<id>` key convention so the backend can run a
     * single `WHERE experiment_<id> = 'variantA'` filter without
     * parsing a nested JSON path.
     */
    @JvmStatic
    public fun setExperimentVariant(experimentId: String, variant: String) {
        setSuperProperty("experiment_$experimentId", variant)
    }

    // ════════════════════════════════════════════════════════════
    // Push
    // ════════════════════════════════════════════════════════════

    /**
     * Register a push notification token for this device. Call
     * from your `FirebaseMessagingService.onNewToken` (FCM) or
     * the equivalent HMS callback.
     *
     * The full token goes once to `/api/sdk/push/register` (so the
     * backend can deliver). Subsequent event payloads only carry
     * `SHA-256(token)` — see briefing R10.
     *
     * @param token Push token from FCM/HMS/APNS.
     * @param provider Token transport — defaults to [PushProvider.FCM]
     *   since the overwhelming majority of Android push deployments
     *   use Firebase.
     */
    @JvmStatic
    @JvmOverloads
    public fun setPushToken(token: String, provider: PushProvider = PushProvider.FCM) {
        runOrBuffer { PushTracker.setPushToken(token, provider) }
    }

    /**
     * Manually log a push notification arrival. Use when the
     * SDK's automatic FCM hook can't be installed (typically
     * because the host app already has a custom
     * `FirebaseMessagingService` it can't share).
     *
     * @param payload Raw notification payload — pass everything you
     *   received from FCM. The SDK extracts campaign IDs and
     *   sanitises content per the configured push content mode.
     * @param appState `"foreground"` (default) for visible alerts,
     *   `"background"` for silent / data-only pushes received while
     *   the app isn't active.
     */
    @JvmStatic
    @JvmOverloads
    public fun logPushReceived(payload: Map<String, Any?>, appState: String = "foreground") {
        runOrBuffer { PushTracker.logPushReceived(payload, appState) }
    }

    /**
     * Log a push open (user tapped the notification). Use from
     * your notification-click handler — typically the launching
     * Activity's `onCreate(intent)`.
     *
     * Captures push attribution: subsequent events for the next
     * [KixoConfiguration.pushAttributionWindowMillis] (default 30
     * min) will inherit `kixo_campaign_id` / `kixo_delivery_id`.
     *
     * @param actionId If the user tapped a custom notification
     *   action button, the action identifier; `null` for default
     *   tap.
     */
    @JvmStatic
    @JvmOverloads
    public fun logPushOpened(payload: Map<String, Any?>, actionId: String? = null) {
        runOrBuffer { PushTracker.logPushOpened(payload, actionId) }
    }

    /**
     * Log a push dismissal (user swiped it away without tapping).
     * Requires the SDK's notification-dismiss BroadcastReceiver
     * to be registered — Agent 11 handles the AndroidManifest
     * registration; manual callers can fire this from their own
     * dismiss receiver.
     */
    @JvmStatic
    public fun logPushDismissed(payload: Map<String, Any?>) {
        runOrBuffer { PushTracker.logPushDismissed(payload) }
    }

    /**
     * Log a push custom-action tap. Pass the action identifier
     * configured on the notification — we never log user-typed
     * reply text (briefing R2 push privacy).
     */
    @JvmStatic
    public fun logPushAction(payload: Map<String, Any?>, actionId: String) {
        runOrBuffer { PushTracker.logPushAction(payload, actionId) }
    }

    /**
     * Log that a previously-registered push token is no longer
     * valid (FCM returned `MismatchSenderId` / `Unregistered`,
     * HMS returned `80300008`, etc.). Sends only the SHA-256
     * hash — never the plaintext token (briefing R10).
     */
    @JvmStatic
    @JvmOverloads
    public fun logPushTokenInvalidated(token: String, provider: PushProvider = PushProvider.FCM) {
        runOrBuffer { PushTracker.logPushTokenInvalidated(token, provider) }
    }

    // ════════════════════════════════════════════════════════════
    // Standard events (sugar)
    // ════════════════════════════════════════════════════════════

    /**
     * Standard purchase event. Drives revenue / ARPU dashboards.
     * Sugar over [track] with the standard property keys spelled
     * correctly. See [StandardEvent.Purchase] for the equivalent
     * sealed-class form.
     */
    @JvmStatic
    @JvmOverloads
    public fun trackPurchase(
        amount: Double,
        currency: String,
        productId: String? = null,
        productName: String? = null,
        quantity: Int? = null,
        properties: Map<String, Any?> = emptyMap(),
    ) {
        track(
            "purchase",
            StandardEvent.Purchase(
                amount = amount,
                currency = currency,
                productId = productId,
                productName = productName,
                quantity = quantity,
                extra = properties,
            ).toProperties(),
        )
    }

    /**
     * Subscription started — drives MRR + cohort retention. See
     * [StandardEvent.SubscriptionStart].
     */
    @JvmStatic
    @JvmOverloads
    public fun trackSubscriptionStart(
        plan: String,
        amount: Double,
        currency: String,
        interval: SubscriptionInterval,
        properties: Map<String, Any?> = emptyMap(),
    ) {
        track(
            "subscribe_start",
            StandardEvent.SubscriptionStart(
                plan = plan,
                amount = amount,
                currency = currency,
                interval = interval,
                extra = properties,
            ).toProperties(),
        )
    }

    /** Free trial started. See [StandardEvent.TrialStart]. */
    @JvmStatic
    @JvmOverloads
    public fun trackTrialStart(plan: String, days: Int, properties: Map<String, Any?> = emptyMap()) {
        track("trial_start", StandardEvent.TrialStart(plan, days, properties).toProperties())
    }

    /** Subscription/trial cancellation. See [StandardEvent.Cancel]. */
    @JvmStatic
    @JvmOverloads
    public fun trackCancel(plan: String, reason: String? = null, properties: Map<String, Any?> = emptyMap()) {
        track("cancel", StandardEvent.Cancel(plan, reason, properties).toProperties())
    }

    /** Plan upgrade. See [StandardEvent.Upgrade]. */
    @JvmStatic
    @JvmOverloads
    public fun trackUpgrade(fromPlan: String, toPlan: String, properties: Map<String, Any?> = emptyMap()) {
        track("upgrade", StandardEvent.Upgrade(fromPlan, toPlan, properties).toProperties())
    }

    /** New-user signup. See [StandardEvent.Signup]. */
    @JvmStatic
    @JvmOverloads
    public fun trackSignup(
        method: String? = null,
        plan: String? = null,
        properties: Map<String, Any?> = emptyMap(),
    ) {
        track("signup", StandardEvent.Signup(method, plan, properties).toProperties())
    }

    /** Activation event. See [StandardEvent.Activation]. */
    @JvmStatic
    @JvmOverloads
    public fun trackActivation(event: String? = null, properties: Map<String, Any?> = emptyMap()) {
        track("activation", StandardEvent.Activation(event, properties).toProperties())
    }

    /** Share / refer event. See [StandardEvent.Share]. */
    @JvmStatic
    @JvmOverloads
    public fun trackShare(channel: String, contentId: String? = null, properties: Map<String, Any?> = emptyMap()) {
        track("share", StandardEvent.Share(channel, contentId, properties).toProperties())
    }

    /** Invite sent. See [StandardEvent.Invite]. */
    @JvmStatic
    @JvmOverloads
    public fun trackInvite(
        channel: String? = null,
        recipientCount: Int? = null,
        properties: Map<String, Any?> = emptyMap(),
    ) {
        track("invite", StandardEvent.Invite(channel, recipientCount, properties).toProperties())
    }

    // ════════════════════════════════════════════════════════════
    // Consent & control
    // ════════════════════════════════════════════════════════════

    /**
     * Opt the user out of all tracking. Subsequent events drop at
     * the consent gate. Persists across process restarts — the
     * opt-out flag is stored by ConsentManager (Agent 10).
     *
     * **B2B note:** see CLAUDE.md — Kixo is B2B. End-user opt-out
     * UI is the customer's responsibility; this method is the
     * programmatic switch they call from their own settings screen.
     *
     * **Wave 4 fix #30:** also stops the EventQueue (cancels the
     * periodic flush + drains the durable buffer) and halts replay
     * capture. Without this, the queue would keep ticking after
     * opt-out and replay would keep capturing frames.
     */
    @JvmStatic
    public fun optOut() {
        runOrBuffer {
            ConsentManager.optOut()
            // Critic 30 (HIGH) — stop the queue + replay so the
            // user's "don't track me" signal is honoured immediately
            // (no further flushes, no further frame capture).
            wiring()?.queueRef?.stop("opted_out")
            ReplayController.optOut()
        }
    }

    /** Opposite of [optOut] — re-enables tracking. */
    @JvmStatic
    public fun optIn() {
        runOrBuffer {
            ConsentManager.optIn()
            // Re-enable replay. The queue stays stopped — re-launching
            // the host process is the supported recovery path (matches
            // iOS where opt-in does NOT auto-restart the in-process
            // queue; the next app launch wires a fresh queue).
            ReplayController.optIn()
        }
    }

    /**
     * Grant analytics consent (for jurisdictions where consent is
     * required before any tracking starts — GDPR, ePrivacy). The
     * SDK ships with consent NOT granted by default in
     * `dataCollection.consentRequired` mode (server-controlled);
     * call this after the user accepts your consent dialog.
     */
    @JvmStatic
    public fun grantConsent() {
        runOrBuffer { ConsentManager.grantConsent() }
    }

    /** Revoke previously-granted consent. Same effect as [optOut]. */
    @JvmStatic
    public fun revokeConsent() {
        runOrBuffer { ConsentManager.revokeConsent() }
    }

    /**
     * Check the opt-out state. Returns `false` (opted in) if the
     * SDK has not been configured yet — opt-out only meaningfully
     * exists once the consent layer is up.
     */
    @JvmStatic
    public fun isOptedOut(): Boolean {
        if (configRef.get() == null) return false
        return ConsentManager.isOptedOut()
    }

    // ════════════════════════════════════════════════════════════
    // Diagnostics
    // ════════════════════════════════════════════════════════════

    /**
     * Snapshot of SDK health. Cheap; safe to call from any thread.
     * Returns [KixoDiagnostics.Uninitialised] if [configure] was
     * never called.
     *
     * Dump this onto a debug screen or hand it to your own log /
     * crash reporter to answer "why aren't events flowing?"
     * without running Kixo under a debugger.
     */
    @JvmStatic
    public fun diagnostics(): KixoDiagnostics {
        val config = configRef.get() ?: return KixoDiagnostics.Uninitialised
        // The diagnostics aggregator (internal/diagnostics/Diagnostics)
        // would assemble the rich snapshot from the live queue +
        // replay + consent sources. Until [Wiring.queueRef] is wired
        // (TODO wave-5), we synthesise a minimal snapshot from the
        // configuration alone — same shape as the prior reflection
        // fallback.
        return KixoDiagnostics(
            initialised = true,
            paused = ConsentManager.isOptedOut(),
            environment = config.environment,
            apiHost = config.apiHost,
            lifecycleState = "initialising",
            lastFlushAtMillis = null,
            lastError = null,
            queue = KixoDiagnostics.QueueHealth(
                bufferedEventCount = 0,
                bufferCap = config.maxBufferSize,
                consecutiveFailures = 0,
                isFlushing = false,
                retryTier = "healthy",
            ),
        )
    }

    /**
     * Force-flush pending events now. Asynchronous — returns
     * immediately. The actual network call happens off the calling
     * thread.
     *
     * Call this before backgrounding (when you want to maximise
     * the chance events land before the OS suspends you), or after
     * a high-value event (e.g. a `purchase`) when you want to
     * minimise the window of loss if the user kills the app.
     */
    @JvmStatic
    public fun flush() {
        wiring()?.queueRef?.flush()
    }

    /**
     * **Test-only.** Force-flush AND wait synchronously for the
     * result, up to [timeoutMs] ms. Returns `true` if the batch
     * landed, `false` on transport failure or timeout.
     *
     * **MUST NOT be called from the main thread** — this method
     * blocks the calling thread on the network round-trip and
     * would freeze your UI. The implementation precondition-throws
     * if it detects the main thread (matches iOS contract).
     *
     * Primary use case: instrumentation tests / fixtures that need
     * to assert "the events I just enqueued reached the backend
     * before I check the next thing." Avoids the brittle
     * `Thread.sleep(...)` workaround.
     */
    @JvmStatic
    public fun flushBlocking(timeoutMs: Long): Boolean {
        require(timeoutMs >= 0) { "timeoutMs must be >= 0" }
        // Main-thread precondition. iOS uses `precondition(!Thread.isMainThread)`;
        // here we throw IllegalStateException — same loud-failure semantics,
        // surfaces as a test crash rather than a silent deadlock.
        if (android.os.Looper.getMainLooper().isCurrentThread) {
            throw IllegalStateException(
                "Kixo.flushBlocking() blocks the calling thread; never call it from the main thread (it would deadlock the network completion dispatch). Use the no-arg Kixo.flush() from main.",
            )
        }
        // No queue wired → nothing to flush; return success so test
        // callers don't fail spuriously on the deferred-integration
        // boundary.
        val q = wiring()?.queueRef ?: return true
        return q.flushBlocking(timeoutMs)
    }

    // ════════════════════════════════════════════════════════════
    // Replay control
    // ════════════════════════════════════════════════════════════

    /**
     * Disable replay capture for the rest of this session AND
     * persist the preference across process restarts. Frames
     * already captured but not yet uploaded stay on disk and
     * upload normally — the opt-out applies only to NEW captures.
     *
     * Use when an end-user opts out via your own privacy settings
     * UI (the SDK has no end-user-facing UI of its own —
     * briefing's three-actor model).
     */
    @JvmStatic
    public fun replayOptOut() {
        runOrBuffer { ReplayController.optOut() }
    }

    /** Opposite of [replayOptOut] — re-enables replay capture. */
    @JvmStatic
    public fun replayOptIn() {
        runOrBuffer { ReplayController.optIn() }
    }

    // ════════════════════════════════════════════════════════════
    // Internals
    // ════════════════════════════════════════════════════════════

    /**
     * If [configure] has landed, run [action] inline; otherwise
     * push it onto the pre-configure ring buffer. Bounded — when
     * the buffer hits [PRE_CONFIG_BUFFER_CAP], we drop the
     * OLDEST queued action (FIFO) and bump [preConfigDropped].
     *
     * Why not use a lock-free queue? `ArrayDeque` + `synchronized`
     * is fast enough — pre-config is <1s of process lifetime —
     * and it gives us the exact FIFO drop semantics the queue
     * uses. Not worth a `ConcurrentLinkedDeque` here.
     */
    private inline fun runOrBuffer(crossinline action: () -> Unit) {
        if (configRef.get() != null) {
            // Subsystems are responsible for their own try/catch;
            // we don't double-wrap. R6 anti-crash is enforced at
            // each subsystem's boundary.
            try {
                action()
            } catch (t: Throwable) {
                // Last-resort net for unforeseen crashes inside
                // subsystem fan-out. Logged, swallowed.
                Log.w(TAG, "Public API call threw — swallowed", t)
            }
            return
        }
        synchronized(preConfigBuffer) {
            // Re-check inside the lock — configure() could land
            // between the outer check and here.
            if (configRef.get() != null) {
                // Race: drain straight through.
                try {
                    action()
                } catch (t: Throwable) {
                    Log.w(TAG, "Public API call threw — swallowed", t)
                }
                return
            }
            if (preConfigBuffer.size >= PRE_CONFIG_BUFFER_CAP) {
                // FIFO drop — same overflow policy as the real queue.
                preConfigBuffer.pollFirst()
                preConfigDropped++
            }
            preConfigBuffer.addLast { action() }
        }
    }

    private fun wiring(): Wiring? = wiringRef.get()

    /**
     * Run [block] swallowing any Throwable. Used during configure()
     * fan-out so a single subsystem failure doesn't tear down the
     * whole bootstrap (R6 anti-crash). Logs the throw with [tag]
     * for triage in debug builds.
     */
    private inline fun runSafely(tag: String, crossinline block: () -> Unit) {
        try {
            block()
        } catch (t: Throwable) {
            Log.w(TAG, "configure step '$tag' failed", t)
        }
    }

    /**
     * Variant of [runSafely] that returns the block's result or null
     * on failure. Used when the wiring needs to capture a reference
     * for later use even if construction itself failed.
     */
    private inline fun <T> runOrNull(tag: String, crossinline block: () -> T): T? {
        return try {
            block()
        } catch (t: Throwable) {
            Log.w(TAG, "configure step '$tag' failed", t)
            null
        }
    }

    /**
     * Bridge from a [LifecycleEvent] (Agent 7's lifecycle observers)
     * onto the EventQueue (Agent 5). Called from the sink installed
     * by [LifecycleEventBus.bindSink] inside [configure].
     *
     * When [queueAdapter] is null (queue wiring deferred to wave 5),
     * the event is logged in debug and dropped — same as the prior
     * reflection-failure behaviour.
     */
    private fun routeLifecycleEvent(event: LifecycleEvent, queueAdapter: EventQueueRef?) {
        val q = queueAdapter ?: return
        val type = wireForKixoEventType(event.eventType)
        q.enqueueCustom(type, event.eventName, event.properties)
    }

    /** Map a [KixoEventType] to its snake_case wire string. */
    private fun wireForKixoEventType(type: KixoEventType): String = when (type) {
        KixoEventType.ScreenView -> "screen_view"
        KixoEventType.Tap -> "tap"
        KixoEventType.Scroll -> "scroll"
        KixoEventType.Network -> "network"
        KixoEventType.Crash -> "crash"
        KixoEventType.Custom -> "custom"
        KixoEventType.SessionStart -> "session_start"
        KixoEventType.SessionEnd -> "session_end"
        KixoEventType.Identify -> "identify"
        KixoEventType.Group -> "group"
        KixoEventType.Lifecycle -> "lifecycle"
        KixoEventType.Navigation -> "navigation"
        KixoEventType.Gesture -> "gesture"
        KixoEventType.PushOpen -> "push_open"
        KixoEventType.PushReceived -> "push_received"
        KixoEventType.PushDismissed -> "push_dismissed"
        KixoEventType.PushSilent -> "push_silent"
        KixoEventType.PushAction -> "push_action"
        KixoEventType.PushPermission -> "push_permission"
        KixoEventType.PushTokenInvalidated -> "push_token_invalidated"
        KixoEventType.DeepLink -> "deep_link"
        KixoEventType.Iap -> "iap"
        KixoEventType.UserProperty -> "user_property"
        KixoEventType.ScreenVisit -> "screen_visit"
        KixoEventType.Goal -> "goal"
    }

    /**
     * Aggregated wiring published by [configure]. Frozen reference;
     * fields are independently thread-safe.
     */
    private data class Wiring(
        val appContext: Context,
        val identityManager: IdentityManager?,
        val userPropertyStore: UserPropertyStore?,
        val superPropertyStore: SuperPropertyStore?,
        /**
         * Optional EventQueue handle. **Currently always null** —
         * the queue/transport boundary is not reconciled in this
         * drop (see TODO in [configure]). Future wave will populate
         * this with a real adapter so all the public-API methods
         * that route through `queueRef?.enqueueCustom(...)` start
         * actually shipping events instead of dropping them.
         */
        val queueRef: EventQueueRef?,
        val identityDedupRef: IdentityDedupRef?,
    )

    /**
     * Narrow facade-side view of Agent 5's `EventQueue`. The real
     * `internal class EventQueue` exposes a richer surface, but the
     * facade only needs these few entry points — keeping the
     * abstraction narrow makes the eventual wave-5 wiring a one-line
     * adapter.
     *
     * Implementations MUST be safe to call from any thread. All
     * methods are fire-and-forget (no return value contract beyond
     * [flushBlocking]).
     */
    private interface EventQueueRef {
        /**
         * Enqueue a custom event with the given (event_type,
         * event_name, properties). Real implementation builds a full
         * [io.kixo.sdk.internal.model.KixoEvent] (with the live
         * device_id / anonymous_id / user_id / session_id /
         * fingerprint / context stamp) and routes through
         * `EventQueue.enqueue(...)`.
         */
        fun enqueueCustom(eventType: String, eventName: String, properties: Map<String, Any?>)

        /** Asynchronous best-effort drain. Mirrors `EventQueue.flush`. */
        fun flush()

        /** Synchronous drain with timeout. Test-only. */
        fun flushBlocking(timeoutMs: Long): Boolean

        /**
         * Stop the queue's periodic flush + transition lifecycle to
         * paused. Called from [optOut] and [reset] (Wave 4 fix #30).
         * Idempotent.
         */
        fun stop(reason: String)
    }

    /**
     * Narrow facade-side view of `IdentityDedup`. Currently only
     * [reset] is needed (called from [reset] to clear the per-process
     * dedup hashes after a logout).
     */
    private interface IdentityDedupRef {
        fun reset()
    }

    /**
     * Per-Push bridge variants — fall back to no-op behaviour when
     * the queue isn't wired. This exactly mirrors the prior
     * reflection behaviour (NoSuchMethodException → silent swallow)
     * but in typed form so the integration boundary is visible.
     */
    private class NoopEventQueueBridge(private val queue: EventQueueRef?) : EventQueueBridge {
        override fun enqueue(eventType: String, properties: Map<String, Any?>) {
            queue?.enqueueCustom(eventType, eventType, properties)
        }
    }

    private class NoopIdentityDedupBridge(private val dedup: IdentityDedupRef?) : IdentityDedupBridge {
        override fun shouldEmitPushToken(tokenSha256: String, provider: PushProvider): Boolean {
            // Without the real IdentityDedup wired, every call returns
            // true (= emit). The downstream registerPushToken bridge is
            // also a no-op, so emitting more often is harmless until
            // the queue+transport wiring lands.
            return true
        }
    }

    private class NoopPushTransportBridge : PushTransportBridge {
        override fun registerPushToken(token: String, provider: PushProvider) {
            // No-op until the transport+queue boundary is reconciled.
            // The plaintext token is NOT logged or persisted (R10).
        }
    }

    /**
     * Concrete [GoalEventSink] handing goal events to the queue. The
     * real [io.kixo.sdk.internal.model.KixoEvent] minting (with the
     * device/anonymous/user/session ids and fingerprint stamp)
     * happens inside the queue adapter — this sink just forwards the
     * properties dictionary and the goal's `name` as both
     * event_type ("goal") and event_name (the goal id).
     */
    private class GoalSink(private val queue: EventQueueRef?) : GoalEventSink {
        override fun enqueueGoal(name: String, properties: JsonObject) {
            // JsonObject IS-A Map<String, JsonElement>; Map is covariant
            // in its value type (`Map<out K, out V>`), so this assigns
            // straight to Map<String, Any?>. The queue adapter
            // serialises JsonElement values transparently when
            // building the wire payload.
            queue?.enqueueCustom("goal", name, properties)
        }
    }
}
