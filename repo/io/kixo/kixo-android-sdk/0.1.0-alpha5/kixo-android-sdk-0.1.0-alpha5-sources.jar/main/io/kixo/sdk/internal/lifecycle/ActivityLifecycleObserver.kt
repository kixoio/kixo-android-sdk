package io.kixo.sdk.internal.lifecycle

import android.app.Activity
import android.app.Application
import android.os.Bundle
import java.lang.ref.WeakReference

/**
 * Tracks the foreground-most Activity for the rest of the SDK to
 * grab via [currentActivity]. Used by:
 *   - The screen-fingerprint subsystem (Agent 9) to call
 *     `activity.window.decorView` and walk the view tree.
 *   - The replay subsystem (Agent 13) to root its frame snapshots
 *     in the right window.
 *   - Any future "show in-app message" feature that needs an Activity
 *     to attach a dialog to.
 *
 * **Strict rule (AGENT_BRIEFING.md §11 anti-examples + R6):** never
 * hold a strong reference to an Activity in a singleton — that's a
 * memory leak the size of the entire view hierarchy and easily one
 * of the most common Android SDK bugs. We use [WeakReference]
 * exclusively. Callers must tolerate `null` (the GC may have collected
 * the Activity between when `onActivityPaused` cleared our reference
 * and when the caller asked).
 *
 * Lifecycle ordering reminder (Android docs):
 *   onCreate → onStart → onResume → [onPause] → onStop → onDestroy
 *
 * We update the weak ref on `onResumed` (the canonical "this Activity
 * is the user-facing top one") and clear it on `onPaused` only when
 * the paused Activity matches our current top. This handles the
 * Activity A → Activity B transition cleanly: B's onResume happens
 * BEFORE A's onPause (yes really — see Android's Activity lifecycle
 * docs), so by the time A's onPause arrives the top is already B and
 * we leave the reference untouched.
 *
 * Thread safety: all `Application.ActivityLifecycleCallbacks` callbacks
 * fire on the main thread, so the @Volatile is just defensive
 * (callers may read `currentActivity()` from a worker thread).
 */
internal class ActivityLifecycleObserver : Application.ActivityLifecycleCallbacks {

    @Volatile
    private var topActivityRef: WeakReference<Activity> = WeakReference<Activity>(null)

    /**
     * The Activity currently in the resumed state, or `null` if none
     * is foregrounded (or the GC reclaimed it). Safe to call from
     * any thread.
     */
    fun currentActivity(): Activity? = topActivityRef.get()

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        // No-op. We track via onResumed/onPaused — onCreated fires too
        // early (the Activity isn't user-visible yet, and on rotation
        // the previous instance is still resumed when the new one is
        // created).
    }

    override fun onActivityStarted(activity: Activity) {
        // No-op. onResumed is the canonical "this is the top-most".
    }

    override fun onActivityResumed(activity: Activity) {
        topActivityRef = WeakReference(activity)
    }

    override fun onActivityPaused(activity: Activity) {
        // Only clear the reference if we ARE the top activity. This
        // handles the A → B transition: the platform fires
        // B.onResume → B.onStart → A.onPause, so by the time we get
        // A.onPause the topActivityRef is already pointing at B and
        // we mustn't null it out. Equality on the underlying Activity
        // pointer (===) is what we want — the WeakReference may have
        // already been cleared by the GC, in which case we no-op.
        val current = topActivityRef.get()
        if (current === activity) {
            // Don't null-out the ref on pause — the user might still
            // re-resume this same Activity (e.g. a transient dialog
            // dismissed). Leave the WeakReference in place; if the
            // Activity is destroyed later the GC reclaims it and
            // `currentActivity()` correctly returns null.
        }
    }

    override fun onActivityStopped(activity: Activity) {
        // No-op. onDestroyed is where we let go.
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        // No-op.
    }

    override fun onActivityDestroyed(activity: Activity) {
        val current = topActivityRef.get()
        if (current === activity) {
            // Explicit reset — even though the WeakReference would
            // eventually clear on its own, having a synchronous null
            // here means subsequent currentActivity() returns null
            // immediately rather than depending on GC scheduling.
            topActivityRef = WeakReference<Activity>(null)
        }
    }
}
