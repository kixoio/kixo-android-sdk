package io.kixo.sdk.internal.replay.upload

import android.util.Log
import io.kixo.sdk.internal.replay.ReplayCapture
import io.kixo.sdk.internal.replay.ReplayConfig
import io.kixo.sdk.internal.replay.ReplayController
import io.kixo.sdk.internal.replay.ReplayUploaderRef

/**
 * Boundary translator between Agent 13's
 * [io.kixo.sdk.internal.replay.ReplayController.ReplayUploaderRef]
 * stub interface and Agent 14's concrete pipeline pair
 * ([ReplayUploader] + [ReplaySessionLifecycle]).
 *
 * **Why an adapter exists at all.** Per AGENT_BRIEFING §6, each
 * agent's folder declares stub interfaces for cross-folder calls
 * rather than depending on another agent's concrete types. The
 * controller's stub shape (`beginSession(config)` /
 * `uploadCapture(capture)` / `endSession()`) was authored before the
 * concrete uploader's shape (`openSession(...)` /
 * `uploadFrame(seq, kind, ...)` / `closeSession(reason)`) was nailed
 * down. Rather than churn either side, this adapter is the seam.
 *
 * **What the seam does:**
 *
 * - [beginSession] maps to [ReplaySessionLifecycle.openSession]. The
 *   per-session metadata that openSession needs (`sessionId`,
 *   `installationId`, `userId`, `releaseId`, `triggers`, `region`,
 *   `flags`) is NOT part of [ReplayConfig]; the lifecycle/identity
 *   tracker collects them and the bootstrap (which constructs this
 *   adapter) supplies them via constructor `*Provider` lambdas. They
 *   are read at `beginSession` time so a userId update between
 *   construction and session-start is honoured.
 *
 * - [uploadCapture] fans a single [ReplayCapture] into 2-4 calls to
 *   [ReplayUploader.uploadFrame] — one per [FrameKind] that has a
 *   payload (PRE if `preFrame` non-null, POST if `postFrame` non-null,
 *   STRUCTURAL if `structuralJson` non-null, OCR if `ocrText`
 *   non-empty). The interaction metadata + screen identity rides on
 *   the FIRST call's `eventMeta` map (so `/api/sdk/replay/events` gets
 *   one row per gesture, not 2-4). Subsequent fan-out calls pass an
 *   empty `eventMeta` so the batcher only enqueues the gcs_path
 *   enrichment when there's nothing else to bundle. Fan-out order is
 *   deterministic (PRE before POST before STRUCTURAL before OCR) so
 *   the `pre_frame_path` lands on the same event row as the
 *   interaction meta.
 *
 * - [endSession] maps to
 *   [ReplaySessionLifecycle.closeSession] with reason
 *   [ReplaySessionLifecycle.EndReason.FOREGROUND_TO_BACKGROUND] —
 *   the typical caller is `appBackgrounded` /
 *   `Kixo.flush()`. Opt-out / low-memory / superseded reasons are
 *   surfaced from the controller via dedicated paths that bypass
 *   this adapter.
 *
 * **Anti-crash.** Per AGENT_BRIEFING §3 R6, every error path swallows
 * + logs. A null `activeUploader()` (race window where the lifecycle
 * sealed mid-call) drops the capture silently with a debug log.
 */
internal class ReplayUploaderAdapter(
    private val uploader: ReplayUploader,
    private val lifecycle: ReplaySessionLifecycle,
    /**
     * Per-session metadata providers. Read at [beginSession] time so
     * the bootstrap doesn't have to hold a stale snapshot. Defaults
     * are safe no-ops — caller wires the real producers (Agent 15's
     * IdentityManager + Agent 7's session tracker).
     */
    private val sessionIdProvider: () -> String,
    private val installationIdProvider: () -> String,
    private val userIdProvider: () -> String? = { null },
    private val releaseIdProvider: () -> String = { "" },
    private val triggersProvider: () -> List<String> = { listOf("baseline") },
    private val regionProvider: () -> String = { "us" },
    private val flagsProvider: () -> Map<String, Boolean>? = { null },
) : ReplayUploaderRef {

    /**
     * Open the backend session. Delegates to
     * [ReplaySessionLifecycle.openSession]; success is silent, failure
     * is logged + swallowed (the controller will keep working — frames
     * will pile up against the now-null `activeUploader()` and be
     * dropped one by one with debug logs).
     */
    override suspend fun beginSession(config: ReplayConfig) {
        try {
            val ok = lifecycle.openSession(
                sessionId = sessionIdProvider(),
                installationId = installationIdProvider(),
                userId = userIdProvider(),
                releaseId = releaseIdProvider(),
                triggers = triggersProvider(),
                region = regionProvider(),
                flags = flagsProvider(),
            )
            if (!ok) {
                Log.d(TAG, "lifecycle.openSession returned false; controller will keep retrying captures (each will drop)")
            }
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle.openSession threw", t)
        }
    }

    /**
     * Fan a single [ReplayCapture] into 1-4 [ReplayUploader.uploadFrame]
     * calls. The interaction + screen-identity metadata rides on the
     * first call so `/api/sdk/replay/events` gets one event row per
     * gesture (subsequent calls pass empty `eventMeta`).
     *
     * Bitmap ownership: [ReplayUploader.uploadFrame] encodes the
     * Bitmap to a JPEG byte array but does NOT recycle the source.
     * iOS hands back an autoreleased `UIImage` here; on Android we
     * lean on the GC plus the controller's [ReplayCapture] going out
     * of scope after this call. Hot-path bitmaps are large but few in
     * flight (max 3 per [ReplayConfig.maxConcurrentCaptures]).
     */
    override suspend fun uploadCapture(capture: ReplayCapture) {
        // If the lifecycle sealed between the controller dispatching
        // and us being scheduled (race window), silently drop. The
        // event timeline still records the gesture via Agent 5's
        // EventQueue — we just lose the frame.
        val live = lifecycle.activeUploader()
        if (live == null) {
            Log.d(TAG, "uploadCapture (seq=${capture.seq}) dropped: no active session")
            return
        }

        // Build the metadata we attach to the FIRST kind in the fan-out
        // (so each gesture lands as exactly one row in
        // session_replay_events). Mirrors iOS sidecar shape — see
        // `kixo-ios-sdk/Sources/Kixo/Replay/ReplayController.swift`
        // lines 2087-2117.
        val firstMeta = HashMap<String, Any?>(8).apply {
            putAll(capture.interaction.toPropertyMap())
            capture.screenIdentity?.let { put("screen_hash", it.hash) }
        }
        var metaUsed = false

        // Deterministic order — PRE before POST before STRUCTURAL
        // before OCR — so `pre_frame_path` lands on the same event row
        // as the interaction meta when both are present.
        if (capture.preFrame != null) {
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.PRE,
                bitmap = capture.preFrame,
                eventMeta = firstMeta,
            )
            metaUsed = true
        }

        if (capture.postFrame != null) {
            val meta = if (!metaUsed) firstMeta.also { metaUsed = true } else emptyMap()
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.POST,
                bitmap = capture.postFrame,
                eventMeta = meta,
            )
        }

        if (capture.structuralJson != null) {
            val meta = if (!metaUsed) firstMeta.also { metaUsed = true } else emptyMap()
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.STRUCTURAL,
                structuralJson = capture.structuralJson.toString(),
                eventMeta = meta,
            )
        }

        if (capture.ocrText.isNotEmpty()) {
            val meta = if (!metaUsed) firstMeta.also { metaUsed = true } else emptyMap()
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.OCR,
                ocrText = capture.ocrText,
                eventMeta = meta,
            )
        }

        // Edge case: capture had no payloads at all (pre/post both
        // null, structural null, ocr empty). Still ship the metadata
        // event so the gesture is on the timeline. Use the OCR slot
        // (lightest payload) with empty text — uploadFrame's encoder
        // returns null on null OCR text, which falls through to the
        // "drop frame, keep event" branch in ReplayUploader. The
        // gesture lands on /replay/events with no gcs_path and the
        // player renders a metadata-only marker.
        if (!metaUsed) {
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.OCR,
                ocrText = null,
                eventMeta = firstMeta,
            )
        }
    }

    /**
     * Seal the session via
     * [ReplaySessionLifecycle.closeSession]. Default reason is
     * [ReplaySessionLifecycle.EndReason.FOREGROUND_TO_BACKGROUND] —
     * the only path that flows through this adapter is the
     * controller's normal `stop()`. Opt-out / low-memory / app-killed
     * sealings are dispatched directly via the lifecycle (the
     * controller handles those out-of-band).
     */
    override suspend fun endSession() {
        try {
            lifecycle.closeSession(ReplaySessionLifecycle.EndReason.FOREGROUND_TO_BACKGROUND)
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle.closeSession threw", t)
        }
    }

    companion object {
        private const val TAG = "Kixo.ReplayUploaderAdapter"
    }
}
