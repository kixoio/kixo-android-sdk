package io.kixo.sdk.internal.queue

/**
 * Builds the wire-format payload sent to `/api/sdk/batch`.
 *
 * Bridges three sources of state into a single serialisable record:
 *   - **Static SDK config** (project_id, api_key, environment, app
 *     version, bundle id) — read from [ConfigHolder].
 *   - **Resolved release_id** — populated after `/api/sdk/init`,
 *     read from [ConfigHolder.snapshot].releaseId.
 *   - **Live device context** — read from the [DeviceInfo] dependency
 *     (Agent 6 owns; we declare a stub interface below + document).
 *   - **The events themselves** — passed in by the caller (typically
 *     [EventQueue] after a `store.checkout`).
 *
 * Wire shape (snake_case, see iOS `Transport.swift` `BatchPayload`):
 *
 * ```json
 * {
 *   "project_id": "kx_proj_…",
 *   "api_key": "kx_key_…",
 *   "platform": "android",
 *   "environment": "development",
 *   "sdk_version": "0.1.0",
 *   "app_version": "1.2.3",
 *   "bundle_id": "com.example.myapp",
 *   "release_id": "<from /api/sdk/init>",
 *   "context": { … enriched device/os/runtime context … },
 *   "batch": [ … events … ],
 *   "sent_at": "ISO8601"
 * }
 * ```
 *
 * **Why is this a separate class from the transport?** The transport
 * (Agent 4) is responsible for HTTP — building the request, parsing
 * the response, mapping status codes to outcomes. Assembling the
 * payload BODY is queue-side concern: the queue knows which events
 * are in this batch, has access to [ConfigHolder] (the queue's the
 * primary consumer) and is the natural owner of the "shape what
 * we're about to send" step. Splitting it out also keeps the
 * transport's mocking surface tiny — the test stub returns
 * `BatchResponse`, doesn't need to fabricate a real payload.
 *
 * **Stub dependencies (declared below per AGENT_BRIEFING.md §6):**
 * we don't own the `DeviceInfo`, `KixoEvent`, `BatchPayload`, or
 * `EnrichedContext` types, so we declare narrow interface stubs
 * here and let the owning agents land the real implementations.
 * When they do, the queue compiles unchanged — the stubs become
 * pass-through aliases or they swap in their concrete types.
 */
internal class BatchPayloadAssembler(
    private val deviceInfo: DeviceInfo,
    private val configHolder: ConfigHolder = ConfigHolder,
) {

    // The default `ConfigHolder` argument lets call sites omit the
    // singleton in the common case — tests inject a different one
    // by overriding the parameter directly.

    /**
     * Wrap [events] into a [BatchPayload] ready for serialisation.
     *
     * Reads the live config snapshot once at the top so the resulting
     * payload is internally consistent (a parallel `setReleaseId(...)`
     * during the call won't half-update the result).
     *
     * @param events The events being shipped in this batch. Caller
     *        is responsible for size limits — the assembler doesn't
     *        impose any.
     * @return A [BatchPayload] populated with the current config +
     *         the live device context. The transport layer is
     *         responsible for serialising this to JSON.
     */
    fun assemble(events: List<KixoEvent>): BatchPayload {
        // Snapshot the config ONCE so a concurrent `set` / `setReleaseId`
        // doesn't tear the resulting payload across two snapshot reads.
        val cfg = configHolder.snapshot()

        return BatchPayload(
            projectId = cfg.projectId,
            apiKey = cfg.apiKey,
            platform = ANDROID_PLATFORM,
            environment = cfg.environment,
            sdkVersion = SDK_VERSION,
            appVersion = cfg.appVersion,
            bundleId = cfg.bundleId,
            releaseId = cfg.releaseId,
            context = deviceInfo.enrichedContext(),
            batch = events,
            // Wall-clock instant the SDK released this batch — the
            // backend uses (sent_at - earliest_event_timestamp) as
            // a "queue staleness" signal for monitoring. Use ISO8601
            // formatting at serialisation time (transport's
            // responsibility); we just stamp the millisecond here.
            sentAtEpochMs = System.currentTimeMillis(),
        )
    }

    private companion object {
        /**
         * Wire token for the `platform` field. Backend's batch route
         * branches on this to pick the right per-event projector
         * (e.g. iOS-specific `screen_view` properties differ from
         * Android's). Keep stable.
         */
        const val ANDROID_PLATFORM: String = "android"

        /**
         * SDK semver in the wire payload. Used by the backend's
         * SDK-version registry + kill-switch to decide whether to
         * accept the batch (per `project_bulletproof_pass.md`).
         *
         * **Caveat:** the source of truth for the version is
         * `BuildConfig.SDK_VERSION` (declared in `kixo/build.gradle.kts`
         * as `buildConfigField "String", "SDK_VERSION", "\"0.1.0\""`).
         * We mirror it as a const here because directly importing
         * `io.kixo.sdk.BuildConfig` from a unit-test module path
         * would require the BuildConfig generator to have run — which
         * a JVM-only test against this class can't guarantee. The
         * Transport layer reads from BuildConfig directly; this
         * fallback is a safety net for the rare assembly-driven path.
         *
         * If you bump the version in build.gradle.kts, bump it here.
         * (A future cleanup: have a single Kotlin constant in a
         * generated source set both the gradle field and this read.)
         */
        // Single-source-of-truth read from BuildConfig (the gradle
        // `buildConfigField` injected at build time). Wave 5 fixed
        // the prior hardcoded "0.1.0" that drifted past the gradle
        // version bump — log lines + wire payloads were stuck on
        // 0.1.0 even after the build version moved to alpha4.
        val SDK_VERSION: String = io.kixo.sdk.BuildConfig.SDK_VERSION
    }
}

// ─────────────────────────────────────────────────────────────────────
// Stub dependencies — owned by other agents; we declare what we need.
//
// Per AGENT_BRIEFING.md §6 file-ownership rule: "If you need a type
// they haven't built yet, declare a stub interface in YOUR folder and
// document the dependency at the top of the file."
//
// When the owning agent lands the real type, either:
//   (a) they conform to the same shape and we delete this stub, or
//   (b) we add a thin adapter in queue/ that maps their type to ours.
//
// Either way, the queue's call sites stay stable.
// ─────────────────────────────────────────────────────────────────────

/**
 * Live device + OS + runtime context. Owned by Agent 6 (`internal/context/`).
 *
 * Returns an [EnrichedContext] populated freshly on each call — the
 * SDK's context tracker (Agent 6) is responsible for cheaply
 * recomputing the volatile fields (battery level, connection type)
 * while caching the static ones (device model, os version).
 */
internal interface DeviceInfo {
    fun enrichedContext(): EnrichedContext
}

/**
 * Enriched device context object. Owned by Agent 6
 * (`internal/context/EnrichedContext.kt`). Mirrors the iOS struct of
 * the same name (see `kixo-ios-sdk/Sources/Kixo/Context/EnrichedContext.swift`).
 *
 * Declared as `interface` so the queue compiles before the data
 * class is in place. Real impl will be a `data class` with `device`,
 * `os`, `runtime`, `hardware`, `app` substructures — all
 * kotlinx.serialization-annotated. The transport serialises this
 * verbatim into the `"context"` field of the batch payload.
 */
internal interface EnrichedContext

/**
 * One event row. Owned by Agent 2 (`internal/model/KixoEvent.kt`).
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Models/Event.swift`'s
 * `KixoEvent` struct. We need only `eventId` from this stub for
 * the queue's bookkeeping (per-event ack reconciliation); the rest
 * of the fields don't matter at the queue layer — the transport
 * handles serialisation.
 */
internal interface KixoEvent {
    /** Stable UUID. Used as the SQLite PK and the per-event ack key. */
    val eventId: String

    /**
     * Wire `event_type` token. Used by [EventQueue.enqueue]'s dedup
     * branch to route identify/user_property/push_token events
     * through [IdentityDedup] before persisting.
     *
     * Stable strings (snake_case) — `"identify"`, `"user_property"`,
     * `"push_token"`. Other types fall through dedup and persist
     * unconditionally.
     */
    val eventType: String
}

/**
 * Final batch shape the transport ships. Owned by Agent 4
 * (`internal/transport/Transport.kt` / a sibling models file).
 *
 * Mirrors iOS's private `BatchPayload` struct in `Transport.swift`.
 * We declare it `data class` here so [BatchPayloadAssembler] can
 * actually instantiate it; when Agent 4 promotes it to a real
 * kotlinx-serializable model, this declaration is replaced by an
 * import.
 */
internal data class BatchPayload(
    val projectId: String,
    val apiKey: String,
    val platform: String,
    val environment: String,
    val sdkVersion: String,
    val appVersion: String,
    val bundleId: String,
    val releaseId: String,
    val context: EnrichedContext?,
    val batch: List<KixoEvent>,
    /**
     * Wall-clock millis. Transport converts to ISO-8601 at
     * serialisation time. Caller stamps once at assembly.
     */
    val sentAtEpochMs: Long,
)
