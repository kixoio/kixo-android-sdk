package io.kixo.sdk.internal.queue

import android.content.Context
import io.kixo.sdk.KixoConfiguration
import io.kixo.sdk.PushProvider
import io.kixo.sdk.internal.context.DeviceInfo as RealDeviceInfo
import io.kixo.sdk.internal.identity.IdentityManager
import io.kixo.sdk.internal.model.BatchPayload as RealBatchPayload
import io.kixo.sdk.internal.model.EnrichedContext as RealEnrichedContext
import io.kixo.sdk.internal.model.KixoEvent as RealKixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.model.toJsonElement
import io.kixo.sdk.internal.storage.EventStorageHelper
import io.kixo.sdk.internal.storage.EventStore as RealEventStore
import io.kixo.sdk.internal.storage.SqliteEventStore
import io.kixo.sdk.internal.transport.BatchOutcome
import io.kixo.sdk.internal.transport.HttpClientFactory
import io.kixo.sdk.internal.transport.Transport as RealTransport
import java.time.Instant
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/**
 * Bridges between Agent 5's parallel-universe stub types
 * (`queue.EventStore`, `queue.Transport`, `queue.KixoEvent`,
 * `queue.BatchPayload`, `queue.EnrichedContext`, `queue.DeviceInfo`)
 * and the real types shipped by Agents 2/3/4/6.
 *
 * Wave 1 isolated each agent in its own folder so they could be built
 * in parallel without contract negotiation. The cost: the queue
 * declared its own narrow interfaces that the real types **don't
 * implement**. Without this wiring, every `Kixo.track(...)` call
 * goes through `wiring()?.queueRef?.enqueueCustom(...)` where
 * `queueRef` is null — silent no-op, no events shipped.
 *
 * The right long-term fix is to drop the queue's stubs and have it
 * import the real types directly. That's a larger refactor of
 * EventQueue.kt + BatchPayloadAssembler.kt + IdentityDedup.kt.
 * For v0.1.0-alpha2 we ship adapters here; the refactor lives in
 * Wave 6.
 *
 * Per AGENT_BRIEFING.md §6 file-ownership: this file lives in
 * `internal/queue/` (Agent 5's folder) because the adapters
 * implement Agent 5's interfaces. Reading peer types is allowed,
 * modifying them is not — so the adapters wrap, never edit.
 */
internal object QueueWiring {

    /**
     * Build the live `EventQueue` + return an [EventQueueRef] suitable
     * for the public facade's `Wiring.queueRef` slot.
     *
     * Side effects (in order):
     *  1. Construct the real `SqliteEventStore` at `<filesDir>/kixo/events.db`
     *     and run `recoverInFlight()` once to re-claim crashed in-flight rows.
     *  2. Construct the shared `OkHttpClient` (debug-build logging on).
     *  3. Construct the real `Transport` against the configured base URL.
     *  4. Construct the queue-internal `BatchPayloadAssembler` with a
     *     `DeviceInfo` adapter.
     *  5. Seed `ConfigHolder` from the [KixoConfiguration] snapshot.
     *  6. Construct the queue with the bridged store + transport +
     *     assembler + a SupervisorJob-rooted scope.
     *  7. Return an [EventQueueRef] adapter that:
     *      - converts public-API `(eventType, eventName, properties)`
     *        triples to real [RealKixoEvent] data classes (stamping
     *        device_id / anonymous_id / user_id / session_id from
     *        IdentityManager + the live device context).
     *      - delegates flush / flushBlocking / stop to the queue.
     */
    fun build(
        context: Context,
        config: KixoConfiguration,
        identity: IdentityManager,
        deviceInfo: RealDeviceInfo,
        releaseId: String? = null,
    ): KixoEventQueueRef {
        // 1. Real store + recover in-flight. The Helper builds the
        //    SupportSQLiteOpenHelper (lazy file create at /filesDir/kixo/),
        //    SqliteEventStore wraps it.
        val storeReal: RealEventStore = SqliteEventStore(EventStorageHelper(context).create())
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch { storeReal.recoverInFlight() }

        // 2. + 3. HTTP client + transport. Logging on in debug.
        val httpClient = HttpClientFactory.create(enableLogging = config.debug)
        val json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = false
        }
        val transportReal = RealTransport(
            httpClient = httpClient,
            baseUrl = config.apiHost,
            json = json,
        )

        // 4. + 5. Seed ConfigHolder from the user's KixoConfiguration so
        //    BatchPayloadAssembler.assemble() reads the right env / creds.
        ConfigHolder.set(
            ConfigHolder.Snapshot(
                projectId = config.projectId,
                apiKey = config.apiKey,
                environment = config.environment,
                apiHost = config.apiHost,
                appVersion = appVersion(context),
                bundleId = context.packageName,
                releaseId = releaseId.orEmpty(),
                maxBufferSize = 200,
                flushAt = 20,
                flushIntervalMs = 30_000L,
                debug = config.debug,
            ),
        )

        val assembler = BatchPayloadAssembler(
            deviceInfo = DeviceInfoAdapter(deviceInfo),
        )

        // 6. Queue itself. Bridge real store + transport into queue's
        //    stub interface shapes.
        val queue = EventQueue(
            store = EventStoreAdapter(storeReal),
            transport = TransportAdapter(transportReal),
            payloadAssembler = assembler,
            scope = scope,
            flushAt = 20,
            flushIntervalMs = 30_000L,
            maxBufferSize = 200,
        )

        // Default queue starts in Initialising — that gates flush.
        // `/api/sdk/init` wiring (Wave 6) is meant to flip us to
        // Running after the server confirms project + release; until
        // then, optimistically transition immediately so events
        // actually ship. Worst case if creds are wrong: backend
        // returns 401, queue's HttpError(permanent=true) path flips
        // us to PausedByServer("http_401"). Fail loud, not silent.
        queue.setLifecycleState(LifecycleState.Running)

        // 7. Public-facade-facing adapter.
        return KixoEventQueueRef(queue, identity, deviceInfo)
    }

    private fun appVersion(context: Context): String =
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
        } catch (_: Throwable) {
            "0.0.0"
        }
}

// ─── store adapter ─────────────────────────────────────────────────

/**
 * Adapts `internal.storage.EventStore` (real) to
 * `internal.queue.EventStore` (Agent 5's stub).
 *
 * - `clear` (real) → `clearAll` (queue's stub).
 * - `KixoEvent` types differ: real is the `@Serializable data class`,
 *   queue's is a narrow `interface`. We wrap each returned event in
 *   [KixoEventAdapter] before handing back. Going the other way
 *   (`append(queue.KixoEvent)`), we expect every `queue.KixoEvent`
 *   passed in to actually be a [KixoEventAdapter] (the only thing
 *   that constructs them). Defensive ClassCastException would crash;
 *   we catch + log instead per R6.
 */
private class EventStoreAdapter(private val real: RealEventStore) : EventStore {
    override suspend fun append(event: KixoEvent) {
        val realEvent = unwrap(event) ?: return
        real.append(realEvent)
    }

    override suspend fun checkout(limit: Int): List<KixoEvent> =
        real.checkout(limit).map { KixoEventAdapter(it) }

    override suspend fun confirm(eventIds: List<String>) =
        real.confirm(eventIds)

    override suspend fun release(eventIds: List<String>) =
        real.release(eventIds)

    override suspend fun pendingCount(): Int = real.pendingCount()

    override suspend fun clearAll() = real.clear()

    private fun unwrap(event: KixoEvent): RealKixoEvent? =
        (event as? KixoEventAdapter)?.real
}

// ─── KixoEvent adapter ─────────────────────────────────────────────

/**
 * Wraps a real `model.KixoEvent` so it satisfies the queue's narrow
 * `KixoEvent` interface + the optional `DedupAwareEvent` helper
 * interface (so identify / user_property / push_token dedup works).
 *
 * The adapter exposes ONLY what the queue reads. The real event
 * keeps its full schema for (de)serialization at the transport
 * boundary — see [TransportAdapter] for the conversion path.
 */
internal class KixoEventAdapter(val real: RealKixoEvent) : KixoEvent, DedupAwareEvent {
    override val eventId: String = real.eventId
    override val eventType: String = real.eventType.name.lowercase()
    override val userId: String? = real.userId
    override val properties: Map<String, Any?> by lazy { jsonObjectToMap(real.properties) }

    private fun jsonObjectToMap(obj: JsonObject): Map<String, Any?> {
        // Lossy by design: we only need primitive equality for dedup
        // hashing. Nested structure is preserved as nested Map/List
        // by recursive elementToAny.
        return obj.entries.associate { (k, v) -> k to JsonAnyConverter.toAny(v) }
    }
}

private object JsonAnyConverter {
    fun toAny(el: kotlinx.serialization.json.JsonElement): Any? {
        return when (el) {
            is kotlinx.serialization.json.JsonNull -> null
            is kotlinx.serialization.json.JsonPrimitive -> when {
                el.isString -> el.content
                el.content == "true" -> true
                el.content == "false" -> false
                el.content.toLongOrNull() != null -> el.content.toLong()
                el.content.toDoubleOrNull() != null -> el.content.toDouble()
                else -> el.content
            }
            is kotlinx.serialization.json.JsonObject ->
                el.entries.associate { (k, v) -> k to toAny(v) }
            is kotlinx.serialization.json.JsonArray ->
                el.map { toAny(it) }
        }
    }
}

// ─── transport adapter ────────────────────────────────────────────

/**
 * Bridges the queue's `Transport` interface (returns `BatchResponse`)
 * to the real `internal.transport.Transport` (returns `BatchOutcome`).
 *
 * Conversions:
 *  - Real `BatchOutcome.Success(acceptedIds, transientIds, permanentIds, paused, …)`
 *    → queue's `BatchResponse.Success(acceptedEventIds = acceptedIds,
 *      errors = permanentIds.map { permanent EventError } + transientIds.map { transient EventError },
 *      paused, pausedReason)`.
 *  - Real `BatchOutcome.HttpError(code, transient)` →
 *    queue's `BatchResponse.HttpError(statusCode = code, permanent = !transient)`.
 *  - Real `BatchOutcome.NetworkError(cause)` → queue's `BatchResponse.NetworkError`.
 *  - Real `BatchOutcome.SerializationError` → queue's
 *    `BatchResponse.HttpError(400, permanent = true)` (our payload
 *    is broken — drop, looping forever on a bad payload would burn
 *    quota AND never recover).
 *
 * Also bridges queue's stub `BatchPayload` → real `model.BatchPayload`.
 */
private class TransportAdapter(private val real: RealTransport) : Transport {
    override suspend fun postBatch(payload: BatchPayload): BatchResponse {
        val realPayload = toRealPayload(payload)
        return when (val outcome = real.postBatch(realPayload)) {
            is BatchOutcome.Success -> BatchResponse.Success(
                acceptedEventIds = outcome.acceptedIds,
                errors = buildErrors(outcome.permanentIds, outcome.transientIds),
                paused = outcome.paused,
                pausedReason = outcome.pausedReason,
            )
            is BatchOutcome.HttpError -> BatchResponse.HttpError(
                statusCode = outcome.code,
                permanent = !outcome.transient,
            )
            is BatchOutcome.NetworkError -> BatchResponse.NetworkError
            BatchOutcome.SerializationError -> BatchResponse.HttpError(
                statusCode = 400,
                permanent = true,
            )
        }
    }

    private fun buildErrors(permanent: List<String>, transient: List<String>): List<EventError> =
        permanent.map { EventError(eventId = it, message = "permanent", permanent = true) } +
            transient.map { EventError(eventId = it, message = "transient", permanent = false) }

    private fun toRealPayload(p: BatchPayload): RealBatchPayload {
        // Unwrap each event back to its real form. Anything not from
        // [KixoEventAdapter] is silently dropped (defensive — this
        // shouldn't happen since enqueue always wraps).
        val realEvents: List<RealKixoEvent> = p.batch.mapNotNull { (it as? KixoEventAdapter)?.real }
        // Real `EnrichedContext` is the queue's `EnrichedContext`
        // because [DeviceInfoAdapter] returns the real type wrapped
        // as the queue's interface. Cast back is safe.
        val realCtx: RealEnrichedContext? = (p.context as? EnrichedContextAdapter)?.real
        return RealBatchPayload(
            projectId = p.projectId,
            apiKey = p.apiKey,
            platform = p.platform,
            environment = p.environment,
            sdkVersion = p.sdkVersion,
            appVersion = p.appVersion,
            bundleId = p.bundleId,
            releaseId = p.releaseId,
            context = realCtx,
            batch = realEvents,
            sentAt = Instant.ofEpochMilli(p.sentAtEpochMs),
        )
    }
}

// ─── DeviceInfo + EnrichedContext adapters ────────────────────────

/**
 * Adapts the real `internal.context.DeviceInfo` (returns real
 * `model.EnrichedContext`) to the queue's stub `DeviceInfo` interface
 * (returns the queue's stub `EnrichedContext` interface).
 *
 * The wrap is just an identity passthrough — the queue's interface
 * is a marker only; we hand back the real type wearing the stub
 * label. [TransportAdapter] casts back to the real type when
 * assembling the wire payload.
 */
private class DeviceInfoAdapter(private val real: RealDeviceInfo) : DeviceInfo {
    override fun enrichedContext(): EnrichedContext =
        EnrichedContextAdapter(real.enrichedContext())
}

private class EnrichedContextAdapter(val real: RealEnrichedContext) : EnrichedContext

// ─── EventQueueRef adapter (public-facade-facing) ─────────────────

/**
 * Implements the public facade's `Kixo.EventQueueRef` interface by
 * wrapping the real `EventQueue`.
 *
 * `enqueueCustom(eventType, eventName, properties)` builds a complete
 * real [RealKixoEvent] (UUID event_id + live identity stamps + map →
 * JsonObject conversion) and routes through `EventQueue.enqueue()`
 * via a launch on the queue's scope (the public API is non-suspend).
 */
internal class KixoEventQueueRef(
    private val queue: EventQueue,
    private val identity: IdentityManager,
    private val deviceInfo: RealDeviceInfo,
) {
    fun enqueueCustom(eventType: String, eventName: String, properties: Map<String, Any?>) {
        val realEvent = RealKixoEvent(
            eventId = UUID.randomUUID().toString(),
            deviceId = identity.deviceId(),
            anonymousId = identity.anonymousId(),
            userId = identity.userId(),
            sessionId = currentSessionId(),
            fingerprint = currentFingerprint(),
            eventType = wireToEnum(eventType),
            eventName = eventName,
            properties = properties.toJsonElement(),
            timestamp = Instant.now(),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(KixoEventAdapter(realEvent))
    }

    fun flush() = queue.flush()
    fun flushBlocking(timeoutMs: Long): Boolean = queue.flushBlocking(timeoutMs)
    fun stop(reason: String) = queue.stop(reason)

    private fun currentSessionId(): String =
        io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap.currentSessionId()
            ?: "boot-${UUID.randomUUID()}"

    private fun currentFingerprint(): String =
        io.kixo.sdk.internal.screen.ScreenIdentity.current().screenId

    private fun wireToEnum(eventType: String): KixoEventType {
        // Defensive: backend rejects unknown event_types as permanent
        // failures, so mapping to .Custom is the safe sink for
        // unrecognised tokens (mirrors iOS). Match against @SerialName
        // wire value (snake_case), not enum constant name (PascalCase).
        return KixoEventType.values().firstOrNull { enumWireValue(it) == eventType }
            ?: KixoEventType.Custom
    }

    private fun enumWireValue(t: KixoEventType): String {
        // Cheap mapping — kotlinx.serialization @SerialName is what we
        // need but its lookup requires reflection; the enum's `name`
        // field is reachable from the constant's declaration order.
        // This mirrors `Json.encodeToString(serializer, t).removeSurrounding("\"")`
        // without paying serialization cost per enqueue.
        return when (t) {
            KixoEventType.ScreenView -> "screen_view"
            KixoEventType.Tap -> "tap"
            KixoEventType.Scroll -> "scroll"
            KixoEventType.Network -> "network"
            KixoEventType.Crash -> "crash"
            KixoEventType.Custom -> "custom"
            KixoEventType.SessionStart -> "session_start"
            KixoEventType.SessionEnd -> "session_end"
            KixoEventType.Identify -> "identify"
            KixoEventType.Group -> "group"
            KixoEventType.Lifecycle -> "lifecycle"
            KixoEventType.Navigation -> "navigation"
            KixoEventType.Gesture -> "gesture"
            KixoEventType.PushOpen -> "push_open"
            KixoEventType.PushReceived -> "push_received"
            KixoEventType.PushDismissed -> "push_dismissed"
            KixoEventType.PushSilent -> "push_silent"
            KixoEventType.PushAction -> "push_action"
            KixoEventType.PushPermission -> "push_permission"
            KixoEventType.PushTokenInvalidated -> "push_token_invalidated"
            KixoEventType.DeepLink -> "deep_link"
            KixoEventType.Iap -> "iap"
            KixoEventType.UserProperty -> "user_property"
            KixoEventType.ScreenVisit -> "screen_visit"
            KixoEventType.Goal -> "goal"
        }
    }
}

/**
 * Helper to launch a suspend `enqueue` from the non-suspend public API
 * surface. Lives on the queue's own scope so cancellation is consistent.
 */
private fun EventQueue.enqueueAsync(event: KixoEvent) {
    // The queue itself owns the scope, but we don't have direct access
    // to it here. Use a process-global SDK scope rooted in SupervisorJob
    // so a single failed enqueue doesn't tear peers down.
    SdkScope.launch { enqueue(event) }
}

private object SdkScope : CoroutineScope by CoroutineScope(SupervisorJob() + Dispatchers.Default)
