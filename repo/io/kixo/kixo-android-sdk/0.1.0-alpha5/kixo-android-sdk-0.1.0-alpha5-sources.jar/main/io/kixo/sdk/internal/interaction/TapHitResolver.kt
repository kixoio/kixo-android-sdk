package io.kixo.sdk.internal.interaction

import android.app.Activity
import android.content.res.Resources
import android.graphics.Rect
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

/**
 * Resolves a window-coordinate tap point to the most specific view
 * underneath it, then extracts a small set of human-readable
 * attributes to label the resulting `tap` event.
 *
 * Mirrors the iOS `WindowEventInterceptor.handleTap` behaviour where
 * the window's `hitTest(loc, with: nil)` returns the deepest
 * `UIView`, and a downstream label-resolver pulls
 * `accessibilityLabel`, `text`, and the type name as fallbacks.
 *
 * **Why we walk the tree manually rather than calling
 * `decorView.dispatchTouchEvent` for hit-testing:** the platform's
 * touch dispatch is intercept-aware and consumes events. We want a
 * READ-ONLY query — "what view is at (x, y)?" — without involving
 * the dispatch chain. The recursive walk is O(depth), and for typical
 * Android view trees (depth ≤ 30) is comfortably under 1 ms even on
 * a low-end device.
 *
 * **PII safeguard.** We DO read `TextView.text` to label the tap
 * (e.g. event_name = "Sign in" for a button). Per AGENT_BRIEFING.md
 * R2, password fields MUST be skipped — the iOS SDK explicitly
 * blacklists `UITextField.isSecureTextEntry`. The Android equivalent
 * is `EditText` with `inputType` containing one of the password /
 * email / phone variations. The redaction-eligible fields are
 * checked here AND in Agent 10's `PIIFilter`; defence in depth.
 *
 * Caller MUST pass an `Activity` reference acquired from
 * `Application.ActivityLifecycleCallbacks`. We never hold this
 * reference past the synchronous call (briefing anti-example §11).
 */
internal object TapHitResolver {

    private const val TAG = "Kixo"

    /**
     * Find the deepest visible view at window coordinates ([x], [y])
     * and return a [TapTarget] describing it. Returns
     * [TapTarget.UNKNOWN] when nothing meaningful resolves (e.g. tap
     * landed on a system bar that the activity doesn't own).
     */
    fun resolve(activity: Activity, x: Float, y: Float): TapTarget {
        return try {
            val root = activity.window?.decorView ?: return TapTarget.UNKNOWN
            val deepest = findDeepestHit(root, x.toInt(), y.toInt())
                ?: return TapTarget.UNKNOWN
            extract(deepest)
        } catch (t: Throwable) {
            // Briefing R6: NEVER let a label-resolver crash the host.
            // Tap will still emit; just without a friendly name.
            Log.w(TAG, "TapHitResolver failed", t)
            TapTarget.UNKNOWN
        }
    }

    /**
     * Recursive deepest-first walk. Returns the deepest visible
     * `View` whose hit-rect (in window coordinates) contains the
     * point. We use `getLocationInWindow` rather than `getGlobalVisibleRect`
     * so off-screen-but-clipped portions of a view are correctly
     * excluded.
     */
    private fun findDeepestHit(view: View, x: Int, y: Int): View? {
        if (view.visibility != View.VISIBLE) return null
        val loc = IntArray(2)
        view.getLocationInWindow(loc)
        val rect = Rect(loc[0], loc[1], loc[0] + view.width, loc[1] + view.height)
        if (!rect.contains(x, y)) return null

        if (view is ViewGroup) {
            // Walk children back-to-front (Android draws front-to-back
            // by index, so the LAST child is on top visually). The
            // first match found from the top is what the user sees.
            for (i in view.childCount - 1 downTo 0) {
                val child = view.getChildAt(i) ?: continue
                val hit = findDeepestHit(child, x, y)
                if (hit != null) return hit
            }
        }
        return view
    }

    /**
     * Pull a small set of identifying attributes from a hit view.
     * Field priority for `event_name` is determined by the caller
     * (typically: resource entry name → text → contentDescription →
     * class name) so this method just gathers everything once.
     *
     * **PII filter (Critic 4 HIGH).** Both `text` and
     * `contentDescription` are read from arbitrary host-app views and
     * routinely carry PII in real-world apps — a button labelled
     * "Send to alex@example.com", a row a11y label "Card ending 4242".
     * We pass both through the privacy package's
     * [io.kixo.sdk.internal.privacy.PiiFilter.redact] before they
     * land in [TapTarget] so emails / phones / SSNs / Luhn-card /
     * JWTs / IBANs become `[email]` / `[phone]` / `[ssn]` / etc.
     * Resource entry name is dev-controlled (xml id) so it skips
     * the filter — sanitising those would corrupt event-name analytics
     * for legitimate ids like `email_input_field`.
     */
    private fun extract(view: View): TapTarget {
        val resourceName = safeResourceName(view)
        val rawText = safeText(view)
        val rawA11y = view.contentDescription?.toString()?.takeIf { it.isNotBlank() }
        val className = view.javaClass.simpleName
        val redact = piiRedactor()
        return TapTarget(
            viewClassName = className,
            contentDescription = rawA11y?.let(redact),
            text = rawText?.let(redact),
            resourceEntryName = resourceName,
        )
    }

    /**
     * Reflection-cached `(String) -> String` redactor. We don't
     * declare a hard import on [io.kixo.sdk.internal.privacy.PiiFilter]
     * because Agent 8's interaction folder shouldn't compile against
     * Agent 10's package per AGENT_BRIEFING §6 file-ownership rule —
     * the wiring should ideally come via constructor injection from
     * Agent 1's bootstrap. Until that bootstrap lands, reflection is
     * the loose-coupling stand-in. Identity fallback when the privacy
     * module isn't on the classpath (best-effort contract).
     */
    @Volatile
    private var cachedRedactor: ((String) -> String)? = null

    private fun piiRedactor(): (String) -> String {
        cachedRedactor?.let { return it }
        val resolved: (String) -> String = try {
            val cls = Class.forName("io.kixo.sdk.internal.privacy.PiiFilter")
            val ctor = cls.getDeclaredConstructor(
                Class.forName("io.kixo.sdk.internal.privacy.EntityTagger"),
            )
            ctor.isAccessible = true
            val instance = ctor.newInstance(null as Any?)
            val redactMethod = cls.getMethod("redact", String::class.java)
            val fn: (String) -> String = { input ->
                try {
                    (redactMethod.invoke(instance, input) as? String) ?: input
                } catch (_: Throwable) {
                    input
                }
            }
            fn
        } catch (_: Throwable) {
            { it }
        }
        cachedRedactor = resolved
        return resolved
    }

    /**
     * Fetch the human-readable resource name for a view's id (e.g.
     * `"sign_in_button"` rather than `0x7f0a01a3`). Wrapped in a
     * try/catch because `Resources.getResourceEntryName` throws
     * `Resources.NotFoundException` when the id is `View.NO_ID`,
     * negative, or aapt-stripped.
     */
    private fun safeResourceName(view: View): String? {
        val id = view.id
        if (id == View.NO_ID || id <= 0) return null
        return try {
            view.context.resources.getResourceEntryName(id)
        } catch (_: Resources.NotFoundException) {
            null
        }
    }

    /**
     * Read the text of a view IF it is a [TextView] AND not a
     * password/email/phone-shaped input. We read pre-redaction text
     * because the resulting label flows into `event_name` which is
     * then re-sanitised by Agent 10's [PIIFilter] before serialisation
     * (defence in depth), but we still avoid the worst-offender
     * fields here so the wire never even sees plaintext credentials.
     *
     * Trims and length-caps to 64 chars — long button labels and
     * paragraph text are unlikely to be useful as event names and
     * inflate the wire payload.
     */
    private fun safeText(view: View): String? {
        if (view !is TextView) return null
        // EditText subclass: defer to inputType to decide whether
        // any of its text is safe to read at all.
        if (view is android.widget.EditText) {
            val type = view.inputType
            val variation = type and android.text.InputType.TYPE_MASK_VARIATION
            val klass = type and android.text.InputType.TYPE_MASK_CLASS
            val isPassword = variation == android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD ||
                variation == android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                variation == android.text.InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS ||
                klass == android.text.InputType.TYPE_CLASS_PHONE
            if (isPassword) return null
        }
        val raw = view.text?.toString() ?: return null
        val trimmed = raw.trim()
        if (trimmed.isEmpty()) return null
        return if (trimmed.length > 64) trimmed.substring(0, 64) else trimmed
    }
}

/**
 * Describes the most specific view a tap resolved to. All fields are
 * nullable because real apps have widely varying levels of
 * accessibility hygiene — many production buttons have no resource
 * id, no text, and no contentDescription. The caller picks the best
 * available label for `event_name`.
 */
internal data class TapTarget(
    val viewClassName: String?,
    val contentDescription: String?,
    val text: String?,
    val resourceEntryName: String?,
) {
    /**
     * Pick the most specific human-readable label. Preference order
     * matches iOS's `accessibilityLabel ?? text ?? type` hierarchy
     * with resource id as a strong first option (Android-specific).
     */
    fun bestLabel(): String? =
        resourceEntryName ?: text ?: contentDescription ?: viewClassName

    companion object {
        val UNKNOWN = TapTarget(
            viewClassName = null,
            contentDescription = null,
            text = null,
            resourceEntryName = null,
        )
    }
}
