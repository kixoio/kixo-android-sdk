package io.kixo.sdk.internal.storage

import android.content.Context
import android.util.Log
import androidx.annotation.VisibleForTesting
import androidx.sqlite.db.SupportSQLiteOpenHelper
import io.kixo.sdk.internal.attribution.AttributionContract
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.storage.EventStorageContract.COL_DATA
import io.kixo.sdk.internal.storage.EventStorageContract.COL_FLAG
import io.kixo.sdk.internal.storage.EventStorageContract.COL_ID
import io.kixo.sdk.internal.storage.EventStorageContract.COL_TIME
import io.kixo.sdk.internal.storage.EventStorageContract.DEFAULT_CHECKOUT_LIMIT
import io.kixo.sdk.internal.storage.EventStorageContract.DEFAULT_MAX_ROWS
import io.kixo.sdk.internal.storage.EventStorageContract.FLAG_IN_FLIGHT
import io.kixo.sdk.internal.storage.EventStorageContract.FLAG_PENDING
import io.kixo.sdk.internal.storage.EventStorageContract.TABLE_EVENTS
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Cross-cutting interface used by Agent 5's `EventQueue`. Implemented
 * by [SqliteEventStore] in production; tests can swap in a fake.
 *
 * **Ack-contract checkout pattern (Mixpanel MPDB):** the queue calls
 * [checkout] to claim up to N events, sends them, then calls
 * [confirm] for the ids the server accepted (`accepted_event_ids[]`)
 * + [confirm] for any errors with `permanent=true`, + [release] for
 * any errors with `permanent=false`. Rows the server didn't mention
 * at all remain durable and are retried; absence is never upgraded
 * into an acknowledgement.
 *
 * Why two methods (`confirm` + `release`) instead of one
 * `applyBatchAck(accepted, rejected)`: the iOS SDK has a single
 * `applyBatchAck` method, but the Android queue (Agent 5) processes
 * permanent-vs-transient failures separately upstream and just wants
 * "delete this list" / "reset this list" primitives. Composing the
 * three at the queue layer keeps this class honest about its job
 * (durable storage, not retry policy).
 */
internal interface EventStore {

    /** Append one event. May trigger a [trimOverflow] if buffer is full. */
    suspend fun append(event: KixoEvent): Boolean

    /** How many events are currently stored (any flag). Diagnostic + tests. */
    suspend fun pendingCount(): Int

    /**
     * Pull up to [limit] **pending** rows (flag=0), atomically mark
     * them as in-flight (flag=1), return the decoded events. Caller
     * MUST eventually call [confirm] or [release] for each returned
     * id; otherwise the row is stuck until the next process launch
     * (when [recoverInFlight] resets it).
     */
    suspend fun checkout(limit: Int = DEFAULT_CHECKOUT_LIMIT): List<KixoEvent>

    /** Permanent delete by id. Called after the server accepts a batch. */
    suspend fun confirm(eventIds: List<String>)

    /** Reset flag=0 by id. Called on transient batch failure for retry. */
    suspend fun release(eventIds: List<String>)

    /** Wipe all rows. For `Kixo.reset()` and after server-pause. */
    suspend fun clear()

    /**
     * Delete every buffered row for which [predicate] returns true,
     * and return how many rows were removed.
     *
     * Used for exactly one job today: reconciling the cold-start
     * buffer against the FIRST resolved project policy. Events
     * admitted during the pre-`/init` default-allow window belong to
     * categories the operator may have switched off; once the real
     * policy lands they must not reach the wire.
     *
     * Rows that fail to decode are never matched — we cannot judge
     * an unreadable row, so it is left alone (the FIFO cap reclaims
     * it eventually).
     */
    suspend fun deleteWhere(predicate: (KixoEvent) -> Boolean): Int

    /**
     * Reset every flag=1 row back to flag=0. Run once on init so events
     * the previous process started uploading but didn't get to ack
     * become eligible for retry. Idempotent.
     */
    suspend fun recoverInFlight()

    /**
     * If the table has > [maxRows] rows, delete the oldest (smallest
     * `time`) until the count is back at the cap. FIFO drop policy.
     * Called automatically from [append] but also exposed so the queue
     * can enforce a tighter cap on demand.
     */
    suspend fun trimOverflow(maxRows: Int = DEFAULT_MAX_ROWS)
}

/**
 * Durable, transactional event queue backed by a single SQLite db
 * (Mixpanel's MPDB pattern). Functional twin of the iOS
 * `SQLiteEventStore.swift`. Read its rationale-rich header comment
 * first if any of the following decisions look surprising.
 *
 * **Why SQLite, not files** (per iOS counterpart):
 *   - One file per event explodes inode usage and slows directory
 *     enumeration linearly with queue size.
 *   - File-system metadata locking serialises writes anyway; SQLite
 *     WAL mode parallelises READERS while still serialising writers.
 *   - Atomic batched DELETE on flush success is one statement vs N
 *     individual `unlink` syscalls.
 *   - Crash safety: WAL + checkpoint guarantees consistency of the
 *     queue as a whole; `FileOutputStream.write + fsync` per event
 *     would only guarantee individual files survive.
 *
 * **Why "flag" column instead of removing rows on checkout**
 * (Mixpanel MPDB): if we DELETE on checkout and the upload then
 * fails (or the process is killed mid-flight), those events are
 * lost. With the flag, a crash leaves the row in flag=1 state; the
 * next process launch's [recoverInFlight] resets it to flag=0 and
 * the next [checkout] re-claims it. Zero events lost across crashes.
 *
 * **Concurrency model:** a single [Mutex] over [Dispatchers.IO]. All
 * public methods do `withContext(io) { mutex.withLock { … } }`. We
 * do NOT use a `SingleThreadContext` because:
 *   1. It's `@DelicateCoroutinesApi` and requires explicit lifecycle
 *      (`close()` to avoid thread leaks).
 *   2. The DB only sees one statement at a time anyway thanks to the
 *      mutex, so the extra dedicated thread buys nothing.
 *   3. `Dispatchers.IO` is a shared, well-tuned pool; using it keeps
 *      our footprint small (R4 — bounded everything).
 *
 * Holding the mutex on a suspend function is safe because nothing
 * inside the lock can suspend (DB I/O is blocking but runs on IO).
 *
 * **Cross-agent dependency (declared per AGENT_BRIEFING.md §6):**
 * [io.kixo.sdk.internal.model.KixoEvent] is owned by Agent 2. We
 * require it to be `@Serializable` (kotlinx.serialization), to expose
 * a `String` field readable as `eventId`, and to round-trip cleanly
 * via `Json.encodeToString` / `Json.decodeFromString<KixoEvent>`.
 * If Agent 2 changes that contract this file breaks at compile time
 * (encode/decode call sites), which is the desired loud failure.
 */
internal class SqliteEventStore @VisibleForTesting internal constructor(
    private val helper: SupportSQLiteOpenHelper,
    private val json: Json = DEFAULT_JSON,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    private val maxRows: Int = DEFAULT_MAX_ROWS,
) : EventStore {

    /**
     * Production constructor — wires up the framework-backed helper
     * with our [EventStorageHelper] callback. The helper builds and
     * migrates the db lazily on first `writableDatabase` access.
     *
     * **CRITICAL constructor invariant:** the constructor is
     * side-effect-free — it does NOT touch the db, it does NOT launch
     * any coroutine, it does NOT run [recoverInFlight]. The SDK init
     * code (Agent 1's `Kixo.configure`) is responsible for invoking
     * `eventStore.recoverInFlight()` exactly once at startup, inside
     * its own `SupervisorJob`-rooted scope. Doing it here would force
     * `runBlocking` (R6 violation, blocks host) or `GlobalScope`
     * (lifecycle leak), neither of which is acceptable.
     *
     * Why "must run at startup, NOT on every checkout": running it
     * on every checkout would race with concurrent in-flight batches
     * (we'd reset flag=1 rows that a parallel checkout had legitimately
     * just claimed). One-shot at boot is the correct cadence.
     */
    constructor(
        context: Context,
        maxRows: Int = DEFAULT_MAX_ROWS,
    ) : this(
        helper = EventStorageHelper(context.applicationContext).create(),
        maxRows = maxRows,
    )

    /**
     * Single point of mutual exclusion. Guards every db touch so the
     * underlying SQLite handle (NOMUTEX-ish behavior in the framework
     * wrapper) only sees one statement at a time. SQLite is fine with
     * concurrent reads in WAL mode but our access pattern is mixed
     * (every checkout writes), so we serialize everything for
     * simplicity.
     */
    private val mutex = Mutex()

    // ─── EventStore impl ──────────────────────────────────────────

    override suspend fun append(event: KixoEvent): Boolean = withContext(ioDispatcher) {
        mutex.withLock {
            try {
                val blob = encodeBlob(event) ?: return@withLock false
                val id = event.eventId
                val now = System.currentTimeMillis().toDouble()
                helper.writableDatabase.run {
                    // INSERT OR REPLACE: idempotent on duplicate eventId.
                    // The SDK shouldn't reuse ids, but a retry-loop
                    // double-firing the same event must not error here
                    // (R6: never crash the host).
                    val sql = """
                        INSERT OR REPLACE INTO $TABLE_EVENTS
                            ($COL_ID, $COL_DATA, $COL_TIME, $COL_FLAG)
                        VALUES (?, ?, ?, $FLAG_PENDING);
                    """.trimIndent()
                    execSQL(sql, arrayOf(id, blob, now))
                }
                // Trim AFTER append, not before — append must be
                // O(1) regardless of buffer state, and the FIFO drop
                // step needs the new row in place to count it.
                trimLocked(maxRows)
                true
            } catch (t: Throwable) {
                // R6: never crash the host. A db-corruption / disk-full
                // here is bad, but losing one analytics event is much
                // better than crashing the customer's app.
                Log.w(TAG, "append failed for event ${event.eventId}", t)
                false
            }
        }
    }

    override suspend fun pendingCount(): Int = withContext(ioDispatcher) {
        mutex.withLock { pendingCountLocked() }
    }

    override suspend fun checkout(limit: Int): List<KixoEvent> = withContext(ioDispatcher) {
        mutex.withLock {
            if (limit <= 0) return@withLock emptyList()
            val claimed = mutableListOf<Pair<String, KixoEvent>>()
            try {
                val db = helper.writableDatabase

                // Step 1: SELECT pending rows in FIFO order.
                val selectSql = """
                    SELECT $COL_ID, $COL_DATA FROM $TABLE_EVENTS
                    WHERE $COL_FLAG = $FLAG_PENDING
                    ORDER BY $COL_TIME ASC
                    LIMIT ?;
                """.trimIndent()
                db.query(selectSql, arrayOf<Any>(limit)).use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val blob = c.getBlob(1) ?: continue
                        val event = decodeBlob(blob) ?: continue
                        claimed += id to event
                    }
                }

                // Step 2: flip the claimed rows to flag=1 in one
                // statement. Smaller WAL frame than N individual
                // updates, and atomic — a checkout call either claims
                // ALL the rows it returns or none of them.
                if (claimed.isNotEmpty()) {
                    val placeholders = Array(claimed.size) { "?" }.joinToString(",")
                    val updateSql = """
                        UPDATE $TABLE_EVENTS SET $COL_FLAG = $FLAG_IN_FLIGHT
                        WHERE $COL_ID IN ($placeholders);
                    """.trimIndent()
                    db.execSQL(updateSql, claimed.map { it.first }.toTypedArray())
                }
            } catch (t: Throwable) {
                Log.w(TAG, "checkout failed (limit=$limit)", t)
                return@withLock emptyList()
            }
            claimed.map { it.second }
        }
    }

    override suspend fun confirm(eventIds: List<String>): Unit = withContext(ioDispatcher) {
        if (eventIds.isEmpty()) return@withContext
        mutex.withLock {
            try {
                deleteByIdsLocked(eventIds)
            } catch (t: Throwable) {
                Log.w(TAG, "confirm failed for ${eventIds.size} ids", t)
            }
        }
    }

    override suspend fun release(eventIds: List<String>): Unit = withContext(ioDispatcher) {
        if (eventIds.isEmpty()) return@withContext
        mutex.withLock {
            try {
                val db = helper.writableDatabase
                // Chunked for the same reason as [deleteByIdsLocked]:
                // one statement may never carry more host parameters
                // than SQLite accepts.
                eventIds.chunked(MAX_SQL_VARIABLES).forEach { chunk ->
                    val placeholders = Array(chunk.size) { "?" }.joinToString(",")
                    // Constrain to flag=1 so we don't accidentally clobber
                    // a row that was already-deleted-and-reinserted with
                    // the same id under us. (Defensive — INSERT OR
                    // REPLACE in append always writes flag=0 anyway.)
                    val sql = """
                        UPDATE $TABLE_EVENTS SET $COL_FLAG = $FLAG_PENDING
                        WHERE $COL_ID IN ($placeholders) AND $COL_FLAG = $FLAG_IN_FLIGHT;
                    """.trimIndent()
                    db.execSQL(sql, chunk.toTypedArray())
                }
            } catch (t: Throwable) {
                Log.w(TAG, "release failed for ${eventIds.size} ids", t)
            }
        }
    }

    override suspend fun clear(): Unit = withContext(ioDispatcher) {
        mutex.withLock {
            try {
                helper.writableDatabase.execSQL("DELETE FROM $TABLE_EVENTS;")
            } catch (t: Throwable) {
                Log.w(TAG, "clear failed", t)
            }
        }
    }

    override suspend fun deleteWhere(predicate: (KixoEvent) -> Boolean): Int =
        withContext(ioDispatcher) {
            mutex.withLock {
                val doomed = mutableListOf<String>()
                try {
                    helper.readableDatabase.query(
                        "SELECT $COL_ID, $COL_DATA FROM $TABLE_EVENTS ORDER BY $COL_TIME ASC;",
                    ).use { cursor ->
                        while (cursor.moveToNext()) {
                            val id = cursor.getString(0) ?: continue
                            val blob = cursor.getBlob(1) ?: continue
                            // A row we cannot decode is a row we cannot
                            // judge — leave it to the FIFO cap.
                            val event = decodeBlob(blob) ?: continue
                            val matched = try {
                                predicate(event)
                            } catch (t: Throwable) {
                                Log.w(TAG, "deleteWhere predicate threw for $id", t)
                                false
                            }
                            if (matched) doomed += id
                        }
                    }
                    deleteByIdsLocked(doomed)
                } catch (t: Throwable) {
                    Log.w(TAG, "deleteWhere failed", t)
                    // The caller uses this operation as a policy barrier:
                    // returning zero would be indistinguishable from "nothing
                    // matched" and would let flush ship rows we failed to
                    // inspect/delete. Propagate so EventQueue keeps the barrier
                    // closed and retries.
                    throw t
                }
                doomed.size
            }
        }

    override suspend fun recoverInFlight(): Unit = withContext(ioDispatcher) {
        mutex.withLock {
            try {
                helper.writableDatabase.execSQL(
                    "UPDATE $TABLE_EVENTS SET $COL_FLAG = $FLAG_PENDING WHERE $COL_FLAG = $FLAG_IN_FLIGHT;",
                )
            } catch (t: Throwable) {
                Log.w(TAG, "recoverInFlight failed", t)
            }
        }
    }

    override suspend fun trimOverflow(maxRows: Int): Unit = withContext(ioDispatcher) {
        mutex.withLock { trimLocked(maxRows) }
    }

    // ─── Internal helpers (must hold [mutex]) ─────────────────────

    /**
     * Caller-must-already-hold-mutex variant of [pendingCount]. Used
     * inside [trimLocked] to avoid the re-entrant lock acquisition
     * that `Mutex` doesn't support (kotlinx Mutex is non-reentrant
     * by design).
     */
    private fun pendingCountLocked(): Int {
        return try {
            helper.readableDatabase
                .query("SELECT COUNT(*) FROM $TABLE_EVENTS;")
                .use { c ->
                    if (c.moveToFirst()) c.getInt(0) else 0
                }
        } catch (t: Throwable) {
            Log.w(TAG, "pendingCount failed", t)
            0
        }
    }

    /**
     * Caller-must-already-hold-mutex variant of [trimOverflow]. Drops
     * the oldest rows (smallest `time`) until total count ≤ [maxRows].
     * Selecting by id-via-subquery instead of `LIMIT` directly because
     * `DELETE … LIMIT` is a sqlite compile-time option not enabled on
     * stock Android.
     */
    private fun trimLocked(maxRows: Int) {
        if (maxRows < 0) return
        val current = pendingCountLocked()
        val toDrop = current - maxRows
        if (toDrop <= 0) return
        try {
            // app_install is the physical-install ledger proposal. It must
            // survive offline FIFO pressure until the backend ACKs it; all
            // ordinary events remain oldest-first eviction candidates.
            val candidates = mutableListOf<String>()
            helper.readableDatabase.query(
                "SELECT $COL_ID, $COL_DATA FROM $TABLE_EVENTS ORDER BY $COL_TIME ASC;",
            ).use { cursor ->
                while (cursor.moveToNext() && candidates.size < toDrop) {
                    val id = cursor.getString(0) ?: continue
                    val blob = cursor.getBlob(1) ?: continue
                    val event = decodeBlob(blob)
                    val canonicalInstall =
                        event?.eventType == KixoEventType.Install &&
                            event.eventName == AttributionContract.APP_INSTALL_EVENT_NAME &&
                            event.installId != null
                    if (!canonicalInstall) {
                        candidates += id
                    }
                }
            }
            deleteByIdsLocked(candidates)
        } catch (t: Throwable) {
            Log.w(TAG, "trimOverflow failed (maxRows=$maxRows)", t)
        }
    }

    /**
     * Delete rows by id, splitting the work so that no single
     * statement ever exceeds SQLite's host-parameter ceiling.
     *
     * **Why this exists (the bug it fixes).** The FIFO trim used to
     * bind one `?` per doomed row in a single `DELETE … IN (…)`.
     * `toDrop` is `rowCount - maxRows`, which is unbounded: a host
     * that lowers `KixoConfiguration.maxBufferSize` between releases
     * (say 5 000 → 200) asks the very first trim after the upgrade to
     * drop 4 800 rows in one statement. Android's SQLite rejects that
     * with `too many SQL variables`, [trimLocked] swallowed the
     * exception, and NOTHING was deleted — so the next append made
     * `toDrop` one larger and the statement one variable wider. The
     * cap was permanently un-enforceable from that moment on and the
     * event buffer grew without bound (disk + memory) for the rest of
     * the install's life. The same trap applies to any single trim
     * failure: once the backlog crosses the ceiling it can never trim
     * again.
     *
     * Caller must already hold [mutex].
     */
    private fun deleteByIdsLocked(ids: List<String>) {
        if (ids.isEmpty()) return
        val db = helper.writableDatabase
        ids.chunked(MAX_SQL_VARIABLES).forEach { chunk ->
            val placeholders = Array(chunk.size) { "?" }.joinToString(",")
            db.execSQL(
                "DELETE FROM $TABLE_EVENTS WHERE $COL_ID IN ($placeholders);",
                chunk.toTypedArray(),
            )
        }
    }

    /**
     * Encode an event to its on-disk byte representation. Returns
     * null on failure (caller swallows + logs upstream). Kept private
     * + nullable so an unexpected serialization edge case (a custom
     * property holding e.g. a non-serializable object) doesn't crash
     * the SDK — it just drops that one event and keeps going (R6).
     */
    private fun encodeBlob(event: KixoEvent): ByteArray? = try {
        json.encodeToString(event).toByteArray(Charsets.UTF_8)
    } catch (t: Throwable) {
        Log.w(TAG, "encodeBlob failed for event ${event.eventId}", t)
        null
    }

    private fun decodeBlob(blob: ByteArray): KixoEvent? = try {
        json.decodeFromString<KixoEvent>(String(blob, Charsets.UTF_8))
    } catch (t: Throwable) {
        // A decode failure means the on-disk row is corrupt or written
        // by an incompatible SDK version. We don't re-claim it (it'd
        // fail forever); the caller skips this row and moves on.
        // Out-of-band cleanup could DELETE such rows by id, but a
        // future migration is the better fix — for now we accept the
        // wasted slot. Pending count stays accurate.
        Log.w(TAG, "decodeBlob failed (corrupt row?)", t)
        null
    }

    // ─── Test access ──────────────────────────────────────────────

    /**
     * Exposed for tests that want to inspect raw row state without
     * going through [checkout] (which has the side-effect of marking
     * rows in-flight). Returns (id, flag) pairs.
     */
    @VisibleForTesting
    internal suspend fun debugRows(): List<Pair<String, Int>> = withContext(ioDispatcher) {
        mutex.withLock {
            val out = mutableListOf<Pair<String, Int>>()
            try {
                helper.readableDatabase
                    .query("SELECT $COL_ID, $COL_FLAG FROM $TABLE_EVENTS ORDER BY $COL_TIME ASC;")
                    .use { c ->
                        while (c.moveToNext()) {
                            out += c.getString(0) to c.getInt(1)
                        }
                    }
            } catch (t: Throwable) {
                Log.w(TAG, "debugRows failed", t)
            }
            out
        }
    }

    /** Exposed for tests that want to verify PRAGMAs landed. */
    @VisibleForTesting
    internal suspend fun debugJournalMode(): String? = withContext(ioDispatcher) {
        mutex.withLock {
            try {
                helper.readableDatabase
                    .query("PRAGMA journal_mode;")
                    .use { c -> if (c.moveToFirst()) c.getString(0) else null }
            } catch (t: Throwable) {
                null
            }
        }
    }


    private companion object {
        const val TAG: String = "Kixo.SqliteEventStore"

        /**
         * Hard ceiling on host parameters (`?`) in ONE statement.
         *
         * Android's bundled SQLite compiles `SQLITE_MAX_VARIABLE_NUMBER`
         * at 999 on every API level this SDK supports; only very recent
         * builds raise it to 32 766, and we cannot detect which one we
         * are running against. Exceeding it throws
         * `SQLiteException: too many SQL variables`. 900 leaves margin
         * for any statement that also binds non-id parameters.
         */
        const val MAX_SQL_VARIABLES: Int = 900

        /**
         * Tolerant Json: silently ignores keys the current model
         * doesn't know about (forward-compat across SDK versions —
         * the on-disk row written by a newer SDK with extra fields
         * still decodes back into an older client) and emits
         * encodeDefaults so default-valued properties round-trip.
         * Pretty-printing is OFF (smaller blobs, faster I/O).
         */
        val DEFAULT_JSON: Json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
            isLenient = false
        }
    }
}
