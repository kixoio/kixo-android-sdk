package io.kixo.sdk.internal.lifecycle

import android.content.Context
import android.util.Log
import io.kixo.sdk.internal.model.KixoEventType
import java.util.UUID

/**
 * Auto-tracks session start/end based on app foreground/background
 * transitions, mirroring iOS [SessionTracker.swift].
 *
 * Definitions:
 *   - **Session start** — fires once on first foreground (the
 *     `app_launch`-coupled start) AND every subsequent foreground
 *     where the prior background lasted ≥ [sessionTimeoutMs].
 *   - **Session end** — fires when a later foreground proves the prior
 *     background exceeded [sessionTimeoutMs]. A brief background keeps one
 *     active session end to end.
 *   - **Session id** — opaque UUID v4 string. Regenerated on every
 *     `session_start`; queried by the EventQueue to stamp on each
 *     outbound event so backend-side queries can join "all events
 *     in session X".
 *
 * Default `sessionTimeoutMs = 30_000` matches both iOS and the wider
 * industry convention (Mixpanel, Amplitude, Firebase Analytics).
 *
 * **Why a hook into [ProcessLifecycleObserver] and not its own
 * lifecycle observer?** Because both subsystems care about the SAME
 * foreground/background signal — registering twice is wasteful and
 * worse, splits the source-of-truth for "when did we last go to
 * background" between two observers that may disagree if the
 * platform fires events out of order. The lifecycle observer is the
 * authoritative timestamp; SessionTracker is a derived state machine.
 *
 * Persistence: nothing in this tracker is persisted. The session
 * lifetime is bound to the process — a process kill (e.g. system
 * low-memory kill) ends the session, the next launch starts a new
 * one. This matches iOS where session id is held in-memory only.
 *
 * Thread safety: all state mutation is done from the main thread
 * (the [ProcessLifecycleObserver] callbacks are @MainThread).
 * `currentSessionId()` is called from arbitrary threads — guarded
 * by @Volatile so the latest UUID is observed without locks.
 */
internal class SessionTracker(
    private val bus: LifecycleEventBus,
    private val sessionTimeoutMs: Long = DEFAULT_TIMEOUT_MS,
    private val idFactory: () -> String = { UUID.randomUUID().toString() },
    /**
     * Fires every time a new session is minted (cold launch + every
     * timeout-driven rotation). Default no-op; production wiring in
     * [KixoInternalBootstrap] passes a callback that resets
     * [io.kixo.sdk.internal.goal.GoalDedup] so per-session goal dedup
     * doesn't leak between sessions.
     *
     * Critic BLOCKER Android-B3 (May 2026) — `GoalDedup.resetForSession`
     * was previously declared but had ZERO callers, so the
     * session-scoped dedup behaved as process-scoped forever. Wired
     * here as a constructor callback rather than a hard import to keep
     * SessionTracker decoupled from the goal subsystem (also keeps the
     * existing unit tests, which pass a stub bus, from needing a
     * goal-subsystem dep).
     */
    private val onNewSession: () -> Unit = {},
) {

    /**
     * Live session id. Updates on every `session_start`. Reads from
     * any thread are safe via @Volatile — modern JVMs treat reference
     * writes as atomic, so a worker thread will never see a torn
     * reference.
     */
    @Volatile
    private var sessionId: String = idFactory()

    /**
     * `true` once the very first session_start has fired (paired with
     * `app_launch`). Used to set the `is_first_session` property on
     * the cold-start session_start event.
     */
    @Volatile
    private var hasStartedAnySession: Boolean = false

    /**
     * `true` while a session is active (between session_start and the
     * matching session_end). Tracked so we don't fire stray
     * `session_end` events when the app backgrounds with no live
     * session (e.g. between processes).
     */
    @Volatile
    private var sessionActive: Boolean = false

    /**
     * An identity boundary may land while the process is backgrounded.
     * Rotate the id immediately so replay cannot reuse the sealed session, but
     * defer session_start until the next foreground in that case.
     */
    @Volatile
    private var boundaryStartPending: Boolean = false

    /**
     * A reset or server-policy recovery rotates the id while collection is closed.
     * The matching session_start is committed only after the destructive clear
     * or fresh server policy completes.
     */
    @Volatile
    private var boundaryRotationPrepared: Boolean = false

    /** Best-effort process foreground truth used when a prepared start commits. */
    @Volatile
    private var processForeground: Boolean = false

    /**
     * Current session id. Returns the active session's UUID — even
     * between sessions the id remains the most recently issued one
     * so an event queued just after `session_end` still has a sensible
     * stamp on it (better than null which would trip the backend's
     * NOT NULL constraint on `events.session_id`).
     */
    fun currentSessionId(): String = sessionId

    /**
     * Start the first session. Called by [KixoInternalBootstrap] AFTER
     * the tracker has been assigned to the bootstrap singleton — same
     * pattern as iOS, where firing session_start from inside `init`
     * would be silently dropped because the EventQueue's enqueue path
     * guards on `sessionTracker != null`.
     *
     * @param isFirstProcess `true` on cold start (always true in
     *   normal operation; tests pass `false` to simulate re-entry).
     */
    @Synchronized
    fun start(isFirstProcess: Boolean = true) {
        processForeground = true
        if (isFirstProcess && !hasStartedAnySession) {
            startNewSession()
        }
    }

    /**
     * Hook called by [ProcessLifecycleObserver.onStart].
     *
     * If a session is already active and we're returning from a brief
     * background (< sessionTimeoutMs) we do nothing — the same session
     * carries through. If the gap exceeded the timeout we end the old
     * session and start a new one.
     *
     * @param bgDurationMs millis spent in the background since last
     *   foreground, or `null` if this is the first-ever foreground of
     *   the process.
     */
    @Synchronized
    fun onProcessForeground(bgDurationMs: Long?) {
        processForeground = true
        if (boundaryRotationPrepared) {
            // Collection authority has not returned yet. Keep the already-
            // rotated id, but do not emit session_start early.
            return
        }
        if (boundaryStartPending) {
            boundaryStartPending = false
            startNewSession(reuseCurrentId = true)
            return
        }

        // First-ever foreground in this process: nothing to compare,
        // session was started in start() above.
        if (bgDurationMs == null) {
            if (!hasStartedAnySession) startNewSession()
            return
        }

        if (bgDurationMs >= sessionTimeoutMs) {
            // Session expired while in the background — end the old
            // (idempotently) and rotate.
            if (sessionActive) {
                endCurrentSession()
            }
            startNewSession()
        }
        // else: brief background, same session continues.
    }

    /**
     * Hook called by [ProcessLifecycleObserver.onStop]. Records foreground
     * truth only. The duration is not known yet, so ending here would make a
     * brief background impossible to resume honestly: subsequent events would
     * reuse a session id whose `session_end` had already been emitted.
     * [onProcessForeground] closes and rotates only after it observes the
     * configured timeout, matching the iOS SDK.
     */
    @Synchronized
    fun onProcessBackground() {
        processForeground = false
    }

    /**
     * Start a fresh analytics session without attributing an end event to the
     * new identity. Used after reset and server-policy recovery.
     *
     * The id changes synchronously even while backgrounded so replay start
     * cannot race with and reuse the prior sealed id. A foregrounded process
     * emits session_start immediately; a backgrounded process emits it on its
     * next foreground using the same already-rotated id.
     */
    @Synchronized
    fun rotateForCollectionBoundary() {
        prepareCollectionBoundaryRotation()
        commitPreparedCollectionBoundaryStart()
    }

    /**
     * Rotate the analytics id synchronously while collection remains closed.
     *
     * This prevents events admitted immediately after a boundary from retaining
     * the sealed prior id. It emits nothing until reset finishes its SQLite clear
     * or fresh remote policy permits session_start to be persisted.
     */
    @Synchronized
    fun prepareCollectionBoundaryRotation() {
        if (boundaryRotationPrepared) return
        sessionActive = false
        sessionId = idFactory()
        boundaryStartPending = false
        if (!hasStartedAnySession) {
            return
        }
        boundaryRotationPrepared = true
    }

    /**
     * Commit the start associated with [prepareCollectionBoundaryRotation].
     * Returns false when there was no prepared boundary.
     */
    @Synchronized
    fun commitPreparedCollectionBoundaryStart(): Boolean {
        if (!boundaryRotationPrepared) return false
        boundaryRotationPrepared = false
        if (processForeground) {
            startNewSession(reuseCurrentId = true)
        } else {
            boundaryStartPending = true
        }
        return true
    }

    private fun startNewSession(reuseCurrentId: Boolean = false) {
        if (!reuseCurrentId) sessionId = idFactory()
        val isFirst = !hasStartedAnySession
        hasStartedAnySession = true
        sessionActive = true

        // Notify subscribers BEFORE emitting session_start so any
        // session-scoped state (e.g. GoalDedup) is already cleared by
        // the time downstream consumers see the new session. Wrapped
        // in a try/catch per AGENT_BRIEFING.md R6 — a buggy callback
        // must not block session emission.
        try {
            onNewSession()
        } catch (t: Throwable) {
            Log.w(TAG, "onNewSession callback threw", t)
        }

        // Coverage fix (May 2026): honour
        // `data_collection.core.sessions == false`. Default-allow on
        // pre-init / missing field. State machine still rolls (sessionId
        // is still rotated, listeners still get onNewSession) but the
        // session_start event is suppressed.
        if (sessionsAllowedByDataCollection()) {
            bus.emit(
                LifecycleEvent(
                    eventType = KixoEventType.SessionStart,
                    eventName = "session_start",
                    properties = mapOf(
                        "session_id" to sessionId,
                        "is_first_session" to isFirst,
                    ),
                )
            )
        }
    }

    private fun endCurrentSession() {
        sessionActive = false
        if (sessionsAllowedByDataCollection()) {
            bus.emit(
                LifecycleEvent(
                    eventType = KixoEventType.SessionEnd,
                    eventName = "session_end",
                    properties = mapOf(
                        "session_id" to sessionId,
                    ),
                )
            )
        }
    }

    /**
     * Coverage check for `data_collection.core.sessions`. Default-allow
     * on pre-init / missing field.
     */
    private fun sessionsAllowedByDataCollection(): Boolean {
        return io.kixo.sdk.internal.queue.DataCollectionHolder.isAllowed { it.core?.sessions }
    }

    internal companion object {
        /**
         * Default session timeout — 30 seconds of background before the
         * next foreground rotates the session. Matches iOS
         * `Configuration.swift` default `sessionTimeout = 30`.
         */
        const val DEFAULT_TIMEOUT_MS: Long = 30_000

        private const val TAG = "Kixo"
    }
}
