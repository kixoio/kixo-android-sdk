package io.kixo.sdk.internal.replay.upload

import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Bitmap → byte[] encoders for replay frames. Default output is JPEG
 * because the universal-decode floor on Android is JPEG (every API
 * level since 1.x), and the player uses standard `<img>` tags.
 *
 * **Why not HEIC** (the iOS default):
 *  - `Bitmap.CompressFormat.HEIF` ships only on **API 28+** (per
 *    Android docs). Our minSdk is 24 — silent decode failures on
 *    Android 7/8 would leave gaps in the replay.
 *  - Player browsers also need to decode HEIF; Chrome/Firefox don't
 *    ship a native HEIF decoder yet (May 2026), so the dashboard
 *    would need to transcode server-side anyway. Round trip = no win.
 *  - WebP at API 18+ is the next-best efficiency tier; we expose
 *    [encodeWebp] for hosts willing to trade the compatibility tail
 *    for ~25% smaller payloads. JPEG stays the default.
 *
 * **Quality + scale knobs:** both come from project policy. The canonical
 * compatibility fallback is JPEG q=15 at captureScale=0.85. Scene entropy
 * can still push a full-window frame above the signed 20 KB cap, so
 * [encodeJpeg] first honours those values, then degrades quality and finally
 * linear resolution in a bounded ladder only when the encoded bytes do not
 * fit. The signed cap always wins over fidelity; an oversized PUT would fail
 * anyway and waste radio + battery.
 *
 * **Off-main:** `Bitmap.compress` is CPU-heavy (~30-80 ms on a
 * mid-range device for a full-screen frame). All callers must invoke
 * from a coroutine on `Dispatchers.IO` or a worker — never from the
 * UI thread (briefing R6 — never block main > 16 ms).
 */
internal object JpegEncoder {

    /**
     * Encode a [Bitmap] to a JPEG byte array, **fitting under the
     * canonical 20 KB cap** by re-encoding at progressively lower
     * quality if the first attempt blows the budget.
     *
     * Why iterative: scene complexity dominates JPEG size at fixed
     * quality (a busy photo gallery vs an empty form differ by 4×
     * even at the same dimensions). A static "q=X" can fit one and
     * blow the other; the cap is a hard contract enforced by the
     * GCS V4 signature, so we must guarantee fit. We start at the exact
     * project-controlled scale and quality, then use a bounded quality ladder
     * down to the dashboard floor and, only if needed, two progressively
     * smaller resolution passes. Compatibility defaults mirror the canonical
     * dashboard policy (quality 0.15 → JPEG 15, scale 0.85).
     *
     * Returns `null` on:
     *   - All bounded quality/scale tiers exceed [maxBytes] (rare — happens for
     *     extremely high-entropy frames, drops cleanly per R6)
     *   - `Bitmap.compress` failure (OOM under memory pressure)
     *
     * The dashboard player upscales for display so the user-visible
     * resolution is unchanged — we trade a small fidelity hit for
     * fitting within egress discipline (the 20 KB agreed cap).
     *
     * @param maxBytes byte ceiling the encoded output must fit
     *        under. Defaults to 20_000 to match the backend
     *        `REPLAY_FRAME_MAX_BYTES` constant.
     * @param downscale linear scale factor in (0,1]. Default 0.85,
     *        matching the canonical project policy.
     */
    fun encodeJpeg(
        bitmap: Bitmap,
        maxBytes: Int = 20_000,
        downscale: Float = 0.85f,
        /**
         * AND-CAP-06 — starting JPEG quality (top of the fit-to-cap
         * ladder). Remote-tunable via `replay.heicQuality`. The encoder
         * still steps DOWN from here to fit [maxBytes]; the tiers below
         * this value are used. Default 15 mirrors project `heicQuality=0.15`.
         */
        startQuality: Int = 15,
    ): ByteArray? {
        if (maxBytes <= 0) return null
        val safeDownscale = downscale.coerceIn(0.05f, 1f)
        val ceilQuality = startQuality.coerceIn(1, 100)
        val qualityTiers = buildList {
            if (QUALITY_TIERS.none { it == ceilQuality }) add(ceilQuality)
            for (quality in QUALITY_TIERS) if (quality <= ceilQuality) add(quality)
        }

        for (scale in scaleCandidates(safeDownscale)) {
            // Downscale BEFORE encode so the JPEG entropy coder sees a
            // smaller surface. Each candidate is relative to the caller's
            // bitmap; we never repeatedly resample an already-scaled result.
            val source = scaled(bitmap, scale)
            try {
                for (quality in qualityTiers) {
                    val out = compressOnce(source, quality)
                    if (out != null && out.size <= maxBytes) return out
                    if (out != null) {
                        Log.d(
                            TAG,
                            "JPEG scale=$scale q=$quality produced ${out.size}B > " +
                                "maxBytes=$maxBytes — degrading within bounded ladder",
                        )
                    }
                }
            } finally {
                // Recycle only our intermediate. createScaledBitmap may return
                // the input when dimensions are unchanged.
                if (source !== bitmap && !source.isRecycled) {
                    try { source.recycle() } catch (_: Throwable) { /* swallow */ }
                }
            }
        }

        Log.w(
            TAG,
            "JPEG encode failed to fit ${maxBytes}B at bounded quality/scale floor " +
                "(high-entropy frame?) — dropping",
        )
        return null
    }

    private fun scaled(bitmap: Bitmap, scale: Float): Bitmap {
        if (scale >= 0.999f) return bitmap
        return try {
            Bitmap.createScaledBitmap(
                bitmap,
                (bitmap.width * scale).toInt().coerceAtLeast(1),
                (bitmap.height * scale).toInt().coerceAtLeast(1),
                /* filter = */ true,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "Bitmap downscale threw — trying source dimensions", t)
            bitmap
        }
    }

    /** Exact project scale first; cap-fitting degradation is bounded. */
    private fun scaleCandidates(projectScale: Float): List<Float> = buildList {
        for (factor in SCALE_FACTORS) {
            val candidate = (projectScale * factor).coerceIn(0.05f, 1.0f)
            if (candidate !in this) add(candidate)
        }
    }

    @androidx.annotation.VisibleForTesting
    internal fun scaleCandidatesForTesting(projectScale: Float): List<Float> =
        scaleCandidates(projectScale.coerceIn(0.05f, 1.0f))

    /**
     * Single JPEG compression pass. Extracted from [encodeJpeg] so
     * the iterative fit-to-cap loop above can call it multiple
     * times against the same already-downscaled source bitmap
     * without repeating the (expensive) downscale step.
     */
    private fun compressOnce(source: Bitmap, quality: Int): ByteArray? {
        val safeQuality = quality.coerceIn(1, 100)
        return try {
            ByteArrayOutputStream(estimateBufferSize(source)).use { stream ->
                val ok = source.compress(Bitmap.CompressFormat.JPEG, safeQuality, stream)
                if (!ok) {
                    Log.w(TAG, "JPEG encode returned false (OOM?) at q=$safeQuality")
                    return null
                }
                stream.toByteArray()
            }
        } catch (t: Throwable) {
            // OutOfMemoryError, IOException — both swallow + log.
            // Replay is best-effort; one missing frame is fine.
            Log.w(TAG, "JPEG encode threw at q=$safeQuality", t)
            null
        }
    }

    /**
     * Quality tiers tried in order by [encodeJpeg]'s fit-to-cap
     * loop. Calibrated against the canonical 20 KB cap: q=60 fits
     * typical UI chrome at aggressive downscale, q=35/20 cover busier
     * scenes, and q=15/10/5 match the dashboard's canonical quality
     * range. Resolution degradation follows only after these are exhausted.
     */
    private val QUALITY_TIERS: IntArray = intArrayOf(60, 35, 20, 15, 10, 5)

    /** Relative scale passes: exact policy value, then two bounded fallbacks. */
    private val SCALE_FACTORS: FloatArray = floatArrayOf(1.0f, 0.7f, 0.5f)

    /**
     * Optional WebP encoder. Available on API 18+ for `WEBP` lossy
     * (every API our minSdk=24 covers) and API 30+ for `WEBP_LOSSY`
     * with explicit quality control. Falls back to the legacy
     * `WEBP` constant on older API levels.
     *
     * Hosts that want ~25% smaller frames at the cost of slightly
     * older browser-decoder support can switch by setting
     * `Configuration.replayFrameFormat = "webp"` (Agent 13's knob).
     * The default stays JPEG.
     */
    fun encodeWebp(bitmap: Bitmap, quality: Int = 80): ByteArray? {
        val safeQuality = quality.coerceIn(1, 100)
        val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+: WEBP_LOSSY honours the quality int directly.
            Bitmap.CompressFormat.WEBP_LOSSY
        } else {
            // API 24-29: legacy WEBP also honours quality (lossy mode).
            // The newer constant is a Google soft-deprecation warning
            // we silence with @Suppress at the call site.
            @Suppress("DEPRECATION")
            Bitmap.CompressFormat.WEBP
        }
        return try {
            ByteArrayOutputStream(estimateBufferSize(bitmap)).use { stream ->
                val ok = bitmap.compress(format, safeQuality, stream)
                if (!ok) {
                    Log.w(TAG, "WebP encode returned false — dropping frame")
                    return null
                }
                stream.toByteArray()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "WebP encode threw — dropping frame", t)
            null
        }
    }

    /**
     * Persist a byte array to disk atomically (write to `.tmp`, then
     * rename) so a crash mid-write never leaves a half-baked staging
     * file that [UploadWorker] would then PUT to GCS.
     *
     * Returns `true` on success. On failure the partial file is
     * removed — the upload will simply not be scheduled.
     */
    fun ByteArray.writeToFile(file: File): Boolean {
        // Make sure the parent dir exists; cacheDir/<sessionId>/ may
        // not have been created yet on the very first frame.
        val parent = file.parentFile
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            Log.w(TAG, "Failed to create cache parent dir ${parent.absolutePath}")
            return false
        }
        val tmp = File(file.parentFile, file.name + ".tmp")
        return try {
            FileOutputStream(tmp).use { it.write(this) }
            // `renameTo` on Android is atomic on the same filesystem
            // (which cacheDir always is) — UploadWorker will only
            // ever see the final filename.
            if (!tmp.renameTo(file)) {
                tmp.delete()
                Log.w(TAG, "Atomic rename failed for ${file.absolutePath}")
                false
            } else {
                true
            }
        } catch (t: Throwable) {
            tmp.delete()
            Log.w(TAG, "Failed to write ${file.absolutePath}", t)
            false
        }
    }

    /**
     * Heuristic initial buffer size for a full-window JPEG. Sizing the
     * [ByteArrayOutputStream] up
     * front avoids 4-5 reallocations during compress (each one
     * doubles + memcpys). Cap at 1 MB so a giant Bitmap doesn't
     * pre-allocate more than necessary.
     */
    private fun estimateBufferSize(bitmap: Bitmap): Int {
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        // Conservative rough rule; the stream grows if a busy frame needs more.
        val estimate = (pixels * 3L / 100L).toInt().coerceAtLeast(8 * 1024)
        return estimate.coerceAtMost(1024 * 1024)
    }

    private const val TAG = "Kixo.JpegEncoder"
}
