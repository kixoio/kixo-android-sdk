package io.kixo.sdk.internal.attribution

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import java.io.File
import java.io.FileNotFoundException
import java.security.MessageDigest
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Bounded direct App-Link resolve outbox.
 *
 * Only canonical, non-PII identifiers are persisted. A Universal Link is
 * reduced to an allowlisted host + validated public slug; a custom scheme is
 * reduced to its canonical click UUID. Incoming URLs, query strings, fragments,
 * resolved destinations and clipboard values never enter this file.
 */
internal class DirectLinkResolveStore(
    private val persistence: Persistence,
    private val projectScope: String,
    private val nowMs: () -> Long = System::currentTimeMillis,
) {
    @Serializable
    internal data class Signal(
        val kind: String,
        val clickId: String? = null,
        val host: String? = null,
        val slug: String? = null,
    ) {
        val resolveUrl: String?
            get() = if (kind == KIND_ROUTE && host != null && slug != null) {
                "https://$host/link/$slug"
            } else {
                null
            }

        companion object {
            fun click(value: String): Signal =
                Signal(kind = KIND_CLICK, clickId = value.lowercase())

            fun route(host: String, slug: String): Signal =
                Signal(kind = KIND_ROUTE, host = host.lowercase(), slug = slug)
        }
    }

    @Serializable
    internal data class StoredResult(
        val linkId: String,
        val clickId: String,
        val campaign: String? = null,
        val mediaSource: String? = null,
        val medium: String? = null,
        val resolutionMethod: String,
        val resolutionConfidence: Double,
    ) {
        fun toResolved(): AppLinkResolver.ResolvedAppLink =
            AppLinkResolver.ResolvedAppLink(
                targetUrl = null,
                linkId = linkId,
                clickId = clickId,
                campaign = campaign,
                mediaSource = mediaSource,
                medium = medium,
                resolutionMethod = resolutionMethod,
                resolutionConfidence = resolutionConfidence,
            )

        fun isValid(): Boolean =
            LINK_ID_PATTERN.matches(linkId) &&
                AppLinkResolver.isCanonicalClickId(clickId) &&
                resolutionMethod ==
                AttributionContract.RESOLUTION_METHOD_DIRECT_APP_LINK &&
                resolutionConfidence in 0.0..1.0 &&
                bounded(campaign) == campaign &&
                bounded(mediaSource) == mediaSource &&
                bounded(medium) == medium

        companion object {
            fun from(value: AppLinkResolver.ResolvedAppLink): StoredResult? {
                if (!LINK_ID_PATTERN.matches(value.linkId) ||
                    !AppLinkResolver.isCanonicalClickId(value.clickId) ||
                    value.resolutionMethod !=
                    AttributionContract.RESOLUTION_METHOD_DIRECT_APP_LINK ||
                    value.resolutionConfidence !in 0.0..1.0
                ) {
                    return null
                }
                return StoredResult(
                    linkId = value.linkId,
                    clickId = value.clickId.lowercase(),
                    campaign = bounded(value.campaign),
                    mediaSource = bounded(value.mediaSource),
                    medium = bounded(value.medium),
                    resolutionMethod = value.resolutionMethod,
                    resolutionConfidence = value.resolutionConfidence,
                )
            }

            private fun bounded(value: String?): String? =
                value?.takeIf { it.isNotBlank() && it.toByteArray().size <= 256 }
        }
    }

    @Serializable
    internal data class Intent(
        val openId: String,
        val eventId: String,
        val projectScope: String,
        val anonymousId: String,
        val deviceId: String,
        val installId: String,
        val userId: String? = null,
        val sessionId: String,
        val fingerprint: String,
        val source: String,
        val signal: Signal,
        val installAttributionCandidate: Boolean,
        val routePathHash: String,
        val createdAtMs: Long,
        val expiresAtMs: Long,
        val attempt: Int = 0,
        val nextAttemptAtMs: Long,
        val result: StoredResult? = null,
    )

    @Serializable
    private data class Receipt(
        val openId: String,
        val eventId: String,
        val projectScope: String,
        val anonymousId: String,
        val deviceId: String,
        val installId: String,
        val signal: Signal,
        val routePathHash: String,
        val expiresAtMs: Long,
    ) {
        fun asTerminalIntent(
            userId: String?,
            sessionId: String,
            fingerprint: String,
            source: String,
            installAttributionCandidate: Boolean,
            nowMs: Long,
        ): Intent = Intent(
            openId = openId,
            eventId = eventId,
            projectScope = projectScope,
            anonymousId = anonymousId,
            deviceId = deviceId,
            installId = installId,
            userId = userId,
            sessionId = sessionId,
            fingerprint = fingerprint,
            source = source,
            signal = signal,
            installAttributionCandidate = installAttributionCandidate,
            routePathHash = routePathHash,
            createdAtMs = nowMs,
            expiresAtMs = expiresAtMs,
            nextAttemptAtMs = nowMs,
        )
    }

    internal interface Persistence {
        sealed interface ReadResult {
            data object Missing : ReadResult
            data object Failure : ReadResult
            data class Value(val raw: String) : ReadResult
        }

        fun read(): ReadResult
        fun write(value: String?): Boolean
    }

    @Serializable
    private data class State(
        val version: Int = STATE_VERSION,
        val blocked: Boolean = false,
        val intents: List<Intent> = emptyList(),
        val receipts: List<Receipt> = emptyList(),
    )

    private val lock = Any()
    @Volatile
    private var blockedInMemory = false

    fun prepare(
        signal: Signal,
        openId: String,
        eventId: String,
        anonymousId: String,
        deviceId: String,
        installId: String,
        userId: String?,
        sessionId: String,
        fingerprint: String,
        source: String,
        installAttributionCandidate: Boolean,
        routePathHash: String,
    ): Intent? {
        if (!valid(
                signal = signal,
                openId = openId,
                eventId = eventId,
                anonymousId = anonymousId,
                deviceId = deviceId,
                installId = installId,
                userId = userId,
                sessionId = sessionId,
                fingerprint = fingerprint,
                source = source,
                routePathHash = routePathHash,
            )
        ) return null

        return synchronized(lock) {
            if (blockedInMemory) return@synchronized null
            val current = prune(
                load(),
                anonymousId = anonymousId,
                deviceId = deviceId,
                installId = installId,
            )
            if (current.blocked) return@synchronized null
            current.intents.firstOrNull { it.openId == openId }?.let { existing ->
                return@synchronized existing.takeIf {
                    it.eventId == eventId &&
                        it.signal == signal &&
                        it.anonymousId == anonymousId &&
                        it.deviceId == deviceId &&
                        it.installId == installId
                }
            }
            current.receipts.firstOrNull {
                it.openId == openId &&
                    it.eventId == eventId &&
                    it.signal == signal &&
                    it.routePathHash == routePathHash
            }?.let {
                return@synchronized it.asTerminalIntent(
                    userId = userId,
                    sessionId = sessionId,
                    fingerprint = fingerprint,
                    source = source,
                    installAttributionCandidate = installAttributionCandidate,
                    nowMs = nowMs(),
                )
            }
            if (current.intents.size >= CAPACITY) return@synchronized null
            val now = nowMs()
            val created = Intent(
                openId = openId.lowercase(),
                eventId = eventId.lowercase(),
                projectScope = projectScope,
                anonymousId = anonymousId,
                deviceId = deviceId,
                installId = installId,
                userId = userId,
                sessionId = sessionId,
                fingerprint = fingerprint,
                source = source,
                signal = signal,
                installAttributionCandidate = installAttributionCandidate,
                routePathHash = routePathHash,
                createdAtMs = now,
                expiresAtMs = now + LIFETIME_MS,
                nextAttemptAtMs = now,
            )
            if (!save(current.copy(intents = current.intents + created))) null else created
        }
    }

    fun current(
        openId: String,
        anonymousId: String,
        deviceId: String,
        installId: String,
    ): Intent? = synchronized(lock) {
        val before = load()
        if (before.blocked) return@synchronized null
        val current = prune(before, anonymousId, deviceId, installId)
        if (current != before) save(current)
        current.intents.firstOrNull { it.openId == openId }
    }

    fun allCurrent(
        anonymousId: String,
        deviceId: String,
        installId: String,
    ): List<Intent> = synchronized(lock) {
        val before = load()
        if (before.blocked) return@synchronized emptyList()
        val current = prune(before, anonymousId, deviceId, installId)
        if (current != before) save(current)
        current.intents.sortedWith(
            compareBy<Intent> { it.nextAttemptAtMs }.thenBy { it.createdAtMs },
        )
    }

    fun isActive(
        openId: String,
        eventId: String,
        anonymousId: String,
        deviceId: String,
        installId: String,
    ): Boolean = synchronized(lock) {
        val before = load()
        if (before.blocked) return@synchronized false
        val current = prune(before, anonymousId, deviceId, installId)
        if (current != before) save(current)
        current.intents.any {
            it.openId == openId && it.eventId == eventId
        }
    }

    fun beginAttempt(openId: String): Intent? =
        mutate(openId) { intent ->
            val now = nowMs()
            if (intent.expiresAtMs <= now) return@mutate null
            val attempt = intent.attempt + 1
            intent.copy(
                attempt = attempt,
                nextAttemptAtMs = now + retryDelayMs(attempt),
            )
        }

    fun postpone(openId: String): Intent? =
        mutate(openId) { intent ->
            val now = nowMs()
            if (intent.expiresAtMs <= now) return@mutate null
            intent.copy(
                nextAttemptAtMs = now + retryDelayMs(intent.attempt.coerceAtLeast(1)),
            )
        }

    fun recordResult(
        openId: String,
        result: AppLinkResolver.ResolvedAppLink,
    ): Intent? {
        val stored = StoredResult.from(result) ?: return null
        return mutate(openId) { it.copy(result = stored) }
    }

    fun settle(openId: String): Intent? = synchronized(lock) {
        val state = load()
        if (state.blocked) return@synchronized null
        val settled = state.intents.firstOrNull { it.openId == openId }
            ?: return@synchronized null
        if (!save(withReceipts(state, listOf(settled)))) {
            return@synchronized null
        }
        settled
    }

    fun settleByEventIds(eventIds: Set<String>): List<Intent> = synchronized(lock) {
        if (eventIds.isEmpty()) return@synchronized emptyList()
        val state = load()
        if (state.blocked) return@synchronized emptyList()
        val settled = state.intents.filter { it.eventId in eventIds }
        if (settled.isEmpty()) return@synchronized emptyList()
        if (!save(withReceipts(state, settled))) {
            return@synchronized emptyList()
        }
        settled
    }

    /**
     * Persist a privacy/identity tombstone. In-memory blocking happens before
     * the write so a disk failure cannot make stale intents eligible again in
     * this process.
     */
    fun blockAndClear(): Boolean = synchronized(lock) {
        blockedInMemory = true
        save(State(blocked = true)) || persistence.write(null)
    }

    /**
     * Start a fresh generation only after an atomic empty-state write succeeds.
     * This is the sole path out of a privacy tombstone.
     */
    fun rearmIfBlocked(): Boolean = synchronized(lock) {
        val state = load()
        if (!blockedInMemory && !state.blocked) return@synchronized true
        val fresh = State()
        val written = save(fresh)
        if (written) blockedInMemory = false
        written
    }

    private fun mutate(openId: String, transform: (Intent) -> Intent?): Intent? =
        synchronized(lock) {
            val state = load()
            val index = state.intents.indexOfFirst { it.openId == openId }
            if (index < 0) return@synchronized null
            val updated = transform(state.intents[index]) ?: return@synchronized null
            val intents = state.intents.toMutableList().also { it[index] = updated }
            if (!save(state.copy(intents = intents))) null else updated
        }

    private fun prune(
        state: State,
        anonymousId: String,
        deviceId: String,
        installId: String,
    ): State {
        if (state.blocked) return state
        val now = nowMs()
        return state.copy(
            intents = state.intents.filter {
                it.projectScope == projectScope &&
                    it.expiresAtMs > now &&
                    it.anonymousId == anonymousId &&
                    it.deviceId == deviceId &&
                    it.installId == installId &&
                    valid(it)
            },
            receipts = state.receipts
                .asSequence()
                .filter {
                    it.expiresAtMs > now &&
                        it.projectScope == projectScope &&
                        it.anonymousId == anonymousId &&
                        it.deviceId == deviceId &&
                        it.installId == installId &&
                        valid(it)
                }
                .sortedByDescending(Receipt::expiresAtMs)
                .take(RECEIPT_CAPACITY)
                .toList(),
        )
    }

    private fun withReceipts(state: State, settled: List<Intent>): State {
        val settledIds = settled.mapTo(hashSetOf(), Intent::openId)
        val receipts = (
            settled.map {
                Receipt(
                    openId = it.openId,
                    eventId = it.eventId,
                    projectScope = it.projectScope,
                    anonymousId = it.anonymousId,
                    deviceId = it.deviceId,
                    installId = it.installId,
                    signal = it.signal,
                    routePathHash = it.routePathHash,
                    expiresAtMs = nowMs() + RECEIPT_LIFETIME_MS,
                )
            } +
                state.receipts.filterNot { it.openId in settledIds }
            )
            .sortedByDescending(Receipt::expiresAtMs)
            .take(RECEIPT_CAPACITY)
        return state.copy(
            intents = state.intents.filterNot { it.openId in settledIds },
            receipts = receipts,
        )
    }

    private fun valid(receipt: Receipt): Boolean =
        receipt.projectScope == projectScope &&
            UUID_PATTERN.matches(receipt.openId) &&
            UUID_PATTERN.matches(receipt.eventId) &&
            IDENTIFIER_PATTERN.matches(receipt.anonymousId) &&
            IDENTIFIER_PATTERN.matches(receipt.deviceId) &&
            IDENTIFIER_PATTERN.matches(receipt.installId) &&
            HASH_PATTERN.matches(receipt.routePathHash) &&
            when (receipt.signal.kind) {
                KIND_CLICK ->
                    receipt.signal.host == null &&
                        receipt.signal.slug == null &&
                        receipt.signal.clickId
                            ?.let(AppLinkResolver::isCanonicalClickId) == true
                KIND_ROUTE ->
                    receipt.signal.clickId == null &&
                        receipt.signal.host?.let(HOST_PATTERN::matches) == true &&
                        receipt.signal.slug?.let(SLUG_PATTERN::matches) == true
                else -> false
            }

    private fun load(): State =
        if (blockedInMemory) {
            State(blocked = true)
        } else when (val read = persistence.read()) {
            Persistence.ReadResult.Missing -> State()
            Persistence.ReadResult.Failure -> {
                blockedInMemory = true
                State(blocked = true)
            }
            is Persistence.ReadResult.Value -> runCatching {
                JSON.decodeFromString(State.serializer(), read.raw)
            }.getOrNull()?.takeIf { it.version == STATE_VERSION } ?: run {
                blockedInMemory = true
                State(blocked = true)
            }
        }

    private fun save(state: State): Boolean {
        val raw = runCatching {
            JSON.encodeToString(State.serializer(), state)
        }.getOrNull() ?: return false
        if (raw.toByteArray().size > MAX_FILE_BYTES) return false
        return persistence.write(raw)
    }

    private fun valid(intent: Intent): Boolean =
        valid(
            signal = intent.signal,
            openId = intent.openId,
            eventId = intent.eventId,
            anonymousId = intent.anonymousId,
            deviceId = intent.deviceId,
            installId = intent.installId,
            userId = intent.userId,
            sessionId = intent.sessionId,
            fingerprint = intent.fingerprint,
            source = intent.source,
            routePathHash = intent.routePathHash,
        ) &&
            intent.createdAtMs > 0 &&
            intent.expiresAtMs > intent.createdAtMs &&
            intent.expiresAtMs - intent.createdAtMs <= LIFETIME_MS &&
            intent.attempt >= 0 &&
            intent.nextAttemptAtMs >= intent.createdAtMs &&
            (intent.result?.isValid() != false)

    private fun valid(
        signal: Signal,
        openId: String,
        eventId: String,
        anonymousId: String,
        deviceId: String,
        installId: String,
        userId: String?,
        sessionId: String,
        fingerprint: String,
        source: String,
        routePathHash: String,
    ): Boolean {
        if (!UUID_PATTERN.matches(openId) ||
            !UUID_PATTERN.matches(eventId) ||
            !IDENTIFIER_PATTERN.matches(anonymousId) ||
            !IDENTIFIER_PATTERN.matches(deviceId) ||
            !IDENTIFIER_PATTERN.matches(installId) ||
            !boundedOptional(userId, MAX_USER_ID_BYTES) ||
            !boundedRequired(sessionId, MAX_CONTEXT_ID_BYTES) ||
            !boundedRequired(fingerprint, MAX_CONTEXT_ID_BYTES) ||
            source !in VALID_SOURCES ||
            !HASH_PATTERN.matches(routePathHash)
        ) return false
        return when (signal.kind) {
            KIND_CLICK ->
                signal.host == null &&
                    signal.slug == null &&
                    signal.clickId?.let(AppLinkResolver::isCanonicalClickId) == true
            KIND_ROUTE ->
                signal.clickId == null &&
                    signal.host?.let(HOST_PATTERN::matches) == true &&
                    signal.slug?.let(SLUG_PATTERN::matches) == true
            else -> false
        }
    }

    companion object {
        const val CAPACITY = 16
        const val LIFETIME_MS = 24 * 60 * 60 * 1_000L
        const val MAX_DELAY_MS = 60 * 60 * 1_000L
        internal const val KIND_CLICK = "click_id"
        internal const val KIND_ROUTE = "route"
        private const val STATE_VERSION = 3
        private const val MAX_FILE_BYTES = 64 * 1_024
        private const val MAX_CONTEXT_ID_BYTES = 256
        private const val MAX_USER_ID_BYTES = 512
        private const val RECEIPT_CAPACITY = 32
        internal const val RECEIPT_LIFETIME_MS = 30_000L
        private const val TAG = "Kixo.DirectLinkStore"
        private val JSON = Json {
            encodeDefaults = true
            ignoreUnknownKeys = true
        }
        private val UUID_PATTERN = Regex(
            "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-" +
                "[89aAbB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$",
        )
        private val IDENTIFIER_PATTERN = Regex("^[A-Za-z0-9._:-]{8,128}$")
        private val LINK_ID_PATTERN = Regex("^[A-Za-z0-9_-]{1,128}$")
        private val HOST_PATTERN = Regex(
            "^(?=.{1,253}$)" +
                "[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?" +
                "(?:\\.[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?)*$",
        )
        private val SLUG_PATTERN = Regex("^[A-Za-z0-9-]{1,60}$")
        private val HASH_PATTERN = Regex("^[0-9a-f]{16}$")
        private val VALID_SOURCES = setOf(
            AttributionContract.DL_SOURCE_APPLINK,
            AttributionContract.DL_SOURCE_PUSH,
            AttributionContract.DL_SOURCE_MANUAL,
        )

        private fun boundedRequired(value: String, maxBytes: Int): Boolean =
            value.isNotBlank() &&
                value.toByteArray(Charsets.UTF_8).size <= maxBytes &&
                value.none(Char::isISOControl)

        private fun boundedOptional(value: String?, maxBytes: Int): Boolean =
            value == null || boundedRequired(value, maxBytes)

        fun retryDelayMs(attempt: Int): Long {
            val exponent = (attempt - 1).coerceIn(0, 12)
            val seconds = (1L shl exponent).coerceAtMost(MAX_DELAY_MS / 1_000)
            return seconds * 1_000
        }

        fun create(
            context: Context,
            projectId: String,
            environment: String,
            apiHost: String,
        ): DirectLinkResolveStore {
            val appContext = context.applicationContext
            val scope = sha256(
                listOf(
                    projectId,
                    environment,
                    apiHost,
                    appContext.packageName,
                ).joinToString("|"),
            ).take(24)
            val directory = File(appContext.noBackupFilesDir, "kixo")
            val file = File(directory, "direct-link-resolve-$scope.json")
            return DirectLinkResolveStore(
                persistence = AtomicPersistence(file),
                projectScope = scope,
            )
        }

        private fun sha256(value: String): String =
            MessageDigest.getInstance("SHA-256")
                .digest(value.toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
    }

    private class AtomicPersistence(file: File) : Persistence {
        private val file = file
        private val backupFile = File("${file.path}.bak")
        private val newFile = File("${file.path}.new")
        private val atomic = AtomicFile(file)

        override fun read(): Persistence.ReadResult =
            try {
                atomic.openRead().use {
                    Persistence.ReadResult.Value(
                        it.readBytes().toString(Charsets.UTF_8),
                    )
                }
            } catch (_: FileNotFoundException) {
                Persistence.ReadResult.Missing
            } catch (t: Throwable) {
                Log.w(TAG, "Direct-link state read failed", t)
                Persistence.ReadResult.Failure
            }

        override fun write(value: String?): Boolean {
            if (value == null) {
                return runCatching {
                    atomic.delete()
                    !file.exists() && !backupFile.exists() && !newFile.exists()
                }.getOrDefault(false)
            }
            return try {
                file.parentFile?.mkdirs()
                val output = atomic.startWrite()
                try {
                    output.write(value.toByteArray(Charsets.UTF_8))
                    output.flush()
                    atomic.finishWrite(output)
                    true
                } catch (t: Throwable) {
                    atomic.failWrite(output)
                    throw t
                }
            } catch (t: Throwable) {
                Log.w(TAG, "Direct-link state write failed", t)
                false
            }
        }
    }
}
