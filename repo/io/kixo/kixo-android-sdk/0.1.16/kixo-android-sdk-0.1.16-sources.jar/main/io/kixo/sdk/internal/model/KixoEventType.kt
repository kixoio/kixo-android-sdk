package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Canonical event type taxonomy. Mirrors iOS `KixoEventType`
 * ([Models/Event.swift]) one-for-one — the backend ClickHouse
 * `events.event_type` column is `LowCardinality(String)` and only
 * accepts the values listed here.
 *
 * Wire shape is the snake_case `@SerialName` value. Adding a new
 * variant must be coordinated with the iOS counterpart and the
 * backend ingest router (`/api/sdk/batch`) — unrecognised
 * `event_type` values are dropped with `permanent=true` server-side.
 *
 * Per AGENT_BRIEFING.md R3, every wire field is snake_case; the enum
 * constant names are Kotlin idiomatic UpperCamelCase but the JSON
 * serialization always emits the `@SerialName` value.
 */
@Serializable
internal enum class KixoEventType {
    @SerialName("screen_view") ScreenView,
    @SerialName("tap") Tap,
    @SerialName("scroll") Scroll,
    @SerialName("network") Network,
    @SerialName("crash") Crash,
    @SerialName("custom") Custom,
    @SerialName("session_start") SessionStart,
    @SerialName("session_end") SessionEnd,
    @SerialName("identify") Identify,
    @SerialName("group") Group,
    @SerialName("lifecycle") Lifecycle,
    @SerialName("navigation") Navigation,
    @SerialName("gesture") Gesture,
    @SerialName("push_open") PushOpen,
    @SerialName("push_received") PushReceived,
    @SerialName("push_dismissed") PushDismissed,
    @SerialName("push_silent") PushSilent,
    @SerialName("push_action") PushAction,
    @SerialName("push_permission") PushPermission,
    @SerialName("push_token_invalidated") PushTokenInvalidated,
    @SerialName("deep_link") DeepLink,
    @SerialName("iap") Iap,
    @SerialName("user_property") UserProperty,

    /**
     * **The canonical install signal (§0 §2, KIX-DL-01).** Fired EXACTLY
     * ONCE per fresh install (`InstallEmitter`), with the public event NAME
     * `app_install` ([AttributionContract.APP_INSTALL_EVENT_NAME]). The wire
     * `event_type` value `"install"` IS the §0 install-discovery key — the
     * backend keys install detection on `event_type == 'install'`, NOT on
     * `standard_kind`. Mirrors iOS `KixoEventType.install`
     * ([Models/Event.swift]) one-for-one + the §0 contract
     * [AttributionContract.INSTALL_EVENT_TYPE].
     *
     * Without this case `wireToEnum("install")` fell through to [Custom] and
     * the install event shipped as `event_type="custom"` → the backend's
     * install-discovery (Link.installCount, organic detection, FREE-cap dedup)
     * stayed 100% dark on Android (BLOCKER A).
     */
    @SerialName("install") Install,

    /**
     * **Android-only synthetic Install-Referrer enrichment (§0 §2-cont,
     * KIX-DL Wave 2).** Carries the Play Install Referrer payload (utm_* /
     * click-injection ordering timestamps) into `/api/sdk/batch`, consumed by
     * `lib/attribution/referrer-post-processor.ts::processReferrerEvents` which
     * keys on the (event_type=`attribution`, event_name=`install_referrer`)
     * tuple ([AttributionContract.REFERRER_EVENT_TYPE] /
     * [AttributionContract.REFERRER_EVENT_NAME]).
     *
     * DISTINCT from [Install]: one fresh install emits BOTH the `app_install`
     * (`event_type=install`) signal AND this `install_referrer`
     * (`event_type=attribution`) enrichment. There is no iOS counterpart — the
     * Play Install Referrer is an Android-only API — so this case is Android-
     * only by design (the backend `events.event_type` column is
     * `LowCardinality(String)` and accepts it). Without this case
     * `wireToEnum("attribution")` fell through to [Custom] and the referrer
     * enrichment never reached `processReferrerEvents` (BLOCKER B).
     */
    @SerialName("attribution") Attribution,

    /**
     * **C.2 always-on flow stream.** One event per logical screen
     * visit (entered/exited/dwell/tap+scroll counts + name
     * candidates). Drains on background / terminate via
     * `FlowRecorder`. Replaces `screenView` as the primary flow
     * signal once the +14d soak completes (Phase C.2.7 on iOS;
     * Android ships at parity from day one).
     */
    @SerialName("screen_visit") ScreenVisit,

    /**
     * Cross-platform goal marker (Wave 7 #C2, May 2026).
     * Mirrors the web SDK's `Kixo.markGoal(name, opts)` /
     * `data-kixo-goal` HTML attribute and iOS's `goal`. Backend
     * auto-goals detector treats `event_type=goal` as ground truth
     * regardless of platform.
     */
    @SerialName("goal") Goal,
}
