package io.kixo.sdk.internal.privacy

/**
 * Phase C.3 — PII regex / heuristic sanitizer applied to every text
 * run that lands in a structural snapshot, regardless of source pass.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Replay/PIIFilter.swift`.
 *
 * **Single-point sanitization mandate** (per AGENT_BRIEFING.md R2):
 * a11y labels, `TextView.text`, OCR runs, and `Mirror`-derived names
 * ALL pass through this filter before reaching the wire format. One
 * place to gate so a new structural pass can't forget the gate and
 * leak a customer's email.
 *
 * **Coverage** (priority order, see [PiiPatterns.ALL]):
 *   1. Email
 *   2. Phone (E.164, US-formatted)
 *   3. Credit card (Luhn-validated, NOT just digit-count)
 *   4. SSN (US 3-2-4 hyphenated)
 *   5. JWT
 *   6. IBAN
 *
 * Optional (off by default) NER pass via [EntityTagger] catches
 * `personalName` tokens that the regex set misses.
 *
 * **Full bounded-string scan.** Every pattern has fixed quantifier
 * ceilings in [PiiPatterns], so the filter scans the complete input
 * supplied by the bounded replay/event/crash pipelines. Head/tail
 * windows are not safe here: PII can appear in the middle or span a
 * window boundary.
 */
internal class PiiFilter(
    /**
     * Optional NER tagger. When non-null and [scanWithNer] is called,
     * the sanitiser also identifies and redacts personal-name tokens
     * via ML Kit Entity Extraction. Off by default — operator must
     * opt in via configuration because (a) it adds a dependency and
     * (b) ML Kit's annotator allocates ~5MB of model data.
     */
    private val entityTagger: EntityTagger? = null,
) {

    /**
     * Locate every PII match in [text] without modifying the input.
     *
     * Runs each [PiiPatterns.ALL] regex over the full input, validates
     * Luhn for card matches, and returns a
     * deduplicated overlap-resolved match list sorted by [PiiMatch.startIdx].
     *
     * **Overlap policy:** when two patterns match overlapping spans
     * (e.g. an IBAN regex and a JWT regex both grabbing a long
     * alphanumeric run), the FIRST in [PiiPatterns.ALL] order wins.
     * The pattern table is ordered most-specific-first for this
     * reason — `EMAIL` before `JWT`, `JWT` before generic IBAN.
     *
     * **No allocation on no-PII path.** If the regex engine finds no
     * matches at all, this returns the singleton [emptyList] — the
     * fast path for the typical "no PII" text run that dominates
     * structural snapshots.
     */
    fun scan(text: String): List<PiiMatch> {
        if (text.isEmpty()) return emptyList()

        val raw = mutableListOf<PiiMatch>()
        collectInto(raw, text)
        if (raw.isEmpty()) return emptyList()
        return resolveOverlaps(raw)
    }

    /**
     * Same as [scan] but additionally runs the optional NER tagger
     * to find personal names. Operator must wire an [EntityTagger]
     * into the constructor for this to do more than [scan].
     *
     * Synchronous — calls into [EntityTagger.findEntities] which
     * holds the single-thread lock internally (mirrors iOS NLTagger
     * lock fix from C.3v3). Caller is expected to be on the OCR
     * queue, never the main thread.
     */
    fun scanWithNer(text: String): List<PiiMatch> {
        val regexMatches = scan(text)
        val tagger = entityTagger ?: return regexMatches
        // Avoid round-tripping NER for very short labels — the
        // ML Kit annotator returns nothing useful and we save a
        // lock acquisition.
        if (text.length < NER_MIN_LENGTH) return regexMatches
        val entities = tagger.findEntities(text)
        if (entities.isEmpty()) return regexMatches
        // Merge regex + NER, then resolve overlaps. Regex wins ties
        // (it's the deterministic source) — accomplished by listing
        // regex matches first.
        val merged = ArrayList<PiiMatch>(regexMatches.size + entities.size)
        merged += regexMatches
        merged += entities
        return resolveOverlaps(merged)
    }

    /**
     * Replace every match in [text] with its [PiiKind.placeholder].
     * Returns the original [text] reference if no matches — zero
     * allocation on the common no-PII path.
     *
     * Replacement walks matches end-to-start so earlier offsets stay
     * valid as we splice. Builds one [StringBuilder] for the result.
     */
    fun redact(text: String): String {
        val matches = scan(text)
        if (matches.isEmpty()) return text
        return applyReplacements(text, matches)
    }

    /**
     * Variant of [redact] that includes NER findings. Same semantics
     * as [scanWithNer] vs [scan].
     */
    fun redactWithNer(text: String): String {
        val matches = scanWithNer(text)
        if (matches.isEmpty()) return text
        return applyReplacements(text, matches)
    }

    /**
     * Boolean fast path: "is there ANY PII in this string?" — used
     * by the structural snapshot pipeline to set a `redacted=true`
     * flag on a container without rewriting child text. Skips the
     * Luhn pass for cards (an over-detection here is acceptable;
     * the container masking is the same either way).
     *
     * Patterns have fixed quantifier ceilings, so this scans the full
     * caller-bounded text. Missing PII is more costly than masking an
     * extra container.
     */
    fun looksLikePii(text: String): Boolean {
        if (text.isEmpty()) return false
        for (pattern in PiiPatterns.ALL) {
            // Intentionally NO Luhn check — this is the FAST boolean
            // path for "should I mask this container at all?". An
            // over-detection here just masks an extra container; a
            // false negative leaks PII. Asymmetric cost → skip Luhn.
            if (pattern.regex.containsMatchIn(text)) return true
        }
        return false
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    private fun collectInto(
        out: MutableList<PiiMatch>,
        text: String,
    ) {
        for (pattern in PiiPatterns.ALL) {
            for (match in pattern.regex.findAll(text)) {
                val span = match.value
                if (pattern.requiresLuhn && !PiiPatterns.luhnValid(span)) continue
                out += PiiMatch(
                    kind = pattern.kind,
                    startIdx = match.range.first,
                    endIdx = match.range.last + 1,
                    value = span,
                )
            }
        }
    }

    /**
     * Resolve overlapping matches. Sort by start index, then for any
     * two adjacent matches that overlap, drop the LATER one (earlier
     * pattern wins per ordering in [PiiPatterns.ALL] — but since we
     * sort by startIdx here, the "earlier" tie-breaker is positional).
     *
     * Identical-start ties (rare — two patterns matching from the
     * same offset) keep the LONGER match: redacting more is the
     * safer default.
     */
    private fun resolveOverlaps(matches: List<PiiMatch>): List<PiiMatch> {
        if (matches.size == 1) return matches
        val sorted = matches.sortedWith(
            compareBy<PiiMatch> { it.startIdx }
                .thenByDescending { it.endIdx - it.startIdx },
        )
        val out = ArrayList<PiiMatch>(sorted.size)
        var lastEnd = -1
        for (m in sorted) {
            if (m.startIdx >= lastEnd) {
                out += m
                lastEnd = m.endIdx
            }
            // Else: m overlaps the previous accepted match — drop it.
        }
        return out
    }

    private fun applyReplacements(text: String, matches: List<PiiMatch>): String {
        // Pre-size the builder optimistically. Worst case the
        // placeholders are longer than the matches and we grow.
        val sb = StringBuilder(text.length)
        var cursor = 0
        for (m in matches) {
            if (m.startIdx > cursor) {
                sb.append(text, cursor, m.startIdx)
            }
            sb.append(m.kind.placeholder)
            cursor = m.endIdx
        }
        if (cursor < text.length) {
            sb.append(text, cursor, text.length)
        }
        return sb.toString()
    }

    internal companion object {
        /**
         * Below this length the NER tagger almost never returns a
         * useful tag (single-word labels like "OK" or "Cancel"). Skip
         * the lock acquisition.
         */
        internal const val NER_MIN_LENGTH: Int = 4

        /**
         * Default singleton with NER disabled — cheap to share across
         * the SDK for the common case where the host app didn't opt
         * in to entity-extraction. Operator gets a NER-enabled
         * instance via [PiiFilter.withNer].
         */
        internal val DEFAULT: PiiFilter = PiiFilter(entityTagger = null)

        /**
         * Construct a filter with NER enabled. Returns a no-NER
         * fallback if ML Kit isn't on the runtime classpath
         * (i.e. the host app excluded the optional dep).
         */
        internal fun withNer(): PiiFilter {
            val tagger = EntityTagger.tryCreate() ?: return DEFAULT
            return PiiFilter(entityTagger = tagger)
        }
    }
}
