package io.kixo.sdk.internal.replay.upload

import android.util.Log
import io.kixo.sdk.internal.replay.ReplayCapture
import io.kixo.sdk.internal.replay.ReplayConfig
import io.kixo.sdk.internal.replay.ReplayController
import io.kixo.sdk.internal.replay.ReplayResumeState
import io.kixo.sdk.internal.replay.ReplaySessionOpenResult
import io.kixo.sdk.internal.replay.ReplayUploaderRef
import kotlinx.coroutines.CancellationException
import java.time.Instant
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

/**
 * Boundary translator between Agent 13's
 * [io.kixo.sdk.internal.replay.ReplayController.ReplayUploaderRef]
 * stub interface and Agent 14's concrete pipeline pair
 * ([ReplayUploader] + [ReplaySessionLifecycle]).
 *
 * **Why an adapter exists at all.** Per AGENT_BRIEFING §6, each
 * agent's folder declares stub interfaces for cross-folder calls
 * rather than depending on another agent's concrete types. The
 * controller's stub shape (`beginSession(config)` /
 * `uploadCapture(capture)` / `endSession()`) was authored before the
 * concrete uploader's shape (`openSession(...)` /
 * `uploadFrame(seq, kind, ...)` / `closeSession(reason)`) was nailed
 * down. Rather than churn either side, this adapter is the seam.
 *
 * **What the seam does:**
 *
 * - [beginSession] maps to [ReplaySessionLifecycle.openSession]. The
 *   per-session metadata that openSession needs (`sessionId`,
 *   `installationId`, `userId`, `releaseId`, `triggers`, `region`,
 *   `flags`) is NOT part of [ReplayConfig]; the lifecycle/identity
 *   tracker collects them and the bootstrap (which constructs this
 *   adapter) supplies them via constructor `*Provider` lambdas. They
 *   are read at `beginSession` time so a userId update between
 *   construction and session-start is honoured.
 *
 * - [uploadCapture] fans a single [ReplayCapture] into 2-4 calls to
 *   [ReplayUploader.uploadFrame] — one per [FrameKind] that has a
 *   payload (PRE if `preFrame` non-null, POST if `postFrame` non-null,
 *   STRUCTURAL if `structuralJson` non-null, OCR if `ocrText`
 *   non-empty). The interaction metadata + screen identity rides on
 *   the FIRST call's `eventMeta` map (so `/api/sdk/replay/events` gets
 *   one row per gesture, not 2-4). Subsequent fan-out calls pass an
 *   empty `eventMeta` so the batcher only enqueues the gcs_path
 *   enrichment when there's nothing else to bundle. Fan-out order is
 *   deterministic (PRE before POST before STRUCTURAL before OCR) so
 *   the `pre_frame_path` lands on the same event row as the
 *   interaction meta.
 *
 * - [endSession] maps to
 *   [ReplaySessionLifecycle.closeSession] with reason
 *   [ReplaySessionLifecycle.EndReason.FOREGROUND_TO_BACKGROUND] —
 *   the typical caller is `appBackgrounded` /
 *   `Kixo.flush()`. Opt-out / low-memory / superseded reasons are
 *   surfaced from the controller via dedicated paths that bypass
 *   this adapter.
 *
 * **Anti-crash.** Per AGENT_BRIEFING §3 R6, every error path swallows
 * + logs. A null `activeUploader()` (race window where the lifecycle
 * sealed mid-call) drops the capture silently with a debug log.
 */
internal class ReplayUploaderAdapter(
    private val lifecycle: ReplaySessionLifecycle,
    /**
     * Per-session metadata providers. Read at [beginSession] time so
     * the bootstrap doesn't have to hold a stale snapshot. Defaults
     * are safe no-ops — caller wires the real producers (Agent 15's
     * IdentityManager + Agent 7's session tracker).
     */
    private val sessionIdProvider: () -> String,
    private val installationIdProvider: () -> String,
    private val userIdProvider: () -> String? = { null },
    private val releaseIdProvider: () -> String = { "" },
    private val triggersProvider: () -> List<String> = { listOf("baseline") },
    private val regionProvider: () -> String = { "us" },
    private val flagsProvider: () -> Map<String, Boolean>? = { null },
) : ReplayUploaderRef {

    /**
     * Open the backend session. Delegates to
     * [ReplaySessionLifecycle.openSession]. The typed result lets the
     * controller retry transient failures without spinning on terminal or
     * policy-paused responses.
     */
    override suspend fun beginSession(config: ReplayConfig): ReplaySessionOpenResult {
        return try {
            val sessionId = sessionIdProvider()
            // KIX-UNI-01 resume contract (v2, F6): when the analytics
            // session id is unchanged since the last ended stint, tell
            // the backend to pre-sign URLs from the continued counter
            // (the controller seeded its seq mint from the same
            // state). Resumed stints ALWAYS send `next_seq` —
            // INCLUDING 0 (a zero-tap stint must still reopen the
            // SEALED row); fresh stints send null (key omitted on
            // the wire).
            val resumeNextSeq: Long? = ReplayResumeState.resumeSeqFor(sessionId)
            val result = lifecycle.openSession(
                sessionId = sessionId,
                installationId = installationIdProvider(),
                userId = userIdProvider(),
                releaseId = releaseIdProvider(),
                triggers = triggersProvider(),
                region = regionProvider(),
                flags = flagsProvider(),
                nextSeq = resumeNextSeq,
            )
            if (result !is ReplaySessionOpenResult.Opened) {
                Log.d(TAG, "lifecycle.openSession returned ${result::class.simpleName}")
            }
            result
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle.openSession threw", t)
            ReplaySessionOpenResult.Retryable
        }
    }

    /**
     * Fan a single [ReplayCapture] into 1-4 [ReplayUploader.uploadFrame]
     * calls. The interaction + screen-identity metadata rides on the
     * first call so `/api/sdk/replay/events` gets one event row per
     * gesture (subsequent calls pass empty `eventMeta`).
     *
     * **Bitmap ownership (FIX 1, 2026-07-05): this adapter is the SINGLE
     * OWNER on the success path.** Under PixelCopy each capture's
     * `preFrame` / `postFrame` is a FRESH native RGB_565 Bitmap (not
     * pooled). [ReplayUploader.uploadFrame] encodes the Bitmap to a JPEG
     * byte array **synchronously** (it stages the bytes to disk before
     * returning) and does NOT recycle the source. So once the fan-out
     * completes the bitmaps are no longer needed by anyone — we recycle
     * them here in a `finally`, promptly (not GC-deferred), to avoid heap
     * pressure in the replay hot path. OCR (`ocr.extract(postFrame)`) runs
     * in the controller BEFORE this call, so `postFrame` is safe to
     * recycle once we return. The controller's own `finally` recycles ONLY
     * the not-yet-handed-off (failure / early-return / exception-before-
     * uploadCapture) paths, so no bitmap is recycled twice; the
     * `!isRecycled` guard here is belt-and-braces against any double
     * recycle.
     */
    override suspend fun uploadCapture(capture: ReplayCapture) {
        // If the lifecycle sealed between the controller dispatching
        // and us being scheduled (race window), silently drop. The
        // event timeline still records the gesture via Agent 5's
        // EventQueue — we just lose the frame.
        //
        // FIX 1: recycle the fresh PixelCopy bitmaps even on this early
        // return — the controller marks ownership TAKEN as soon as this
        // call returns without throwing, so its `finally` won't recycle
        // them; we're the single owner from the moment we're invoked.
        val live = lifecycle.activeUploader()
        if (live == null) {
            Log.d(TAG, "uploadCapture (seq=${capture.seq}) dropped: no active session")
            recycleFrames(capture)
            return
        }
        try {
            fanOut(capture, live)
        } finally {
            // FIX 1 — single-owner recycle. uploadFrame encoded each
            // bitmap synchronously (bytes already staged), so the source
            // bitmaps are dead here on EVERY path out of the fan-out
            // (success, per-frame drop, or a throw). Guarded so a double
            // recycle can't crash.
            recycleFrames(capture)
        }
    }

    /** FIX 1 — recycle a capture's pre/post frames iff live. Idempotent. */
    private fun recycleFrames(capture: ReplayCapture) {
        capture.preFrame?.takeIf { !it.isRecycled }?.recycle()
        capture.postFrame?.takeIf { !it.isRecycled }?.recycle()
    }

    /** The 1-4 [ReplayUploader.uploadFrame] fan-out. */
    private suspend fun fanOut(capture: ReplayCapture, live: ReplayUploader) {

        // Build the metadata we attach to the FIRST kind in the fan-out
        // (so each gesture lands as exactly one row in
        // session_replay_events). Mirrors iOS sidecar shape — see
        // `kixo-ios-sdk/Sources/Kixo/Replay/ReplayController.swift`
        // lines 4013-4051 (`postTapEvent`). Wave 1 (KIX-UNI-02/03): both
        // keys carry the same 8-hex analytics fingerprint —
        // `screen_identity_hash` is the replay-native cluster key,
        // `screen_fingerprint` is the cross-stream bridge column.
        val firstMeta = HashMap<String, Any?>(14).apply {
            putAll(capture.interaction.toPropertyMap())
            // AND-CAP-05 — REQUIRED by the backend
            // (/api/sdk/replay/events): captured_at_pre/post are read
            // as ISO-8601 and stamped into CH `ts_pre` / `ts`. Without
            // them the backend fell back to server-receive time so the
            // player mis-placed the tap dot. `captured_at_pre` = gesture
            // time; `captured_at_post` = the REAL PixelCopy callback
            // wall-clock. Also emit `tap_duration_ms` (mirrors iOS' 50)
            // which the backend maps to CH `tap_duration_ms`.
            put("captured_at_pre", toIso8601(capture.capturedAtPreMs))
            put("captured_at_post", toIso8601(capture.capturedAtPostMs))
            put("tap_duration_ms", 50)
            // AND-CAP-05 — non-gesture trigger override
            // (screen_change / dirty / heartbeat) shipped as the raw
            // wire `tap_kind`, overriding the taxonomy enum value from
            // toPropertyMap() above. Player special-cases these.
            capture.tapKindOverride?.let { put("tap_kind", it) }
            capture.screenIdentity?.let {
                put("screen_identity_hash", it.hash)
                put("screen_fingerprint", it.hash)
            }
        }
        var metaUsed = false

        // Deterministic order — PRE before POST before STRUCTURAL
        // before OCR — so `pre_frame_path` lands on the same event row
        // as the interaction meta when both are present.
        if (capture.preFrame != null) {
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.PRE,
                bitmap = capture.preFrame,
                eventMeta = firstMeta,
                jpegQuality = capture.jpegQuality,
                encodeDownscale = capture.encodeDownscale,
            )
            metaUsed = true
        }

        if (capture.postFrame != null) {
            val meta = if (!metaUsed) firstMeta.also { metaUsed = true } else emptyMap()
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.POST,
                bitmap = capture.postFrame,
                eventMeta = meta,
                jpegQuality = capture.jpegQuality,
                encodeDownscale = capture.encodeDownscale,
            )
        }

        if (capture.structuralJson != null) {
            val meta = if (!metaUsed) firstMeta.also { metaUsed = true } else emptyMap()
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.STRUCTURAL,
                structuralJson = capture.structuralJson.toString(),
                eventMeta = meta,
            )
        }

        if (capture.ocrText.isNotEmpty()) {
            val meta = if (!metaUsed) firstMeta.also { metaUsed = true } else emptyMap()
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.OCR,
                ocrText = capture.ocrText,
                eventMeta = meta,
            )
        }

        // Edge case: capture had no payloads at all (pre/post both
        // null, structural null, ocr empty). Still ship the metadata
        // event so the gesture is on the timeline. Use the OCR slot
        // (lightest payload) with empty text — uploadFrame's encoder
        // returns null on null OCR text, which falls through to the
        // "drop frame, keep event" branch in ReplayUploader. The
        // gesture lands on /replay/events with no gcs_path and the
        // player renders a metadata-only marker.
        if (!metaUsed) {
            live.uploadFrame(
                seq = capture.seq,
                kind = FrameKind.OCR,
                ocrText = null,
                eventMeta = firstMeta,
            )
        }
    }

    /**
     * Seal the session via
     * [ReplaySessionLifecycle.closeSession]. Default reason is
     * [ReplaySessionLifecycle.EndReason.FOREGROUND_TO_BACKGROUND] —
     * the only path that flows through this adapter is the
     * controller's normal `stop()`. Opt-out / low-memory / app-killed
     * sealings are dispatched directly via the lifecycle (the
     * controller handles those out-of-band).
     */
    override suspend fun endSession() {
        try {
            lifecycle.closeSession(ReplaySessionLifecycle.EndReason.FOREGROUND_TO_BACKGROUND)
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle.closeSession threw", t)
        }
    }

    override suspend fun endSessionForTimeout() {
        try {
            lifecycle.closeSession(ReplaySessionLifecycle.EndReason.TIMEOUT)
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle timeout close threw", t)
        }
    }

    override suspend fun endSessionForOptOut() {
        try {
            lifecycle.closeSessionForOptOut()
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle opt-out close threw", t)
        }
    }

    /** Identity/policy boundary: erase local replay work without a final RPC. */
    override suspend fun discardSession() {
        try {
            lifecycle.discardSession()
        } catch (t: Throwable) {
            Log.w(TAG, "lifecycle.discardSession threw", t)
        }
    }

    companion object {
        private const val TAG = "Kixo.ReplayUploaderAdapter"

        /**
         * AND-CAP-05 — epoch millis → ISO-8601 with fractional seconds
         * + trailing Z (UTC), matching the iOS
         * `ISO8601DateFormatter([.withInternetDateTime,
         * .withFractionalSeconds])` shape the backend `new Date(iso)`
         * parses. `minSdk=24` + core-library desugaring makes
         * java.time available.
         */
        private val ISO_FMT: DateTimeFormatter =
            DateTimeFormatter.ISO_OFFSET_DATE_TIME.withZone(ZoneOffset.UTC)

        internal fun toIso8601(epochMs: Long): String =
            ISO_FMT.format(Instant.ofEpochMilli(epochMs))
    }
}
