package io.kixo.sdk.internal.screen

import android.util.Log
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import java.util.UUID

/**
 * Emits a lightweight `screen_visit` event for every accepted screen
 * change. Mirrors iOS [FlowRecorder] — always-on (NOT gated by replay
 * sample verdict) so `/journey` Flows / App Map / Funnel get full
 * coverage even on sessions that aren't sampled for replay.
 *
 * **Why a separate stream from `screen_view`:** historically iOS used
 * `event_type = screen_view`. That path is unreliable on iOS 26 SwiftUI
 * Metal-direct (10 events/day vs 190 replay tap rows) and the same
 * pattern is expected on Android Compose. `screen_visit` is the
 * always-on, structurally-derived signal; `screen_view` from
 * [Kixo.screen("name")] explicit calls is a separate (manual) signal.
 *
 * **Emit-on-CLOSE (Wave 1, KIX-UNI-03 — iOS FlowRecorder parity):**
 * a visit is opened by [recordVisit] but only emitted when it CLOSES —
 * either because the NEXT visit was accepted (`exit_reason=forward`)
 * or because the app backgrounded (`exit_reason=background`, driven
 * by the process-lifecycle `app_background` signal wired in
 * `Kixo.configure`). Closing lets the event carry `dwell_ms` /
 * `exited_at`. The event `timestamp` stays the visit's ENTRY wall
 * clock so timestamp-based ordering matches pre-Wave-1 rows. A visit
 * left open on process kill is lost — accepted (iOS parity).
 *
 * **Decoupling from EventQueue:** Agent 5 owns the actual
 * `EventQueue.enqueue` API. To keep the screen package independent we
 * bind via [emitter] — Agent 1's [Kixo.configure] sets the emitter
 * lambda once, pointing at `EventQueue.enqueue`. Until set, CLOSED
 * emissions are buffered in [pendingBeforeBind] (capped at 32,
 * drop-oldest) so the early screens during cold-start aren't lost.
 *
 * Wire format mirrors iOS — same `event_type`, same property keys,
 * same snake_case (AGENT_BRIEFING.md §3 R3):
 *
 * ```
 * {
 *   "event_type":   "screen_visit",
 *   "event_name":   "<resolved screen name>",
 *   "fingerprint":  "<screen fingerprint hex>",
 *   "timestamp":    <visit ENTRY wall clock>,
 *   "properties": {
 *     "screen_id":             "<fingerprint hex>",
 *     "screen_name":           "<resolved name>",
 *     "prev_screen_id":        "<previous fingerprint hex>" | null,
 *     "trigger":               "activity_resumed"|"fragment_resumed"|"compose_route"|"explicit_override",
 *     "visit_id":              "<UUID minted at visit entry>",
 *     "entry_index":           <0-based, monotonic per analytics session>,
 *     "entered_at":            <epoch millis>,
 *     "exited_at":             <epoch millis>,
 *     "dwell_ms":              <exited_at - entered_at, ≥ 0>,
 *     "exit_reason":           "forward"|"background",
 *     "_kixo_name_candidates": [ {text, source, confidence}, ... ]
 *   }
 * }
 * ```
 *
 * **Threading:** [recordVisit] is called from the main thread by
 * [ScreenTracker]; [onAppBackground] from the main-thread process
 * observer. [bindEmitter]/[bindSessionIdProvider] can arrive from the
 * `Kixo.configure` thread — visit state is guarded by [stateLock].
 * The emitter lambda is invoked synchronously and Agent 5's
 * [EventQueue] handles the off-main hop internally.
 */
internal object ScreenVisitRecorder {

    private const val TAG = "Kixo"

    /**
     * Cap on events buffered before the EventQueue emitter is bound.
     * Unbounded buffering would let a misconfigured host that never
     * calls [Kixo.configure] grow memory indefinitely. 32 is enough
     * for the typical "configure happens after the first 1-2 screens"
     * race; older entries silently drop.
     */
    private const val MAX_PENDING_BEFORE_BIND = 32

    /**
     * Single emitter slot, written once by [bindEmitter]. Volatile +
     * a single producer (Agent 1) means we don't need a lock around
     * read-then-call. The sigil "Emitter" is intentionally narrow —
     * it accepts only the per-event params we care about, not a
     * full [KixoEvent] DTO, so this file doesn't depend on Agent 2's
     * model package shape.
     */
    @Volatile
    private var emitter: Emitter? = null

    /**
     * Analytics session id source, bound by Agent 1 alongside the
     * emitter ([bindSessionIdProvider]). Drives the per-session
     * `entry_index` counter reset. Returns null pre-bootstrap /
     * pre-bind — the counter then keeps counting (see
     * [nextEntryIndexLocked]) so buffered cold-start visits keep
     * their entry order without duplicate indices after bind.
     */
    @Volatile
    private var sessionIdProvider: () -> String? = { null }

    /** FIFO of closed-but-unsent emissions (drop-oldest at cap). */
    private val pendingBeforeBind = ArrayDeque<Emission>(MAX_PENDING_BEFORE_BIND)

    /** Guards [currentVisit] / [entryCounter] / [lastSessionKey]. */
    private val stateLock = Any()

    /** The OPEN visit — emitted when the next visit closes it. */
    private var currentVisit: PendingVisit? = null

    /** 0-based per-analytics-session entry counter. */
    private var entryCounter: Int = 0

    /** Session id observed at the last [recordVisit] (null until known). */
    private var lastSessionKey: String? = null

    /**
     * Why this screen change happened, recorded so the backend can
     * reconstruct nav graphs. Mirrors iOS [ScreenVisit.TriggerKind]
     * but pruned to Android-relevant cases.
     */
    internal enum class Trigger(val wire: String) {
        ActivityResumed("activity_resumed"),
        FragmentResumed("fragment_resumed"),
        ComposeRoute("compose_route"),
        ExplicitOverride("explicit_override"),
    }

    /** Why the visit closed — wire values match iOS FlowRecorder. */
    private enum class ExitReason(val wire: String) {
        Forward("forward"),
        Background("background"),
    }

    /**
     * Single entry entrypoint. Idempotency / dedup is the caller's
     * responsibility ([ScreenTracker.maybeRecordVisit] does the 2 s
     * fingerprint window + 1 s name window — see iOS comment in
     * `ScreenTracker.swift` for the rationale on the dual window).
     *
     * Opens a new visit and CLOSES (emits) the previous one with
     * `exit_reason=forward`. `visit_id` / `entry_index` are assigned
     * here at ENTRY time — buffered pre-bind visits therefore keep
     * their entry order regardless of when the emitter binds.
     *
     * The previous identity is read from [ScreenIdentity] BEFORE the
     * caller updates it, so this method receives the new snapshot
     * directly and computes `prev_screen_id` from the atomic
     * getAndSet result.
     */
    fun recordVisit(
        snapshot: ScreenIdentity.Snapshot,
        previous: ScreenIdentity.Snapshot,
        trigger: Trigger,
    ) {
        val now = System.currentTimeMillis()
        val closed: Emission?
        synchronized(stateLock) {
            val visit = PendingVisit(
                visitId = UUID.randomUUID().toString(),
                entryIndex = nextEntryIndexLocked(readSessionKey()),
                screenId = snapshot.screenId,
                screenName = snapshot.screenName,
                prevScreenId = previous.screenId.takeIf { it.isNotEmpty() },
                candidates = snapshot.candidates,
                trigger = trigger,
                enteredAtMillis = now,
            )
            closed = currentVisit?.close(exitedAtMillis = now, exitReason = ExitReason.Forward)
            currentVisit = visit
        }
        closed?.let { emitOrBuffer(it) }
    }

    /**
     * Close + emit the open visit with `exit_reason=background`.
     * Driven by the existing process-lifecycle `app_background`
     * signal (ProcessLifecycleOwner-debounced — per-Activity stops
     * during in-app navigation do NOT fire this). No-op when no
     * visit is open.
     */
    fun onAppBackground() {
        val closed: Emission?
        synchronized(stateLock) {
            closed = currentVisit?.close(
                exitedAtMillis = System.currentTimeMillis(),
                exitReason = ExitReason.Background,
            )
            currentVisit = null
        }
        closed?.let { emitOrBuffer(it) }
    }

    /**
     * Bind the emitter lambda. Agent 1 calls this once from
     * [Kixo.configure]; subsequent calls REPLACE the binding
     * (covers `Kixo.configure` reconfiguration during tests).
     *
     * Drains any CLOSED visits buffered during cold-start. A still-
     * open visit is NOT drained — it emits through the live emitter
     * when it eventually closes.
     */
    fun bindEmitter(emitter: Emitter) {
        this.emitter = emitter
        val drained = synchronized(pendingBeforeBind) {
            val copy = pendingBeforeBind.toList()
            pendingBeforeBind.clear()
            copy
        }
        for (emission in drained) {
            try {
                emitter.emit(emission)
            } catch (t: Throwable) {
                Log.w(TAG, "screen_visit drain emit failed", t)
            }
        }
    }

    /**
     * Bind the analytics-session-id source for the `entry_index`
     * counter. Agent 1 calls this from [Kixo.configure] (same wiring
     * pass as [bindEmitter]).
     */
    fun bindSessionIdProvider(provider: () -> String?) {
        sessionIdProvider = provider
    }

    /**
     * Test seam — clear the bound emitter/provider, the open visit
     * and any pending buffer. Production code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        emitter = null
        sessionIdProvider = { null }
        synchronized(pendingBeforeBind) { pendingBeforeBind.clear() }
        synchronized(stateLock) {
            currentVisit = null
            entryCounter = 0
            lastSessionKey = null
        }
    }

    // ─── Internals ──────────────────────────────────────────────────

    private fun readSessionKey(): String? = try {
        sessionIdProvider()
    } catch (t: Throwable) {
        // R6 — a throwing provider must not kill the visit stream.
        Log.w(TAG, "screen_visit sessionIdProvider threw", t)
        null
    }

    /**
     * Assign the next `entry_index`, resetting the counter on a REAL
     * session roll (non-null → different non-null). A null→non-null
     * transition (cold-start visits recorded before the provider is
     * bound / before the session tracker booted) ADOPTS the id
     * without resetting — those buffered visits are stamped with the
     * drain-time session id downstream, so restarting the counter
     * would mint duplicate indices inside one session.
     */
    private fun nextEntryIndexLocked(sessionKey: String?): Int {
        if (sessionKey != null) {
            if (lastSessionKey != null && sessionKey != lastSessionKey) {
                entryCounter = 0
            }
            lastSessionKey = sessionKey
        }
        return entryCounter++
    }

    private fun emitOrBuffer(emission: Emission) {
        val em = emitter
        if (em == null) {
            // Pre-configure cold-start race — buffer for later drain.
            synchronized(pendingBeforeBind) {
                if (pendingBeforeBind.size >= MAX_PENDING_BEFORE_BIND) {
                    pendingBeforeBind.removeFirst()
                }
                pendingBeforeBind.addLast(emission)
            }
            return
        }
        try {
            em.emit(emission)
        } catch (t: Throwable) {
            // R6 — never crash the host. Emitter failure (e.g. queue
            // full because PausedByServer drained but emitter still
            // bound) just drops the visit.
            Log.w(TAG, "screen_visit emit failed", t)
        }
    }

    // ─── Wire-format DTOs ───────────────────────────────────────────

    /**
     * Single screen-visit event passed across the package boundary.
     * Agent 1's emitter wires this into a full `KixoEvent` (Agent 2
     * model) — keeping this struct narrow + serialization-free means
     * Agent 9 doesn't compile-time depend on Agent 2.
     */
    internal data class Emission(
        val eventType: String,
        val eventName: String,
        val fingerprint: String,
        val properties: JsonObject,
        val timestampMillis: Long,
    )

    /** Emitter contract bound by Agent 1. */
    internal fun interface Emitter {
        fun emit(emission: Emission)
    }

    private data class PendingVisit(
        val visitId: String,
        val entryIndex: Int,
        val screenId: String,
        val screenName: String,
        val prevScreenId: String?,
        val candidates: List<NameCandidate>,
        val trigger: Trigger,
        val enteredAtMillis: Long,
    ) {
        fun close(exitedAtMillis: Long, exitReason: ExitReason): Emission {
            val props = buildJsonObject {
                put("screen_id", JsonPrimitive(screenId))
                put("screen_name", JsonPrimitive(screenName))
                put(
                    "prev_screen_id",
                    if (prevScreenId == null) JsonNull else JsonPrimitive(prevScreenId),
                )
                put("trigger", JsonPrimitive(trigger.wire))
                put("visit_id", JsonPrimitive(visitId))
                put("entry_index", JsonPrimitive(entryIndex))
                put("entered_at", JsonPrimitive(enteredAtMillis))
                put("exited_at", JsonPrimitive(exitedAtMillis))
                put("dwell_ms", JsonPrimitive((exitedAtMillis - enteredAtMillis).coerceAtLeast(0L)))
                put("exit_reason", JsonPrimitive(exitReason.wire))
                put("_kixo_name_candidates", buildJsonArray {
                    for (c in candidates) {
                        add(
                            buildJsonObject {
                                // Cross-SDK/backend canonical key. Older
                                // Android builds used `value`, which the batch
                                // candidate extractor did not consume.
                                put("text", JsonPrimitive(c.value))
                                put("source", JsonPrimitive(c.source.wireName()))
                                put("confidence", JsonPrimitive(c.confidence))
                            }
                        )
                    }
                })
            }
            return Emission(
                eventType = "screen_visit",
                eventName = screenName,
                fingerprint = screenId,
                properties = props,
                // ENTRY wall clock, NOT close time — preserves the
                // tier-2 timestamp-fallback ordering of pre-Wave-1 rows.
                timestampMillis = enteredAtMillis,
            )
        }
    }
}

/**
 * Pull the snake_case wire name for [NameSource]. Avoids reflection by
 * mirroring the [SerialName] annotations directly — kotlinx-serialization
 * IS the encoder so the values must match identically.
 */
private fun NameSource.wireName(): String = when (this) {
    NameSource.ExplicitOverride -> "explicit_override"
    NameSource.ActivityTitle -> "activity_title"
    NameSource.ToolbarTitle -> "toolbar_title"
    NameSource.FragmentTag -> "fragment_tag"
    NameSource.ComposeRoute -> "compose_route"
    NameSource.TopLabel -> "top_label"
    NameSource.Fingerprint -> "fingerprint"
}
