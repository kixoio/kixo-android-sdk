package io.kixo.sdk.internal.attribution

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Stores deep-link / install attribution (link / click / campaign ids) for a
 * bounded window after the last resolved deep link (deferred-referrer OR
 * App-Link / custom-scheme open). While the window is active, every outbound
 * event inherits these as `attribution_*` props so the dashboard can attribute
 * downstream conversions WITHOUT a backend join.
 *
 * Mirrors [io.kixo.sdk.internal.push.PushAttributionStore] exactly
 * (in-memory singleton, first-write-wins on `decorate`, `clear()` on
 * `Kixo.reset()`). The `attribution_*` namespace is shared with push + link +
 * referrer per the attribution-engine contract (§3.3); `attribution_kind`
 * disambiguates the source.
 *
 * Wire keys reference [AttributionContract] — never re-spelled inline.
 */
internal object InstallAttributionStore {

    private val lock = ReentrantLock()

    private var lastOpenAt: Long? = null
    private var linkId: String? = null
    private var clickId: String? = null
    private var campaign: String? = null
    private var source: String? = null
    private var medium: String? = null
    private var kind: String? = null

    /** Default window — 30 minutes, matching the push store + iOS. */
    const val DEFAULT_WINDOW_MS: Long = 30L * 60 * 1000

    /**
     * Stamp a new attribution window. Last-write-wins (a later open overwrites
     * an earlier one), matching standard multi-touch-attribution defaults.
     *
     * @param kind one of [AttributionContract.ATTR_KIND_INSTALL_REFERRER] /
     *   `ATTR_KIND_DEFERRED_DEEPLINK` / `ATTR_KIND_APPLINK`.
     */
    fun recordOpen(
        linkId: String?,
        clickId: String?,
        campaign: String?,
        source: String?,
        medium: String?,
        kind: String,
        nowMs: Long = System.currentTimeMillis(),
    ) {
        lock.withLock {
            lastOpenAt = nowMs
            this.linkId = linkId
            this.clickId = clickId
            this.campaign = campaign
            this.source = source
            this.medium = medium
            this.kind = kind
        }
    }

    /**
     * Merge attribution props into [eventProps] WITHOUT overwriting any key
     * already present (first-write-wins). No-op when the window expired or
     * `recordOpen` was never called. `attribution_age_ms` is always written
     * (diagnostic, non-negative only).
     */
    fun decorate(
        eventProps: MutableMap<String, Any?>,
        nowMs: Long = System.currentTimeMillis(),
        windowMs: Long = DEFAULT_WINDOW_MS,
    ): MutableMap<String, Any?> {
        lock.withLock {
            val openedAt = lastOpenAt ?: return eventProps
            val age = nowMs - openedAt
            // Negative age (clock skew) is treated as in-window — matches the
            // push store's choice.
            if (age > windowMs) return eventProps

            putIfAbsent(eventProps, AttributionContract.ATTR_LINK_ID, linkId)
            putIfAbsent(eventProps, AttributionContract.ATTR_CLICK_ID, clickId)
            putIfAbsent(eventProps, AttributionContract.ATTR_CAMPAIGN, campaign)
            putIfAbsent(eventProps, AttributionContract.ATTR_SOURCE, source)
            putIfAbsent(eventProps, AttributionContract.ATTR_MEDIUM, medium)
            putIfAbsent(eventProps, AttributionContract.ATTR_KIND, kind)
            if (age >= 0) {
                eventProps[AttributionContract.ATTR_AGE_MS] = age
            }
        }
        return eventProps
    }

    private fun putIfAbsent(props: MutableMap<String, Any?>, key: String, value: String?) {
        if (value != null && !props.containsKey(key)) props[key] = value
    }

    /**
     * `JsonObject` variant of [decorate], used by the enqueue chokepoint AFTER
     * the per-event PII sanitiser has run. The analytics queue stamps event
     * `properties` as a `JsonObject` (see
     * [io.kixo.sdk.internal.queue.KixoEventQueueRef]); both the public-API
     * `enqueueCustom` path AND the pre-built-event `enqueueEvent` path
     * (TouchInterceptor / ScreenVisitRecorder) funnel through here so EVERY
     * outbound event inside the window inherits `attribution_*` — closing the
     * AC-5 / §3.3 "subsequent events inherit attribution_link_id" promise
     * end-to-end (NOT just the in-isolation unit-test guarantee).
     *
     * Runs post-sanitise on purpose: the attribution values are routing ids
     * (link CUID / click UUID / campaign slug), NOT customer free-text — they
     * must bypass [io.kixo.sdk.internal.privacy.PiiFilter] so a UUID/CUID that
     * happens to brush a redaction regex is never mangled. First-write-wins
     * (never clobbers a key the caller already set, e.g. the `deep_link`
     * event's own `kixo_link_id`/`kixo_click_id` use DIFFERENT keys so there is
     * no collision regardless).
     *
     * Returns the SAME [props] reference untouched when the window is closed /
     * never opened (no allocation on the no-op hot path), otherwise a NEW
     * `JsonObject` with the `attribution_*` keys merged in.
     */
    fun decorate(
        props: JsonObject,
        nowMs: Long = System.currentTimeMillis(),
        windowMs: Long = DEFAULT_WINDOW_MS,
    ): JsonObject {
        lock.withLock {
            val openedAt = lastOpenAt ?: return props
            val age = nowMs - openedAt
            if (age > windowMs) return props

            val out = LinkedHashMap<String, JsonElement>(props)
            putJsonIfAbsent(out, AttributionContract.ATTR_LINK_ID, linkId)
            putJsonIfAbsent(out, AttributionContract.ATTR_CLICK_ID, clickId)
            putJsonIfAbsent(out, AttributionContract.ATTR_CAMPAIGN, campaign)
            putJsonIfAbsent(out, AttributionContract.ATTR_SOURCE, source)
            putJsonIfAbsent(out, AttributionContract.ATTR_MEDIUM, medium)
            putJsonIfAbsent(out, AttributionContract.ATTR_KIND, kind)
            if (age >= 0 && !out.containsKey(AttributionContract.ATTR_AGE_MS)) {
                out[AttributionContract.ATTR_AGE_MS] = JsonPrimitive(age)
            }
            return JsonObject(out)
        }
    }

    private fun putJsonIfAbsent(props: MutableMap<String, JsonElement>, key: String, value: String?) {
        if (value != null && !props.containsKey(key)) props[key] = JsonPrimitive(value)
    }

    /** Wipe the window. Called from `Kixo.reset()` so attribution can't bleed
     *  across a logout / identity rotation. */
    fun clear() {
        lock.withLock {
            lastOpenAt = null
            linkId = null
            clickId = null
            campaign = null
            source = null
            medium = null
            kind = null
        }
    }

    /** Test-only inspection. */
    internal fun snapshotForTests(): Map<String, String?> = lock.withLock {
        mapOf(
            "link_id" to linkId,
            "click_id" to clickId,
            "campaign" to campaign,
            "source" to source,
            "medium" to medium,
            "kind" to kind,
        )
    }
}
