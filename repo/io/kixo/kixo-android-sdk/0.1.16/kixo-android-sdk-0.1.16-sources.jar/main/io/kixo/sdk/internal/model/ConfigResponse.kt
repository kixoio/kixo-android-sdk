package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** Query envelope for `GET /api/sdk/config`. The API key is never put here. */
internal data class ConfigRequest(
    val projectId: String,
    val apiKey: String,
    val appId: String = "",
    val releaseId: String = "",
    val platform: String = "android",
    val bundleId: String,
    val environment: String,
    val sdkVersion: String,
)

/**
 * Live project policy returned by `GET /api/sdk/config`.
 *
 * The normal route uses `dataCollection` (camelCase). Paused/legacy response
 * branches have historically also emitted `data_collection`; decoding both
 * keeps a rolling backend/SDK update fail-safe without treating an empty
 * policy as permission to record replay.
 */
@Serializable
internal data class ConfigResponse(
    @SerialName("dataCollection")
    private val camelDataCollection: DataCollection? = null,

    @SerialName("data_collection")
    private val snakeDataCollection: DataCollection? = null,

    val paused: Boolean = false,

    @SerialName("paused_reason")
    val pausedReason: String? = null,

    @SerialName("app_id")
    val appId: String = "",

    @SerialName("app_name")
    val appName: String = "",
) {
    val dataCollection: DataCollection?
        get() = camelDataCollection ?: snakeDataCollection
}
