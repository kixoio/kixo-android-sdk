package io.kixo.sdk.internal.replay.upload

import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import kotlin.math.min

/**
 * Process-wide throttle for stale WorkManager frames that need a fresh lease.
 *
 * Normal uploads carry the still-valid batch lease consumed from SignedUrlPool
 * and never enter this path. Delayed Wi-Fi/process-recovery workers can arrive
 * in a herd after their leases expire, so they share a deterministic bounded
 * mutex stripe and exponential cooldown. A stripe serializes requests; it does
 * not coalesce identical WorkManager jobs into one response. Hash collisions
 * conservatively throttle unrelated sessions instead of growing process memory.
 * The 1.1 s floor stays below the backend's 60 requests/minute ceiling.
 */
internal class ReplayFrameSignCoordinator(
    private val nowMillis: () -> Long = System::currentTimeMillis,
    private val sleep: suspend (Long) -> Unit = { delay(it) },
    private val request: suspend (
        OkHttpClient,
        ReplayFrameSigner.Input,
        Boolean,
        Boolean,
    ) -> ReplayFrameSigner.Outcome = { client, input, connected, metered ->
        ReplayFrameSigner(client).sign(input, connected, metered)
    },
    private val minimumIntervalMs: Long = MINIMUM_INTERVAL_MS,
    private val baseBackoffMs: Long = BASE_BACKOFF_MS,
    private val maxBackoffMs: Long = MAX_BACKOFF_MS,
    stateStripeCount: Int = DEFAULT_STATE_STRIPES,
) {
    private data class State(
        val mutex: Mutex = Mutex(),
        var failures: Int = 0,
        var nextAllowedAtMs: Long = 0L,
    )

    private val states: Array<State>

    init {
        require(stateStripeCount > 0) { "stateStripeCount must be positive" }
        states = Array(stateStripeCount) { State() }
    }

    suspend fun sign(
        client: OkHttpClient,
        input: ReplayFrameSigner.Input,
        connected: Boolean,
        metered: Boolean,
    ): ReplayFrameSigner.Outcome {
        // Backend rate limits signing per project. Every session/install for
        // that project must therefore share one process-local stripe; including
        // sessionId here would let recovered sessions multiply request rate.
        val key = listOf(input.baseUrl, input.projectId).joinToString("\u001f")
        val hash = key.hashCode()
        val state = states[((hash xor (hash ushr 16)) and Int.MAX_VALUE) % states.size]
        return state.mutex.withLock {
            val waitMs = (state.nextAllowedAtMs - nowMillis()).coerceAtLeast(0L)
            if (waitMs > 0L) sleep(waitMs)

            val outcome = request(client, input, connected, metered)
            val completedAt = nowMillis()
            when (outcome) {
                is ReplayFrameSigner.Outcome.Fresh -> {
                    state.failures = 0
                    state.nextAllowedAtMs = completedAt + minimumIntervalMs
                }
                ReplayFrameSigner.Outcome.Retry -> {
                    state.failures = (state.failures + 1).coerceAtMost(31)
                    val shift = (state.failures - 1).coerceAtMost(20)
                    state.nextAllowedAtMs = completedAt + min(
                        baseBackoffMs * (1L shl shift),
                        maxBackoffMs,
                    )
                }
                is ReplayFrameSigner.Outcome.PolicyRejected,
                ReplayFrameSigner.Outcome.PermanentFailure,
                ReplayFrameSigner.Outcome.RemotePaused,
                -> {
                    state.failures = 0
                    state.nextAllowedAtMs = completedAt + minimumIntervalMs
                }
            }
            outcome
        }
    }

    @androidx.annotation.VisibleForTesting
    internal fun stateSlotCountForTesting(): Int = states.size

    companion object {
        internal const val MINIMUM_INTERVAL_MS: Long = 1_100L
        internal const val BASE_BACKOFF_MS: Long = 2_000L
        internal const val MAX_BACKOFF_MS: Long = 60_000L
        internal const val DEFAULT_STATE_STRIPES: Int = 64

        val shared: ReplayFrameSignCoordinator = ReplayFrameSignCoordinator()
    }
}
