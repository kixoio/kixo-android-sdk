package io.kixo.sdk

/** Receives the result of a durable local SDK write. */
public fun interface KixoCommitCallback {
    /** True only after the event has been committed to the SDK's SQLite queue. */
    public fun onCommitted(committed: Boolean)
}
