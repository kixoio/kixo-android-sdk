package io.kixo.sdk

/**
 * Holds direct-open callbacks that arrive before the host registers its
 * listener. Registration and buffering share one monitor, so a cold-start
 * delivery cannot fall between a null listener read and listener publication.
 */
internal class DirectDeepLinkCallbackStore(
    private val capacity: Int = 32,
) {
    internal data class Pending(
        val link: KixoDeferredLink?,
        val expectedEpoch: Long?,
        val expectedRoutingEpoch: Long,
        val expectedPushRoutingEpoch: Long?,
        val requiresCollection: Boolean,
    )

    private val lock = Any()
    private var listener: DeferredDeepLinkListener? = null
    private val pending = ArrayDeque<Pending>()

    init {
        require(capacity > 0)
    }

    fun register(newListener: DeferredDeepLinkListener): List<Pending> = synchronized(lock) {
        listener = newListener
        pending.toList().also { pending.clear() }
    }

    /**
     * @return true when buffered; false when a listener is already available.
     */
    fun bufferIfListenerMissing(
        link: KixoDeferredLink?,
        expectedEpoch: Long?,
        expectedRoutingEpoch: Long,
        requiresCollection: Boolean,
        expectedPushRoutingEpoch: Long? = null,
    ): Boolean =
        synchronized(lock) {
            if (listener != null) return@synchronized false
            while (pending.size >= capacity) pending.removeFirst()
            pending.addLast(
                Pending(
                    link,
                    expectedEpoch,
                    expectedRoutingEpoch,
                    expectedPushRoutingEpoch,
                    requiresCollection,
                ),
            )
            true
        }

    fun currentListener(): DeferredDeepLinkListener? = synchronized(lock) { listener }

    /**
     * Privacy boundaries drop attribution results but preserve local RECEIVED
     * routing. Navigation is functional and carries no collection.
     */
    fun clearCollectionBoundPending() = synchronized(lock) {
        pending.removeAll { it.requiresCollection }
    }

    fun clearPushBoundPending() = synchronized(lock) {
        pending.removeAll { it.expectedPushRoutingEpoch != null }
    }

    /** Identity/project boundaries must not replay any route from the old scope. */
    fun clearAllPending() = synchronized(lock) {
        pending.clear()
    }
}
