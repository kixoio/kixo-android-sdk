package io.kixo.sdk.internal.screen

import android.app.Activity
import android.os.Bundle
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.ViewGroup

/**
 * Automatic screen detection. Mirrors iOS [ScreenTracker] — same dual
 * dedup window, same name-resolution priority, same content-invariant
 * fingerprint.
 *
 * **Three detection sources (covered by Agent 7's
 * `ActivityLifecycleObserver`):**
 *  1. **Activities** — every
 *     `Application.ActivityLifecycleCallbacks.onActivityResumed` drives
 *     [onActivityResumed].
 *  2. **Fragments** — for any [Activity] that is a
 *     `androidx.fragment.app.FragmentActivity` we register a
 *     `FragmentManager.FragmentLifecycleCallbacks` via the optional
 *     [FragmentBridge] (set by `Kixo.configure` once a host's classpath
 *     has been confirmed to include `androidx.fragment`). Agent 7's
 *     lifecycle observer calls [onActivityCreated] on every Activity
 *     creation and we install the fragment callbacks there.
 *     `DialogFragment`s and other overlay-style fragments are filtered
 *     out — they're modal overlays, not screens (see iOS comment about
 *     DialogFragment / popup → don't emit).
 *  3. **Compose Navigation** — best-effort via reflection on a
 *     `NavController` if the host installed one. We deliberately do
 *     NOT compile-depend on `androidx.navigation:navigation-compose`
 *     (would force every consumer to ship the runtime); reflection
 *     means the integration silently no-ops on apps without
 *     Navigation, and Just Works on apps that have it.
 *
 * **Why all-reflection for fragments + navigation:** `androidx.fragment`
 * is ~50 KB compiled and `androidx.navigation` is another ~120 KB.
 * Compose-only or Navigation-Compose-only apps shouldn't pay either
 * cost. Per AGENT_BRIEFING.md §5 ("KEEP MINIMAL"), reflection is
 * the right tool for "use it if it's there, no-op if it isn't."
 *
 * **Dual dedup (mirrors iOS rationale verbatim):**
 *  - Fingerprint dedup catches simultaneous fires of the same
 *    structural screen (e.g. an Activity resume that triggers an
 *    immediate Fragment resume on the same content). 2 s window.
 *  - Name dedup catches structurally-different but semantically-same
 *    screens (e.g. a SwiftUI / Compose hot-reload of the same screen
 *    with a slightly different role tree). 1 s window.
 *
 * **Threading:** every entry-point is invoked from the main thread
 * by Android lifecycle callbacks. View-tree access happens
 * synchronously here. Emission to the EventQueue is fire-and-forget
 * (Agent 5's queue handles its own off-main hop).
 *
 * **Stub deps documented per AGENT_BRIEFING §6:**
 *  - [ScreenVisitRecorder.Emitter] — bound by Agent 1's
 *    `Kixo.configure`, wraps Agent 5's `EventQueue.enqueue`.
 *  - `ActivityLifecycleObserver` (Agent 7) — calls into us via
 *    [onActivityResumed] / [onActivityCreated].
 *  - `InteractionTracker` (Agent 8, `io.kixo.sdk.internal.interaction`)
 *    — READS [ScreenIdentity.current] to stamp tap events.
 */
internal object ScreenTracker {

    private const val TAG = "Kixo"

    /** 2 s — same as iOS `fingerprintDedupWindow`. */
    private const val FINGERPRINT_DEDUP_MS = 2_000L

    /** 1 s — same as iOS `dedupWindow`. */
    private const val NAME_DEDUP_MS = 1_000L

    /** Recent fingerprints with monotonic timestamps for dedup. */
    private val recentFingerprints = ArrayDeque<Pair<String, Long>>()

    /** Recent names with monotonic timestamps for dedup. */
    private val recentNames = ArrayDeque<Pair<String, Long>>()

    /**
     * One-shot explicit override from `Kixo.screen("Name")`. Consumed
     * by the very next [maybeRecordVisit] (within a 2 s TTL); after
     * consumption returns to null. The TTL stops a long-stale override
     * from accidentally renaming a future screen if `Kixo.screen` is
     * called and then the user navigates away before the framework
     * fires its lifecycle callback.
     */
    @Volatile
    private var pendingExplicitName: String? = null

    @Volatile
    private var pendingExplicitNameAt: Long = 0L

    /**
     * Set the next-visit name override. Called from
     * `Kixo.screen("Name")` (Agent 1). The override applies to the
     * very next `maybeRecordVisit` IF it arrives within 2 s;
     * otherwise it is silently discarded.
     */
    fun setExplicitName(name: String) {
        pendingExplicitName = name
        pendingExplicitNameAt = SystemClock.elapsedRealtime()
    }

    // ─── Activity hook (called by Agent 7's ActivityLifecycleObserver) ─

    /**
     * Called from
     * `Application.ActivityLifecycleCallbacks.onActivityCreated` by
     * Agent 7's lifecycle observer. Triggers reflective registration
     * of `FragmentManager.FragmentLifecycleCallbacks` on the activity
     * if it's a `FragmentActivity`.
     *
     * Idempotent — registering twice is harmless because Android
     * de-duplicates listener instances.
     */
    fun onActivityCreated(activity: Activity, @Suppress("UNUSED_PARAMETER") savedInstanceState: Bundle?) {
        val bridge = fragmentBridge
        if (bridge != null) {
            try {
                bridge.attachIfFragmentActivity(activity, ::onFragmentResumed)
            } catch (t: Throwable) {
                // R6 — never crash the host. The worst case is we miss
                // fragment-driven visits in this activity.
                Log.w(TAG, "register fragment callbacks failed", t)
            }
        }
    }

    /**
     * Plug-in surface for fragment integration. A separate, optional
     * SDK module (or a small reflective shim in Agent 7's lifecycle
     * folder) implements [FragmentBridge] only when
     * `androidx.fragment.app.FragmentManager` is available at compile
     * time. We don't import it here so the screen package stays free
     * of that ~50 KB transitive dep on Compose-only consumers.
     *
     * Set once during `Kixo.configure` (Agent 1) — re-binding is
     * harmless because [onActivityCreated] reads the latest pointer
     * each call.
     */
    @Volatile
    private var fragmentBridge: FragmentBridge? = null

    fun bindFragmentBridge(bridge: FragmentBridge) {
        fragmentBridge = bridge
    }

    /**
     * Adapter the optional fragment integration implements. The
     * single method must register a `FragmentLifecycleCallbacks` on
     * every `FragmentActivity` and forward `onFragmentResumed` calls
     * to the [onResumed] lambda — typed as `Any` so the bridge
     * doesn't leak `androidx.fragment.app.Fragment` back into the
     * screen package.
     */
    internal fun interface FragmentBridge {
        fun attachIfFragmentActivity(activity: Activity, onResumed: (Any) -> Unit)
    }

    /**
     * Called from
     * `Application.ActivityLifecycleCallbacks.onActivityResumed`.
     * Drives an Activity-source visit attempt.
     */
    fun onActivityResumed(activity: Activity) {
        try {
            maybeRecordVisit(
                activity = activity,
                fragment = null,
                composeRoute = readComposeRoute(activity),
                trigger = ScreenVisitRecorder.Trigger.ActivityResumed,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "screen tracker activity resumed failed", t)
        }
    }

    /**
     * Public hook called by the optional [FragmentBridge] on
     * `FragmentManager.FragmentLifecycleCallbacks.onFragmentResumed`.
     * Filters dialog/headless fragments and delegates to
     * [maybeRecordVisit].
     *
     * Typed as [Any] so the public surface doesn't compile-depend on
     * `androidx.fragment.app.Fragment`. The fragment is fed back into
     * [NameCandidateCollector] which extracts tag + class name
     * reflectively; not a concern that we can't cast.
     */
    fun onFragmentResumed(fragment: Any) {
        try {
            // Filter overlay-style fragments — they're modal overlays
            // on top of an existing screen, not screens themselves.
            // Class-name match avoids compiling against DialogFragment.
            val cls = fragment.javaClass
            if (isDialogFragmentClass(cls)) return

            // Read fragment.view + fragment.activity reflectively.
            val view = readFragmentView(fragment) ?: return
            if (view.width == 0 && view.height == 0) return

            val activity = readFragmentActivity(fragment)

            maybeRecordVisit(
                activity = activity,
                fragment = fragment,
                composeRoute = activity?.let { readComposeRoute(it) },
                trigger = ScreenVisitRecorder.Trigger.FragmentResumed,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "screen tracker fragment resumed failed", t)
        }
    }

    // ─── Public sugar — Kixo.screen("Name") path ───────────────────

    /**
     * Manual `Kixo.screen("Name")` call. Records a visit immediately
     * (skipping the lifecycle path) using the host's current Activity
     * to source the rest of the candidates.
     *
     * If no Activity is foregrounded yet (called from `Application`
     * cold-start before any Activity exists), the override is queued
     * via [setExplicitName] so the next lifecycle-driven visit will
     * carry it.
     */
    fun recordExplicit(activity: Activity?, name: String) {
        setExplicitName(name)
        if (activity != null) {
            try {
                maybeRecordVisit(
                    activity = activity,
                    fragment = null,
                    composeRoute = readComposeRoute(activity),
                    trigger = ScreenVisitRecorder.Trigger.ExplicitOverride,
                )
            } catch (t: Throwable) {
                Log.w(TAG, "screen tracker explicit failed", t)
            }
        }
    }

    // ─── Core decision logic ───────────────────────────────────────

    /**
     * Compute fingerprint, dedup, resolve name, update [ScreenIdentity],
     * emit `screen_visit`. Idempotent — every call goes through the
     * dedup gate, so multiple sources firing on the same screen
     * resolve to a single emission.
     */
    private fun maybeRecordVisit(
        activity: Activity?,
        fragment: Any?,
        composeRoute: String?,
        trigger: ScreenVisitRecorder.Trigger,
        // Set when this call was re-posted after a zero-size root view
        // (see the size gate below). Prevents an unbounded re-post loop
        // on a genuinely empty screen.
        deferred: Boolean = false,
    ) {
        // Coverage fix (May 2026): honour server-side
        // `data_collection.core.pageViews == false`. Default-allow on
        // pre-init / missing field. Checked here at EMIT time (not
        // install time) so an operator toggle takes effect on the next
        // screen visit without re-installing the per-Activity hook.
        if (!io.kixo.sdk.internal.queue.DataCollectionHolder.isAllowed { it.core?.pageViews }) {
            return
        }
        val rootView = resolveRootView(activity, fragment) ?: return
        // Gate on having SOMETHING measurable. The fingerprint helper
        // returns the EMPTY sentinel when not measurable, but we
        // additionally short-circuit so we don't burn the rest of
        // the pipeline on a no-op.
        //
        // 2026-07-04 fix: `onActivityResumed` (and `onFragmentResumed`)
        // routinely fire BEFORE the root view has been laid out — its
        // width/height are still 0 at resume time. Previously we simply
        // returned, so a screen whose first (and often only) resume
        // precedes layout was NEVER recorded — the whole screen was
        // silently missed (observed live: MainActivity's first resume
        // AND ProductDetailActivity's only resume both gated out here,
        // so ProductDetail produced no screen_visit at all). Instead of
        // dropping it, re-post ONCE onto the view's message queue so the
        // retry runs after the pending layout pass, when the view has
        // real dimensions. `deferred` guards against re-posting forever
        // on a view that stays 0×0 (a truly empty screen).
        if (rootView.width == 0 && rootView.height == 0) {
            if (!deferred) {
                rootView.post {
                    try {
                        maybeRecordVisit(activity, fragment, composeRoute, trigger, deferred = true)
                    } catch (t: Throwable) {
                        Log.w(TAG, "deferred screen visit retry failed", t)
                    }
                }
            }
            return
        }

        val fingerprint = ScreenFingerprint.compute(rootView)
        if (fingerprint == ScreenFingerprint.EMPTY_FINGERPRINT) return

        val now = SystemClock.elapsedRealtime()

        // ── Fingerprint dedup ── (2 s window)
        evictOlderThan(recentFingerprints, now - FINGERPRINT_DEDUP_MS)
        if (recentFingerprints.any { it.first == fingerprint }) return
        recentFingerprints.addLast(fingerprint to now)

        // ── Resolve explicit name override ──
        val explicitName = takePendingExplicitName(now)

        // ── Build candidate list + pick a name ──
        val candidates = NameCandidateCollector.collect(
            activity = activity,
            fragment = fragment,
            composeRoute = composeRoute,
            explicitName = explicitName,
            rootView = rootView,
            fingerprint = fingerprint,
        )
        val resolvedName = candidates.bestName()

        // ── Name dedup ── (1 s window — looser, catches same-screen
        // with different fingerprints e.g. due to dynamic state)
        evictOlderThan(recentNames, now - NAME_DEDUP_MS)
        val nameLower = resolvedName.lowercase()
        val isDup = recentNames.any { (recent, _) ->
            val recentLower = recent.lowercase()
            recentLower == nameLower ||
                recentLower.contains(nameLower) ||
                nameLower.contains(recentLower)
        }
        if (isDup) return
        recentNames.addLast(resolvedName to now)

        // ── Update identity + emit visit ──
        val snapshot = ScreenIdentity.Snapshot(
            screenId = fingerprint,
            screenName = resolvedName,
            candidates = candidates,
        )
        val previous = ScreenIdentity.update(snapshot)
        ScreenVisitRecorder.recordVisit(snapshot, previous, trigger)
    }

    /**
     * Pull the staged explicit name IF still within the 2 s TTL
     * window. Returns null otherwise. Single-shot — any successful
     * read clears the staging slot so the same name doesn't carry
     * over to the next visit.
     */
    private fun takePendingExplicitName(now: Long): String? {
        val name = pendingExplicitName ?: return null
        val age = now - pendingExplicitNameAt
        pendingExplicitName = null
        return if (age <= FINGERPRINT_DEDUP_MS) name else null
    }

    /**
     * Identify the root [View] for fingerprint + label scan. We
     * deliberately use [android.R.id.content] rather than
     * `Window.getDecorView` so we skip system bars (status bar, nav
     * bar, IME shadow) — those aren't user content and they vary by
     * device chrome which would tear the cross-device fingerprint.
     */
    private fun resolveRootView(activity: Activity?, fragment: Any?): View? {
        // Fragment view (if available) is the more specific source.
        fragment?.let { readFragmentView(it) }?.let { return it }
        return activity?.findViewById(android.R.id.content)
    }

    // ─── Fragment integration helpers (reflective) ─────────────────

    /**
     * `androidx.fragment.app.DialogFragment` detection by class-name
     * walk. Mirrors iOS's "popup → don't emit screen_visit" rule.
     */
    private fun isDialogFragmentClass(cls: Class<*>): Boolean {
        var c: Class<*>? = cls
        while (c != null) {
            val name = c.name
            if (name == "androidx.fragment.app.DialogFragment") return true
            if (name == "android.app.DialogFragment") return true
            c = c.superclass
        }
        return false
    }

    private fun readFragmentView(fragment: Any): View? {
        return try {
            val m = fragment.javaClass.getMethod("getView")
            m.invoke(fragment) as? View
        } catch (_: Throwable) {
            null
        }
    }

    private fun readFragmentActivity(fragment: Any): Activity? {
        return try {
            val m = fragment.javaClass.getMethod("getActivity")
            m.invoke(fragment) as? Activity
        } catch (_: Throwable) {
            null
        }
    }

    // ─── Compose Navigation route detection ────────────────────────

    /**
     * Best-effort Compose Navigation route detection.
     *
     * We don't compile against `androidx.navigation:navigation-compose`
     * (would force every consumer to ship that runtime). Instead we
     * locate a `NavHostFragment` / `FragmentContainerView` in the
     * activity's content view, ask it for its `NavController`, and
     * read the current destination route.
     *
     * Returns null on apps without Navigation; returns the current
     * destination route string when Navigation IS installed.
     */
    private fun readComposeRoute(activity: Activity): String? {
        return try {
            val content = activity.findViewById<View>(android.R.id.content) ?: return null
            findNavControllerInTree(content, depth = 0)?.let { controller ->
                readCurrentRoute(controller)
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun findNavControllerInTree(view: View, depth: Int): Any? {
        if (depth > 6) return null
        val cls = view.javaClass.simpleName
        if (cls.endsWith("NavHostFragment") || cls.endsWith("FragmentContainerView")) {
            try {
                val m = view.javaClass.getMethod("getNavController")
                val controller = m.invoke(view)
                if (controller != null && controller.javaClass.simpleName.contains("NavController")) {
                    return controller
                }
            } catch (_: Throwable) {
                // Not a real NavHost — keep walking.
            }
        }
        if (view is ViewGroup) {
            val breadth = minOf(view.childCount, 30)
            for (i in 0 until breadth) {
                val child = view.getChildAt(i) ?: continue
                findNavControllerInTree(child, depth + 1)?.let { return it }
            }
        }
        return null
    }

    private fun readCurrentRoute(controller: Any): String? {
        return try {
            // controller.currentBackStackEntry?.destination?.route
            val entryMethod = controller.javaClass.getMethod("getCurrentBackStackEntry")
            val entry = entryMethod.invoke(controller) ?: return null
            val destMethod = entry.javaClass.getMethod("getDestination")
            val dest = destMethod.invoke(entry) ?: return null
            val routeMethod = dest.javaClass.getMethod("getRoute")
            routeMethod.invoke(dest) as? String
        } catch (_: Throwable) {
            null
        }
    }

    private fun evictOlderThan(deque: ArrayDeque<Pair<String, Long>>, cutoffMs: Long) {
        while (deque.isNotEmpty() && deque.first().second < cutoffMs) {
            deque.removeFirst()
        }
    }

    /**
     * Test seam — clear all dedup state between unit tests. Production
     * code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        recentFingerprints.clear()
        recentNames.clear()
        pendingExplicitName = null
        pendingExplicitNameAt = 0L
        fragmentBridge = null
    }
}
