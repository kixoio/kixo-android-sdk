package io.kixo.sdk.internal

/**
 * Single source of truth for the SDK ingest base URL per environment.
 *
 * Wave 5 fix for the duplicated host strings that were copy-pasted
 * across `KixoConfiguration.defaultApiHost`, `EnvironmentDetector.kt`,
 * `ConfigHolder.UNINITIALISED.apiHost`, and several doc comments.
 * Adding a new env (e.g. `"qa"`) is now a one-line edit here instead
 * of a grep-and-pray sweep.
 *
 * Internal-only: customers SHOULD NOT depend on these strings; they
 * pass the environment NAME (`"development"` / `"production"`) and
 * the SDK resolves the host. If a customer needs
 * a custom backend, they pass `KixoConfiguration.Builder.apiHost(...)`
 * which overrides resolution entirely.
 *
 * The wire-token alignment with `KixoConfiguration.environment` is:
 *
 * | env name        | host                            |
 * |-----------------|---------------------------------|
 * | `"development"` | https://sdk.dev.kixo.io         |
 * | `"production"`  | https://sdk.kixo.io             |
 */
internal object KixoEndpoints {
    const val DEV: String = "https://sdk.dev.kixo.io"
    const val PROD: String = "https://sdk.kixo.io"

    /**
     * Resolve a base URL from a supported environment name. Unsupported
     * values fail explicitly so a typo or unprovisioned `staging` cannot
     * silently route every event to a dead host.
     */
    fun forEnvironment(name: String): String = when (name.trim().lowercase()) {
        "development" -> DEV
        "production" -> PROD
        else -> throw IllegalArgumentException(
            "Unsupported Kixo environment '$name'. Use 'production' or 'development', " +
                "and Builder.apiHost(...) for a custom endpoint.",
        )
    }
}
