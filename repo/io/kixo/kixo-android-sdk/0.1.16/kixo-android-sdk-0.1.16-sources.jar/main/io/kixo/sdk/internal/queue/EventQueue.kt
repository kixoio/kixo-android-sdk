package io.kixo.sdk.internal.queue

import android.util.Log
import io.kixo.sdk.PushProvider
import io.kixo.sdk.internal.model.BatchPayload
import io.kixo.sdk.internal.model.DataCollection
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.privacy.ConsentManager
import io.kixo.sdk.internal.privacy.PreConfigurePrivacyGate
import io.kixo.sdk.internal.storage.EventStore
import io.kixo.sdk.internal.transport.BatchOutcome
import io.kixo.sdk.internal.transport.TransportContract
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/**
 * Ships events from the SDK to `/api/sdk/batch` with batching, jitter,
 * a bounded buffer and the cooldown pivot to recovery.
 *
 * Faithful Kotlin port of `kixo-ios-sdk/Sources/Kixo/EventQueue.swift`
 * with two adaptations for the platform:
 *   1. **Coroutines, not GCD.** `workQueue.async { … }` becomes
 *      `scope.launch { … }`. The serialising "lock" becomes a
 *      coroutine [Mutex] so we don't block a thread while waiting
 *      for it. Same suspend/resume semantics as iOS's NSLock-around-
 *      DispatchQueue but cheaper to compose.
 *   2. **StateFlow for lifecycle.** The Kixo facade subscribes to
 *      [lifecycleState] to mirror our internal phase into its public
 *      `KixoDiagnostics`. iOS uses a `var` + a callback closure
 *      (`onCooldownEntered`); StateFlow gives us the same one-way
 *      signal with built-in latest-value semantics.
 *
 * **Five invariants (verbatim from iOS):**
 *
 *   1. **Host app NEVER crashes.** Every error path swallows; the
 *      worst case is dropped analytics, never a crash. AGENT_BRIEFING
 *      R6.
 *
 *   2. **We retry on the same schedule as the web SDK.** The first
 *      10 failed sends fire on a fast schedule (5 / 10 / 20 / 30 /
 *      60s × 6). Failures 11-29 retry every 60s. Failures 30+
 *      enter a 30-min cooldown. See [RetryScheduler].
 *
 *   3. **Buffer is bounded.** `maxBufferSize` (default 200) caps
 *      both the in-memory batch and the on-disk store. When a new
 *      event would push the queue over the cap, the OLDEST is
 *      dropped (FIFO) — handled inside [EventStore.append] (Agent 3).
 *
 *   4. **Jitter prevents thundering herd.** Every retry delay gets
 *      a random ±25% wobble. When the backend recovers from an
 *      outage a million clients don't hit `/api/sdk/batch`
 *      simultaneously.
 *
 *   5. **First success resets state.** One good 2xx with at least
 *      one accepted event clears `consecutiveFailures` and snaps
 *      us back to the normal cadence. There's no slow decay —
 *      recovery is immediate.
 *
 * **Lifecycle interplay:**
 *  - `Initialising` / `Recovering`: events buffer, no flush.
 *  - `Running`: normal flush cadence.
 *  - `PausedByServer`: events DROPPED at enqueue time + the durable
 *    buffer is drained on entry. The server told us to stop;
 *    persisting more would just delay recovery.
 *
 * **Threading model:** all internal mutations + flushes run on the
 * `scope` parameter (a `CoroutineScope` rooted in `SupervisorJob +
 * Dispatchers.Default`). Public methods are safe to call from any
 * thread. Public methods that need to interact with internal state
 * either marshal through the scope or use `synchronized`.
 */
internal class EventQueue(
    private val store: EventStore,
    private val transport: TransportContract,
    private val payloadAssembler: BatchPayloadAssembler,
    private val scope: CoroutineScope,
    /**
     * Number of buffered events that triggers an immediate flush.
     * Mirrors iOS's `Configuration.flushAt` default 20. Pass a
     * smaller value in tests to avoid having to enqueue 20 events.
     */
    private val flushAt: Int = 20,
    /**
     * Periodic flush cadence. Default 30s — same as iOS + the web SDK.
     */
    private val flushIntervalMs: Long = 30_000L,
    /**
     * FIFO cap on the on-disk + in-memory buffer. The store enforces
     * this when [append][EventStore.append] is called; the queue
     * just passes it through for diagnostics.
     */
    private val maxBufferSize: Int = 200,
    /** Verbose logcat output (debug builds only). */
    private val debug: Boolean = false,
    /**
     * Wave 13 — opt-out for the periodic-flush timer started in
     * `init { startPeriodicFlush() }`. Production always wants it
     * (default `true`); tests under `runTest` + virtual time pass
     * `false` so the scheduler doesn't get spammed with N years
     * worth of timer ticks every time `advanceTimeBy(...)` is
     * called inside a retry loop. Without this, `runTest`'s
     * "drain everything before completing" semantic ends up
     * cleaning up dozens of orphaned mutex-acquirer coroutines
     * from the periodic-flush ticker, which can take real-time
     * minutes when the virtual-time advance crossed many flush
     * intervals.
     */
    private val enablePeriodicFlush: Boolean = true,
    /**
     * Wave 14 — opt-out for the auto-retry path inside
     * [scheduleRetry]. Production wants it (`true`): a
     * NetworkError / transient HttpError ticks the failure counter
     * and a retry is launched on a backoff schedule. Tests under
     * `runTest` + virtual time pass `false` so each `flush()`
     * call corresponds to EXACTLY ONE `postBatch` call, with no
     * background retries firing during the next
     * `advanceTimeBy(...)` window.
     *
     * The cooldown-pivot logic (transition to
     * [LifecycleState.Recovering] when [consecutiveFailures]
     * crosses [RetryScheduler.COOLDOWN_THRESHOLD]) STILL fires
     * regardless of this flag — it's a state-machine transition,
     * not a retry — so the cooldown unit test re-uses the same
     * queue + a 30-iteration `repeat { q.flush() }` to exercise
     * the lifecycle change without any parked coroutines.
     *
     * Without this opt-out, `advanceUntilIdle()` after a
     * NetworkError walks the retry chain all the way to cooldown
     * (every parked `delay(N)` wakes up and chains another retry),
     * which broke the original [`transient failure...`] +
     * [`success after failures...`] tests in Wave 13. See trace
     * in [project_android_sdk.md] Wave 14 #1 for the analysis.
     */
    private val enableAutoRetry: Boolean = true,
    /**
     * The per-event consent gate (FIX 3 — opt-out/consent was a no-op on
     * the live stream). Consulted inside [enqueue] for EVERY event before
     * persistence: returns `false` to drop the event silently.
     *
     * Production default delegates to [ConsentManager.shouldEmit] — the
     * single source of truth for the two-flag (`optedOut` / `consentGranted`)
     * policy. While opted out EVERYTHING drops (incl. the canonical
     * `app_install` signal); while consent is merely un-granted only the
     * essential operational events flow. Before this gate, the queue checked
     * only [LifecycleState.PausedByServer] + identity dedup, so a device with
     * a PERSISTED opt-out kept emitting (the `revokeConsent`/`optOut` public
     * API silently leaked the live event stream). iOS anchors its enqueue
     * gate to this same `shouldEmit` mirror, so Android was the regressed
     * side.
     *
     * Injected (not a hard static call) so unit tests can drive the gate
     * deterministically without standing up a Robolectric `SharedPreferences`
     * through `ConsentManager.init`. The default keeps production behaviour
     * single-sourced through `ConsentManager`.
     */
    private val consentGate: (KixoEventType) -> Boolean = ConsentManager::shouldEmit,
    /** Production-only linearisation gate for raw batch calls. */
    private val privacyGate: PreConfigurePrivacyGate? = null,
    private val onAcceptedEventIds: (Set<String>) -> Unit = {},
    private val onPermanentEventIds: (Set<String>) -> Unit = {},
    private val onDurableQueueCleared: () -> Unit = {},
    private val onRunning: () -> Unit = {},
) {

    // ─── State ────────────────────────────────────────────────────

    /** Coroutine mutex around all state-mutating sections. */
    private val mutex: Mutex = Mutex()
    private val persistenceBoundaryMutex: Mutex = Mutex()
    private val identityBoundaryGeneration = AtomicLong(0L)

    /**
     * Number of consecutive failed flushes since the last partial-
     * or-full success. Resets to 0 on success.
     *
     * Modified under [mutex]. Read by [diagnostics] (snapshot under
     * the same mutex) and by the retry loop after each flush attempt.
     */
    private var consecutiveFailures: Int = 0

    /**
     * Set while a flush is in-flight so two concurrent flushes don't
     * race and re-send the same events twice.
     *
     * Modified under [mutex]. iOS uses a bool guarded by NSLock for
     * the same purpose.
     */
    private var isFlushing: Boolean = false

    /**
     * Lifecycle phase as a [StateFlow] — emit on every transition so
     * the Kixo facade can mirror it into its public `KixoDiagnostics`
     * without polling.
     *
     * Default starting state is [LifecycleState.Initialising]. The
     * Kixo facade transitions us to [LifecycleState.Running] (or
     * [LifecycleState.PausedByServer]) once `/api/sdk/init` resolves.
     */
    private val _lifecycleState: MutableStateFlow<LifecycleState> =
        MutableStateFlow(LifecycleState.Initialising)

    /**
     * The dedup pass for identify/user_property/push_token events.
     * Held by the queue (rather than a separate singleton) because
     * the lifecycle of dedup state matches the queue's lifecycle —
     * both reset on `Kixo.reset()`.
     */
    private val identityDedup: IdentityDedup = IdentityDedup()

    /**
     * Once-per-cooldown-episode flag for the `Recovering` transition.
     * Without it, every retry while the failure counter sits at 30+
     * would re-emit the lifecycle transition. Reset when the failure
     * counter drops back below threshold (i.e., on success).
     *
     * Modified under [mutex].
     */
    private var hasNotifiedCooldown: Boolean = false

    /**
     * Handle to the periodic flush coroutine so [stop] can cancel
     * it cleanly. Started lazily on the first [enqueue] / [flush]
     * call (which is also when `scope` is guaranteed to be alive).
     */
    private var periodicFlushJob: Job? = null

    /**
     * True while the queue is paused because of a CLIENT stop
     * ([stop] — `Kixo.optOut()` / `Kixo.revokeConsent()` / `Kixo.reset()`),
     * as opposed to a SERVER kill-switch (`paused=true` on a batch/control-
     * plane response, or a permanent 4xx). [resume] only re-opens a client-
     * stopped queue after the next fresh `/api/sdk/config` response; a local
     * consent toggle alone can never override a version kill-switch.
     *
     * Set true inside [stop], cleared inside [resume] and on any
     * [setLifecycleState] transition to a non-paused state.
     */
    @Volatile
    private var clientStopped: Boolean = false

    /** Server-owned pause latch, independent from local consent/reset state. */
    @Volatile
    private var serverPauseReason: String? = null

    @Volatile
    private var identityResetInFlight: Boolean = false

    /** Fail-closed latch: a later config response cannot reopen uncleared rows. */
    @Volatile
    private var identityResetFailed: Boolean = false

    /**
     * A successful identity clear may finish before the control plane has
     * authorised collection, or while a server pause is still active. Retain
     * the reset completion hook until the queue reaches a genuine Running
     * state; consuming it early would drop the new session_start and re-arm
     * replay against an unresolved policy.
     */
    private val identityResetReadyLock = Any()
    private var pendingIdentityResetReady: PendingIdentityResetReady? = null

    /** True only after an authoritative control-plane response newer than the
     * latest local privacy resume request. */
    @Volatile
    private var serverPolicyResolved: Boolean = false

    /**
     * True once collection has actually been OPEN under an explicit
     * non-paused authority — i.e. the queue reached
     * [LifecycleState.Running]. While it is true the durable buffer may
     * hold events captured lawfully under that grant, and a later
     * SERVER pause must therefore stop FUTURE capture only.
     *
     * Cleared by the destructive privacy paths ([stop] /
     * [clearForIdentityReset]) because those wipe the buffer, so there
     * is no lawful backlog left to protect.
     */
    @Volatile
    private var collectionGrantedByPolicy: Boolean = false

    /**
     * One-shot latch for the cold-start buffer reconciliation. The
     * window between `Kixo.configure(...)` and the first resolved
     * `data_collection` has no policy at all, so every tracker
     * default-allows and the rows it produces land in the durable
     * store unjudged. The FIRST resolved policy is the first authority
     * over them; later policy changes only affect future capture.
     */
    private val prePolicyBufferReconciled = AtomicBoolean(false)

    /**
     * Set synchronously by [reconcilePrePolicyBuffer] and cleared by the
     * coroutine it launches. While true no flush may claim a batch: the
     * pre-policy rows are still being judged, and shipping them first
     * would put events on the wire that the operator has switched off.
     */
    @Volatile
    private var prePolicyReconciliationPending: Boolean = false

    /**
     * Number of destructive SQLite clears still running. A local resume may
     * clear the stop latch immediately, but it must not reopen enqueue until
     * every clear that began before it has completed.
     */
    private val destructiveClearsInFlight = AtomicInteger(0)

    /** A client resume deferred behind clear/reset/initial-policy barriers. */
    @Volatile
    private var resumeRequested: Boolean = false

    /** Wakes the control-plane loop without a 30-minute wait. */
    private val collectionAllowedSignal = Channel<Unit>(Channel.CONFLATED)

    /**
     * Monotonic privacy generation for `/init` and `/config` responses.
     * Network calls are deliberately not held under [controlPlaneGenerationLock],
     * but every response is applied under it. A privacy stop/resume therefore
     * linearizes either before the apply (the response is rejected) or after it
     * (the stop immediately tears the applied state back down).
     */
    private val controlPlaneGenerationLock = Any()
    private val controlPlaneGeneration = AtomicLong(0L)

    /**
     * Best-effort cached pending count from the last successful
     * [store.pendingCount] read (taken inside the flush path or after
     * an enqueue). Updated under no lock so [diagnostics] can read it
     * without suspending. Critic 7 fix: replaces the prior
     * [runBlocking] inside [diagnostics] which could ANR if a host
     * called diagnostics() from the main thread at a UI moment. The
     * slight staleness is documented in [QueueDiagnostics] —
     * diagnostics is best-effort by contract.
     */
    @Volatile
    private var lastKnownPendingCount: Int = 0

    init {
        if (enablePeriodicFlush) startPeriodicFlush()
    }

    // ─── Public API ──────────────────────────────────────────────

    /**
     * Reactive view of the lifecycle phase. Subscribe from the Kixo
     * facade to surface the same value through `Kixo.diagnostics()`.
     * Cold-collected — no background work is started just because
     * someone subscribes.
     */
    fun lifecycleState(): StateFlow<LifecycleState> = _lifecycleState.asStateFlow()

    /**
     * Append an event to the queue. Persisted via [EventStore.append]
     * BEFORE returning so a crash before the next flush still
     * preserves it. Triggers an immediate flush if the threshold is
     * met AND we're in [LifecycleState.Running].
     *
     * **Identity dedup:** events with `eventType` in the dedup set
     * (`identify` / `user_property` / `push_token`) are gated through
     * [IdentityDedup] BEFORE persistence. A duplicate identify call
     * with the same traits never touches disk. See iOS comment in
     * `Kixo.swift`: "Observed on LikePost: 41 `identify`, 37
     * `user_property`, 10 `push_token` per device in a 2h window".
     *
     * **Paused state:** events are dropped silently. The server told
     * us to stop. Persisting them would just delay recovery when
     * the server resumes us.
     *
     * **Project policy:** an auto-capture category the resolved
     * `data_collection` affirmatively switches off never reaches disk,
     * checked at the persistence boundary rather than trusting the
     * emitting tracker's earlier gate read. Customer-authored events
     * are never matched — see [DataCollectionEventGate].
     */
    suspend fun enqueue(
        event: KixoEvent,
        expectedIdentityBoundaryGeneration: Long? = null,
    ): Boolean {
        // Drop early when paused — never write to disk.
        val state = _lifecycleState.value
        if (state is LifecycleState.PausedByServer) {
            if (debug) Log.d(TAG, "Drop event ${event.eventId}: SDK paused (${state.reason ?: "unspecified"})")
            return false
        }

        // FIX 3 — consent gate. EVERY event (incl. the canonical
        // `app_install` signal) drops here while the device is opted out, and
        // non-essential events drop while consent is un-granted. Checked
        // BEFORE the dedup pass + the persistence call so an opted-out device
        // never writes to disk. Single-sourced through `ConsentManager`
        // (mirrors iOS, which anchors its enqueue gate to the same
        // `shouldEmit`). This closes the leak where `optOut()` / `revokeConsent()`
        // flipped the flag but the queue kept emitting.
        if (!consentGate(event.eventType)) {
            if (debug) Log.d(TAG, "Drop event ${event.eventId}: consent gate (type=${event.eventType})")
            return false
        }

        // Identity dedup (the iOS hot-path optimisation). The dedup
        // decision is made BEFORE the persistence call so a no-op
        // identify never touches disk.
        if (!shouldEmitForDedup(event)) {
            if (debug) Log.v(TAG, "Drop event ${event.eventId}: identity dedup matched prior call")
            return false
        }

        // Persist. The store enforces the FIFO cap (`maxBufferSize`)
        // by dropping the oldest row if needed — that's an internal
        // detail of EventStore.append, the queue doesn't need to
        // double-check.
        val persisted = runCatching {
            persistenceBoundaryMutex.withLock {
                if (identityResetInFlight ||
                    expectedIdentityBoundaryGeneration?.let {
                        it != identityBoundaryGeneration.get()
                    } == true
                ) {
                    return@withLock false
                }
                // Judge the project policy at the PERSISTENCE boundary, not
                // only at emit time. Every tracker checks its own gate before
                // it emits, but the emission then hops a coroutine before it
                // reaches disk — so an event whose gate read the cold-start
                // default-allow can be appended AFTER the first resolved
                // policy landed. [reconcilePrePolicyBuffer] only judges rows
                // that were already on disk when it ran, so such a row
                // escaped both gates: an app that backgrounds while `/init`
                // is in flight shipped the buffered `session_end` of a
                // project whose operator had switched session tracking off.
                //
                // Both halves share [persistenceBoundaryMutex] and the policy
                // is published before the reconcile is queued, which makes
                // them jointly exhaustive: a row appended before the
                // reconcile pass is deleted by it, and a row appended after
                // it reads the resolved policy here and never lands.
                if (isDisabledByResolvedPolicy(event)) {
                    if (debug) {
                        Log.d(
                            TAG,
                            "Drop event ${event.eventId}: project policy disabled " +
                                "(type=${event.eventType})",
                        )
                    }
                    return@withLock false
                }
                store.append(event)
            }
        }
            .onFailure { t ->
                // R6: never throw out of enqueue. A persistence
                // failure (disk full, encoding bug, sqlite locked)
                // means we drop the event — but not the host app.
                if (debug) Log.w(TAG, "Persist failed for ${event.eventId}", t)
            }
            .getOrDefault(false)
        if (!persisted) return false

        // Threshold trigger. Re-check `Running` AND `!isFlushing`
        // inside the mutex at fire time — the state we read above
        // could be stale by now (a parallel flush failed and ticked
        // us into `Recovering` between the dedup check and here).
        val pending = runCatching { store.pendingCount() }.getOrDefault(Int.MAX_VALUE)
        // Refresh the diagnostics cache (Critic 7 fix). Skip on the
        // Int.MAX_VALUE sentinel which means the count call failed —
        // we don't want to lie about an unbounded queue.
        if (pending != Int.MAX_VALUE) lastKnownPendingCount = pending
        if (pending >= flushAt) {
            scope.launch { tryFlush() }
        }
        return true
    }

    /**
     * Best-effort drain. Idempotent; safe to call from any thread.
     * Returns immediately — the actual send happens async on
     * [scope].
     *
     * No-op if the queue is suspended (anything but
     * [LifecycleState.Running]) or already flushing — the in-flight
     * batch will still resolve on its own.
     */
    fun flush() {
        scope.launch { tryFlush() }
    }

    /**
     * Synchronous drain for tests + manual triggers. Blocks the
     * calling thread until the flush completes or the timeout
     * elapses.
     *
     * **MUST NOT be called from the main thread** — uses
     * `runBlocking` internally which would ANR a real Android app.
     * The contract (also in the briefing) is "test-only / manual
     * teardown only". Provided so tests don't have to plumb
     * `runTest` everywhere.
     *
     * @return `true` if a flush completed within the timeout
     *         (success OR no-op-with-empty-buffer counts), `false`
     *         on timeout.
     */
    fun flushBlocking(timeoutMs: Long): Boolean {
        // Marshal to the queue's scope/dispatcher so we honour the
        // serialisation guarantee. `runBlocking` parks the caller's
        // thread; the actual flush still runs on `scope`'s
        // dispatcher (Default by convention) so we don't deadlock
        // on a single-thread executor.
        return runBlocking(Dispatchers.Default) {
            withTimeoutOrNull(timeoutMs) {
                tryFlush()
                true
            } ?: false
        }
    }

    /**
     * Transition the lifecycle phase. Called by the Kixo facade
     * (Agent 1) from `/api/sdk/init` outcomes and from its
     * recovery-loop. Side effects:
     *   - On entering `Running`: kicks an immediate flush so
     *     events buffered during the suspend window land
     *     promptly instead of waiting for the next periodic tick.
     *   - On entering `PausedByServer`: drains the durable buffer
     *     ONLY when nothing in it was captured under an explicit
     *     non-paused policy — see [shouldEraseBufferOnPause].
     *   - On entering `Recovering` from `Running`: resets the
     *     failure counter so the next attempt starts from rapid-
     *     tier rather than cooldown. (The iOS path does the same
     *     via `resetFailureCounter()`.)
     *
     * Idempotent: setting the same state twice is a cheap no-op.
     */
    fun setLifecycleState(state: LifecycleState) {
        val prev = _lifecycleState.value
        if (prev == state) return
        _lifecycleState.value = state

        if (debug) Log.d(TAG, "Lifecycle ${prev.name} → ${state.name}")

        when (state) {
            is LifecycleState.Running -> {
                // The only production authority that reaches Running is an
                // accepted server policy. Direct unit-test transitions model
                // that same resolved state.
                serverPolicyResolved = true
                // From here on, anything in the durable buffer was captured
                // under an explicit non-paused policy. A later server pause
                // may close the door; it may not burn what is behind it.
                collectionGrantedByPolicy = true
                runCatching(onRunning)
                    .onFailure { if (debug) Log.w(TAG, "Running observer failed", it) }
                // Reset failure counter + clear cooldown notification
                // flag so the next failure starts the rapid tier
                // again from #1.
                scope.launch {
                    mutex.withLock {
                        consecutiveFailures = 0
                        hasNotifiedCooldown = false
                    }
                    // Kick a flush so buffered events ship right away.
                    tryFlush()
                }
            }
            is LifecycleState.PausedByServer -> {
                if (shouldEraseBufferOnPause()) {
                    launchDestructiveClear("Drain on pause")
                }
            }
            else -> {
                // Initialising / Recovering: no immediate side effect
                // beyond suspending the flush path (the periodic flush
                // checks state before each attempt).
            }
        }
    }

    /**
     * Does entering [LifecycleState.PausedByServer] erase what is
     * already buffered?
     *
     * **Yes** for the destructive privacy paths:
     *  - [stop] — `Kixo.optOut()` / `Kixo.revokeConsent()` /
     *    `Kixo.reset()`. The end user withdrew permission; deleting
     *    what we hold is the whole point.
     *  - a failed identity-reset clear, where old-identity rows may
     *    still be on disk and must never ship under the new identity.
     *  - a pause that arrives before collection was ever explicitly
     *    opened (project paused / app not approved at `/init`). Those
     *    rows were admitted by the cold-start default-allow window, not
     *    by an authority that said "yes".
     *
     * **No** for a mid-session pause — the dashboard toggle an operator
     * flips while the app is running, a `paused=true` batch response, or
     * a permanent 4xx. Collection was explicitly open when those events
     * were captured, so they are the customer's data. A pause means
     * "stop collecting from now on", never "destroy the last hour of a
     * customer's analytics". Enqueue still drops every NEW event while
     * paused, and the retained backlog ships if and when the operator
     * un-pauses (or on the next launch).
     */
    private fun shouldEraseBufferOnPause(): Boolean =
        clientStopped || identityResetFailed || !collectionGrantedByPolicy

    /**
     * Reconcile the cold-start buffer against the FIRST resolved
     * `data_collection` policy.
     *
     * Between `Kixo.configure(...)` and the first `/api/sdk/init`
     * response there is no policy: [DataCollectionHolder] is null and
     * every tracker gate default-allows, so session, tap, crash and
     * push rows land in the durable store unjudged. Without this step a
     * project with session tracking switched off still receives the
     * `session_start` / `session_end` pair that the SDK buffered before
     * it was told — they simply go out on the wire on the first flush
     * after `/init`, having bypassed every gate the operator set.
     *
     * Runs exactly once per process, against the first resolved policy
     * only. A LATER tightening is not retroactive: by then the events
     * were captured under an explicit grant and are protected by the
     * same rule as [shouldEraseBufferOnPause].
     *
     * Only categories the policy affirmatively disables are dropped,
     * and never a customer-authored event — see [DataCollectionEventGate].
     *
     * This pass judges the rows that are on disk when it runs. Its other
     * half is [isDisabledByResolvedPolicy] at the persistence boundary,
     * which catches the emission that was already in flight when the
     * policy landed; see the comment in [enqueue].
     */
    fun reconcilePrePolicyBuffer(dataCollection: DataCollection?) {
        if (dataCollection == null) return
        if (!prePolicyBufferReconciled.compareAndSet(false, true)) return
        // Set BEFORE returning to the caller (which is about to move the
        // lifecycle to Running) so no flush can claim the unjudged rows
        // in the gap before the coroutine below runs.
        prePolicyReconciliationPending = true
        scope.launch {
            try {
                var retryDelayMs = PRE_POLICY_RECONCILE_RETRY_MIN_MS
                while (currentCoroutineContext().isActive) {
                    try {
                        val dropped = persistenceBoundaryMutex.withLock {
                            store.deleteWhere { event ->
                                DataCollectionEventGate.isExplicitlyDisabled(
                                    dataCollection,
                                    event.eventType,
                                )
                            }
                        }
                        if (debug && dropped > 0) {
                            Log.d(TAG, "Dropped $dropped pre-policy events disabled by project policy")
                        }
                        lastKnownPendingCount = store.pendingCount()
                        break
                    } catch (cancelled: CancellationException) {
                        throw cancelled
                    } catch (failure: Throwable) {
                        // Privacy is fail-closed: never unlatch flush while a
                        // disabled pre-policy row may still be on disk. SQLite
                        // failures are normally transient (busy/I/O pressure),
                        // so retry with a bounded backoff until this process
                        // stops or the deletion really succeeds.
                        if (debug) {
                            Log.w(
                                TAG,
                                "Pre-policy buffer reconcile failed; retrying",
                                failure,
                            )
                        }
                        delay(retryDelayMs)
                        retryDelayMs =
                            (retryDelayMs * 2).coerceAtMost(PRE_POLICY_RECONCILE_RETRY_MAX_MS)
                    }
                }
            } finally {
                // Cancellation means the whole queue scope is stopping, so no
                // later flush can escape. A live scope reaches here only after
                // reconciliation succeeded.
                prePolicyReconciliationPending = false
            }
            tryFlush()
        }
    }

    /**
     * Does the currently resolved project policy affirmatively switch
     * off the category [event] belongs to?
     *
     * Read under [persistenceBoundaryMutex] by [enqueue] so the answer
     * cannot be older than a policy that a concurrent
     * [reconcilePrePolicyBuffer] has already acted on.
     *
     * `null` (no policy resolved yet) is not a denial — the cold-start
     * window keeps its default-allow, and the reconcile pass is what
     * judges those rows once the first policy lands.
     */
    private fun isDisabledByResolvedPolicy(event: KixoEvent): Boolean {
        val policy = DataCollectionHolder.snapshot() ?: return false
        return DataCollectionEventGate.isExplicitlyDisabled(policy, event.eventType)
    }

    /**
     * Wipe identity dedup caches. Called from `Kixo.reset()` after
     * a logout so a re-identify with the same payload still fires
     * once.
     *
     * Does NOT touch the durable event store — the host can
     * separately call `clear()` through Agent 3's API if they
     * want a full reset.
     */
    fun resetIdentityDedup() {
        identityDedup.reset()
    }

    /**
     * Clear pre-logout rows without permanently stopping the SDK. Enqueue is
     * paused during the short asynchronous SQLite clear so no event from the
     * new identity can be swept up by the old-identity cleanup.
     */
    fun clearForIdentityReset(
        onBoundaryStarted: () -> Unit = {},
        onReady: () -> Unit = {},
    ) {
        val boundaryGeneration = synchronized(identityResetReadyLock) {
            val generation = identityBoundaryGeneration.incrementAndGet()
            // The newest identity boundary owns readiness. A callback retained
            // by an older, policy-blocked reset must not survive replacement.
            pendingIdentityResetReady = null
            identityResetInFlight = true
            // The old identity's rows are being erased below; nothing
            // survives for a later pause to protect.
            collectionGrantedByPolicy = false
            _lifecycleState.value = LifecycleState.PausedByServer("identity_reset")
            generation
        }
        val boundaryStarted = runCatching(onBoundaryStarted)
            .onFailure { if (debug) Log.w(TAG, "Identity reset boundary failed", it) }
            .isSuccess
        destructiveClearsInFlight.incrementAndGet()
        scope.launch {
            var cleared = false
            try {
                cleared = runCatching {
                    persistenceBoundaryMutex.withLock { store.clear() }
                }
                    .onFailure { if (debug) Log.w(TAG, "Identity reset clear failed", it) }
                    .isSuccess
                if (cleared) {
                    lastKnownPendingCount = 0
                    identityDedup.reset()
                    runCatching(onDurableQueueCleared)
                        .onFailure { if (debug) Log.w(TAG, "Queue-clear observer failed", it) }
                }
            } finally {
                destructiveClearsInFlight.decrementAndGet()
                synchronized(identityResetReadyLock) {
                    // Generation increment and this entire commit share one
                    // monitor, closing the stale check-then-act window.
                    if (identityBoundaryGeneration.get() == boundaryGeneration) {
                        identityResetInFlight = false
                        if (!cleared || !boundaryStarted) {
                            identityResetFailed = true
                            discardPendingIdentityResetReady(boundaryGeneration)
                            // Old-identity rows may still exist. Never reopen a
                            // queue that could flush them under the new identity.
                            _lifecycleState.value =
                                LifecycleState.PausedByServer("identity_reset_clear_failed")
                        } else {
                            identityResetFailed = false
                            retainIdentityResetReady(boundaryGeneration, onReady)
                        }
                    }
                }
                // Even a stale clear owns this decrement. If it was the last
                // destructive operation, it must release the current successful
                // generation without applying its own stale result.
                reconcileIdentityResetAfterDestructiveClears()
            }
        }
    }

    fun identityBoundaryGeneration(): Long = identityBoundaryGeneration.get()

    /** Apply a server kill-switch without conflating it with local opt-out. */
    fun setServerPaused(reason: String?) {
        serverPolicyResolved = true
        serverPauseReason = reason ?: "server_paused"
        setLifecycleState(LifecycleState.PausedByServer(serverPauseReason))
    }

    /**
     * Cancel calls admitted under the superseded server policy. Kept separate
     * from [setServerPaused] so control-plane apply can release
     * [controlPlaneGenerationLock] first; public opt-out takes the locks in the
     * opposite order (privacy → control-plane), so nesting would deadlock.
     */
    fun retireCollectionNetworkCalls() {
        privacyGate?.rotateCollectionBoundary()
    }

    /**
     * Clear the server latch after a successful config refresh. A local
     * opt-out still wins; otherwise collection and the periodic timer resume.
     */
    fun setServerRunning() {
        serverPolicyResolved = true
        serverPauseReason = null
        if (clientStopped || identityResetFailed) return
        if (identityResetInFlight || destructiveClearsInFlight.get() > 0) {
            // Preserve the authoritative unpause until the durable privacy
            // barrier completes. Its finally path will reconcile this request.
            resumeRequested = true
            return
        }
        if (resumeRequested) {
            reconcileRequestedResume()
            runPendingIdentityResetReadyIfRunning()
            return
        }
        if (enablePeriodicFlush && periodicFlushJob == null) startPeriodicFlush()
        setLifecycleState(LifecycleState.Running)
        runPendingIdentityResetReadyIfRunning()
    }

    /** Snapshot the privacy generation immediately before a control-plane call. */
    fun controlPlaneGeneration(): Long = controlPlaneGeneration.get()

    /**
     * Apply one response only if no opt-out/revoke/resume boundary occurred
     * since its request began. The block and privacy transitions share one
     * monitor, closing the check-then-apply race.
     */
    fun applyIfControlPlaneGenerationCurrent(
        expectedGeneration: Long,
        apply: () -> Unit,
    ): Boolean = synchronized(controlPlaneGenerationLock) {
        if (controlPlaneGeneration.get() != expectedGeneration) return@synchronized false
        apply()
        true
    }

    /**
     * Wait for the normal refresh deadline or an explicit privacy-resume
     * signal. Using this for the steady-state delay as well as the opted-out
     * branch means opt-in cannot get stranded behind an already-running
     * 30-minute sleep.
     */
    suspend fun awaitControlPlaneRefresh(timeoutMs: Long) {
        withTimeoutOrNull(timeoutMs) { collectionAllowedSignal.receive() }
    }

    /**
     * Invalidate any replay-policy response already in flight, then wake the
     * control plane. A local replay opt-in must be authorised by a request that
     * began after that edge, not by a response from the vetoed generation.
     */
    fun requestControlPlaneRefresh() {
        synchronized(controlPlaneGenerationLock) {
            controlPlaneGeneration.incrementAndGet()
            collectionAllowedSignal.trySend(Unit)
        }
    }

    /**
     * Snapshot of queue health for `Kixo.diagnostics()`.
     *
     * **Best-effort, never blocks (Critic 7 fix).** An earlier
     * revision called `store.pendingCount()` + acquired the coroutine
     * [mutex] inside a `runBlocking(Dispatchers.Default)`. Even on
     * Default, `runBlocking` parks the calling thread until the work
     * completes — if a host calls `Kixo.diagnostics()` from the main
     * thread during a UI moment AND the SQLite count query takes
     * longer than the ANR window (e.g. checkpoint stall on a
     * write-heavy app), the host ANRs. The fix:
     *  - Read the cached [lastKnownPendingCount] (Volatile, lock-
     *    free) instead of touching SQLite. The cache is refreshed
     *    after every [enqueue] threshold check + after every
     *    successful flush — so it lags the truth by at most one
     *    flush interval (~30s) under normal load. Documented on
     *    [QueueDiagnostics].
     *  - Read [consecutiveFailures] / [isFlushing] / lifecycle as
     *    plain field reads. They're all simple primitives /
     *    references; no torn-read risk for the diagnostic use
     *    case (the worst case is a 1-microsecond inconsistency
     *    between failures and isFlushing, irrelevant for a human-
     *    readable diagnostic).
     *
     * The trade-off (slight cache staleness vs no ANR risk) is the
     * right one for a diagnostics surface that the briefing already
     * calls "best-effort."
     */
    fun diagnostics(): QueueDiagnostics {
        val lifecycle = _lifecycleState.value
        val pausedReason = (lifecycle as? LifecycleState.PausedByServer)?.reason
        val failures = consecutiveFailures
        return QueueDiagnostics(
            bufferedEventCount = lastKnownPendingCount,
            bufferCap = maxBufferSize,
            consecutiveFailures = failures,
            isFlushing = isFlushing,
            retryTier = RetryScheduler.tierName(failures),
            lifecycleState = lifecycle.name,
            pausedReason = pausedReason,
        )
    }

    // ─── Internals ───────────────────────────────────────────────

    /**
     * Identity dedup gate. Returns true if the event should be
     * emitted, false if it duplicates the last one of its kind.
     *
     * Non-dedup event types fall through unconditionally.
     *
     * The dedup hashes live in `properties` for the wire-format
     * versions of these events. We extract the relevant fields
     * defensively — wrong-shape properties (theoretically a host
     * bug) emit the event rather than silently dropping it. R6:
     * never crash; here, prefer one duplicate over zero events.
     */
    private fun shouldEmitForDedup(event: KixoEvent): Boolean {
        return when (event.eventType) {
            KixoEventType.Identify -> {
                val (userId, traits) = identifyExtractor(event)
                identityDedup.shouldEmitIdentify(userId, traits)
            }
            KixoEventType.UserProperty -> {
                val (key, value) = userPropertyExtractor(event)
                if (key == null) {
                    // Malformed user_property event — let it through.
                    true
                } else {
                    identityDedup.shouldEmitUserProperty(key, value)
                }
            }
            // The prior queue used `event.eventType == "push_token"` for
            // dedup. The real wire token is `push_token_invalidated`
            // (the only push-token-related event_type the SDK emits).
            // Use the enum form so the wire string is single-sourced
            // through @SerialName on the enum definition.
            KixoEventType.PushTokenInvalidated -> {
                val (token, provider) = pushTokenExtractor(event)
                if (token == null) {
                    true
                } else {
                    identityDedup.shouldEmitPushToken(token, provider)
                }
            }
            else -> true
        }
    }

    /**
     * Best-effort extractor for an `identify` event's payload. Reads
     * `user_id` + the rest of `properties` as traits.
     *
     * Reads directly from the real [KixoEvent] (`userId` field +
     * `properties: JsonObject`). The JsonObject is converted to
     * `Map<String, Any?>` so [IdentityDedup.shouldEmitIdentify] can
     * hash it the same way the iOS path does. Conversion cost is
     * proportional to property-bag size (small, single-digit kb in
     * practice).
     */
    private fun identifyExtractor(event: KixoEvent): Pair<String?, Map<String, Any?>> {
        return Pair(event.userId, jsonObjectToMap(event.properties))
    }

    /**
     * Extract `(key, value)` for a `user_property` event. The wire
     * shape is `{ "key": "<string>", "value": <any> }`, mirroring
     * iOS. We pull the key as a string primitive and pass the value
     * through as a kotlin-typed scalar (Boolean / Long / Double /
     * String / null) for the dedup hasher.
     */
    private fun userPropertyExtractor(event: KixoEvent): Pair<String?, Any?> {
        val props = event.properties
        val key = props["key"]?.jsonPrimitive?.contentOrNull
        val value = jsonElementToAny(props["value"])
        return Pair(key, value)
    }

    /**
     * Extract `(token, provider)` for a `push_token_invalidated`
     * event. Wire shape: `{ "push_token": "<sha256>", "push_provider": "fcm" }`.
     */
    private fun pushTokenExtractor(event: KixoEvent): Pair<String?, PushProvider> {
        val props = event.properties
        val token = props["push_token"]?.jsonPrimitive?.contentOrNull
        val providerStr = props["push_provider"]?.jsonPrimitive?.contentOrNull
        val provider = PushProvider.fromWireValue(providerStr) ?: PushProvider.FCM
        return Pair(token, provider)
    }

    /**
     * Convert a [JsonObject] to a `Map<String, Any?>` with kotlin-
     * typed scalars. Used by the dedup pass which needs a stable
     * non-Json representation for its SHA-256 keying (the same shape
     * iOS hashes).
     *
     * Lossy by design — the dedup only needs primitive equality, not
     * fidelity round-trips through JSON. Nested JsonObject /
     * JsonArray values recurse so multi-level traits hash
     * deterministically.
     */
    private fun jsonObjectToMap(obj: JsonObject): Map<String, Any?> =
        obj.entries.associate { (k, v) -> k to jsonElementToAny(v) }

    private fun jsonElementToAny(el: JsonElement?): Any? {
        if (el == null) return null
        return when (el) {
            is JsonNull -> null
            is JsonPrimitive -> when {
                el.isString -> el.content
                el.content == "true" -> true
                el.content == "false" -> false
                el.content.toLongOrNull() != null -> el.content.toLong()
                el.content.toDoubleOrNull() != null -> el.content.toDouble()
                else -> el.content
            }
            is JsonObject -> el.entries.associate { (k, v) -> k to jsonElementToAny(v) }
            is JsonArray -> el.map { jsonElementToAny(it) }
        }
    }

    /**
     * Single-flight flush. Honours the suspend gate (any state but
     * [LifecycleState.Running] is a no-op) and the in-flight gate
     * (a parallel flush already running is a no-op).
     *
     * Marked `private` even though [flush] / [flushBlocking] both
     * route through it — the public surface always goes through
     * the scope.
     */
    private suspend fun tryFlush() {
        val gate = privacyGate
        if (gate == null) {
            tryFlushAuthorised(collectionEpoch = null)
            return
        }
        val job = currentCoroutineContext()[Job] ?: return
        val lease = gate.registerCollectionTask(
            job = job,
            liveOptedOut = ConsentManager::isOptedOut,
            liveConsentGranted = ConsentManager::hasConsent,
        ) ?: return
        try {
            tryFlushAuthorised(collectionEpoch = lease.epoch)
        } catch (cancelled: CancellationException) {
            // A privacy/reset boundary may cancel after isFlushing=true.
            // Release the single-flight latch non-cancellably so opt-in can
            // later drain a fresh generation instead of wedging forever.
            withContext(NonCancellable) {
                mutex.withLock { isFlushing = false }
            }
            throw cancelled
        } finally {
            lease.close()
        }
    }

    private suspend fun tryFlushAuthorised(collectionEpoch: Long?) {
        // Re-check lifecycle + in-flight gate INSIDE the mutex so
        // a transition during the launch dispatch doesn't let two
        // flushes race.
        val proceed = mutex.withLock {
            val state = _lifecycleState.value
            if (state !is LifecycleState.Running) return@withLock false
            if (isFlushing) return@withLock false
            isFlushing = true
            true
        }
        if (!proceed) return

        // The cold-start buffer has not been judged against the first
        // resolved policy yet. Shipping now would put pre-policy rows
        // from a disabled category on the wire. The reconcile coroutine
        // kicks a fresh flush when it is done.
        if (prePolicyReconciliationPending) {
            mutex.withLock { isFlushing = false }
            return
        }

        // Claim the batch. The store flips claimed rows to in-flight
        // (Mixpanel MPDB pattern) so a parallel claim wouldn't see
        // them. No buffer here — the queue is a thin orchestrator
        // over the durable store.
        val batch: List<KixoEvent> = try {
            store.checkout(MAX_BATCH_SIZE)
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            if (debug) Log.w(TAG, "checkout failed", t)
            mutex.withLock { isFlushing = false }
            return
        }

        if (batch.isEmpty()) {
            mutex.withLock { isFlushing = false }
            return
        }

        // Build the payload. Pulls the live config snapshot + the
        // device context. Cheap (data-class instantiation).
        val payload: BatchPayload = try {
            payloadAssembler.assemble(batch)
        } catch (t: Throwable) {
            // R6: assembly failure is a permanent bug, not a network
            // problem. Release the in-flight rows so they retry
            // (defensive — the bug is in our code, retry won't help,
            // but dropping silently is worse).
            if (debug) Log.w(TAG, "payload assembly failed", t)
            runCatching { store.release(batch.map { it.eventId }) }
            mutex.withLock { isFlushing = false }
            return
        }

        // Make the network call. Transport never throws — outcomes
        // are wrapped in [BatchOutcome]. R6 boundary: Transport's
        // contract owns the "never throw" guarantee for HTTP errors.
        // Convert outcome → queue's internal [BatchResponse] model so
        // the rest of the apply path stays platform-neutral (this
        // mapping used to live in `TransportAdapter` in QueueWiring;
        // post-Wave 6 refactor it lives inline as a private helper).
        val outcome: BatchOutcome = try {
            if (collectionEpoch == null) {
                transport.postBatch(payload)
            } else {
                transport.postBatch(payload, collectionEpoch)
            }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (t: Throwable) {
            // Defensive — Transport SHOULDN'T throw, but if a future
            // refactor regresses we still don't crash. Treat as
            // transient so events retry.
            if (debug) Log.w(TAG, "transport.postBatch threw (treating as transient)", t)
            BatchOutcome.NetworkError(t)
        }

        applyResponse(batch, outcome.toQueueResponse())
    }

    /**
     * Convert the real [BatchOutcome] (Agent 4's transport return type)
     * into the queue's internal [BatchResponse] model.
     *
     *  - [BatchOutcome.Success] partitions IDs into `accepted /
     *    transient / permanent`. Queue's [BatchResponse.Success]
     *    expects `acceptedEventIds` + a single `errors` list of
     *    [EventError] with `permanent` flags set per bucket. We fold
     *    permanent + transient back into one list, tagging each with
     *    the right flag.
     *  - [BatchOutcome.HttpError] flips `transient` to `permanent`
     *    via negation (queue's model expresses the inverse polarity).
     *  - [BatchOutcome.NetworkError] is always transient → discard
     *    the cause (the queue only acts on the typed outcome; the
     *    underlying exception is logged at the transport boundary).
     *  - [BatchOutcome.SerializationError] means our own payload
     *    was malformed — drop the batch as a permanent 400 so we
     *    don't loop forever on a bad shape.
     */
    private fun BatchOutcome.toQueueResponse(): BatchResponse = when (this) {
        is BatchOutcome.Success -> BatchResponse.Success(
            acceptedEventIds = acceptedIds,
            errors = permanentIds.map {
                EventError(eventId = it, message = "permanent", permanent = true)
            } + transientIds.map {
                EventError(eventId = it, message = "transient", permanent = false)
            },
            paused = paused,
            pausedReason = pausedReason,
        )
        is BatchOutcome.HttpError -> BatchResponse.HttpError(
            statusCode = code,
            permanent = !transient,
        )
        is BatchOutcome.NetworkError -> BatchResponse.NetworkError
        BatchOutcome.SerializationError -> BatchResponse.HttpError(
            statusCode = 400,
            permanent = true,
        )
    }

    /**
     * Apply the per-event acks from a [BatchResponse], reconciling
     * the durable store and updating retry / lifecycle state.
     *
     * Possible outcomes:
     *   - `Success` with at least one accepted/permanent event →
     *     reset failure counter, schedule another flush if more
     *     events arrived during the in-flight send.
     *   - `Success` with all-transient or `NetworkError` /
     *     `HttpError(transient)` → tick failure counter, schedule
     *     a retry with backoff.
     *   - `HttpError(permanent)` (e.g. 401) → drop the events,
     *     transition to `PausedByServer`. The host's API key is
     *     wrong; retrying makes nothing better.
     *   - `Success(paused=true)` → server has flipped our SDK
     *     to off; transition to `PausedByServer` carrying the
     *     server's reason code.
     */
    private suspend fun applyResponse(batch: List<KixoEvent>, response: BatchResponse) {
        when (response) {
            is BatchResponse.Success -> {
                // Per-event ack contract (briefing R5):
                //   - in `acceptedEventIds` → DELETE
                //   - in `errors` with permanent=true → DELETE
                //   - in `errors` with permanent=false → release (flag=0, retry)
                //   - missing from BOTH → defensive: retry as transient
                val batchIds = batch.mapTo(linkedSetOf()) { it.eventId }
                val acceptedIds = response.acceptedEventIds
                    .filterTo(linkedSetOf()) { it in batchIds }
                val transientIds = mutableSetOf<String>()
                val permanentIds = mutableSetOf<String>()
                for (err in response.errors) {
                    if (err.eventId !in batchIds) continue
                    if (err.permanent) permanentIds += err.eventId
                    else transientIds += err.eventId
                }

                // Defensive: an event that appears in BOTH the
                // accepted list AND the errors list would be
                // ambiguous. Trust the explicit error over the
                // accepted (matches iOS Transport.swift's resolved-
                // ids semantics — error wins).
                for (id in transientIds) acceptedIds.remove(id)
                for (id in permanentIds) acceptedIds.remove(id)

                // Defensive: never delete a durable event that the backend
                // omitted from both ack arrays. Transport normally performs
                // this classification, but queue-level tests/adapters can
                // construct BatchResponse directly, so enforce it again.
                val mentioned = acceptedIds + transientIds + permanentIds
                for (e in batch) {
                    if (e.eventId !in mentioned) transientIds += e.eventId
                }

                // Settle: accepted + permanent are dropped from the
                // store; transient are released for the next claim.
                runCatching {
                    store.confirm((acceptedIds + permanentIds).toList())
                }.onFailure { if (debug) Log.w(TAG, "confirm failed", it) }
                if (acceptedIds.isNotEmpty()) {
                    runCatching { onAcceptedEventIds(acceptedIds) }
                        .onFailure { if (debug) Log.w(TAG, "Accepted-event observer failed", it) }
                }
                if (permanentIds.isNotEmpty()) {
                    if (response.paused) {
                        // A paused 2xx is a PROJECT-level verdict (app awaiting
                        // approval, blocked/ inactive app, SDK-version or
                        // release-binding pause). That gate stamps `permanent`
                        // on EVERY event in the batch, including the stable
                        // `app_install` proposal, so treating it as an
                        // event-level poison verdict would terminally abandon
                        // the install ledger row that the customer recovers by
                        // simply approving the app — installs would under-report
                        // for those devices forever, with no retry.
                        //
                        // Report the rows as LOST instead: the durable
                        // proposals (canonical install, deep-link outbox) are
                        // rebuilt on the next Running transition. This matches
                        // the batch-wide `HttpError(permanent)` branch below and
                        // DurableAppLinkResolveCoordinator's stated contract
                        // ("explicit per-event poison is terminal; batch-wide
                        // pauses are not").
                        runCatching { onDurableQueueCleared() }
                            .onFailure { if (debug) Log.w(TAG, "Queue-clear observer failed", it) }
                    } else {
                        runCatching { onPermanentEventIds(permanentIds) }
                            .onFailure { if (debug) Log.w(TAG, "Permanent-event observer failed", it) }
                    }
                }

                runCatching {
                    if (transientIds.isNotEmpty()) {
                        store.release(transientIds.toList())
                    }
                }.onFailure { if (debug) Log.w(TAG, "release failed", it) }

                // Counter logic — "made progress" means accepted OR
                // permanent (both indicate the backend is reachable
                // and processing).
                val madeProgress = acceptedIds.isNotEmpty() || permanentIds.isNotEmpty()
                val anyTransient = transientIds.isNotEmpty()
                val (failures, hadFailures) = mutex.withLock {
                    val prev = consecutiveFailures
                    if (madeProgress) {
                        consecutiveFailures = 0
                        hasNotifiedCooldown = false
                    } else if (anyTransient) {
                        consecutiveFailures += 1
                    }
                    isFlushing = false
                    Pair(consecutiveFailures, prev > 0)
                }

                if (madeProgress && hadFailures && debug) {
                    Log.i(TAG, "Recovered after failures — back to normal cadence")
                }

                // Handle server-paused signal. The Success carries
                // `paused=true` when the project was killed mid-batch
                // — we honour that by transitioning lifecycle even
                // though the events themselves landed.
                if (response.paused) {
                    setServerPaused(response.pausedReason)
                    retireCollectionNetworkCalls()
                    return
                }

                // Retry path for all-transient outcomes (no progress).
                if (!madeProgress && anyTransient) {
                    scheduleRetry(failures)
                }

                // Made progress AND there's still data to ship?
                // Don't wait for the periodic timer.
                if (madeProgress) {
                    val pending = runCatching { store.pendingCount() }.getOrDefault(0)
                    // Refresh diagnostics cache (Critic 7 fix).
                    lastKnownPendingCount = pending
                    if (pending > 0) scope.launch { tryFlush() }
                }
            }

            is BatchResponse.HttpError -> {
                if (response.permanent) {
                    // 4xx (except 429): permanent. The events are
                    // bad / the host is misconfigured. Drop them so
                    // we don't loop forever, and pivot to
                    // PausedByServer carrying a synthetic reason so
                    // the host's diagnostics surface the cause.
                    //
                    // Do not report these as per-event permanent rejects. A
                    // batch-wide auth/project failure can be fixed by the host
                    // and the stable install proposal must remain recoverable
                    // on the next process. onPermanentEventIds is reserved for
                    // explicit event-level poison verdicts from a 2xx response.
                    runCatching { store.confirm(batch.map { it.eventId }) }
                    mutex.withLock {
                        consecutiveFailures = 0
                        hasNotifiedCooldown = false
                        isFlushing = false
                    }
                    val reason = "http_${response.statusCode}"
                    if (debug) Log.w(TAG, "Permanent batch failure ($reason) — pausing SDK")
                    setServerPaused(reason)
                    retireCollectionNetworkCalls()
                } else {
                    // Transient HTTP — re-release rows + tick counter.
                    runCatching { store.release(batch.map { it.eventId }) }
                    val failures = mutex.withLock {
                        consecutiveFailures += 1
                        isFlushing = false
                        consecutiveFailures
                    }
                    scheduleRetry(failures)
                }
            }

            is BatchResponse.NetworkError -> {
                // Network-level failure — release rows, tick counter,
                // schedule retry with backoff.
                runCatching { store.release(batch.map { it.eventId }) }
                val failures = mutex.withLock {
                    consecutiveFailures += 1
                    isFlushing = false
                    consecutiveFailures
                }
                scheduleRetry(failures)
            }
        }
    }

    /**
     * Schedule a retry at the current tier's delay. If the failure
     * count crosses [RetryScheduler.COOLDOWN_THRESHOLD], also
     * transition to [LifecycleState.Recovering] — the lifecycle
     * controller (Kixo facade) listens for that and pivots to
     * `/api/sdk/init` re-fetch instead of continuing to hammer
     * `/api/sdk/batch`.
     *
     * Once-per-cooldown-episode notification: [hasNotifiedCooldown]
     * gates the transition so a retry-loop sitting at 35 failures
     * doesn't re-emit the lifecycle change every attempt. The flag
     * resets when the failure counter resets.
     */
    private suspend fun scheduleRetry(failures: Int) {
        // Cooldown pivot — fire once per episode. Runs regardless of
        // [enableAutoRetry] because it's a state-machine transition,
        // not a retry. The cooldown unit test relies on this so it
        // can drive 30 manual `flush()` calls and observe the
        // Running → Recovering transition without parking any
        // background coroutines.
        if (failures >= RetryScheduler.COOLDOWN_THRESHOLD) {
            val shouldPivot = mutex.withLock {
                if (hasNotifiedCooldown) false
                else {
                    hasNotifiedCooldown = true
                    true
                }
            }
            if (shouldPivot) {
                // Transition to Recovering. The Kixo facade subscribes
                // to lifecycleState() and will start its config-refetch
                // loop on this signal. We DON'T schedule the retry
                // delay below — recovery is the controller's job from
                // here.
                setLifecycleState(LifecycleState.Recovering)
                return
            }
        }

        // Wave 14 — opt-out for tests. Production keeps it on so
        // a NetworkError chains a backoff retry instead of waiting
        // for the next periodic flush. Tests pass `false` so each
        // `flush()` corresponds to exactly one `postBatch` (no
        // parked retries firing during `advanceTimeBy(...)`).
        if (!enableAutoRetry) return

        val delayMs = RetryScheduler.nextDelayMs(failures)
        if (debug) Log.d(TAG, "Flush failed (#$failures) — retry in ${delayMs}ms (${RetryScheduler.tierName(failures)})")

        // Normal retry: launch a delayed flush attempt. The launch
        // is fire-and-forget on `scope` — if a parallel periodic
        // tick or another scheduled retry beats us to it, the
        // single-flight gate inside [tryFlush] makes ours a no-op.
        scope.launch {
            delay(delayMs)
            // Re-check lifecycle: if we transitioned to PausedByServer
            // / Recovering during the delay, skip.
            if (_lifecycleState.value is LifecycleState.Running) {
                tryFlush()
            }
        }
    }

    /**
     * Periodic flush coroutine. Ticks every [flushIntervalMs] and
     * fires a flush when [LifecycleState.Running]. The single-flight
     * gate inside [tryFlush] handles overlapping with retry-driven
     * flushes safely.
     *
     * Cancelled when the parent `scope` is cancelled (typically only
     * at SDK teardown — production code never tears down the SDK,
     * but tests do).
     */
    private fun startPeriodicFlush() {
        periodicFlushJob?.cancel()
        periodicFlushJob = scope.launch {
            while (isActive) {
                delay(flushIntervalMs)
                if (_lifecycleState.value is LifecycleState.Running) {
                    tryFlush()
                }
            }
        }
    }

    /**
     * Test-only: bring the queue to a clean stop. Cancels the
     * periodic flush and clears in-flight state so a subsequent
     * test instance starts fresh. Production code never calls this.
     */
    internal fun stopForTest() {
        periodicFlushJob?.cancel()
        periodicFlushJob = null
        // We can't safely runBlocking inside a test teardown without
        // risking ANR on emulator-backed tests; just null out the
        // flag from any thread (atomic Boolean would be cleaner;
        // for now this is best-effort).
    }

    /**
     * Production stop hook (Critic 3 BLOCKER).
     *
     * Cancels the periodic flush coroutine started in [init] and
     * pivots lifecycle into [LifecycleState.PausedByServer] with a
     * caller-supplied [reason]. The "PausedByServer" state name is
     * a slight misnomer here — the immediate caller is `Kixo.optOut`
     * / `Kixo.reset`, not the server — but the semantics are what
     * we want: enqueue() drops events silently and the durable
     * buffer drains. (The state-name was set in stone before the
     * client-driven pause path; renaming it is a separate refactor.)
     *
     * Wiring contract: Agent 1 (the public facade) calls this from
     * `Kixo.optOut()` and `Kixo.reset()` with reasons "opted_out"
     * and "reset" respectively. Without this hook, the periodic
     * flush coroutine kept ticking forever after opt-out and would
     * sometimes catch a re-armed Running state during reset, double-
     * shipping events that the user explicitly walked away from.
     *
     * Idempotent: calling twice is harmless (cancel on a null Job is
     * a no-op).
     */
    fun stop(reason: String = "stopped") {
        synchronized(controlPlaneGenerationLock) {
            // Invalidate any response whose network call began before this
            // privacy boundary. The corresponding resume increments again.
            controlPlaneGeneration.incrementAndGet()
            // Mark this as a client-initiated stop so a later [resume]
            // (from optIn / grantConsent) is allowed to re-open the queue.
            clientStopped = true
            resumeRequested = false
            // The buffer is about to be erased by the pause branch, so
            // there is no lawful backlog left for a later pause to
            // protect. A fresh grant re-arms this on the next Running.
            collectionGrantedByPolicy = false
            periodicFlushJob?.cancel()
            periodicFlushJob = null
            // Drain + drop. Runs through setLifecycleState so the
            // PausedByServer branch wipes the durable store and any
            // observers see the transition.
            setLifecycleState(LifecycleState.PausedByServer(reason))
        }
    }

    /**
     * Resume a queue previously halted by [stop] (opt-out / consent
     * revoke), WITHOUT requiring an app relaunch.
     *
     * Wiring contract: the public facade calls this from `Kixo.optIn()`
     * and `Kixo.grantConsent()` so a mid-process consent re-grant wakes
     * the control plane immediately. Before this, opt-in only flipped the
     * `ConsentManager` flag and left the queue's periodic flush cancelled +
     * lifecycle in `PausedByServer` — so nothing shipped until the next
     * process launch wired a fresh queue.
     *
     * Behaviour:
     *  - Invalidates the pre-privacy server snapshot.
     *  - Wakes the control-plane loop immediately.
     *  - Remains closed until a fresh response calls [setServerRunning].
     *
     * **Guard:** only a CLIENT stop is resumable in-process. If the
     * queue is paused by a SERVER kill-switch (`paused=true` response /
     * permanent 4xx) or is still `Initialising`/`Recovering`, this is a
     * no-op — a local consent toggle must not override the server's
     * pause or force a premature `Running` before the control plane resolves.
     * Idempotent: calling on an already-running queue no-ops.
     */
    fun resume() {
        synchronized(controlPlaneGenerationLock) {
            if (!clientStopped) return
            // A response from before either edge of the privacy-silent window
            // cannot authorize this resumed generation.
            controlPlaneGeneration.incrementAndGet()
            clientStopped = false
            resumeRequested = true
            // A project may have been paused or replay-disabled while this install
            // was privacy-silent. Never reopen from the pre-opt-out snapshot.
            serverPolicyResolved = false
            collectionAllowedSignal.trySend(Unit)
        }
    }

    /**
     * Reopen only after every local and server authority has resolved. In
     * particular, `Initialising -> stop -> resume/reset` must stay off-wire
     * until `/init` supplies the first policy, and `stop -> resume` must wait
     * for the stop-triggered SQLite purge before accepting new rows.
     */
    private fun reconcileRequestedResume() {
        if (!resumeRequested || clientStopped) return
        if (!serverPolicyResolved || serverPauseReason != null) return
        if (identityResetInFlight || identityResetFailed ||
            destructiveClearsInFlight.get() > 0
        ) {
            return
        }
        resumeRequested = false
        // Re-arm the periodic flush coroutine (startPeriodicFlush cancels
        // any stale handle first, so this is safe even if one lingered).
        // Gated on [enablePeriodicFlush] exactly like the `init` block so
        // virtual-time tests that opt out of the ticker don't get an
        // ever-rescheduling delay loop after resume().
        if (enablePeriodicFlush) startPeriodicFlush()
        // Back to Running — resets failure counters + kicks a flush so
        // events enqueued after opt-in ship without waiting for relaunch.
        setLifecycleState(LifecycleState.Running)
    }

    private fun launchDestructiveClear(label: String) {
        destructiveClearsInFlight.incrementAndGet()
        scope.launch {
            try {
                runCatching { store.clear() }
                    .onFailure { t -> if (debug) Log.w(TAG, "$label failed", t) }
                lastKnownPendingCount = 0
                runCatching(onDurableQueueCleared)
                    .onFailure { if (debug) Log.w(TAG, "Queue-clear observer failed", it) }
            } finally {
                destructiveClearsInFlight.decrementAndGet()
                reconcileRequestedResume()
                reconcileIdentityResetAfterDestructiveClears()
            }
        }
    }

    /**
     * Restore lifecycle for the current successful identity boundary only
     * after every older/newer destructive clear has left SQLite. State changes
     * are generation-serialised; the customer readiness callback is consumed
     * afterwards, outside the monitor.
     */
    private fun reconcileIdentityResetAfterDestructiveClears() {
        val shouldAttemptReady = synchronized(identityResetReadyLock) {
            val pending = pendingIdentityResetReady
            if (pending == null ||
                pending.boundaryGeneration != identityBoundaryGeneration.get() ||
                identityResetInFlight ||
                identityResetFailed ||
                destructiveClearsInFlight.get() > 0
            ) {
                false
            } else {
                when {
                    serverPauseReason != null ->
                        setLifecycleState(LifecycleState.PausedByServer(serverPauseReason))
                    clientStopped -> Unit
                    !serverPolicyResolved ->
                        setLifecycleState(LifecycleState.Initialising)
                    resumeRequested -> reconcileRequestedResume()
                    else -> setLifecycleState(LifecycleState.Running)
                }
                true
            }
        }
        if (shouldAttemptReady) {
            runPendingIdentityResetReadyIfRunning()
        }
    }

    private fun retainIdentityResetReady(
        boundaryGeneration: Long,
        callback: () -> Unit,
    ) {
        synchronized(identityResetReadyLock) {
            if (identityBoundaryGeneration.get() == boundaryGeneration) {
                pendingIdentityResetReady =
                    PendingIdentityResetReady(boundaryGeneration, callback)
            }
        }
    }

    private fun discardPendingIdentityResetReady(boundaryGeneration: Long) {
        synchronized(identityResetReadyLock) {
            if (pendingIdentityResetReady?.boundaryGeneration == boundaryGeneration) {
                pendingIdentityResetReady = null
            }
        }
    }

    /**
     * Consume the post-clear hook once, and only at the point where all local
     * privacy barriers and the current authoritative server policy agree that
     * the queue is Running. Repeated config responses therefore cannot emit a
     * second session_start.
     */
    private fun runPendingIdentityResetReadyIfRunning() {
        val callback = synchronized(identityResetReadyLock) {
            val ready =
                _lifecycleState.value is LifecycleState.Running &&
                    serverPolicyResolved &&
                    serverPauseReason == null &&
                    !clientStopped &&
                    !identityResetInFlight &&
                    !identityResetFailed &&
                    !resumeRequested &&
                    destructiveClearsInFlight.get() == 0
            if (!ready) {
                null
            } else {
                pendingIdentityResetReady
                    ?.takeIf {
                        it.boundaryGeneration == identityBoundaryGeneration.get()
                    }
                    ?.also { pendingIdentityResetReady = null }
                    ?.callback
            }
        }
        callback?.let {
            runCatching(it)
                .onFailure {
                    if (debug) Log.w(TAG, "Identity reset ready callback failed", it)
                }
        }
    }

    private companion object {
        const val TAG: String = "Kixo.EventQueue"
        const val PRE_POLICY_RECONCILE_RETRY_MIN_MS: Long = 1_000L
        const val PRE_POLICY_RECONCILE_RETRY_MAX_MS: Long = 30_000L

        /**
         * Cap on a single batch claim. Matches iOS's default
         * `loadPendingEvents(limit: 500)` — large enough to drain a
         * heavy backlog in one round trip, small enough to keep the
         * batch payload under the backend's per-request size cap.
         */
        const val MAX_BATCH_SIZE: Int = 500
    }

    private data class PendingIdentityResetReady(
        val boundaryGeneration: Long,
        val callback: () -> Unit,
    )
}

// ─────────────────────────────────────────────────────────────────────
// Internal apply-response model.
//
// [BatchResponse] + [EventError] are the queue's own per-event-ack
// reconciliation types. They were previously parallel-universe
// duplicates of the real [BatchOutcome] from Agent 4's transport;
// the Wave 6 refactor (May 2026) imports the real BatchOutcome,
// converts it to BatchResponse via [toQueueResponse] above, and uses
// these locally for the `applyResponse` partition logic.
//
// Keeping them as a queue-internal model (not an Agent-4 concern) is
// deliberate: the partition step branches on permanent / transient /
// accepted / paused with queue-specific lifecycle side-effects. Tying
// it to the transport's wire-side outcome shape would couple the
// queue's recovery state machine to the transport's encoding choices.
// ─────────────────────────────────────────────────────────────────────

/**
 * Per-event ack response classified for the queue's apply path.
 * Built from [BatchOutcome] inside [EventQueue.toQueueResponse].
 */
internal sealed class BatchResponse {
    /**
     * 2xx response from the batch endpoint. Carries per-event acks
     * + the optional server-paused signal.
     *
     * @property acceptedEventIds   IDs of events the backend stored.
     * @property errors             Per-event failures (with their
     *           `permanent` flag set).
     * @property paused             True when the server has flipped
     *           our SDK to off mid-batch (kill-switch). Triggers a
     *           transition to [LifecycleState.PausedByServer] even
     *           though THIS batch landed.
     * @property pausedReason       Server-supplied code (`"sdk_version_disabled"`,
     *           etc.) when [paused]. Surfaced through diagnostics.
     */
    data class Success(
        val acceptedEventIds: List<String>,
        val errors: List<EventError>,
        val paused: Boolean = false,
        val pausedReason: String? = null,
    ) : BatchResponse()

    /**
     * Non-2xx HTTP response. `permanent=true` means a 4xx (other
     * than 429); the events are bad and we drop them. `permanent=false`
     * means 5xx / 429; the events stay queued for retry.
     */
    data class HttpError(val statusCode: Int, val permanent: Boolean) : BatchResponse()

    /**
     * Network-level failure (no response, DNS error, TLS handshake
     * timeout). Always transient.
     */
    object NetworkError : BatchResponse()
}

/**
 * Single per-event error built into [BatchResponse.Success.errors]
 * during the [BatchOutcome] → [BatchResponse] conversion.
 */
internal data class EventError(
    val eventId: String,
    val message: String,
    /**
     * True when retrying won't help (validation failure, kill-
     * switched event_type, schema rejection). The queue drops
     * these from the durable store. False for rate-limit / timeout
     * / 5xx — those release for retry.
     */
    val permanent: Boolean,
)
