package io.kixo.sdk.internal.attribution

/**
 * Immutable snapshot of a single Play Install Referrer read.
 *
 * **§0 §15 (FROZEN, OVERRIDES the section draft):** the `*ServerSeconds` API
 * variants do **NOT** exist on the public `ReferrerDetails`. We carry ONLY the
 * four fields the public API exposes:
 *   - [referrerUrl]            `getInstallReferrer()` — the raw referrer string
 *                              (a URL query-string fragment, NOT a full URL).
 *   - [clickTsSeconds]         `getReferrerClickTimestampSeconds()`
 *   - [installBeginTsSeconds]  `getInstallBeginTimestampSeconds()`
 *   - [googlePlayInstantParam] `getGooglePlayInstantParam()`
 *
 * Click-injection is gated server-side on the Play-STAMPED
 * `clickTsSeconds` vs `installBeginTsSeconds` ordering + a `received_at` upper
 * bound (tri-state pass/fail/unknown, flag-not-reject) — no server-seconds.
 *
 * `installVersion` (`getInstallVersion()`) is also exposed on the public API
 * and IS carried — it disambiguates the installing app version for the
 * synthesized event row.
 */
internal data class ReferrerSnapshot(
    val referrerUrl: String,
    val clickTsSeconds: Long,
    val installBeginTsSeconds: Long,
    val installVersion: String?,
    val googlePlayInstantParam: Boolean,
) {
    companion object {
        /**
         * JSON-encode the snapshot for the persisted `referrer_snapshot` blob
         * (so a re-POST on next launch needs no re-read — §3.2.1). Hand-rolled
         * to avoid pulling kotlinx-serialization annotations onto this internal
         * type; the four fields are scalar so a flat object is enough.
         */
        fun toJson(s: ReferrerSnapshot): String {
            val sb = StringBuilder(128)
            sb.append('{')
            sb.append("\"referrer_url\":").append(jsonStr(s.referrerUrl)).append(',')
            sb.append("\"click_seconds\":").append(s.clickTsSeconds).append(',')
            sb.append("\"install_begin_seconds\":").append(s.installBeginTsSeconds).append(',')
            sb.append("\"install_version\":").append(jsonStr(s.installVersion)).append(',')
            sb.append("\"google_play_instant\":").append(s.googlePlayInstantParam)
            sb.append('}')
            return sb.toString()
        }

        private fun jsonStr(v: String?): String {
            if (v == null) return "null"
            val sb = StringBuilder(v.length + 2)
            sb.append('"')
            for (c in v) {
                when (c) {
                    '"' -> sb.append("\\\"")
                    '\\' -> sb.append("\\\\")
                    '\n' -> sb.append("\\n")
                    '\r' -> sb.append("\\r")
                    '\t' -> sb.append("\\t")
                    else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c)
                }
            }
            sb.append('"')
            return sb.toString()
        }
    }
}
