package io.kixo.sdk.internal.replay.upload

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import io.kixo.sdk.internal.replay.ReplayResumeState
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.replay.ReplayController
import io.kixo.sdk.internal.replay.ReplaySessionOpenResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import okhttp3.OkHttpClient
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Owns the lifecycle of a single replay session: open → seal.
 * Wraps:
 *   - [SignedUrlClient] for the start/end RPCs
 *   - [SignedUrlPool] for the per-frame URL leases
 *   - [ReplayEventBatcher] for the per-tap metadata stream
 *   - [ReplayUploader] for the orchestration
 *
 * Called by Agent 13's ReplayController. The controller decides
 * WHEN a session opens (sample-rate hit, rage-click trigger,
 * crash trigger); this class executes the open/close mechanics.
 *
 * **Crash defence:** writes session metadata to SharedPreferences
 * the moment a session opens. On the NEXT launch, [recoverFromCrash]
 * checks for any orphaned sessions (process killed before
 * session/end fired) and posts a session/end with reason
 * `app_terminated` so the backend doesn't sit with a "live · 0"
 * row. The backend ALSO has a 30-min idle-sweep cron as a
 * defence-in-depth fallback (see iOS C.4 phantom-session fix
 * lesson) — both layers help.
 *
 * **Why SharedPreferences not SQLite:** session metadata is small
 * (one row, < 200 bytes) and we need it durable past a force-kill.
 * SharedPreferences's commit semantics fit perfectly; spinning up
 * a SQLite db just for one row is overkill and adds a dependency
 * on Agent 3's storage helper.
 */
@SuppressLint("ApplySharedPref") // commit() deliberately closes process-death windows.
internal class ReplaySessionLifecycle(
    private val context: Context,
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val runtimePolicy: ReplayRuntimePolicy,
    private val endWorkScheduler: ReplayEndWorkScheduler = WorkManagerReplayEndWorkScheduler,
) {

    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
    private val pendingEndStore: ReplayPendingEndStore by lazy {
        ReplayPendingEndStore(prefs)
    }

    @Volatile private var current: Active? = null
    /** Serializes open/close/discard so a stale close cannot clear a new stint. */
    private val lifecycleMutex = Mutex()
    private val lifecycleGeneration = AtomicLong(0L)
    private val remotePauseLatched = AtomicBoolean(false)
    /** Closed stints whose durable frame work is still pending. */
    private val retainedUploaders = ConcurrentHashMap.newKeySet<ReplayUploader>()
    /** Prevent identical recovery retries from replacing WorkManager backoff. */
    private val scheduledEnds = ConcurrentHashMap<String, ScheduledEnd>()
    private val persistenceLock = Any()

    /**
     * Active session bundle exposed to [ReplayUploader] via
     * [activeUploader]. Null when no session is open.
     */
    private data class Active(
        val sessionId: String,
        /**
         * The session id the ADAPTER requested (the analytics session
         * id) — [ReplayResumeState] is keyed by it, while [sessionId]
         * is whatever the server echoed back. In practice they match;
         * keying the resume carry off the client-side id keeps the
         * state machine consistent with the adapter/controller seams.
         */
        val clientSessionId: String,
        val installationId: String,
        val policyToken: String,
        val stintId: String,
        val stintEpoch: Long,
        val startedAt: Instant,
        val client: SignedUrlClient,
        val pool: SignedUrlPool,
        val batcher: ReplayEventBatcher,
        val uploader: ReplayUploader,
        val metadataOnly: Boolean,
        val metadataOnlyReason: String?,
        /**
         * F11 — `/session/end` counters carried in from PREVIOUS
         * stints of the same session id (0 on fresh opens). The end
         * report is `carried + staged-this-stint` because the backend
         * absolute-overwrites: reporting stint-local values would
         * clobber the session's totals down to the last stint's.
         */
        val carriedFrameCount: Int,
        val carriedTotalBytes: Long,
        val carriedLastFrameSeq: Long?,
    )

    /** The currently-active uploader, or null when no session is open. */
    fun activeUploader(): ReplayUploader? = current?.uploader

    /** True when the active session is in metadata-only mode (server quota). */
    fun metadataOnly(): Boolean = current?.metadataOnly == true

    /** Optional reason string the backend returned with metadata_only. */
    fun metadataOnlyReason(): String? = current?.metadataOnlyReason

    /**
     * Open a new replay session. Returns true on success (the
     * uploader is now ready for [ReplayUploader.uploadFrame] calls);
     * false on failure (network or server error — caller backs off).
     *
     * **Idempotency:** opening a second session while one is live
     * seals the first with reason `superseded` then opens the new
     * one. Caller should normally not do this — but a misbehaving
     * controller shouldn't strand state.
     */
    suspend fun openSession(
        sessionId: String,
        installationId: String,
        userId: String?,
        releaseId: String,
        triggers: List<String>,
        region: String,
        flags: Map<String, Boolean>? = null,
        /**
         * KIX-UNI-01 resume contract (v2, F6) — seq the backend
         * should pre-sign URLs from. `null` = fresh open (the
         * `next_seq` key is omitted from the wire body); non-null —
         * INCLUDING 0 — = this stint RESUMES a previous stint of the
         * SAME analytics session (see
         * [io.kixo.sdk.internal.replay.ReplayResumeState]) and the
         * watermark is always serialized so the backend reopens the
         * SEALED row.
         */
        nextSeq: Long? = null,
    ): ReplaySessionOpenResult {
        // Capture before waiting for another lifecycle operation. An identity
        // reset that wins the mutex rotates this token, so the old opening can
        // neither reconcile nor persist under the successor generation.
        val policyToken = runtimePolicy.workerToken()
        return lifecycleMutex.withLock {
            val policyCurrent = runtimePolicy.runIfCallAllowed(
                token = policyToken,
                authority = ReplayRuntimePolicy.CallAuthority.DATA,
                block = {},
            )
            if (!policyCurrent) {
                return@withLock ReplaySessionOpenResult.PolicyPaused
            }
            val bundleId = runCatching { context.packageName }
                .getOrNull()
                ?.trim()
                .orEmpty()
            if (bundleId.isBlank()) {
                Log.d(TAG, "openSession: host package name is unavailable")
                return@withLock ReplaySessionOpenResult.Terminal
            }
            if (releaseId.isBlank()) {
                // The replay backend binds every session to the exact approved
                // release established by /init. Never fall back to a package-only
                // or newest-release lookup while control-plane identity is absent.
                Log.d(TAG, "openSession: release id is unavailable")
                return@withLock ReplaySessionOpenResult.Retryable
            }
            // Crash recovery is launched independently during SDK bootstrap.
            // A fast fresh start must not win this mutex first and overwrite
            // the previous process's open-session breadcrumb. Reconcile it
            // synchronously before any new opening/start state is persisted.
            when (recoverFromCrashLocked(policyToken, installationId).status) {
                CrashRecoveryStatus.READY -> Unit
                CrashRecoveryStatus.RETRYABLE ->
                    return@withLock ReplaySessionOpenResult.Retryable
                CrashRecoveryStatus.POLICY_PAUSED ->
                    return@withLock ReplaySessionOpenResult.PolicyPaused
            }
            when (reconcileSupersededOpening(
                sessionId = sessionId,
                installationId = installationId,
                policyToken = policyToken,
            )) {
                OpeningReconcile.Done -> Unit
                OpeningReconcile.Retryable ->
                    return@withLock ReplaySessionOpenResult.Retryable
                OpeningReconcile.PolicyPaused ->
                    return@withLock ReplaySessionOpenResult.PolicyPaused
            }
            // Seal any leftover live session before opening a new one.
            if (current != null) {
                closeSessionLocked(EndReason.SUPERSEDED)
            }
            val openGeneration = lifecycleGeneration.incrementAndGet()
            remotePauseLatched.set(false)
            // Every object in this stint keeps the token captured BEFORE the
            // start RPC. It must never borrow a later identity/privacy generation.
            // A start response may be lost after the server has opened the stint.
            // Persist the client id BEFORE the socket and reuse it for retries of
            // this exact analytics session + installation pair.
            val stintId = getOrCreateOpeningStintId(sessionId, installationId)
                ?: return@withLock ReplaySessionOpenResult.Retryable

            val startedAt = Instant.now()
            val client = SignedUrlClient(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            installationId = installationId,
            runtimePolicy = runtimePolicy,
            policyToken = policyToken,
        )

        val startOutcome = client.startSession(
            sessionId = sessionId,
            installationId = installationId,
            stintId = stintId,
            userId = userId,
            releaseId = releaseId,
            bundleId = bundleId,
            startedAtIso = ISO.format(startedAt),
            triggers = triggers,
            region = region,
            initialUrlCount = 8,
            flags = flags,
            nextSeq = nextSeq,
        )
        val response = when (startOutcome) {
            is SignedUrlClient.StartOutcome.Opened -> startOutcome.response
            SignedUrlClient.StartOutcome.Retryable -> {
                Log.d(TAG, "openSession: retryable server start failure for $sessionId")
                return@withLock ReplaySessionOpenResult.Retryable
            }
            SignedUrlClient.StartOutcome.Terminal -> {
                runtimePolicy.denyUntilFreshRemotePolicy()
                return@withLock ReplaySessionOpenResult.Terminal
            }
        }
        if (response.paused) {
            clearOpeningStintIfMatches(sessionId, installationId, stintId)
            handleRemotePaused(
                expectedGeneration = openGeneration,
                expectedSessionId = null,
                reason = response.pausedReason,
            )
            return@withLock ReplaySessionOpenResult.PolicyPaused
        }
        if (!response.ok || response.sessionId.isBlank() ||
            response.stintEpoch !in 1L..MAX_STINT_EPOCH
        ) {
            clearOpeningStintIfMatches(sessionId, installationId, stintId)
            Log.d(TAG, "openSession: invalid server response for $sessionId")
            runtimePolicy.denyUntilFreshRemotePolicy()
            return@withLock ReplaySessionOpenResult.Terminal
        }

        val carried = if (nextSeq != null) {
            ReplayResumeState.carriedTotalsFor(sessionId)
        } else {
            ReplayResumeState.StintTotals(0, 0L, null)
        }
        val pool = SignedUrlPool(
            client = client,
            sessionId = response.sessionId,
            onRemotePaused = { reason ->
                handleRemotePaused(openGeneration, response.sessionId, reason)
            },
        )
        // Mutex-only local preparation may suspend; final publication below
        // re-checks the immutable token under the policy monitor.
        pool.seed(response.signedUrls)

        var published = false
        val committed = runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.DATA,
        ) {
            // Persist + publish under the same policy monitor as opt-out/reset.
            // A response that completed just before a boundary cannot create a
            // fresh local session after that boundary has returned.
            // Once the server has opened a new epoch, a durable end from the
            // prior stint is stale; remove its local retry record. An already
            // in-flight request is still stopped by the server epoch compare.
            if (!persistSession(
                originalId = sessionId,
                returnedId = response.sessionId,
                installationId = installationId,
                stintId = stintId,
                startedAt = startedAt,
                frameCount = carried.frameCount,
                totalBytes = carried.totalBytes,
                lastFrameSeq = carried.lastFrameSeq,
                stintEpoch = response.stintEpoch,
            )) return@runIfCallAllowed
            pendingEndStore.removeForSession(response.sessionId, installationId)

            val batcher = ReplayEventBatcher(
                context = context,
                httpClient = httpClient,
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                sessionId = response.sessionId,
                installationId = installationId,
                runtimePolicy = runtimePolicy,
                policyToken = policyToken,
                onRemotePaused = { reason ->
                    handleRemotePaused(openGeneration, response.sessionId, reason)
                },
            ).apply { start() }

            lateinit var uploader: ReplayUploader
            uploader = ReplayUploader(
                context = context,
                pool = pool,
                eventBatcher = batcher,
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                sessionId = response.sessionId,
                installationId = installationId,
                runtimePolicy = runtimePolicy,
                policyToken = policyToken,
                metadataOnly = response.metadataOnly,
                onPendingUploadsDrained = { retainedUploaders.remove(uploader) },
                onStagedTotalsChanged = { frameCount, totalBytes, lastFrameSeq ->
                    runtimePolicy.runIfCallAllowed(
                        token = policyToken,
                        authority = ReplayRuntimePolicy.CallAuthority.DATA,
                    ) {
                        persistOpenTotals(
                            expectedSessionId = response.sessionId,
                            frameCount = carried.frameCount + frameCount,
                            totalBytes = carried.totalBytes + totalBytes,
                            lastFrameSeq = listOfNotNull(
                                carried.lastFrameSeq,
                                lastFrameSeq,
                            ).maxOrNull(),
                        )
                    }
                },
            )

            current = Active(
                sessionId = response.sessionId,
                clientSessionId = sessionId,
                installationId = installationId,
                policyToken = policyToken,
                stintId = stintId,
                stintEpoch = response.stintEpoch,
                startedAt = startedAt,
                client = client,
                pool = pool,
                batcher = batcher,
                uploader = uploader,
                metadataOnly = response.metadataOnly,
                metadataOnlyReason = response.metadataOnlyReason,
                carriedFrameCount = carried.frameCount,
                carriedTotalBytes = carried.totalBytes,
                carriedLastFrameSeq = carried.lastFrameSeq,
            )
            published = true
        }
        if (!committed || !published) {
            Log.d(TAG, "openSession: policy changed or breadcrumb was not durable before publish")
            return@withLock ReplaySessionOpenResult.PolicyPaused
        }
        ReplaySessionOpenResult.Opened(sessionId)
        }
    }

    /**
     * A `/session/start` request can reach the backend even when its response
     * is lost. Before a different analytics session overwrites that durable
     * opening breadcrumb, replay the old idempotency key, learn its exact
     * stint epoch, and seal it. Offline keeps the old breadcrumb and blocks
     * the new open; no second potentially orphaned server session is created.
     */
    private suspend fun reconcileSupersededOpening(
        sessionId: String,
        installationId: String,
        policyToken: String,
    ): OpeningReconcile {
        val opening = readOpeningAttempt() ?: return OpeningReconcile.Done
        if (opening.sessionId == sessionId &&
            opening.installationId == installationId
        ) {
            return OpeningReconcile.Done
        }
        if (opening.installationId != installationId) {
            // Identity reset owns the old installation boundary. Its server
            // row, if any, is intentionally left to the idle sweeper rather
            // than sending old-identity cleanup under new credentials.
            clearOpeningStintIfMatches(
                opening.sessionId,
                opening.installationId,
                opening.stintId,
            )
            return OpeningReconcile.Done
        }

        val client = SignedUrlClient(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            installationId = opening.installationId,
            runtimePolicy = runtimePolicy,
            policyToken = policyToken,
        )
        val stintEpoch = when (val outcome = client.reconcileSession(
            sessionId = opening.sessionId,
            stintId = opening.stintId,
        )) {
            SignedUrlClient.ReconcileOutcome.Retryable ->
                return OpeningReconcile.Retryable
            SignedUrlClient.ReconcileOutcome.Terminal -> {
                runtimePolicy.denyUntilFreshRemotePolicy()
                return OpeningReconcile.PolicyPaused
            }
            SignedUrlClient.ReconcileOutcome.Absent,
            SignedUrlClient.ReconcileOutcome.Closed,
            SignedUrlClient.ReconcileOutcome.Superseded -> {
                clearOpeningStintIfMatches(
                    opening.sessionId,
                    opening.installationId,
                    opening.stintId,
                )
                return OpeningReconcile.Done
            }
            is SignedUrlClient.ReconcileOutcome.Open -> outcome.stintEpoch
        }

        val endOutcome = client.endSession(
            sessionId = opening.sessionId,
            stintId = opening.stintId,
            endedAtIso = ISO.format(Instant.now()),
            frameCount = 0,
            totalBytes = 0,
            endReason = EndReason.SUPERSEDED.wire,
            stintEpoch = stintEpoch,
        )
        when (endOutcome) {
            is SignedUrlClient.EndOutcome.Acknowledged -> Unit
            SignedUrlClient.EndOutcome.Retry,
            SignedUrlClient.EndOutcome.Terminal -> {
                // Even a permanent-looking 4xx can race a server transition.
                // Preserve the breadcrumb and re-read authoritative state
                // before a later attempt is allowed to open a fresh session.
                return OpeningReconcile.Retryable
            }
        }
        clearOpeningStintIfMatches(
            opening.sessionId,
            opening.installationId,
            opening.stintId,
        )
        return OpeningReconcile.Done
    }

    /**
     * A replay data-plane 200/paused response is authoritative immediately;
     * do not wait for the thirty-minute config poll. Generation/session checks
     * prevent a late callback from an old stint from stopping its successor.
     */
    private fun handleRemotePaused(
        expectedGeneration: Long,
        expectedSessionId: String?,
        reason: String?,
    ) {
        if (lifecycleGeneration.get() != expectedGeneration) return
        if (expectedSessionId != null && current?.sessionId != expectedSessionId) return
        if (!remotePauseLatched.compareAndSet(false, true)) return
        Log.d(TAG, "Replay remotely paused${reason?.let { ": $it" } ?: ""}")
        runtimePolicy.denyUntilFreshRemotePolicy()
        ReplayController.stopForRemotePolicy()
    }

    /**
     * Seal the currently-open session. Freezes new capture, drains the event
     * batcher, posts session/end, preserves already-staged background uploads,
     * and removes the SharedPreferences entry. No-op if no session is open.
     */
    suspend fun closeSession(reason: EndReason) = lifecycleMutex.withLock {
        closeSessionLocked(reason)
    }

    /**
     * End-user privacy boundary: destroy every content-bearing replay artifact,
     * then durably queue only the aggregate session/end cleanup. Unlike an
     * identity reset, opt-out must seal the server row so it cannot remain live.
     */
    suspend fun closeSessionForOptOut() = lifecycleMutex.withLock {
        val active = current ?: return@withLock
        current = null

        val cumulativeFrameCount = active.carriedFrameCount + active.uploader.stagedFrameCount()
        val cumulativeTotalBytes = active.carriedTotalBytes + active.uploader.totalStagedBytes()
        val cumulativeLastFrameSeq = listOfNotNull(
            active.carriedLastFrameSeq,
            active.uploader.lastStagedFrameSeq(),
        ).maxOrNull()
        val pendingEnd = ReplayPendingEndStore.Record(
            sessionId = active.sessionId,
            installationId = active.installationId,
            stintId = active.stintId,
            stintEpoch = active.stintEpoch,
            endedAtIso = ISO.format(Instant.now()),
            frameCount = cumulativeFrameCount,
            totalBytes = cumulativeTotalBytes,
            lastFrameSeq = cumulativeLastFrameSeq,
            endReason = EndReason.EXPLICIT_OPT_OUT.wire,
            framesDropped = active.uploader.framesDropped(),
            dropReasons = active.uploader.framesDroppedByReason(),
            discardPendingEvents = true,
        )

        try { active.batcher.discard() } catch (t: Throwable) {
            Log.d(TAG, "opt-out batcher discard threw", t)
        }
        try { active.uploader.discardPendingUploads() } catch (t: Throwable) {
            Log.d(TAG, "opt-out uploader discard threw", t)
        }
        retainedUploaders.remove(active.uploader)
        val previouslyClosedUploaders = retainedUploaders.toList()
        retainedUploaders.clear()
        previouslyClosedUploaders.forEach { uploader ->
            try { uploader.discardPendingUploads() } catch (t: Throwable) {
                Log.d(TAG, "opt-out retained uploader discard threw", t)
            }
        }
        try { active.pool.clear() } catch (t: Throwable) {
            Log.d(TAG, "opt-out pool clear threw", t)
        }

        val cleanupToken = runtimePolicy.workerToken()
        // This local write intentionally does not require a resolved policy:
        // optIn can race the async close and move policy to "awaiting fresh".
        // The worker itself remains generation-gated and waits for resolution.
        if (pendingEndStore.upsert(pendingEnd)) {
            schedulePendingEnd(pendingEnd, cleanupToken)
            clearPersistedOpenSession(active.sessionId)
        }
    }

    private suspend fun closeSessionLocked(reason: EndReason) {
        val active = current ?: return
        current = null

        // 1. Freeze capture before snapshotting the server retry bound. Work
        //    already staged stays durable; anything that lost this race sees
        //    capture-closed and cannot create an unreported seq afterwards.
        retainedUploaders += active.uploader
        active.uploader.closeCaptureKeepingPendingUploads()

        // 2. Drain durable event metadata first. When offline, leave the end
        // record to WorkManager: sealing synchronously before the event worker
        // would create an avoidable ordering race after process death.
        val eventsDrained = try {
            active.batcher.stop()
        } catch (t: Throwable) {
            Log.d(TAG, "batcher.stop threw", t)
            false
        }

        // 3. Tell the backend the session is sealed. Best-effort —
        //    the 30-min idle-sweep cron will catch us if the call
        //    fails AND the next launch's crash recovery doesn't
        //    pick it up.
        //
        // F11 — report CUMULATIVE totals for the session id (carried
        // from previous stints + staged this stint): the end route
        // absolute-overwrites, so a resumed session reporting only
        // its last stint would permanently undercount. The carry is
        // saved BEFORE the RPC so a network throw can't lose it.
        val cumulativeFrameCount = active.carriedFrameCount + active.uploader.stagedFrameCount()
        val cumulativeTotalBytes = active.carriedTotalBytes + active.uploader.totalStagedBytes()
        val cumulativeLastFrameSeq = listOfNotNull(
            active.carriedLastFrameSeq,
            active.uploader.lastStagedFrameSeq(),
        ).maxOrNull()
        ReplayResumeState.onStintTotals(
            sessionId = active.clientSessionId,
            frameCount = cumulativeFrameCount,
            totalBytes = cumulativeTotalBytes,
            lastFrameSeq = cumulativeLastFrameSeq,
        )
        val endedAt = Instant.now()
        val pendingEnd = ReplayPendingEndStore.Record(
            sessionId = active.sessionId,
            installationId = active.installationId,
            stintId = active.stintId,
            stintEpoch = active.stintEpoch,
            endedAtIso = ISO.format(endedAt),
            frameCount = cumulativeFrameCount,
            totalBytes = cumulativeTotalBytes,
            lastFrameSeq = cumulativeLastFrameSeq,
            endReason = reason.wire,
            framesDropped = active.uploader.framesDropped(),
            dropReasons = active.uploader.framesDroppedByReason(),
        )
        var durablyQueued = false
        val cleanupAllowed = runtimePolicy.runIfCallAllowed(
            token = active.policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.CLEANUP,
        ) {
            durablyQueued = pendingEndStore.upsert(pendingEnd)
            if (durablyQueued) {
                schedulePendingEnd(pendingEnd, active.policyToken)
                clearPersistedOpenSession(active.sessionId)
            }
        }
        if (cleanupAllowed && eventsDrained) {
            val outcome = sendPendingEnd(active.client, pendingEnd)
            if (outcome != SignedUrlClient.EndOutcome.Retry) {
                pendingEndStore.removeIfUnchanged(pendingEnd)
                clearPersistedOpenSession(active.sessionId)
            }
        }

        // 4. The sealed-retry sign contract permits only exact,
        //    already-staged frames bounded by last_frame_seq + retention.
        if (!active.uploader.hasPendingUploads()) {
            retainedUploaders.remove(active.uploader)
        }

        // 5. Drop signed URLs we never used.
        try { active.pool.clear() } catch (t: Throwable) { Log.d(TAG, "pool.clear threw", t) }

        // 6. The open breadcrumb was moved atomically to the pending-end store
        //    above. On transient failure that durable record survives launch.
    }

    /**
     * Hard identity/policy close. No final event flush and no session/end RPC:
     * cancel everything that can wake later, delete staged bytes, and remove
     * the crash-recovery breadcrumb. Serialized with [openSession], so an
     * in-flight session/start cannot publish a fresh [current] after discard.
     */
    suspend fun discardSession() = lifecycleMutex.withLock {
        val active = current
        current = null
        if (active != null) {
            try { active.batcher.discard() } catch (t: Throwable) {
                Log.d(TAG, "batcher.discard threw", t)
            }
            try { active.uploader.discardPendingUploads() } catch (t: Throwable) {
                Log.d(TAG, "uploader discard threw", t)
            }
            try { active.pool.clear() } catch (t: Throwable) {
                Log.d(TAG, "pool.clear threw", t)
            }
        }
        val closedUploaders = retainedUploaders.toList()
        retainedUploaders.clear()
        closedUploaders.forEach { uploader ->
            try { uploader.discardPendingUploads() } catch (t: Throwable) {
                Log.d(TAG, "retained uploader discard threw", t)
            }
        }
        clearAllPersistedState()
        Unit
    }

    /**
     * On launch, check for a session that was open when the process
     * died and ship a session/end so the dashboard doesn't see a
     * "live · 0" row sitting forever. Mirrors the iOS C.4 phantom-
     * session fix.
     *
     * Returns the `session_id` we recovered (for diagnostics) or
     * null if there was nothing to recover.
     */
    suspend fun recoverFromCrash(expectedInstallationId: String? = null): String? {
        val policyToken = runtimePolicy.workerToken()
        return lifecycleMutex.withLock {
            recoverFromCrashLocked(policyToken, expectedInstallationId).recoveredSessionId
        }
    }

    private suspend fun recoverFromCrashLocked(
        policyToken: String,
        expectedInstallationId: String?,
    ): CrashRecoveryResult {
        val migration = migrateCrashBreadcrumb(policyToken, expectedInstallationId)
        if (migration.status != CrashRecoveryStatus.READY) return migration

        val currentSessionId = current?.sessionId
        val pending = buildList {
            pendingEndStore.snapshot().forEach { record ->
                if (expectedInstallationId != null &&
                    record.installationId != expectedInstallationId
                ) {
                    // Identity reset owns this boundary. Never grant a retired
                    // installation's cleanup record the successor generation.
                    pendingEndStore.removeIfUnchanged(record)
                } else if (record.sessionId != currentSessionId) {
                    add(record)
                }
            }
        }
        pending.forEach { record ->
            schedulePendingEnd(record, policyToken)
            val client = SignedUrlClient(
                httpClient = httpClient,
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                installationId = record.installationId,
                runtimePolicy = runtimePolicy,
                policyToken = policyToken,
            )
            val outcome = sendPendingEnd(client, record)
            if (outcome != SignedUrlClient.EndOutcome.Retry) {
                pendingEndStore.removeIfUnchanged(record)
            }
        }
        return migration.copy(
            recoveredSessionId = migration.recoveredSessionId
                ?: pending.firstOrNull()?.sessionId,
        )
    }

    /**
     * Move the process-death breadcrumb to the durable pending-end store under
     * the caller's policy generation. Once that write commits, network
     * acknowledgement is no longer a prerequisite for opening a new session.
     */
    private fun migrateCrashBreadcrumb(
        policyToken: String,
        expectedInstallationId: String?,
    ): CrashRecoveryResult {
        if (current != null) return CrashRecoveryResult(CrashRecoveryStatus.READY)
        val crashedSessionId = prefs.getString(KEY_OPEN_SESSION_ID, null)
            ?: return CrashRecoveryResult(CrashRecoveryStatus.READY)
        val installationId = prefs.getString(KEY_INSTALLATION_ID, null)
        val stintId = prefs.getString(KEY_STINT_ID, null)

        var result = CrashRecoveryResult(
            CrashRecoveryStatus.RETRYABLE,
            crashedSessionId,
        )
        val admitted = runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.CLEANUP,
        ) {
            // A reset publishes its new generation before the synchronous
            // purge reaches these preferences. Re-read under the policy lock
            // so a successor generation can never adopt the old breadcrumb.
            if (prefs.getString(KEY_OPEN_SESSION_ID, null) != crashedSessionId) {
                result = CrashRecoveryResult(CrashRecoveryStatus.READY)
                return@runIfCallAllowed
            }
            if (installationId.isNullOrBlank() || stintId.isNullOrBlank() ||
                (expectedInstallationId != null && installationId != expectedInstallationId)
            ) {
                result = CrashRecoveryResult(
                    status = if (clearPersistedOpenSession(crashedSessionId)) {
                        CrashRecoveryStatus.READY
                    } else {
                        CrashRecoveryStatus.RETRYABLE
                    },
                    recoveredSessionId = crashedSessionId,
                )
                return@runIfCallAllowed
            }

            Log.d(TAG, "Recovering crashed session $crashedSessionId")
            val disk = ReplayPendingUploadStore.pendingStats(
                context = context,
                sessionId = crashedSessionId,
                installationId = installationId,
            )
            val persistedLastSeq = if (prefs.contains(KEY_LAST_FRAME_SEQ)) {
                prefs.getLong(KEY_LAST_FRAME_SEQ, -1L).takeIf { it >= 0L }
            } else {
                null
            }
            val record = ReplayPendingEndStore.Record(
                sessionId = crashedSessionId,
                installationId = installationId,
                stintId = stintId,
                stintEpoch = prefs.getLong(KEY_STINT_EPOCH, 1L).coerceAtLeast(1L),
                endedAtIso = ISO.format(Instant.now()),
                frameCount = maxOf(prefs.getInt(KEY_FRAME_COUNT, 0), disk.frameCount),
                totalBytes = maxOf(prefs.getLong(KEY_TOTAL_BYTES, 0L), disk.totalBytes),
                lastFrameSeq = listOfNotNull(
                    persistedLastSeq,
                    disk.lastFrameSeq,
                ).maxOrNull(),
                endReason = EndReason.APP_TERMINATED.wire,
            )
            if (!pendingEndStore.upsert(record)) {
                result = CrashRecoveryResult(
                    CrashRecoveryStatus.RETRYABLE,
                    crashedSessionId,
                )
                return@runIfCallAllowed
            }

            // pendingEndStore is now the source of truth. A failed clear is
            // harmless: a later fresh persist may overwrite the breadcrumb,
            // while the old close remains durable and independently retryable.
            clearPersistedOpenSession(crashedSessionId)
            result = CrashRecoveryResult(
                CrashRecoveryStatus.READY,
                crashedSessionId,
            )
        }
        return if (admitted) {
            result
        } else {
            CrashRecoveryResult(
                CrashRecoveryStatus.POLICY_PAUSED,
                crashedSessionId,
            )
        }
    }

    private fun schedulePendingEnd(
        record: ReplayPendingEndStore.Record,
        policyToken: String,
    ): Boolean {
        val scheduled = ScheduledEnd(policyToken, record)
        if (scheduledEnds[record.key] == scheduled) return true
        val enqueued = endWorkScheduler.enqueue(
            context = context,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            policyToken = policyToken,
            record = record,
        )
        if (enqueued) scheduledEnds[record.key] = scheduled
        return enqueued
    }

    /**
     * Wire crash recovery to production without phoning home before privacy
     * and a fresh project response permit it. Session/end is cleanup-exempt,
     * so replay itself may remain disabled; only resolved+privacyAllowed are
     * required.
     */
    suspend fun recoverFromCrashAfterFreshPolicy(
        installationIdProvider: () -> String,
    ) {
        // StateFlow suspension is allocation-free while privacy remains
        // closed; the old 250 ms loop woke forever on an opted-out install.
        repeat(MAX_END_RECOVERY_ATTEMPTS) { attempt ->
            if (!currentCoroutineContext().isActive) return
            runtimePolicy.awaitFreshPrivacyPolicy()
            val policyToken = runtimePolicy.workerToken()
            val recovery = lifecycleMutex.withLock {
                recoverFromCrashLocked(
                    policyToken = policyToken,
                    expectedInstallationId = installationIdProvider(),
                )
            }
            val activeId = current?.sessionId
            val hasRetryable = pendingEndStore.snapshot().any { it.sessionId != activeId }
            if (recovery.status == CrashRecoveryStatus.READY && !hasRetryable) return
            delay(END_RECOVERY_BASE_DELAY_MS shl attempt)
        }
    }

    private suspend fun sendPendingEnd(
        client: SignedUrlClient,
        record: ReplayPendingEndStore.Record,
    ): SignedUrlClient.EndOutcome = try {
        client.endSession(
            sessionId = record.sessionId,
            stintId = record.stintId,
            endedAtIso = record.endedAtIso,
            frameCount = record.frameCount,
            totalBytes = record.totalBytes,
            endReason = record.endReason,
            lastFrameSeq = record.lastFrameSeq,
            stintEpoch = record.stintEpoch,
            framesDropped = record.framesDropped,
            dropReasons = record.dropReasons,
        )
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (t: Throwable) {
        Log.d(TAG, "endSession threw", t)
        SignedUrlClient.EndOutcome.Retry
    }

    private fun persistSession(
        originalId: String,
        returnedId: String,
        installationId: String,
        stintId: String,
        startedAt: Instant,
        frameCount: Int,
        totalBytes: Long,
        lastFrameSeq: Long?,
        stintEpoch: Long,
    ): Boolean = synchronized(persistenceLock) {
        val committed = runCatching {
            prefs.edit()
                .putString(KEY_OPEN_SESSION_ID, returnedId)
                .putString(KEY_ORIGINAL_SESSION_ID, originalId)
                .putString(KEY_INSTALLATION_ID, installationId)
                .putString(KEY_STINT_ID, stintId)
                .putString(KEY_STARTED_AT, ISO.format(startedAt))
                .putInt(KEY_FRAME_COUNT, frameCount)
                .putLong(KEY_TOTAL_BYTES, totalBytes)
                .putLong(KEY_STINT_EPOCH, stintEpoch)
                .apply {
                    if (lastFrameSeq == null) remove(KEY_LAST_FRAME_SEQ)
                    else putLong(KEY_LAST_FRAME_SEQ, lastFrameSeq)
                }
                .commit()
        }.onFailure { Log.d(TAG, "persistSession threw", it) }
            .getOrDefault(false)
        // Keep the opening id until the open breadcrumb itself is durable. If
        // commit() reports a disk failure, an in-process retry must still use
        // the id the server may already have accepted.
        if (committed) clearOpeningStintIfMatches(originalId, installationId, stintId)
        committed
    }

    private fun getOrCreateOpeningStintId(
        sessionId: String,
        installationId: String,
    ): String? = synchronized(persistenceLock) {
        val existing = prefs.getString(KEY_OPENING_STINT_ID, null)
        val sameAttempt = !existing.isNullOrBlank() &&
            prefs.getString(KEY_OPENING_SESSION_ID, null) == sessionId &&
            prefs.getString(KEY_OPENING_INSTALLATION_ID, null) == installationId
        if (sameAttempt) {
            // commit() can update the in-memory map yet report that its disk
            // write failed. Recommit before trusting a restored/in-memory id;
            // no start request is allowed until one synchronous write succeeds.
            val durable = runCatching {
                prefs.edit()
                    .putString(KEY_OPENING_STINT_ID, existing)
                    .putString(KEY_OPENING_SESSION_ID, sessionId)
                    .putString(KEY_OPENING_INSTALLATION_ID, installationId)
                    .commit()
            }.onFailure { Log.d(TAG, "re-persist opening stint id threw", it) }
                .getOrDefault(false)
            return@synchronized existing.takeIf { durable }
        }

        val fresh = UUID.randomUUID().toString()
        val committed = runCatching {
            prefs.edit()
                .putString(KEY_OPENING_STINT_ID, fresh)
                .putString(KEY_OPENING_SESSION_ID, sessionId)
                .putString(KEY_OPENING_INSTALLATION_ID, installationId)
                .commit()
        }.onFailure { Log.d(TAG, "persist opening stint id threw", it) }
            .getOrDefault(false)
        fresh.takeIf { committed }
    }

    private fun readOpeningAttempt(): OpeningAttempt? = synchronized(persistenceLock) {
        val stintId = prefs.getString(KEY_OPENING_STINT_ID, null)
            ?.takeIf { it.isNotBlank() }
            ?: return@synchronized null
        val sessionId = prefs.getString(KEY_OPENING_SESSION_ID, null)
            ?.takeIf { it.isNotBlank() }
            ?: return@synchronized null
        val installationId = prefs.getString(KEY_OPENING_INSTALLATION_ID, null)
            ?.takeIf { it.isNotBlank() }
            ?: return@synchronized null
        OpeningAttempt(sessionId, installationId, stintId)
    }

    private fun clearOpeningStintIfMatches(
        sessionId: String,
        installationId: String,
        stintId: String,
    ) = synchronized(persistenceLock) {
        val matches = prefs.getString(KEY_OPENING_STINT_ID, null) == stintId &&
            prefs.getString(KEY_OPENING_SESSION_ID, null) == sessionId &&
            prefs.getString(KEY_OPENING_INSTALLATION_ID, null) == installationId
        if (matches) {
            runCatching {
                prefs.edit()
                    .remove(KEY_OPENING_STINT_ID)
                    .remove(KEY_OPENING_SESSION_ID)
                    .remove(KEY_OPENING_INSTALLATION_ID)
                    .commit()
            }.onFailure { Log.d(TAG, "clear opening stint id threw", it) }
        }
        Unit
    }

    private fun persistOpenTotals(
        expectedSessionId: String,
        frameCount: Int,
        totalBytes: Long,
        lastFrameSeq: Long?,
    ) = synchronized(persistenceLock) {
        if (prefs.getString(KEY_OPEN_SESSION_ID, null) != expectedSessionId) return@synchronized
        runCatching {
            prefs.edit()
                .putInt(KEY_FRAME_COUNT, frameCount)
                .putLong(KEY_TOTAL_BYTES, totalBytes)
                .apply {
                    if (lastFrameSeq == null) remove(KEY_LAST_FRAME_SEQ)
                    else putLong(KEY_LAST_FRAME_SEQ, lastFrameSeq)
                }
                .commit()
        }
    }

    private fun clearPersistedOpenSession(
        expectedSessionId: String? = null,
    ): Boolean = synchronized(persistenceLock) {
            if (expectedSessionId != null &&
                prefs.getString(KEY_OPEN_SESSION_ID, null) != expectedSessionId
            ) {
                return@synchronized true
            }
            runCatching {
                prefs.edit()
                .remove(KEY_OPEN_SESSION_ID)
                .remove(KEY_ORIGINAL_SESSION_ID)
                .remove(KEY_INSTALLATION_ID)
                .remove(KEY_STINT_ID)
                .remove(KEY_STARTED_AT)
                .remove(KEY_FRAME_COUNT)
                .remove(KEY_TOTAL_BYTES)
                .remove(KEY_LAST_FRAME_SEQ)
                .remove(KEY_STINT_EPOCH)
                .remove(KEY_OPENING_STINT_ID)
                .remove(KEY_OPENING_SESSION_ID)
                .remove(KEY_OPENING_INSTALLATION_ID)
                .commit()
            }.onFailure { Log.d(TAG, "clearPersistedOpenSession threw", it) }
                .getOrDefault(false)
        }

    private fun clearAllPersistedState() {
        synchronized(persistenceLock) {
            runCatching { prefs.edit().clear().commit() }
                .onFailure { Log.d(TAG, "clearAllPersistedState threw", it) }
        }
    }

    /**
     * Reasons we send to `/api/sdk/replay/session/end` — mirror
     * the iOS catalog. Backend dashboards group sessions by reason
     * for ops insight.
     */
    enum class EndReason(val wire: String) {
        FOREGROUND_TO_BACKGROUND("foreground_to_background"),
        APP_TERMINATED("app_terminated"),
        EXPLICIT_OPT_OUT("explicit_opt_out"),
        TIMEOUT("timeout"),
        LOW_MEMORY("low_memory"),
        SUPERSEDED("superseded"),
    }

    private data class OpeningAttempt(
        val sessionId: String,
        val installationId: String,
        val stintId: String,
    )

    private enum class OpeningReconcile {
        Done,
        Retryable,
        PolicyPaused,
    }

    private enum class CrashRecoveryStatus {
        READY,
        RETRYABLE,
        POLICY_PAUSED,
    }

    private data class CrashRecoveryResult(
        val status: CrashRecoveryStatus,
        val recoveredSessionId: String? = null,
    )

    private data class ScheduledEnd(
        val policyToken: String,
        val record: ReplayPendingEndStore.Record,
    )

    companion object {
        private const val PREFS_NAME = ReplayPendingEndStore.PREFS_NAME
        private const val KEY_OPEN_SESSION_ID = "open_session_id"
        private const val KEY_ORIGINAL_SESSION_ID = "original_session_id"
        private const val KEY_INSTALLATION_ID = "installation_id"
        private const val KEY_STINT_ID = "stint_id"
        private const val KEY_STARTED_AT = "started_at"
        private const val KEY_FRAME_COUNT = "frame_count"
        private const val KEY_TOTAL_BYTES = "total_bytes"
        private const val KEY_LAST_FRAME_SEQ = "last_frame_seq"
        private const val KEY_STINT_EPOCH = "stint_epoch"
        private const val KEY_OPENING_STINT_ID = "opening_stint_id"
        private const val KEY_OPENING_SESSION_ID = "opening_session_id"
        private const val KEY_OPENING_INSTALLATION_ID = "opening_installation_id"

        private const val MAX_END_RECOVERY_ATTEMPTS = 5
        private const val END_RECOVERY_BASE_DELAY_MS = 1_000L
        private const val MAX_STINT_EPOCH = 2_147_483_647L

        private val ISO: DateTimeFormatter = DateTimeFormatter.ISO_INSTANT

        private const val TAG = "Kixo.ReplaySessionLifecycle"

        /**
         * A privacy rotation removes identity-bearing open/start breadcrumbs but
         * preserves non-content pending session/end records.
         */
        internal fun purgePrivacySensitiveBreadcrumbs(context: Context) {
            runCatching {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .remove(KEY_OPEN_SESSION_ID)
                    .remove(KEY_ORIGINAL_SESSION_ID)
                    .remove(KEY_INSTALLATION_ID)
                    .remove(KEY_STINT_ID)
                    .remove(KEY_STARTED_AT)
                    .remove(KEY_FRAME_COUNT)
                    .remove(KEY_TOTAL_BYTES)
                    .remove(KEY_LAST_FRAME_SEQ)
                    .remove(KEY_STINT_EPOCH)
                    .remove(KEY_OPENING_STINT_ID)
                    .remove(KEY_OPENING_SESSION_ID)
                    .remove(KEY_OPENING_INSTALLATION_ID)
                    .commit()
            }.onFailure { Log.d(TAG, "privacy breadcrumb purge threw", it) }
        }
    }
}
