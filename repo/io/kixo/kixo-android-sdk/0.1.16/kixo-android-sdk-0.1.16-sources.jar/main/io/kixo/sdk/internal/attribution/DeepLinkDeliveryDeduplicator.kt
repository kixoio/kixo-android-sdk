package io.kixo.sdk.internal.attribution

/** Bounded same-URI delivery dedup shared by cold and warm direct-open paths. */
internal class DeepLinkDeliveryDeduplicator(
    private val windowMs: Long,
    private val capacity: Int = 64,
) {
    private data class Delivery(val uri: String, val atMs: Long)

    private val lock = Any()
    private val recent = ArrayDeque<Delivery>()

    init {
        require(windowMs > 0)
        require(capacity > 0)
    }

    fun accept(uri: String, nowMs: Long): Boolean = synchronized(lock) {
        while (recent.isNotEmpty() && nowMs - recent.first().atMs >= windowMs) {
            recent.removeFirst()
        }
        if (recent.any { delivery ->
                delivery.uri == uri && nowMs - delivery.atMs in 0 until windowMs
            }
        ) {
            return@synchronized false
        }
        while (recent.size >= capacity) recent.removeFirst()
        recent.addLast(Delivery(uri, nowMs))
        true
    }

    fun clear() = synchronized(lock) {
        recent.clear()
    }
}
