package io.kixo.sdk.internal.transport

import io.kixo.sdk.internal.model.BatchPayload
import io.kixo.sdk.internal.model.BatchResponse
import io.kixo.sdk.internal.model.ConfigRequest
import io.kixo.sdk.internal.model.ConfigResponse
import io.kixo.sdk.internal.model.InitRequest
import io.kixo.sdk.internal.model.InitResponse
import io.kixo.sdk.internal.privacy.PreConfigurePrivacyGate
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okhttp3.HttpUrl.Companion.toHttpUrl
import java.io.IOException
import kotlin.coroutines.resume

/**
 * Outcome of a single batch POST. Maps to the partition contract
 * [io.kixo.sdk.internal.queue] (Agent 5) consumes:
 *
 *  - [Success]      — server acknowledged the batch; the three id
 *                     buckets drive DELETE / DELETE / RE-ENQUEUE in the
 *                     SQLite store.
 *  - [NetworkError] — IOException at the socket layer; treat all
 *                     events as transient and bump the retry counter.
 *  - [SerializationError] — request couldn't be encoded OR response
 *                     couldn't be decoded. Permanent — retrying won't
 *                     help, the wire shape is mismatched. Drop the
 *                     batch (loud `Log.w`) so we don't pin the queue.
 *  - [HttpError]    — HTTP code outside 2xx. `transient=true` for
 *                     429/5xx, `false` for 4xx (other than 429).
 *
 * `paused` on [Success] mirrors the server's kill-switch: when set,
 * the lifecycle controller transitions to `pausedByServer` and stops
 * draining. We surface it on Success (not as a separate error) because
 * the server still gave us a valid response — it just also told us to
 * be quiet for a while.
 */
internal sealed class BatchOutcome {
    data class Success(
        val acceptedIds: List<String>,
        val transientIds: List<String>,
        val permanentIds: List<String>,
        val paused: Boolean,
        val pausedReason: String?,
    ) : BatchOutcome()

    data class NetworkError(val cause: Throwable) : BatchOutcome()

    data object SerializationError : BatchOutcome()

    /**
     * @param transient true for 429 + 5xx (retry); false for any other
     *        4xx (drop — client is misconfigured, retrying makes it
     *        worse). 401 specifically is permanent + the lifecycle
     *        controller treats it as `pausedByServer`.
     */
    data class HttpError(
        val code: Int,
        val transient: Boolean,
    ) : BatchOutcome()
}

/**
 * HTTP transport for the Kixo Android SDK. Mirrors the iOS
 * `Transport.swift` rationale (per-event acks, defensive default,
 * 4xx-permanent-vs-5xx-transient classification) but exposes a
 * `suspend` API so [io.kixo.sdk.internal.queue] (Agent 5) and the
 * lifecycle controller can `await` the result inside a coroutine
 * instead of nesting callbacks.
 *
 * **Thread model:** all I/O happens on `Dispatchers.IO` via OkHttp's
 * blocking call — wrapped in [suspendCancellableCoroutine] so the
 * coroutine's cancellation cancels the OkHttp [Call]. Keeping the
 * callsite suspend-only avoids the Swift completion-handler nesting
 * pattern; the queue just `withContext(Dispatchers.IO) { … }`.
 *
 * **Why not Retrofit?** AGENT_BRIEFING §5: "Retrofit (OkHttp + manual
 * JSON is enough)". One JSON encode/decode + one HTTP call doesn't
 * justify another dependency.
 *
 * **Auth.** `Authorization: Bearer <api_key>` header AND `api_key` in
 * body — backend supports both, and shipping both means a future
 * server-side switch to header-only auth is a no-op for the SDK.
 */
/**
 * Behavioral contract callers (the queue, the push subsystem,
 * QueueWiring's init bootstrap) consume from [Transport]. Extracted
 * in Wave 13 to enable in-memory test substitution: real
 * [Transport] runs the OkHttp + JSON + ack-classifier pipeline,
 * the test substitutes a `FakeTransport` that returns canned
 * [BatchOutcome] / [InitResponse] / Boolean values without ever
 * hopping to `Dispatchers.IO`. The previous `EventQueueTest` ran
 * a real `MockWebServer` against the real `Transport`, which
 * deadlocked the `runTest` virtual-time scheduler because each
 * `withContext(Dispatchers.IO)` jump bypassed the test
 * dispatcher (see Wave 12 cooldown-test `@Disabled` rationale).
 *
 * Production wiring (`QueueWiring.build` + `Kixo.configure`)
 * keeps constructing the concrete [Transport] — only the queue +
 * push consumers' parameter types changed from `Transport` to
 * [TransportContract]. The runtime type is identical.
 *
 * Why an interface and not just `open` on [Transport]: an
 * `open class` inheritance subclass would need to skip the
 * `withContext(Dispatchers.IO)` calls AND duplicate the
 * (suspend signatures + AckClassifier wiring + URL construction).
 * An interface is the cleanest seam — implementers commit to the
 * suspend signatures and nothing else.
 */
internal interface TransportContract {
    suspend fun postBatch(payload: BatchPayload): BatchOutcome
    suspend fun postBatch(payload: BatchPayload, collectionEpoch: Long): BatchOutcome =
        postBatch(payload)
    suspend fun postInit(req: InitRequest): InitResponse?
    /** Optional because queue-only test doubles never use the control plane. */
    suspend fun getConfig(req: ConfigRequest): ConfigResponse? = null
    suspend fun postPushRegister(req: io.kixo.sdk.internal.model.PushRegisterRequest): Boolean
    suspend fun postPushRegister(
        req: io.kixo.sdk.internal.model.PushRegisterRequest,
        collectionEpoch: Long,
    ): Boolean = postPushRegister(req)
}

internal class Transport(
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val json: Json,
    private val privacyGate: PreConfigurePrivacyGate? = null,
) : TransportContract {

    /**
     * POST a batch to `/api/sdk/batch` and surface the partition.
     *
     * The full pipeline:
     *  1. Encode the payload (`SerializationError` on failure — drop).
     *  2. POST with API key in header + body.
     *  3. Map status code → [BatchOutcome] tier (4xx-no-429 perm,
     *     429+5xx transient, 2xx parse).
     *  4. On 2xx, decode the response (malformed/incomplete ack is
     *     transient — never delete rows without explicit acknowledgement).
     *  5. Run [AckClassifier] — missing event_ids retry as transient.
     *
     * Returns a [BatchOutcome] never throws. The host app must never
     * crash because analytics couldn't send (briefing R6).
     */
    override suspend fun postBatch(payload: BatchPayload): BatchOutcome =
        postBatchInternal(payload, collectionEpoch = null)

    override suspend fun postBatch(
        payload: BatchPayload,
        collectionEpoch: Long,
    ): BatchOutcome = postBatchInternal(payload, collectionEpoch)

    private suspend fun postBatchInternal(
        payload: BatchPayload,
        collectionEpoch: Long?,
    ): BatchOutcome = withContext(Dispatchers.IO) {
        // ─── (1) Encode the request body ───────────────────────
        val body: String = try {
            json.encodeToString(BatchPayload.serializer(), payload)
        } catch (e: SerializationException) {
            // Payload is structurally bad — won't get smaller on
            // retry, the bug is in the event shape upstream.
            return@withContext BatchOutcome.SerializationError
        } catch (e: Throwable) {
            // Defensive: unknown encode failure (e.g. OOM during JSON
            // build for a giant batch). Treat as serialization too —
            // re-trying the same payload would just OOM again.
            return@withContext BatchOutcome.SerializationError
        }

        val request = Request.Builder()
            .url(Endpoints.url(baseUrl, Endpoints.BATCH))
            .post(body.toRequestBody(JSON_MEDIA_TYPE))
            // Header auth in addition to body auth — see class kdoc.
            .header("Authorization", "Bearer ${payload.apiKey}")
            .header("Content-Type", "application/json; charset=utf-8")
            .build()

        // ─── (2 + 3) Execute and classify status code ──────────
        val response: Response = try {
            executeAsync(httpClient.newCall(request), collectionEpoch)
        } catch (e: IOException) {
            // Socket / DNS / TLS failure. EventQueue treats this as
            // transient (the whole batch goes back to the front).
            return@withContext BatchOutcome.NetworkError(e)
        }

        response.use { resp ->
            val code = resp.code
            // 4xx (except 429) = permanent. The server is telling us
            // the request itself is wrong (bad project_id, schema
            // violation, etc.) and retrying with the same bytes can
            // only fail again. EventQueue drops the batch.
            if (code in 400..499 && code != 429) {
                return@withContext BatchOutcome.HttpError(code = code, transient = false)
            }
            // 429 (rate-limited) + 5xx = transient. Retry tier handles
            // the backoff schedule.
            if (code == 429 || code in 500..599) {
                return@withContext BatchOutcome.HttpError(code = code, transient = true)
            }
            // Anything weirdly outside the documented ranges (3xx
            // redirect we didn't follow, 1xx informational) — treat as
            // transient. We followed redirects automatically (OkHttp
            // default), so a 3xx here is a server misconfiguration
            // worth retrying briefly.
            if (code !in 200..299) {
                return@withContext BatchOutcome.HttpError(
                    code = code,
                    transient = true,
                )
            }

            // ─── (4) Decode + validate the 2xx response body ───
            //
            // A 2xx status is NOT on its own permission to DELETE queued
            // events. The backend's success contract ALWAYS returns a
            // structured per-event ack body (`success: true` +
            // `accepted_event_ids`), and a kill-switch returns
            // `paused: true`. An EMPTY or INCOMPLETE 2xx body — blank,
            // truncated, or a bare `{}` synthesized by a proxy / load
            // balancer / gateway that returned 200 WITHOUT the request
            // ever reaching our handler — carries NO real ack. Treating
            // that as "the whole batch was accepted" silently DROPS every
            // event the server never actually stored (the exact data-loss
            // bug). We must never delete un-acknowledged events, so on a
            // missing/incomplete ack we RETRY (transient): the batch stays
            // in the durable store and ships once we get a real ack.
            val responseBody = resp.body?.string().orEmpty()
            if (responseBody.isBlank()) {
                // Blank 2xx body → no ack. Retry rather than drop.
                return@withContext BatchOutcome.HttpError(code = code, transient = true)
            }
            val decoded: BatchResponse = try {
                json.decodeFromString(BatchResponse.serializer(), responseBody)
            } catch (e: SerializationException) {
                // A malformed/truncated 2xx response carries no trustworthy
                // ack. Keep the durable rows and retry; SerializationError
                // is reserved for our own request-encoding failures.
                return@withContext BatchOutcome.HttpError(code = code, transient = true)
            } catch (e: Throwable) {
                return@withContext BatchOutcome.HttpError(code = code, transient = true)
            }
            // The body decoded, but is it a REAL ack? The backend marks a
            // genuine per-event ack with `success: true` and a kill-switch
            // with `paused: true`. A 2xx body carrying NEITHER (e.g. a bare
            // `{}` that decoded to all-defaults, or a partial/garbled JSON
            // that happened to parse) is an incomplete ack we can't act on
            // — the AckClassifier's defensive default would otherwise treat
            // every un-mentioned event as accepted and drop the whole
            // batch. Retry instead of dropping.
            if (!decoded.success && decoded.paused != true) {
                return@withContext BatchOutcome.HttpError(code = code, transient = true)
            }

            // ─── (5) Partition into accepted / perm / transient ─
            val (accepted, permanent, transient) =
                AckClassifier.classify(payload.batch, decoded)

            return@withContext BatchOutcome.Success(
                acceptedIds = accepted,
                transientIds = transient,
                permanentIds = permanent,
                // BatchResponse.paused is nullable on the wire; treat
                // missing as "not paused".
                paused = decoded.paused == true,
                pausedReason = decoded.pausedReason,
            )
        }
    }

    /**
     * POST `/api/sdk/init`. Returns the parsed [InitResponse] on 2xx,
     * or `null` on transient failure (network / 5xx) so the lifecycle
     * controller knows to retry. Permanent 4xx (bad project_id /
     * api_key, both 401) also returns `null` — at the init stage we
     * have no events to drop, so the controller's job is just "try
     * again later" regardless of permanent/transient.
     *
     * The init response's `paused` field is the kill-switch entry
     * point — the controller transitions straight to `pausedByServer`
     * before any events get enqueued.
     */
    override suspend fun postInit(req: InitRequest): InitResponse? = withContext(Dispatchers.IO) {
        val body: String = try {
            json.encodeToString(InitRequest.serializer(), req)
        } catch (e: Throwable) {
            return@withContext null
        }

        val request = Request.Builder()
            .url(Endpoints.url(baseUrl, Endpoints.INIT))
            .post(body.toRequestBody(JSON_MEDIA_TYPE))
            .header("Authorization", "Bearer ${req.apiKey}")
            .header("Content-Type", "application/json; charset=utf-8")
            .build()

        val response: Response = try {
            executeAsync(httpClient.newCall(request))
        } catch (e: IOException) {
            return@withContext null
        }

        response.use { resp ->
            // Init failures are uniformly "try again later". We don't
            // distinguish 401 (bad key) from 503 (Cloud Run cold) —
            // the controller will refetch on its own schedule.
            if (!resp.isSuccessful) return@withContext null
            val text = resp.body?.string().orEmpty()
            if (text.isBlank()) return@withContext null
            try {
                json.decodeFromString(InitResponse.serializer(), text)
            } catch (e: Throwable) {
                null
            }
        }
    }

    /**
     * Fetch the live project policy from `/api/sdk/config`.
     * Credentials are header-only; putting `api_key` in the query string
     * would leak it into device/proxy URL logs. Unknown/malformed responses
     * return null so callers retain their last resolved (possibly stricter)
     * policy and retry on the control-plane cadence.
     */
    override suspend fun getConfig(req: ConfigRequest): ConfigResponse? = withContext(Dispatchers.IO) {
        val base = Endpoints.url(baseUrl, Endpoints.CONFIG)
        val url = try {
            base.toHttpUrl().newBuilder()
                .addQueryParameter("project_id", req.projectId)
                .apply {
                    // Prefer release_id: backend re-verifies its app against
                    // the caller's bundle envelope. app_id is only a legacy
                    // fallback when init could not resolve a release.
                    if (req.releaseId.isNotBlank()) {
                        addQueryParameter("release_id", req.releaseId)
                    } else if (req.appId.isNotBlank()) {
                        addQueryParameter("app_id", req.appId)
                    }
                }
                .addQueryParameter("platform", req.platform)
                .addQueryParameter("bundle_id", req.bundleId)
                .addQueryParameter("environment", req.environment)
                .addQueryParameter("sdk_version", req.sdkVersion)
                .build()
        } catch (_: Throwable) {
            return@withContext null
        }

        val request = Request.Builder()
            .url(url)
            .get()
            .header("Authorization", "Bearer ${req.apiKey}")
            .header("Accept", "application/json")
            .build()

        val response = try {
            executeAsync(httpClient.newCall(request))
        } catch (_: IOException) {
            return@withContext null
        }
        response.use { resp ->
            if (!resp.isSuccessful) return@withContext null
            val text = resp.body?.string().orEmpty()
            if (text.isBlank()) return@withContext null
            try {
                json.decodeFromString(ConfigResponse.serializer(), text)
            } catch (_: Throwable) {
                null
            }
        }
    }

    /**
     * POST `/api/sdk/push/register`. Returns `true` on 2xx, `false` on
     * any failure (transient or permanent — caller can't do much
     * about either; the next `setPushToken` call will retry).
     *
     * Per AGENT_BRIEFING.md R10: this is THE place plaintext push
     * tokens leave the device. The request body carries the raw
     * token. NEVER log it.
     */
    override suspend fun postPushRegister(
        req: io.kixo.sdk.internal.model.PushRegisterRequest,
    ): Boolean = postPushRegisterInternal(req, collectionEpoch = null)

    override suspend fun postPushRegister(
        req: io.kixo.sdk.internal.model.PushRegisterRequest,
        collectionEpoch: Long,
    ): Boolean = postPushRegisterInternal(req, collectionEpoch)

    private suspend fun postPushRegisterInternal(
        req: io.kixo.sdk.internal.model.PushRegisterRequest,
        collectionEpoch: Long?,
    ): Boolean = withContext(Dispatchers.IO) {
        val body: String = try {
            json.encodeToString(io.kixo.sdk.internal.model.PushRegisterRequest.serializer(), req)
        } catch (_: Throwable) {
            return@withContext false
        }
        val request = Request.Builder()
            .url(io.kixo.sdk.internal.transport.Endpoints.url(baseUrl, io.kixo.sdk.internal.transport.Endpoints.PUSH_REGISTER))
            .post(body.toRequestBody(JSON_MEDIA_TYPE))
            .header("Authorization", "Bearer ${req.apiKey}")
            .header("Content-Type", "application/json; charset=utf-8")
            .build()
        val response: Response = try {
            executeAsync(httpClient.newCall(request), collectionEpoch)
        } catch (_: IOException) {
            return@withContext false
        }
        response.use { it.isSuccessful }
    }

    /**
     * Adapter from OkHttp's [Call.enqueue] callback to a coroutine.
     * Cancelling the surrounding scope cancels the [Call] (so
     * `withTimeout` actually frees the socket instead of leaving it
     * dangling for `callTimeout`). Throws [IOException] on failure.
     */
    private suspend fun executeAsync(call: Call, collectionEpoch: Long? = null): Response {
        val gate = privacyGate
        if (gate != null && collectionEpoch != null) {
            return gate.executeCollectionCall(collectionEpoch, call)
        }
        return suspendCancellableCoroutine { cont ->
            cont.invokeOnCancellation {
                // Best-effort — Call.cancel() is idempotent + safe to
                // call from any thread.
                runCatching { call.cancel() }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWith(Result.failure(e))
                }
                override fun onResponse(call: Call, response: Response) {
                    if (cont.isActive) cont.resume(response)
                }
            })
        }
    }

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
