package io.kixo.sdk.internal.replay

import android.content.Context

/** Project-scoped persisted negative replay veto. It can only disable replay;
 * positive authority always comes from the fresh project control plane. */
internal object ReplayOptOutStore {
    private const val PREFS_NAME = "io.kixo.sdk.replay.opt_out"
    private const val KEY_PREFIX = "opted_out_"

    fun isOptedOut(context: Context, projectId: String): Boolean = runCatching {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_PREFIX + projectId, false)
    }.getOrDefault(false)

    fun setOptedOut(context: Context, projectId: String, optedOut: Boolean) {
        runCatching {
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(KEY_PREFIX + projectId, optedOut)
                .commit()
        }
    }
}
