package io.kixo.sdk.internal.privacy

import android.text.InputType
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.webkit.WebView
import android.widget.EditText

/**
 * Pure decision function for the **always-on structural redaction**
 * layer (per AGENT_BRIEFING.md R2 layer 1).
 *
 * Three categories of view get unconditionally masked, regardless of
 * what's in their text content:
 *
 * 1. **Operator-marked sensitive views** — anything in [MaskRegistry]
 *    via the public extension `View.setKixoMask(true)`.
 *
 * 2. **InputType-flagged credential fields** — [EditText] whose
 *    [InputType] declares password / email / phone semantics. The
 *    Android keyboard already hides characters here (no autocorrect,
 *    no suggestion bar) and the IME contract treats these as
 *    sensitive — we mirror that contract for replay.
 *
 * 3. **Opaque content surfaces** — [WebView] (HTML can render
 *    arbitrary user content from any origin), [SurfaceView] /
 *    [TextureView] (typically DRM video, paid content, camera preview,
 *    AR scene). We can't see inside, so we mask the bounding box
 *    rather than risk leaking a frame of HBO / Netflix / a customer's
 *    paywalled content.
 *
 * 4. **Compose hosts (`AndroidComposeView`)** — `androidx.compose.material(.material3).TextField`
 *    is NOT a [View] subclass; the entire Compose tree lives inside a
 *    single `AndroidComposeView` host and is invisible to View
 *    traversal. That means a Compose password field would not match
 *    the [EditText] InputType rule and would leak its plaintext to the
 *    structural snapshot. Until per-Compose-node introspection ships
 *    (requires Compose Tooling APIs / SemanticsOwner walk on the main
 *    thread), the safe default is to mask any AndroidComposeView host
 *    wholesale. Customer can opt back IN once they've audited the
 *    composables for PII by tagging the outermost ComposeView ancestor
 *    with `setKixoMask(false)`. **TODO:** add a Compose-aware
 *    introspector that walks SemanticsOwner.rootSemanticsNode and
 *    redacts only password / email semantics nodes (mirrors iOS
 *    `UITextField.isSecureTextEntry` per-leaf logic).
 *
 * ## Why a separate fun and not a method on [View]
 * Pure function is unit-testable without an Android device. The
 * caller (replay's structural snapshotter, owned by Agent 13) just
 * passes the [View] in. No state, no allocation.
 *
 * ## Performance
 * Called for every view in the visible hierarchy on every replay
 * frame. Must be branch-free hot. Uses bitwise [InputType] checks
 * (cheap) and instanceof checks (also cheap on modern ART) — no
 * reflection, no allocation.
 */
internal object StructuralRedactionRules {

    /**
     * Decide whether [view] must be masked from replay capture.
     *
     * Returns `true` if ANY of the three categories above matches.
     * Returns `false` for all other views — they participate in
     * structural snapshots normally and their text runs through
     * [PiiFilter] regex/NER as the per-text safety net.
     *
     * Null-safe: returns `false` for null views (defensive — should
     * never happen since the caller iterates a non-null hierarchy,
     * but if it does we don't want to NPE).
     */
    @JvmStatic
    @JvmOverloads
    fun shouldRedact(view: View?, maskAllInputs: Boolean = false): Boolean {
        if (view == null) return false
        // Cheapest check first: registry lookup is O(1) on a hashed
        // map (well, weakly-keyed, but still constant per call). Most
        // views will NOT be in the registry, so this is a fast no.
        if (MaskRegistry.isMasked(view)) return true
        // Opaque surfaces — single instanceof per type, branch
        // predictor will collapse the false cases.
        if (view is WebView) return true
        if (view is SurfaceView) return true
        if (view is TextureView) return true
        // The project policy can mask ALL input controls. Credential/email/
        // phone fields remain unconditionally masked even when the customer
        // explicitly turns the broad switch off.
        if (view is EditText && (maskAllInputs || isSensitiveInputType(view.inputType))) return true
        // Compose host: AndroidComposeView (and its inner subclass
        // AndroidComposeView$ViewLayer etc). simpleName.contains is the
        // cheapest sniff that doesn't require a Compose dependency on
        // this module — we just need to know "this view's tree is
        // opaque to View traversal." Critic 4 BLOCKER: every Compose
        // TextField (material + material3) is unreachable from this
        // function via the EditText branch, so without this default
        // mask, a Compose password field would leak. See class kdoc
        // category 4 + the customer opt-in via
        // `composeView.setKixoMask(false)` after PII audit.
        if (view.javaClass.simpleName.contains("AndroidComposeView")) return true
        return false
    }

    /**
     * Decode the [InputType] bitfield to decide if the field holds a
     * credential or PII.
     *
     * The five flags we mask:
     *  - TYPE_TEXT_VARIATION_PASSWORD — generic password.
     *  - TYPE_TEXT_VARIATION_VISIBLE_PASSWORD — "show password" mode
     *    is still credential entry.
     *  - TYPE_TEXT_VARIATION_WEB_PASSWORD — HTML form password input
     *    (some apps embed via WebView surrogates).
     *  - TYPE_NUMBER_VARIATION_PASSWORD — numeric PIN entry.
     *  - TYPE_TEXT_VARIATION_EMAIL_ADDRESS / TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS
     *    — email is PII.
     *  - TYPE_CLASS_PHONE — phone number entry.
     *
     * The InputType layout: bottom 4 bits are CLASS, next 4 bits are
     * VARIATION. We mask both `MASK_VARIATIONS` against the variation
     * we recognise AND check the CLASS alone for `TYPE_CLASS_PHONE`
     * (no variation needed).
     */
    @Suppress("MagicNumber")
    private fun isSensitiveInputType(inputType: Int): Boolean {
        // Phone — class alone is enough.
        if (inputType and InputType.TYPE_MASK_CLASS == InputType.TYPE_CLASS_PHONE) return true

        val variation = inputType and InputType.TYPE_MASK_VARIATION
        when (variation) {
            InputType.TYPE_TEXT_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
            InputType.TYPE_NUMBER_VARIATION_PASSWORD,
            InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
                -> return true
        }
        return false
    }
}
