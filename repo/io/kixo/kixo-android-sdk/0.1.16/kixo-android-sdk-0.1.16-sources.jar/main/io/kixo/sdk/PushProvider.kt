package io.kixo.sdk

/**
 * Push notification token provider.
 *
 * Android delivery currently supports Firebase Cloud Messaging only.
 * The backend uses this value to route the token through FCM HTTP v1
 * and to scope token deduplication.
 *
 * Wire format: the `wireValue` is what lands in the event property
 * `push_provider` and on the `/api/sdk/push/register` body's `provider`
 * field. The backend's push routing layer keys off this exactly.
 *
 * **Default = [FCM]**.
 */
public enum class PushProvider(
    public val wireValue: String,
    /** Whether this SDK can safely register/deliver this provider. */
    public val supportedOnAndroid: Boolean,
) {
    /**
     * Firebase Cloud Messaging — Google's standard Android push
     * transport. Default for [Kixo.setPushToken].
     *
     * Wire token: `"fcm"`. The iOS SDK uses `"firebase"` for the same
     * conceptual provider, but the Android wire token is `"fcm"` to
     * stay consistent with the FCM SDK's own naming and the backend's
     * routing logic (which already keys off `"fcm"` for Android
     * delivery).
     */
    FCM("fcm", true),

    /**
     * Kept for source compatibility with 0.1.13 integrations. Kixo's
     * Android backend currently has no HMS delivery path, so registration is
     * an intentional no-op. This constant can be removed only in a major
     * release.
     */
    @Deprecated(
        message = "HMS delivery is not supported; token registration is a no-op",
        replaceWith = ReplaceWith("PushProvider.FCM"),
    )
    HMS("hms", false),

    /**
     * Kept for source compatibility with cross-platform 0.1.13 call sites.
     * APNs tokens must be registered by the iOS SDK; Android no-ops safely.
     */
    @Deprecated(
        message = "APNS delivery belongs to the iOS SDK; registration is a no-op",
        replaceWith = ReplaceWith("PushProvider.FCM"),
    )
    APNS("apns", false);

    public companion object {
        /**
         * Parse a wire token back into an enum. Returns null on
         * unknown — caller decides whether to fall back to [FCM] or
         * drop the event. Used by the dashboard SDK round-trip when
         * reading server-stored push metadata.
         *
         * Tolerates legacy spellings. HMS/APNS parse to deprecated constants
         * for source/wire round-trip compatibility, while registration still
         * no-ops through [supportedOnAndroid].
        */
        @JvmStatic
        @Suppress("DEPRECATION")
        public fun fromWireValue(value: String?): PushProvider? {
            if (value == null) return null
            return when (value.lowercase()) {
                "fcm", "firebase" -> FCM
                "hms", "huawei" -> HMS
                "apns", "apple" -> APNS
                else -> null
            }
        }
    }
}
