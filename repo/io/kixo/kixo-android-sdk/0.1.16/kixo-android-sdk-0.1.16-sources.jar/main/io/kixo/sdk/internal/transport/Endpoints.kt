package io.kixo.sdk.internal.transport

/**
 * Centralised endpoint paths so a wire-format change is a one-file
 * edit, not a grep-and-pray sweep across replay/upload/identity. Paths
 * mirror the backend's api/sdk/... routes exactly.
 *
 * Hosts are intentionally NOT here — environment selection lives in
 * configuration (`KixoConfiguration.environment`) so the same URL set
 * works in dev / staging / prod without recompiling.
 */
internal object Endpoints {
    // ─── Core ingest ──────────────────────────────────────────
    /** Once on launch — fetches `release_id`, `data_collection`, `paused`. */
    const val INIT = "/api/sdk/init"

    /** Periodic project-owned live policy refresh. */
    const val CONFIG = "/api/sdk/config"

    /** Periodic event flush (every 30 s OR every 20 events). */
    const val BATCH = "/api/sdk/batch"

    /** Side-channel identify (most events use /batch instead). */
    const val IDENTIFY = "/api/sdk/identify"

    // ─── Push ─────────────────────────────────────────────────
    /** Once per token change — only place a plaintext push token leaves the device. */
    const val PUSH_REGISTER = "/api/sdk/push/register"

    // ─── Attribution (deep-linking / MMP) ─────────────────────
    /**
     * Deferred-deep-link RESOLVE (BLOCKER-B resolution, KIX-DL Wave 2).
     *
     * There is NO dedicated `/api/sdk/attribution/referrer` route on the backend
     * (it never existed — the old `ATTRIBUTION_REFERRER` constant pointed at a
     * 404). The deterministic deferred attribution is resolved via the SAME
     * endpoint iOS uses: the SDK POSTs `{project_id, api_key, kixo_click_id}`
     * and the backend runs the §0 §3 existence + ownership + single-use check,
     * returning `{resolved, link:{id,target_path,data}, media_source, campaign,
     * match_method, ...}`. The Play Install Referrer ENRICHMENT (utm_* / click-
     * injection ordering) rides as a synthetic `install_referrer` event into
     * [BATCH] (the path `processReferrerEvents` already consumes) — NOT here.
     */
    const val LINK_RESOLVE = "/api/sdk/link/resolve"

    /**
     * Deterministic install-receipt validation (KIX-MMP-FRAUD-01). The SDK POSTs
     * a Play Integrity token + `{project_id, api_key, platform:"android",
     * install_id, integrity_token}`; the backend verifies device integrity +
     * package, enforces single-use, and stamps the install `validated`
     * (anti-replay / anti-spoof). Fail-open on the backend — an absent token is
     * never a fraud reject. The SAME path iOS uses for its StoreKit receipt.
     */
    const val INSTALL_VALIDATE = "/api/sdk/install/validate"

    /**
     * Android Privacy Sandbox ARA SOURCE registration (KIX-MMP-ARA-01, Phase A).
     * The on-device `MeasurementManager.registerSource` fetches this URI on a
     * Kixo deep-link click; the backend returns an
     * `Attribution-Reporting-Register-Source` header (the SDK carries the
     * `kixo_click_id` + link `slug` as query params). Parallel to SKAN's source
     * surface — Android-only, gracefully no-op when the AdServices runtime is
     * absent.
     */
    const val ARA_SOURCE = "/api/sdk/ara/source"

    /**
     * Android Privacy Sandbox ARA TRIGGER registration (KIX-MMP-ARA-01, Phase A).
     * The on-device `MeasurementManager.registerTrigger` fetches this URI on
     * install / first-open; the backend returns an
     * `Attribution-Reporting-Register-Trigger` header.
     */
    const val ARA_TRIGGER = "/api/sdk/ara/trigger"

    // ─── Replay ───────────────────────────────────────────────
    /** On replay session open. */
    const val REPLAY_SESSION_START = "/api/sdk/replay/session/start"

    /** Read-only recovery for an ambiguous replay session open. */
    const val REPLAY_SESSION_RECONCILE = "/api/sdk/replay/session/reconcile"

    /** Per-tap replay metadata (interaction taxonomy + tap coords). */
    const val REPLAY_EVENTS = "/api/sdk/replay/events"

    /** When the signed-URL pool runs low. */
    const val REPLAY_FRAMES_SIGN = "/api/sdk/replay/frames/sign"

    /** Tile-style frame signing (per-leaf HEIC tiles, iOS C.3 v1+v2). */
    const val REPLAY_FRAMES_SIGN_TILES = "/api/sdk/replay/frames/sign-tiles"

    /** On replay session seal. */
    const val REPLAY_SESSION_END = "/api/sdk/replay/session/end"

    /**
     * Build a fully-qualified URL for the given base + path.
     *
     * **Wave 5: HTTPS assert.** A misconfigured operator pointing at
     * `http://sdk.dev.kixo.io` would silently ship every event
     * payload — push tokens, user_ids, full event properties — in
     * cleartext. We refuse and fall back to PROD HTTPS rather than
     * risk plaintext egress. Production-side network_security_config
     * blocks cleartext too on Android 28+, but the SDK's defensive
     * check fires earlier and produces a more readable log line.
     *
     * **Wave 14: loopback exception.** `http://localhost`,
     * `http://127.0.0.1`, `http://0.0.0.0`, `http://[::1]` pass through
     * untouched — local-dev only, no PII risk because traffic never
     * leaves the host. This is what unit tests use (OkHttp
     * `MockWebServer` always binds HTTP-only on localhost) and what
     * developers running a backend on `./gradlew run` use.
     */
    fun url(baseUrl: String, path: String): String {
        val isHttps = baseUrl.startsWith("https://")
        val isLocalHttp = baseUrl.startsWith("http://localhost") ||
            baseUrl.startsWith("http://127.0.0.1") ||
            baseUrl.startsWith("http://0.0.0.0") ||
            baseUrl.startsWith("http://[::1]")
        val safeBase = if (!isHttps && !isLocalHttp) {
            android.util.Log.w(
                "Kixo.Endpoints",
                "Refusing non-HTTPS non-loopback baseUrl '$baseUrl' — falling back to ${io.kixo.sdk.internal.KixoEndpoints.PROD}. " +
                    "Set KixoConfiguration.Builder.apiHost(\"https://...\") explicitly if you need a custom host.",
            )
            io.kixo.sdk.internal.KixoEndpoints.PROD
        } else {
            baseUrl
        }
        // Strip a trailing slash on `safeBase` so we don't end up with
        // `https://sdk.dev.kixo.io//api/sdk/batch`. Cheap to do here
        // once vs. expecting every caller to remember.
        val trimmed = if (safeBase.endsWith('/')) safeBase.dropLast(1) else safeBase
        return trimmed + path
    }
}
