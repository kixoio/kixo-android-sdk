package io.kixo.sdk.internal.model

import kotlinx.serialization.Serializable

/**
 * Typed mirror of the `data_collection` payload returned by
 * `POST /api/sdk/init`. Wire shape lives at
 * `kixo-backend/apps/web/src/lib/sdk/data-collection-defaults.ts`.
 *
 * **Coverage fix (May 2026).** Previously the SDK parsed the entire
 * `data_collection` blob as a raw `JsonObject` and never routed it
 * anywhere — operator dashboard toggles were 100% no-op on Android.
 * This type + [io.kixo.sdk.internal.queue.DataCollectionHolder] +
 * the per-subsystem emit-time gating restored full coverage.
 *
 * Every field is nullable so the SDK can distinguish:
 *  - server affirmatively SET `false`  → suppress
 *  - server affirmatively SET `true`   → allow
 *  - server DIDN'T SEND the field      → fall back to safe default
 *
 * The convention across all consumers is **default-allow on null** —
 * if the server didn't ship `data_collection.core.pageViews`, we
 * still record page views. The conservative degradation is for the
 * `paused` flag only, which is read separately by the queue's
 * lifecycle machine.
 */
@Serializable
internal data class DataCollection(
    val paused: Boolean? = null,
    val core: CoreConfig? = null,
    val engagement: EngagementConfig? = null,
    val performance: PerformanceConfig? = null,
    val heatmaps: HeatmapsConfig? = null,
    val replay: ReplayDataConfig? = null,
    val device: DeviceConfig? = null,
    val privacy: PrivacyConfig? = null,
    val attribution: AttributionConfig? = null,
    val screenshots: ScreenshotsConfig? = null,
    val identity: IdentityConfig? = null,
    val push: PushConfig? = null,
) {
    @Serializable internal data class CoreConfig(
        val pageViews: Boolean? = null,
        val sessions: Boolean? = null,
        val errors: Boolean? = null,
    )

    @Serializable internal data class EngagementConfig(
        val clicks: Boolean? = null,
        val scrollDepth: Boolean? = null,
        val forms: Boolean? = null,
        val rageClicks: Boolean? = null,
        val deadClicks: Boolean? = null,
        val engagementTime: Boolean? = null,
        val refreshLoop: Boolean? = null,
    )

    @Serializable internal data class PerformanceConfig(
        val webVitals: Boolean? = null,
        val networkRequests: Boolean? = null,
        val resourceErrors: Boolean? = null,
        val perfBudget: Boolean? = null,
    )

    @Serializable internal data class HeatmapsConfig(
        val clicks: Boolean? = null,
        val mouseMovement: Boolean? = null,
        val scrollDepth: Boolean? = null,
    )

    @Serializable internal data class ReplayDataConfig(
        val enabled: Boolean? = null,
        // 0-100 percent on the wire. Sparse contract (2026-07): the
        // backend omits default-valued fields, and the default sample
        // rate is 100 — a PRESENT replay block with a missing rate
        // means "record every session". Consumers resolve it through
        // [effectiveSampleRateFraction]; QueueWiring threads that
        // fraction into the deterministic sampler verdict via
        // ReplayController.updateSampleRate (S3 / KIX-UNI-22 parity).
        // An explicit value still wins, and an explicit 0 hard-disables.
        val sampleRate: Double? = null,
        val maskInputs: Boolean? = null,
        /**
         * Whether replay artifacts may upload over a metered/mobile
         * connection. Missing is deliberately Wi-Fi-only. This is the
         * wire counterpart of the dashboard's
         * `dataCollection.replay.captureOnCellular` switch; the public
         * `KixoConfiguration.replayCaptureOnCellular` value is retained only
         * for source compatibility and is not an authority.
         */
        val captureOnCellular: Boolean? = null,
        /** Per-stint wall-clock cap, seconds (10..3600 on the server). */
        val maxDurationSec: Double? = null,

        // ── AND-CAP-04 perf knobs (2026-07-05). All nullable: null =
        //    "server said nothing, keep the compiled default". Field
        //    names/casing match the iOS `RemoteConfig.ReplayConfig`
        //    (camelCase) so the backend serves ONE replay block for
        //    both platforms. Applied in
        //    QueueWiring.applyDataCollectionSideEffects. ────────────
        /** Master gate for frame capture (→ ReplayConfig.frameCaptureEnabled). */
        val frameCaptureEnabled: Boolean? = null,
        /** Structural snapshot pipeline gate (→ structuralSnapshotEnabled). */
        val structuralEnabled: Boolean? = null,
        /** iOS-only tile pipeline; decoded for wire parity, ignored on Android. */
        val tileCaptureEnabled: Boolean? = null,
        /** ML Kit OCR sidecar gate (→ ocrEnabled). Enterprise-gated server-side. */
        val ocrEnabled: Boolean? = null,
        /** Global capture cadence floor, ms (→ captureMinIntervalMs). */
        val captureMinIntervalMs: Double? = null,
        /** Dedicated scroll-end FRAME capture (→ scrollEndCaptureEnabled). */
        val scrollEndCaptureEnabled: Boolean? = null,
        /** Min seconds between scroll-end frame captures (→ scrollEndMinIntervalSec). */
        val scrollEndMinIntervalSec: Double? = null,
        /** Dirty-settle delay, ms (→ postTapSettleMs). */
        val postTapSettleMs: Double? = null,
        /** Dirty-heartbeat period, SECONDS on the wire (→ dirtyHeartbeatMs). */
        val dirtyHeartbeatSec: Double? = null,
        /** Frame encode quality, 0-1 fraction on the wire (→ jpegQuality). */
        val heicQuality: Double? = null,
        /** Frame render/downscale factor (→ captureScale). */
        val captureScale: Double? = null,
        /** Shared iOS/Android in-flight capture ceiling. */
        val maxConcurrentCaptures: Double? = null,
        /** Android on-device OCR concurrency ceiling. */
        val maxConcurrentOcr: Double? = null,
    ) {
        /**
         * Sparse-wire sample-rate resolution (2026-07 contract), in
         * 0-100 percent. The backend omits `sampleRate` when it equals
         * the default — and the default is 100. A PRESENT replay block
         * whose rate is missing or non-finite therefore means "record
         * every session"; an explicit finite value wins (`25` → 25.0)
         * and an explicit `0`/negative hard-disables (→ 0.0).
         *
         * An ABSENT replay block is NOT covered here: absence means
         * replay is OFF, and callers must fail closed BEFORE consulting
         * this helper (`replay?.effectiveSampleRateFraction() ?: 0.0`).
         */
        fun effectiveSampleRatePercent(): Double =
            (sampleRate?.takeIf { it.isFinite() } ?: 100.0).coerceIn(0.0, 100.0)

        /** [effectiveSampleRatePercent] as the 0-1 fraction fed to the sampler. */
        fun effectiveSampleRateFraction(): Double = effectiveSampleRatePercent() / 100.0
    }

    @Serializable internal data class DeviceConfig(
        val hardwareInfo: Boolean? = null,
        val connectionInfo: Boolean? = null,
        val batteryInfo: Boolean? = null,
        val context: Boolean? = null,
        val lifecycle: Boolean? = null,
    )

    @Serializable internal data class PrivacyConfig(
        val collectIPs: Boolean? = null,
        val geoLocation: Boolean? = null,
        val userAgent: Boolean? = null,
    )

    @Serializable internal data class AttributionConfig(
        val enabled: Boolean? = null,
        val clickIds: Boolean? = null,
        val utm: Boolean? = null,
        val referrer: Boolean? = null,
    )

    @Serializable internal data class ScreenshotsConfig(
        val enabled: Boolean? = null,
        val quality: Int? = null,
        val maxWidth: Int? = null,
        val excludedScreens: List<String>? = null,
    )

    @Serializable internal data class IdentityConfig(
        val collectEmail: Boolean? = null,
        val collectPhone: Boolean? = null,
        val collectName: Boolean? = null,
        val collectLocation: Boolean? = null,
        val collectPushTokens: Boolean? = null,
        val hashPiiBeforeStorage: Boolean? = null,
    )

    @Serializable internal data class PushConfig(
        val enabled: Boolean? = null,
        // "full" | "preview" | "hash_only" — see
        // `io.kixo.sdk.internal.push.ContentMode`.
        val contentMode: String? = null,
        val titlePreviewChars: Int? = null,
        val bodyPreviewChars: Int? = null,
    )
}
