@file:Suppress("unused")

package io.kixo.sdk

import android.util.Log
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import io.kixo.sdk.internal.push.PushTracker

/**
 * Optional convenience subclass of Firebase's [FirebaseMessagingService]
 * that auto-tracks every FCM event through Kixo. Customers extend this in
 * their app and register it in their `AndroidManifest.xml` exactly as they
 * would a plain `FirebaseMessagingService` — only the base class changes:
 *
 * ```kotlin
 * class MyMessagingService : KixoFirebaseMessagingService() {
 *     override fun onMessageReceived(remoteMessage: RemoteMessage) {
 *         super.onMessageReceived(remoteMessage)  // Kixo logs the event
 *         // … customer's own routing / notification display
 *     }
 * }
 * ```
 *
 * ```xml
 * <service
 *     android:name=".MyMessagingService"
 *     android:exported="false">
 *     <intent-filter>
 *         <action android:name="com.google.firebase.MESSAGING_EVENT" />
 *     </intent-filter>
 * </service>
 * ```
 *
 * Because this class genuinely IS a `FirebaseMessagingService`, FCM
 * routes messages to the customer's subclass and `super.onMessageReceived`
 * / `super.onNewToken` hand them to Kixo. (The prior revision did NOT
 * extend the Firebase service and used reflection on an `Any?` parameter,
 * so a manifest-registered subclass was never actually invoked by FCM and
 * the customer's typed `onMessageReceived(RemoteMessage)` override did not
 * override anything — the auto-tracking path was dead.)
 *
 * Moved from `io.kixo.sdk.internal.push` to `io.kixo.sdk` in v0.1.3 so
 * customers can import via `import io.kixo.sdk.KixoFirebaseMessagingService`.
 *
 * **Firebase is a `compileOnly` dependency of the SDK** (same shape as ML
 * Kit — see AGENT_BRIEFING.md §5). The SDK compiles against the Firebase
 * messaging types but does NOT add firebase-messaging to its own POM, so a
 * host that doesn't use FCM pays nothing: nothing references this class, so
 * the JVM verifier never loads it and the Firebase superclass is never
 * resolved. A host that DOES use FCM already depends on
 * `com.google.firebase:firebase-messaging` (required to receive pushes at
 * all), which supplies this base class at their compile + runtime.
 *
 * **Agent-13 / replay note:** if a WorkManager-driven background uploader
 * for replay frames ships, the FCM data-channel might be a more efficient
 * wake-up trigger than periodic polling. Out of scope for the push slice —
 * flagged for the design follow-up.
 */
public abstract class KixoFirebaseMessagingService : FirebaseMessagingService() {

    /**
     * Kixo hook. Customers call this via `super.onMessageReceived(...)`.
     * Routes to `push_received` (visible message) or `push_silent`
     * (data-only message). Customers wanting different semantics can
     * override and skip the `super` call — Kixo is opt-in here.
     */
    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        try {
            val payload = extractPayload(remoteMessage)
            // Data-only (silent) push = no notification block AND no
            // title/body promoted from the data map.
            val isSilent = remoteMessage.notification == null &&
                payload["title"] == null &&
                payload["body"] == null
            if (isSilent) {
                PushTracker.logPushSilent(payload)
            } else {
                PushTracker.logPushReceived(payload, appState = "background")
            }
        } catch (t: Throwable) {
            // Per AGENT_BRIEFING.md R6, never crash the host. A malformed
            // RemoteMessage from a customer's edge case is worth a warn
            // line, not a crash report.
            Log.w(TAG, "onMessageReceived swallow", t)
        }
    }

    /**
     * Kixo hook. Customers call this via `super.onNewToken(...)`. The
     * [PushProvider] is hard-coded to [PushProvider.FCM] because this is
     * by definition the FCM service.
     */
    override fun onNewToken(token: String) {
        super.onNewToken(token)
        if (token.isEmpty()) return
        try {
            PushTracker.setPushToken(token, PushProvider.FCM)
        } catch (t: Throwable) {
            Log.w(TAG, "onNewToken swallow", t)
        }
    }

    /**
     * Build a sanitizer-compatible `Map<String, Any?>` from a
     * [RemoteMessage]: the flat `data` map, plus the notification block's
     * title/body promoted to flat keys so the sanitizer's
     * notification-block fallback OR the flat-key fast path both work —
     * whichever the customer's send pipeline chose.
     */
    private fun extractPayload(remoteMessage: RemoteMessage): Map<String, Any?> {
        val out = LinkedHashMap<String, Any?>()
        out.putAll(remoteMessage.data)
        remoteMessage.notification?.let { notification ->
            notification.title?.let { if (out["title"] == null) out["title"] = it }
            notification.body?.let { if (out["body"] == null) out["body"] = it }
        }
        return out
    }

    private companion object {
        const val TAG = "Kixo/PushFcm"
    }
}
