package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.transport.Endpoints
import io.kixo.sdk.internal.replay.upload.JpegEncoder.writeToFile
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Call
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/**
 * Crash-safe native replay metadata queue. One atomic JSON file owns one
 * `(session, seq)` and the first writer wins until the backend acknowledges it.
 * Files live under the SDK's backup-excluded `filesDir/kixo/` subtree rather
 * than Android's evictable cache, so offline rows survive storage-pressure
 * cache cleanup. The synchronous privacy/reset purge explicitly retires both
 * this directory and the raw-frame cache.
 */
internal class ReplayPendingEventStore(
    private val context: Context,
    private val json: Json = Json { ignoreUnknownKeys = true; encodeDefaults = true },
) {
    @Serializable
    internal data class Record(
        val version: Int = VERSION,
        val baseUrl: String,
        val projectId: String,
        val apiKey: String,
        val sessionId: String,
        val installationId: String,
        val policyToken: String,
        val eventId: String,
        val seq: Long,
        /** Payload without queue-owned event_id/seq; wire encoding overwrites both. */
        val payload: JsonObject,
        val createdAtEpochMs: Long = System.currentTimeMillis(),
    )

    /**
     * Persist before queue admission. If this seq already exists, return the
     * original record unchanged so a duplicate callback can never replace its
     * UUID or payload.
     */
    fun firstWrite(record: Record): Record? = synchronized(DISK_LOCK) {
        if (!record.isValid()) return null
        val file = fileFor(record) ?: return null
        val existing = read(file)
        if (existing != null && existing.isValid() && existing.sameSlot(record)) {
            return existing
        }
        if (file.exists()) runCatching { file.delete() }

        val encoded = runCatching {
            json.encodeToString(Record.serializer(), record).toByteArray(Charsets.UTF_8)
        }.getOrNull() ?: return null
        if (encoded.size > MAX_RECORD_BYTES) return null
        file.parentFile?.mkdirs()
        if (!encoded.writeToFile(file)) return null
        runCatching { file.setLastModified(record.createdAtEpochMs) }
        trimSession(file.parentFile ?: return record)
        file.parentFile?.parentFile?.let(::trimGlobal)
        record.takeIf { file.exists() }
    }

    fun snapshot(
        baseUrl: String,
        projectId: String,
        apiKey: String,
        sessionId: String,
        installationId: String,
    ): List<Record> = synchronized(DISK_LOCK) {
        val directory = sessionDirectory(
            baseUrl = baseUrl,
            projectId = projectId,
            sessionId = sessionId,
            installationId = installationId,
        ) ?: return emptyList()
        return directory.listFiles()
            ?.asSequence()
            ?.filter { it.isFile && it.extension == RECORD_EXTENSION }
            ?.mapNotNull { file ->
                val record = read(file)
                if (record == null || !record.isValid() ||
                    record.baseUrl != baseUrl ||
                    record.projectId != projectId ||
                    record.apiKey != apiKey ||
                    record.sessionId != sessionId ||
                    record.installationId != installationId ||
                    fileFor(record)?.canonicalFile != file.canonicalFile
                ) {
                    runCatching { file.delete() }
                    null
                } else {
                    record
                }
            }
            ?.sortedWith(compareBy<Record> { it.seq }.thenBy { it.eventId })
            ?.take(MAX_EVENTS_PER_SESSION)
            ?.toList()
            ?: emptyList()
    }

    fun removeIfUnchanged(record: Record): Boolean = synchronized(DISK_LOCK) {
        val file = fileFor(record) ?: return false
        val current = read(file) ?: return !file.exists()
        if (current == record) runCatching { file.delete() }.getOrDefault(false) else false
    }

    fun removeSession(
        baseUrl: String,
        projectId: String,
        sessionId: String,
        installationId: String,
    ): Boolean = synchronized(DISK_LOCK) {
        val directory = sessionDirectory(baseUrl, projectId, sessionId, installationId)
            ?: return false
        !directory.exists() || runCatching { directory.deleteRecursively() }.getOrDefault(false)
    }

    fun hasPending(
        baseUrl: String,
        projectId: String,
        apiKey: String,
        sessionId: String,
        installationId: String,
    ): Boolean = snapshot(baseUrl, projectId, apiKey, sessionId, installationId).isNotEmpty()

    fun count(
        baseUrl: String,
        projectId: String,
        apiKey: String,
        sessionId: String,
        installationId: String,
    ): Int = snapshot(baseUrl, projectId, apiKey, sessionId, installationId).size

    private fun read(file: File): Record? = runCatching {
        if (file.length() !in 1..MAX_RECORD_BYTES.toLong()) return@runCatching null
        json.decodeFromString(Record.serializer(), file.readText())
    }.getOrNull()

    private fun Record.sameSlot(other: Record): Boolean =
        baseUrl == other.baseUrl && projectId == other.projectId &&
            sessionId == other.sessionId && installationId == other.installationId &&
            seq == other.seq

    private fun Record.isValid(): Boolean =
        version == VERSION && baseUrl.isNotBlank() && projectId.isNotBlank() &&
            apiKey.isNotBlank() && sessionId.isNotBlank() && installationId.isNotBlank() &&
            policyToken.isNotBlank() && EVENT_ID.matches(eventId) &&
            seq in 0L..MAX_NATIVE_FRAME_SEQ

    private fun fileFor(record: Record): File? = sessionDirectory(
        baseUrl = record.baseUrl,
        projectId = record.projectId,
        sessionId = record.sessionId,
        installationId = record.installationId,
    )?.resolve("${record.seq.toString().padStart(6, '0')}.$RECORD_EXTENSION")

    private fun sessionDirectory(
        baseUrl: String,
        projectId: String,
        sessionId: String,
        installationId: String,
    ): File? = runCatching {
        val key = sha256("$baseUrl\u001f$projectId\u001f$sessionId\u001f$installationId")
        eventsRoot()?.resolve(key)?.canonicalFile
    }.getOrNull()

    private fun eventsRoot(): File? = runCatching {
        val files = context.filesDir.absolutePath.takeIf { it.isNotBlank() } ?: return null
        File(files, "kixo/replay-events").canonicalFile
    }.getOrNull()

    private fun trimSession(directory: File) {
        val files = directory.listFiles()
            ?.filter { it.isFile && it.extension == RECORD_EXTENSION }
            ?.sortedWith(compareBy<File> { it.lastModified() }.thenBy { it.name })
            ?: return
        val trimmed = files.take((files.size - MAX_EVENTS_PER_SESSION).coerceAtLeast(0))
        trimmed.forEach { file ->
            runCatching { file.delete() }
        }
        if (trimmed.isNotEmpty()) {
            Log.d(TAG, "Replay-event durable queue full — dropped ${trimmed.size} oldest rows")
        }
    }

    /** Bound storage across many offline sessions, not just within one stint. */
    private fun trimGlobal(root: File) {
        val files = root.listFiles()
            ?.asSequence()
            ?.filter(File::isDirectory)
            ?.flatMap { directory ->
                directory.listFiles()
                    ?.asSequence()
                    ?.filter { it.isFile && it.extension == RECORD_EXTENSION }
                    ?: emptySequence()
            }
            ?.sortedWith(compareBy<File> { it.lastModified() }.thenBy { it.absolutePath })
            ?.toList()
            ?: return
        val trimmed = files.take((files.size - MAX_EVENTS_GLOBAL).coerceAtLeast(0))
        trimmed.forEach { file ->
            val parent = file.parentFile
            runCatching { file.delete() }
            runCatching { parent?.delete() }
        }
        if (trimmed.isNotEmpty()) {
            Log.d(TAG, "Replay-event global queue full — dropped ${trimmed.size} oldest rows")
        }
    }

    private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { byte -> "%02x".format(byte) }

    companion object {
        private val DISK_LOCK = Any()
        internal const val VERSION = 1
        internal const val MAX_EVENTS_PER_SESSION = 500
        internal const val MAX_EVENTS_GLOBAL = 2_000
        internal const val MAX_NATIVE_FRAME_SEQ = 20_000L
        private const val MAX_RECORD_BYTES = 32 * 1024
        private const val RECORD_EXTENSION = "json"
        private const val TAG = "Kixo.ReplayPendingEventStore"
        private val EVENT_ID = Regex(
            "^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$",
        )
    }
}

/** Shared drain used by the foreground batcher and WorkManager workers. */
internal object ReplayPendingEventDrain {
    enum class Outcome { DRAINED, RETRY }

    private enum class SendOutcome {
        ACKNOWLEDGED,
        REMOTE_PAUSED,
        RETRY,
        TERMINAL,
        POLICY_DISCARD,
    }

    private data class SendResult(
        val outcome: SendOutcome,
        val pausedReason: String? = null,
    )

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = false }
    private val mediaType = "application/json; charset=utf-8".toMediaType()
    private val drainLocks = ConcurrentHashMap<String, Mutex>()
    private val activeCalls = ConcurrentHashMap<String, MutableSet<Call>>()

    suspend fun drainSession(
        context: Context,
        httpClient: OkHttpClient,
        store: ReplayPendingEventStore,
        baseUrl: String,
        projectId: String,
        apiKey: String,
        sessionId: String,
        installationId: String,
        networkState: () -> Pair<Boolean, Boolean> = { currentNetwork(context) },
        onCallStarted: (Call) -> Unit = {},
        onCallFinished: (Call) -> Unit = {},
        onRemotePaused: (String?) -> Unit = {},
    ): Outcome {
        val drainKey = drainKey(baseUrl, projectId, sessionId, installationId)
        val mutex = drainLocks.computeIfAbsent(drainKey) { Mutex() }
        return mutex.withLock {
            val records = store.snapshot(baseUrl, projectId, apiKey, sessionId, installationId)
            for (tokenGroup in records.groupBy { it.policyToken }.values) {
                for (batch in tokenGroup.chunked(MAX_BATCH_SIZE)) {
                    val result = sendBatch(
                        httpClient = httpClient,
                        records = batch,
                        drainKey = drainKey,
                        networkState = networkState,
                        onCallStarted = onCallStarted,
                        onCallFinished = onCallFinished,
                    )
                    when (result.outcome) {
                        SendOutcome.ACKNOWLEDGED,
                        SendOutcome.POLICY_DISCARD,
                        -> batch.forEach(store::removeIfUnchanged)
                        SendOutcome.REMOTE_PAUSED -> {
                            batch.forEach(store::removeIfUnchanged)
                            onRemotePaused(result.pausedReason)
                        }
                        SendOutcome.RETRY -> return@withLock Outcome.RETRY
                        SendOutcome.TERMINAL -> {
                            // A batch-level 4xx may belong to one malformed
                            // row. Isolate it so unrelated durable rows survive.
                            if (batch.size == 1) {
                                store.removeIfUnchanged(batch.single())
                            } else {
                                for (record in batch) {
                                    val single = sendBatch(
                                        httpClient = httpClient,
                                        records = listOf(record),
                                        drainKey = drainKey,
                                        networkState = networkState,
                                        onCallStarted = onCallStarted,
                                        onCallFinished = onCallFinished,
                                    )
                                    when (single.outcome) {
                                        SendOutcome.ACKNOWLEDGED,
                                        SendOutcome.TERMINAL,
                                        SendOutcome.POLICY_DISCARD,
                                        -> store.removeIfUnchanged(record)
                                        SendOutcome.REMOTE_PAUSED -> {
                                            store.removeIfUnchanged(record)
                                            onRemotePaused(single.pausedReason)
                                        }
                                        SendOutcome.RETRY -> return@withLock Outcome.RETRY
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Outcome.DRAINED
        }
    }

    private suspend fun sendBatch(
        httpClient: OkHttpClient,
        records: List<ReplayPendingEventStore.Record>,
        drainKey: String,
        networkState: () -> Pair<Boolean, Boolean>,
        onCallStarted: (Call) -> Unit,
        onCallFinished: (Call) -> Unit,
    ): SendResult {
        val first = records.firstOrNull() ?: return SendResult(SendOutcome.ACKNOWLEDGED)
        if (records.any {
            it.baseUrl != first.baseUrl || it.projectId != first.projectId ||
                it.apiKey != first.apiKey || it.sessionId != first.sessionId ||
                it.installationId != first.installationId || it.policyToken != first.policyToken
        }) return SendResult(SendOutcome.TERMINAL)

        val events = JsonArray(records.map { record ->
            JsonObject(record.payload.toMutableMap().apply {
                put("event_id", JsonPrimitive(record.eventId))
                put("seq", JsonPrimitive(record.seq))
            })
        })
        val body = JsonObject(mapOf(
            "project_id" to JsonPrimitive(first.projectId),
            "api_key" to JsonPrimitive(first.apiKey),
            "session_id" to JsonPrimitive(first.sessionId),
            "installation_id" to JsonPrimitive(first.installationId),
            "events" to events,
        )).toString()
        val request = runCatching {
            Request.Builder()
                .url(Endpoints.url(first.baseUrl, Endpoints.REPLAY_EVENTS))
                .post(body.toRequestBody(mediaType))
                .header("Authorization", "Bearer ${first.apiKey}")
                .header("Content-Type", "application/json; charset=utf-8")
                .build()
        }.getOrElse { return SendResult(SendOutcome.TERMINAL) }

        val network = networkState()
        val call = httpClient.newCall(request)
        activeCalls.computeIfAbsent(drainKey) { ConcurrentHashMap.newKeySet() }.add(call)
        onCallStarted(call)
        val guarded = try {
            ReplayRuntimePolicy.executeWorkerCall(
                token = first.policyToken,
                connected = network.first,
                metered = network.second,
                call = call,
            )
        } catch (_: IOException) {
            return SendResult(SendOutcome.RETRY)
        } catch (_: Throwable) {
            return SendResult(SendOutcome.RETRY)
        } finally {
            activeCalls[drainKey]?.remove(call)
            onCallFinished(call)
        }
        if (guarded is ReplayRuntimePolicy.WorkerCallResult.Rejected) {
            return if (guarded.decision == ReplayRuntimePolicy.WorkerDecision.DISCARD) {
                SendResult(SendOutcome.POLICY_DISCARD)
            } else {
                SendResult(SendOutcome.RETRY)
            }
        }
        return (guarded as ReplayRuntimePolicy.WorkerCallResult.Executed).response.use { response ->
            when {
                response.isSuccessful -> {
                    val root = runCatching {
                        json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
                    }.getOrNull() ?: return@use SendResult(SendOutcome.RETRY)
                    when {
                        root["paused"]?.jsonPrimitive?.booleanOrNull == true -> SendResult(
                            SendOutcome.REMOTE_PAUSED,
                            root["paused_reason"]?.jsonPrimitive?.content,
                        )
                        root["ok"]?.jsonPrimitive?.booleanOrNull == true ->
                            SendResult(SendOutcome.ACKNOWLEDGED)
                        else -> SendResult(SendOutcome.RETRY)
                    }
                }
                response.code == 408 || response.code == 429 || response.code in 500..599 ->
                    SendResult(SendOutcome.RETRY)
                response.code in 400..499 -> SendResult(SendOutcome.TERMINAL)
                else -> SendResult(SendOutcome.RETRY)
            }
        }
    }

    internal fun currentNetwork(context: Context): Pair<Boolean, Boolean> = try {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE)
            as? ConnectivityManager ?: return false to true
        val network = manager.activeNetwork ?: return false to true
        val capabilities = manager.getNetworkCapabilities(network) ?: return false to true
        capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) to
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
    } catch (_: Throwable) {
        false to true
    }

    /**
     * Close the worker-vs-discard race even when the caller did not rotate the
     * project policy first. Calls already holding the session drain mutex are
     * cancelled; deletion then runs under that mutex so no later socket can
     * start from the retired snapshot.
     */
    suspend fun discardSession(
        store: ReplayPendingEventStore,
        baseUrl: String,
        projectId: String,
        sessionId: String,
        installationId: String,
    ) {
        val key = drainKey(baseUrl, projectId, sessionId, installationId)
        activeCalls[key]?.toList()?.forEach { runCatching { it.cancel() } }
        drainLocks.computeIfAbsent(key) { Mutex() }.withLock {
            activeCalls[key]?.toList()?.forEach { runCatching { it.cancel() } }
            store.removeSession(baseUrl, projectId, sessionId, installationId)
        }
    }

    private fun drainKey(
        baseUrl: String,
        projectId: String,
        sessionId: String,
        installationId: String,
    ): String = listOf(baseUrl, projectId, sessionId, installationId).joinToString("\u001f")

    private const val MAX_BATCH_SIZE = 100
}

/** Scheduling seam for durable replay metadata. */
internal fun interface ReplayEventWorkScheduler {
    fun enqueue(context: Context, record: ReplayPendingEventStore.Record): Boolean
}

internal object WorkManagerReplayEventWorkScheduler : ReplayEventWorkScheduler {
    override fun enqueue(context: Context, record: ReplayPendingEventStore.Record): Boolean =
        runCatching {
            val input = Data.Builder()
                .putString(ReplayEventWorker.KEY_BASE_URL, record.baseUrl)
                .putString(ReplayEventWorker.KEY_PROJECT_ID, record.projectId)
                .putString(ReplayEventWorker.KEY_API_KEY, record.apiKey)
                .putString(ReplayEventWorker.KEY_SESSION_ID, record.sessionId)
                .putString(ReplayEventWorker.KEY_INSTALLATION_ID, record.installationId)
                .build()
            val request = OneTimeWorkRequestBuilder<ReplayEventWorker>()
                // The immutable project cellular policy is enforced again by
                // ReplayRuntimePolicy immediately before the socket. CONNECTED
                // avoids stranding a restored job after Wi-Fi-only is loosened.
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(NetworkType.CONNECTED)
                        .build(),
                )
                .setInputData(input)
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
                .addTag("kixo-replay")
                .addTag("kixo-replay-events")
                .addTag("kixo-replay-session-${record.sessionId}")
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                workName(record),
                ExistingWorkPolicy.REPLACE,
                request,
            )
            true
        }.getOrElse {
            // Foreground flush still owns the same durable row. A later enqueue
            // or session/end recovery gets another scheduling opportunity.
            Log.d(TAG, "Unable to schedule durable replay-event drain", it)
            false
        }

    private fun workName(record: ReplayPendingEventStore.Record): String {
        val identity = listOf(
            record.baseUrl,
            record.projectId,
            record.sessionId,
            record.installationId,
        ).joinToString("\u001f")
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(identity.toByteArray(Charsets.UTF_8))
            .take(12)
            .joinToString("") { "%02x".format(it) }
        return "kixo-replay-events-$digest"
    }

    private const val TAG = "Kixo.ReplayEventWorker"
}

/** Process-death/offline drain for replay metadata sidecars. */
internal class ReplayEventWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        val baseUrl = inputData.getString(KEY_BASE_URL).orEmpty()
        val projectId = inputData.getString(KEY_PROJECT_ID).orEmpty()
        val apiKey = inputData.getString(KEY_API_KEY).orEmpty()
        val sessionId = inputData.getString(KEY_SESSION_ID).orEmpty()
        val installationId = inputData.getString(KEY_INSTALLATION_ID).orEmpty()
        if (baseUrl.isBlank() || projectId.isBlank() || apiKey.isBlank() ||
            sessionId.isBlank() || installationId.isBlank()
        ) return androidx.work.ListenableWorker.Result.failure()

        val client = UploadWorkerSingletons.httpClient
            ?: return androidx.work.ListenableWorker.Result.retry()
        return when (
            ReplayPendingEventDrain.drainSession(
                context = applicationContext,
                httpClient = client,
                store = ReplayPendingEventStore(applicationContext),
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                sessionId = sessionId,
                installationId = installationId,
            )
        ) {
            ReplayPendingEventDrain.Outcome.DRAINED ->
                androidx.work.ListenableWorker.Result.success()
            ReplayPendingEventDrain.Outcome.RETRY ->
                androidx.work.ListenableWorker.Result.retry()
        }
    }

    companion object {
        const val KEY_BASE_URL = "replay_event_base_url"
        const val KEY_PROJECT_ID = "replay_event_project_id"
        const val KEY_API_KEY = "replay_event_api_key"
        const val KEY_SESSION_ID = "replay_event_session_id"
        const val KEY_INSTALLATION_ID = "replay_event_installation_id"
    }
}
