package io.kixo.sdk.internal.replay

/**
 * Runtime configuration for the Android replay capture pipeline. Only fields
 * consumed by Android runtime paths live here; the project-controlled subset
 * is applied from `/api/sdk/config` by `QueueWiring`.
 *
 * **Why so many flags?** The iOS SDK's April 28 2026 perf-bisect
 * (see `feedback_perf_diagnosis.md` in the Kixo memory) taught us
 * that "the SDK is slow" reports usually come down to ONE subsystem,
 * not the whole pipeline. Granular flags let ops binary-search the
 * failing subsystem on a real device by toggling one flag at a time
 * via remote config — no app update required.
 *
 * **Defaults** mirror the iOS C.3 v3 `Config`:
 *  - `frameCaptureEnabled = true` — master gate; without it the SDK
 *    still emits tap metadata events but no Bitmap raster work.
 *  - `scrollEndCaptureEnabled = false` — the dirty-settle path already
 *    covers scroll changes; the project can opt into a dedicated frame.
 *  - `structuralSnapshotEnabled = false` — project/plan opt-in for the
 *    JSON view-tree sidecar.
 *  - `ocrEnabled = false` — project/plan opt-in for on-device ML Kit
 *    text recognition (never cloud OCR).
 *  - `maxConcurrentCaptures = 3` — semaphore ceiling on in-flight
 *    captures (briefing §3 R4 "bounded everything"). Tightened to
 *    1 under memory pressure (see [CaptureSlot]).
 *  - `maxConcurrentOcr = 4` — ML Kit Vision is parallelisable but
 *    each invocation pins ~5-15 MB of intermediate tensors. Hard cap
 *    keeps us safe on iPhone-class memory.
 *  - `replaySampleRate = 0.0` — fail closed until project policy
 *    supplies the effective sample rate. NOT the wire default (the
 *    sparse 2026-07 contract defaults a present-block missing rate to
 *    100%); see the field doc for why the compiled bootstrap stays 0.
 *    See [Sampler].
 *  - `jpegQuality = 15`, `captureScale = 0.85` — compatibility
 *    fallbacks match the canonical dashboard/server defaults.
 *
 * **Lifecycle:** instantiated by [ReplayController.start] and held
 * for the SDK lifetime. Project policy updates are applied through
 * [ReplayController.updateRemoteConfig] without requiring the host
 * application to reconfigure the SDK.
 *
 * **No serialisation annotation here.** This DTO never crosses the
 * wire; remote-config delivers individual fields via a separate
 * payload.
 */
internal data class ReplayConfig(
    /**
     * Master gate for Bitmap capture (pre + post + emergency). When
     * `false`, the SDK still emits tap metadata events but
     * [FrameSnapshotter] never runs → zero `View.draw()` work →
     * main-thread cost ≈ 0 ms per tap. Useful baseline test:
     * "is the SDK slow because of capture, or something else?"
     */
    val frameCaptureEnabled: Boolean = true,

    /**
     * Dedicated scroll-end FRAME capture.
     *
     * **DEFAULT OFF (AND-CAP-02, 2026-07-05 dirty-driven redesign).**
     * The dirty engine ([DirtyTracker] → settle capture) already
     * covers content that changes after a scroll, so a separate
     * scroll-end frame is redundant. The lightweight scroll EVENT row
     * (for the player timeline) is still emitted by Agent 8's
     * `ScrollEndDetector` regardless of this flag — this only gates
     * whether a scroll-end also forces a frame render. Operators can
     * flip it back on via remote config when investigating scroll UX.
     * Mirrors iOS `Config.scrollEndCaptureEnabled` (compiled default
     * FALSE since the dirty engine landed).
     */
    val scrollEndCaptureEnabled: Boolean = false,

    /**
     * Minimum seconds between consecutive scroll-end captures within
     * a session. Even an unbounded flick stream produces at most one
     * snapshot per "scroll burst followed by pause" — no spam.
     */
    val scrollEndMinIntervalSec: Double = 0.5,

    /**
     * Master gate for structural snapshot pipeline (view-tree walk +
     * JSON encode). ~8-15 ms main-thread when fired.
     *
     * **DEFAULT OFF (AND-CAP-03, 2026-07-05).** Mirrors the iOS
     * decision — the heavy structural pass is opt-in via remote config
     * (`replay.structuralEnabled`), not on by default. The
     * `replay-plan-gate` on the backend forces it false for non-
     * Enterprise plans anyway, so the SDK just faithfully applies
     * whatever the server sends. Disabled → player loses structural /
     * hybrid / wireframe modes; pixel mode still works. NOTE: the
     * view-tree walk still runs to compute masking regions for
     * PixelCopy capture even when this is off — this flag only gates
     * shipping the JSON sidecar.
     */
    val structuralSnapshotEnabled: Boolean = false,

    /**
     * ML Kit on-device text recognition. ~60-100 ms worker per tap on
     * mid-tier devices, off-main only.
     *
     * **DEFAULT OFF (AND-CAP-03, 2026-07-05).** Opt-in via remote
     * config (`replay.ocrEnabled`); Enterprise-gated server-side.
     * Mirrors iOS.
     *
     * **HARD RULE — see AGENT_BRIEFING §3 R1.** This is on-device ML
     * Kit (`com.google.mlkit:text-recognition`), NOT a cloud LLM.
     * Operator pays $0 per inference. Cloud OCR is server-side only,
     * gated behind operator-invoked chat actions.
     */
    val ocrEnabled: Boolean = false,

    /**
     * Cap on pipeline tasks across tap + scroll-end paths. Drop new
     * captures (fall back to metadata-only event) when at cap. Halves
     * to 1 under memory pressure (Agent 7's
     * [io.kixo.sdk.internal.lifecycle.MemoryPressure]).
     *
     * Why 3? On iPhone 17 Pro the iOS team measured 3 simultaneous
     * `drawHierarchy` raster pins as the safe ceiling — at 4+ we
     * started to see OOMs on 3 GB-class devices (iPhone 11/12). The
     * Android budget is similar; default cap = 3 unless operator
     * tunes via remote config.
     */
    val maxConcurrentCaptures: Int = 3,

    /**
     * Cap on concurrent ML Kit OCR tasks. Each invocation pins
     * intermediate tensors so unbounded fan-out at high tap rate can
     * exhaust the worker pool. Per AGENT_BRIEFING §3 R4 "bounded
     * everything" — never let a hot path become unbounded.
     */
    val maxConcurrentOcr: Int = 4,

    /**
     * Reservoir baseline sample rate (0.0..1.0). Independent of
     * trigger-based capture (rage-click / crash overrides force ON
     * for the affected session).
     *
     * The compiled value is DELIBERATELY zero, even under the sparse
     * 2026-07 wire contract where a present `dataCollection.replay`
     * block with an omitted `sampleRate` means 100%. That contract is
     * resolved by `ReplayDataConfig.effectiveSampleRateFraction()` at
     * every policy consumer (ReplayRuntimePolicy, QueueWiring's
     * `updateSampleRate` push, the ReplayController start/tap gates),
     * so by the time [ReplayController.start] runs on a server-
     * authorized path, `serverSampleRateOverride` already carries the
     * effective rate (1.0 when the field was omitted) and keeps overriding
     * this bootstrap across later stints. This field is only the verdict rate
     * when NO resolved project policy exists — a legacy/malformed
     * control-plane response must not silently opt a project into
     * replay, so that residual path stays fail-closed at 0.
     */
    val replaySampleRate: Double = 0.0,

    /** Project-controlled wall-clock cap for one replay stint. */
    val maxDurationMs: Long = 300_000L,

    // ─── AND-CAP-02 dirty-driven cadence (2026-07-05). Mirrors iOS
    //     `Config.postTapSettleMs` / `dirtyHeartbeatSec` /
    //     `captureMinIntervalMs`. Applied by [ReplayController] +
    //     [DirtyTracker]. ─────────────────────────────────────────

    /**
     * Settle delay (ms) between a dirty signal (tap / screen entry /
     * layout churn / scroll settle) and the capture it schedules. A
     * tap/scroll storm debounces into ONE capture at the trailing
     * edge. Clamped 100…5000 by [DirtyCadenceClamp.settleMs] when
     * threaded from remote config. Mirrors iOS default 500.
     */
    val postTapSettleMs: Long = 500L,

    /**
     * Dirty-heartbeat period (ms). While a stint is foregrounded and
     * the screen is dirty-but-settled, the heartbeat captures at this
     * cadence as a backstop. On a static screen the heartbeat does
     * nothing (dirty flag is clear). Clamped 1_000…60_000 by
     * [DirtyCadenceClamp.heartbeatMs]. Mirrors iOS `dirtyHeartbeatSec`
     * (5 s).
     */
    val dirtyHeartbeatMs: Long = 5_000L,

    /**
     * Global capture cadence floor (ms). A settle/heartbeat capture
     * whose predecessor rendered within this window is throttled and
     * re-armed. 0 = no throttle. Guards against a fast dirty stream
     * turning into a render-per-frame storm. Mirrors iOS
     * `captureMinIntervalMs`.
     */
    val captureMinIntervalMs: Long = 800L,

    // ─── AND-CAP-06 compression knobs (2026-07-05). heicQuality maps
    //     to `jpegQuality` on Android (we ship JPEG, not HEIC — see
    //     JpegEncoder). captureScale mirrors iOS. ──────────────────

    /**
     * Starting JPEG quality for the fit-to-cap encoder (1…100). The
     * encoder still steps DOWN from here to fit the 20 KB cap; this
     * only sets the ceiling. Remote-tunable via `replay.heicQuality`
     * (the cross-platform wire name — iOS HEIC quality is a 0-1
     * fraction, converted to 0-100 when threaded to Android). Compiled
     * fallback 15 matches the canonical server default (`0.15`).
     */
    val jpegQuality: Int = 15,

    /**
     * Frame render/downscale factor in (0,1]. Applied to the PixelCopy
     * destination + JPEG downscale. Lower = smaller GPU readback +
     * fewer bytes to compress. Remote-tunable via `replay.captureScale`
     * (clamped 0.3…1.0 by [DirtyCadenceClamp.captureScale]). Compiled
     * fallback 0.85 matches the canonical server default.
     */
    val captureScale: Float = 0.85f,
)
