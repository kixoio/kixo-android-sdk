package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Request body for `POST /api/sdk/init`. Hits the backend once on
 * SDK launch to fetch `release_id`, `data_collection`, and the
 * `paused` kill-switch state. Mirrors iOS `init` request shape (the
 * iOS path doesn't have a typed DTO — see `Kixo.swift` `fetchInit()`
 * — but the wire shape is the same).
 *
 * **Field contracts:**
 *
 *  - `platform`: hard-coded `"android"` (one valid value).
 *  - `bundle_id`: app's `applicationId` from BuildConfig.
 *  - `app_version`: human-readable version name (e.g. `"1.2.3"`).
 *  - `build`: stringified build number / version code.
 *  - `environment`: one of `"development" | "production"`,
 *    auto-detected from BuildConfig.DEBUG / FLAG_DEBUGGABLE per
 *    AGENT_BRIEFING.md §4. Operator can override via
 *    `Configuration.environment("development")`.
 *  - `sdk_version`: this SDK module's version string (BuildConfig
 *    constant `SDK_VERSION`).
 */
@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
@Serializable
internal data class InitRequest(
    @SerialName("project_id")
    val projectId: String,

    @SerialName("api_key")
    val apiKey: String,

    // Wave 6 fix: backend requires `platform` field. Without
    // @EncodeDefault(ALWAYS) the default `"android"` value gets
    // omitted under our `encodeDefaults = false` Json config →
    // backend returns 400 → init fails silently. Forces emit.
    @kotlinx.serialization.EncodeDefault(kotlinx.serialization.EncodeDefault.Mode.ALWAYS)
    @SerialName("platform")
    val platform: String = "android",

    @SerialName("bundle_id")
    val bundleId: String,

    @SerialName("app_version")
    val appVersion: String,

    @SerialName("build")
    val build: String,

    @SerialName("environment")
    val environment: String,

    @SerialName("sdk_version")
    val sdkVersion: String,
)
