package io.kixo.sdk.internal.push

import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Stores push attribution (campaign / delivery / push ids) for a
 * bounded window after the last `push_open`. While the window is
 * active, every outbound event inherits these as `attribution_*`
 * properties so the dashboard can attribute downstream conversions
 * back to the campaign that opened the session.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Push/PushAttributionStore.swift`
 * with two intentional differences:
 *
 *  1. **In-memory only on Android (v1).** iOS persists to
 *     `UserDefaults` so a crash inside the window survives relaunch.
 *     Android v1 ships pure-memory; the next milestone will add
 *     `SharedPreferences` persistence keyed by `anonymousId` (matching
 *     iOS's namespacing). Out-of-scope for this agent's slice.
 *  2. **Last-write-wins for properties already set on the event.** The
 *     `decorate` contract is "first-write-wins from explicit user
 *     properties": if the caller's event already has e.g. its own
 *     `attribution_campaign_id`, we leave it alone. iOS does this in
 *     the EventQueue; we move the merge into the store so callers
 *     can't accidentally clobber explicit values.
 *
 * Singleton via `object` because there's exactly one attribution
 * window per process — coupling it to the public-API facade
 * (`Kixo.reset()`) is the only sensible architecture and a
 * second instance would just race with the first.
 *
 * **Thread-safety**: a single [ReentrantLock] guards both the read
 * (`decorate`) and write (`recordOpen`, `clear`) paths. Read traffic
 * is once-per-event so the lock contention is negligible.
 */
internal object PushAttributionStore {

    private val lock = ReentrantLock()

    private var lastOpenAt: Long? = null
    private var lastCampaignId: String? = null
    private var lastDeliveryId: String? = null
    private var lastJobId: String? = null
    private var lastPushId: String? = null
    private var lastSendId: String? = null

    /**
     * Default attribution window. 30 minutes matches iOS and the
     * push-tracking memory note. Caller (Kixo facade) can override
     * by passing a custom value to [decorate]; recording always
     * just stamps the timestamp and lets the read path enforce the
     * window.
     */
    const val DEFAULT_WINDOW_MS: Long = 30L * 60 * 1000

    /**
     * Stamp a new attribution window. Called from `Kixo.logPushOpened`
     * AFTER the sanitizer has parsed the payload — only the routing
     * ids land here, never user content.
     *
     * Last-write-wins (overwrite, not merge): if a user opens push A,
     * then push B within the window, push B's attribution decorates
     * subsequent events. Matches standard multi-touch-attribution
     * defaults and iOS's behavior.
     */
    fun recordOpen(
        campaignId: String?,
        deliveryId: String?,
        pushId: String?,
        jobId: String? = null,
        sendId: String? = null,
        nowMs: Long = System.currentTimeMillis(),
    ) {
        lock.withLock {
            val hasTrustedId = listOf(campaignId, deliveryId, jobId, sendId)
                .any { !it.isNullOrBlank() }
            if (hasTrustedId) {
                lastOpenAt = nowMs
                lastCampaignId = campaignId
                lastDeliveryId = deliveryId
                lastJobId = jobId
                lastPushId = pushId
                lastSendId = sendId
            } else {
                clearLocked()
            }
        }
    }

    /**
     * Merge attribution properties into [eventProps] **without
     * overwriting** any keys already present. First-write-wins: an
     * event that explicitly sets `attribution_campaign_id` keeps its
     * value. The caller mutates and returns the same map for
     * fluent-style use in the EventQueue.
     *
     * If the window has expired (or `recordOpen` was never called),
     * this is a no-op. The store does NOT proactively clear on
     * expiry — the next `recordOpen` overwrites and the next
     * `clear()` (on `Kixo.reset()`) wipes; reads just gate on the
     * window. Cheaper than a scheduled timer.
     *
     * @return the same [eventProps] reference for chaining.
     */
    fun decorate(
        eventProps: MutableMap<String, Any?>,
        nowMs: Long = System.currentTimeMillis(),
        windowMs: Long = DEFAULT_WINDOW_MS,
    ): MutableMap<String, Any?> {
        lock.withLock {
            val openedAt = lastOpenAt ?: return eventProps
            val age = nowMs - openedAt
            // Negative `age` means clock moved backward (NTP correction
            // or a test setting `nowMs`). Treat as in-window — clearing
            // would surprise tests, and clock-skew "attribution" is
            // still attribution.
            if (age > windowMs) return eventProps

            // first-write-wins per the agent contract.
            if (!eventProps.containsKey("attribution_campaign_id")) {
                lastCampaignId?.let { eventProps["attribution_campaign_id"] = it }
            }
            if (!eventProps.containsKey("attribution_delivery_id")) {
                lastDeliveryId?.let { eventProps["attribution_delivery_id"] = it }
            }
            if (!eventProps.containsKey("attribution_job_id")) {
                lastJobId?.let { eventProps["attribution_job_id"] = it }
            }
            if (!eventProps.containsKey("attribution_push_id")) {
                lastPushId?.let { eventProps["attribution_push_id"] = it }
            }
            if (!eventProps.containsKey("attribution_send_id")) {
                lastSendId?.let { eventProps["attribution_send_id"] = it }
            }
            // Always include the age — this is purely diagnostic, not
            // user-supplied, so first-write-wins doesn't apply. Caps
            // dashboard's "how long after the open did this fire?"
            // analyses without an extra join.
            if (age >= 0) {
                eventProps["attribution_age_ms"] = age
            }
        }
        return eventProps
    }

    /**
     * `JsonObject` variant of [decorate], used by the analytics enqueue
     * chokepoint ([io.kixo.sdk.internal.queue.KixoEventQueueRef]) AFTER the
     * per-event PII sanitiser has run, so every outbound event inside the
     * push-open window inherits `attribution_campaign_id` / `_delivery_id` /
     * `_push_id` / `_age_ms`.
     *
     * Pre-fix this store was wired only into its own unit tests — the push
     * counterpart of the deferred AND-DL-09 wiring. It now shares the one
     * chokepoint with [io.kixo.sdk.internal.attribution.InstallAttributionStore]
     * (push decorates first; the install store's first-write-wins then fills any
     * remaining keys). First-write-wins; returns the SAME [props] reference on
     * the closed-window no-op fast path.
     */
    fun decorate(
        props: JsonObject,
        nowMs: Long = System.currentTimeMillis(),
        windowMs: Long = DEFAULT_WINDOW_MS,
    ): JsonObject {
        lock.withLock {
            val openedAt = lastOpenAt ?: return props
            val age = nowMs - openedAt
            if (age > windowMs) return props

            val out = LinkedHashMap<String, JsonElement>(props)
            putJsonIfAbsent(out, "attribution_campaign_id", lastCampaignId)
            putJsonIfAbsent(out, "attribution_delivery_id", lastDeliveryId)
            putJsonIfAbsent(out, "attribution_job_id", lastJobId)
            putJsonIfAbsent(out, "attribution_push_id", lastPushId)
            putJsonIfAbsent(out, "attribution_send_id", lastSendId)
            if (age >= 0 && !out.containsKey("attribution_age_ms")) {
                out["attribution_age_ms"] = JsonPrimitive(age)
            }
            return JsonObject(out)
        }
    }

    private fun putJsonIfAbsent(props: MutableMap<String, JsonElement>, key: String, value: String?) {
        if (value != null && !props.containsKey(key)) props[key] = JsonPrimitive(value)
    }

    /**
     * Wipe attribution. Called from `Kixo.reset()` (Agent 1) so a
     * user logout / identity rotation can't bleed campaign credit
     * into the next user's events. Also called from tests.
     */
    fun clear() {
        lock.withLock {
            clearLocked()
        }
    }

    private fun clearLocked() {
        lastOpenAt = null
        lastCampaignId = null
        lastDeliveryId = null
        lastJobId = null
        lastPushId = null
        lastSendId = null
    }

    /**
     * Test-only inspection of current state. NOT exported beyond
     * the package; production code must go through [decorate]
     * which enforces the window check.
     */
    internal fun snapshotForTests(): Triple<String?, String?, String?> {
        return lock.withLock {
            Triple(lastCampaignId, lastDeliveryId, lastPushId)
        }
    }
}
