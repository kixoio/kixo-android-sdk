package io.kixo.sdk.internal.attribution

import android.content.Context
import android.util.Log
import com.android.installreferrer.api.InstallReferrerClient
import com.android.installreferrer.api.InstallReferrerStateListener
import com.android.installreferrer.api.ReferrerDetails
import io.kixo.sdk.internal.attribution.ReferrerFetcher.FetchResult

/**
 * Thin wrapper over the async `InstallReferrerClient` bind/connect flow.
 *
 * Mechanics (developer.android.com/google/play/installreferrer/library):
 *   1. `newBuilder(context).build()` → `startConnection(listener)`.
 *   2. `onInstallReferrerSetupFinished(responseCode)` →
 *        - `OK`(0)                  read `installReferrer` ONCE, then
 *                                   `endConnection()`. Terminal-success.
 *        - `SERVICE_UNAVAILABLE`(1) transient → controller retries next launch.
 *        - `FEATURE_NOT_SUPPORTED`(2) terminal (old/absent Play Store, GMS-less).
 *        - else                     unknown → transient.
 *   3. `onInstallReferrerServiceDisconnected`(-1) transient.
 *
 * The client is `endConnection()`'d immediately after a single read — never
 * held open (primary-doc requirement).
 *
 * **§0 §15:** only the four PUBLIC `ReferrerDetails` getters are read —
 * `getInstallReferrer`, `getReferrerClickTimestampSeconds`,
 * `getInstallBeginTimestampSeconds`, `getGooglePlayInstantParam` (+
 * `getInstallVersion`). There are NO `*ServerSeconds` getters; we do NOT read
 * them. Click-injection is gated server-side on the Play-stamped click vs
 * install-begin ordering, not server-seconds.
 *
 * **R8/anti-crash:** the entire subsystem entry is behind an
 * [isAvailable] `Class.forName` check (AC-6). If a host strips the lib via
 * R8/dependency-exclusion, the SDK degrades to a logged no-op rather than
 * crashing.
 *
 * The wrapper is open + the actual bind is delegated to a [ClientFactory] so
 * unit tests inject a fake `InstallReferrerClient` without an emulator.
 */
internal class InstallReferrerClientWrapper(
    private val context: Context,
    private val clientFactory: ClientFactory = ClientFactory { ctx ->
        InstallReferrerClient.newBuilder(ctx).build()
    },
) : ReferrerFetcher {

    fun interface ClientFactory {
        fun create(context: Context): InstallReferrerClient
    }

    /**
     * Bind, read once, and callback. The callback fires exactly once per
     * [fetch] call. Never throws — any unexpected error becomes a
     * [ReferrerFetcher.FetchResult.TransientFailure] (so a flaky bind retries)
     * unless the lib is absent (`TerminalFailure`).
     */
    override fun fetch(callback: (FetchResult) -> Unit) {
        if (!isAvailable()) {
            Log.w(TAG, "InstallReferrer library not on classpath; referrer read skipped (no-op).")
            callback(FetchResult.TerminalFailure("library_absent"))
            return
        }
        val client: InstallReferrerClient = try {
            clientFactory.create(context)
        } catch (t: Throwable) {
            Log.w(TAG, "InstallReferrerClient build failed", t)
            callback(FetchResult.TransientFailure("build_failed"))
            return
        }

        val fired = java.util.concurrent.atomic.AtomicBoolean(false)
        fun deliver(result: FetchResult) {
            if (fired.compareAndSet(false, true)) callback(result)
        }

        try {
            client.startConnection(object : InstallReferrerStateListener {
                override fun onInstallReferrerSetupFinished(responseCode: Int) {
                    when (responseCode) {
                        InstallReferrerClient.InstallReferrerResponse.OK -> {
                            val result = try {
                                val r: ReferrerDetails = client.installReferrer
                                FetchResult.Success(toSnapshot(r))
                            } catch (t: Throwable) {
                                Log.w(TAG, "getInstallReferrer() failed after OK", t)
                                FetchResult.TransientFailure("read_failed")
                            } finally {
                                runCatching { client.endConnection() }
                            }
                            deliver(result)
                        }

                        InstallReferrerClient.InstallReferrerResponse.FEATURE_NOT_SUPPORTED -> {
                            runCatching { client.endConnection() }
                            deliver(FetchResult.TerminalFailure("feature_not_supported"))
                        }

                        InstallReferrerClient.InstallReferrerResponse.SERVICE_UNAVAILABLE -> {
                            runCatching { client.endConnection() }
                            deliver(FetchResult.TransientFailure("service_unavailable"))
                        }

                        else -> {
                            runCatching { client.endConnection() }
                            deliver(FetchResult.TransientFailure("unknown_$responseCode"))
                        }
                    }
                }

                override fun onInstallReferrerServiceDisconnected() {
                    // SERVICE_DISCONNECTED (-1): transient (Play Store updated
                    // in bg). The controller owns the bounded retry; just
                    // surface it. endConnection() is implicit on disconnect.
                    deliver(FetchResult.TransientFailure("service_disconnected"))
                }
            })
        } catch (t: Throwable) {
            // A throw out of startConnection (e.g. a security exception on a
            // locked-down ROM) is transient — try again next launch.
            Log.w(TAG, "startConnection threw", t)
            runCatching { client.endConnection() }
            deliver(FetchResult.TransientFailure("connect_threw"))
        }
    }

    private fun toSnapshot(r: ReferrerDetails): ReferrerSnapshot = ReferrerSnapshot(
        referrerUrl = runCatching { r.installReferrer }.getOrDefault(""),
        clickTsSeconds = runCatching { r.referrerClickTimestampSeconds }.getOrDefault(0L),
        installBeginTsSeconds = runCatching { r.installBeginTimestampSeconds }.getOrDefault(0L),
        installVersion = runCatching { r.installVersion }.getOrNull(),
        googlePlayInstantParam = runCatching { r.googlePlayInstantParam }.getOrDefault(false),
    )

    companion object {
        private const val TAG = "Kixo.InstallReferrer"

        /**
         * R8/strip guard. `true` iff the InstallReferrer lib is on the runtime
         * classpath. Cached after first resolution (the result is process-stable
         * — a class either loads or it doesn't).
         */
        @Volatile
        private var availabilityCache: Boolean? = null

        fun isAvailable(): Boolean {
            availabilityCache?.let { return it }
            val resolved = runCatching {
                Class.forName("com.android.installreferrer.api.InstallReferrerClient")
                true
            }.getOrDefault(false)
            availabilityCache = resolved
            return resolved
        }

        /** Test-only override of the availability cache. */
        @androidx.annotation.VisibleForTesting
        fun setAvailableForTest(value: Boolean?) {
            availabilityCache = value
        }
    }
}
