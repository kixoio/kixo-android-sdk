package io.kixo.sdk.internal.attribution

/**
 * Pulls the deep-link URL out of a RAW push payload so a push tap can route
 * through the shared `Kixo.handleDeepLink` path (AND-DL-11 — close the push
 * actionUrl open-gap).
 *
 * ### Why this lives here (not inline in the sanitizer / facade)
 * The push pipeline delivers the deep-link URL under one of the keys
 * [DEEP_LINK_KEYS] (`deep_link` / `link` / `url`). The
 * [io.kixo.sdk.internal.push.PushPayloadSanitizer] *strips* that URL down to a
 * `has_deep_link: true` flag for the `push_open` analytics event (privacy: the
 * URL is never put on the wire). So the URL the host should ROUTE to must be
 * read from the **un-sanitized** payload — this extractor is that single,
 * unit-testable read. The key ORDER MUST stay in lock-step with the value the
 * sanitizer recognised when it set `has_deep_link=true` so the routed URL is
 * exactly the flagged one — and it DOES, because [DEEP_LINK_KEYS] is now the
 * SINGLE owned list: `PushPayloadSanitizer.sanitize` spreads THIS constant into
 * its `firstNonEmptyString(...)` deep-link check rather than re-spelling the
 * keys. A reorder therefore moves both sides at once; they cannot diverge.
 * [io.kixo.sdk.internal.push.PushSanitizerDeepLinkKeyOrderTest] is the
 * cross-module guard that pins the routed-URL ⇆ flag agreement on a multi-key
 * fixture (not a hardcoded-literal restatement of the list).
 */
internal object PushDeepLinkExtractor {

    /**
     * Push-payload keys that may carry the deep-link URL, in priority order.
     * The SINGLE owned source of this set + order — `PushPayloadSanitizer`
     * references THIS constant (spread into its `firstNonEmptyString(...)`
     * has-deep-link check) so the routed URL and the `has_deep_link` flag are
     * decided by one list, never two drifting spellings.
     */
    val DEEP_LINK_KEYS: List<String> = listOf("deep_link", "link", "url")

    /** First non-blank string value among [DEEP_LINK_KEYS], or `null` when the
     *  push carried no deep link. Tolerant of non-String values (ignored). */
    fun extract(payload: Map<String, Any?>): String? {
        for (key in DEEP_LINK_KEYS) {
            val v = payload[key]
            if (v is String && v.isNotBlank()) return v
        }
        return null
    }
}
