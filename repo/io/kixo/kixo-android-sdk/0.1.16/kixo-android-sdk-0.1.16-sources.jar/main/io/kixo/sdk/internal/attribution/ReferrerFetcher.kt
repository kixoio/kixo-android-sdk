package io.kixo.sdk.internal.attribution

/**
 * The seam between [InstallReferrerController] and the actual Play Install
 * Referrer bind/connect ([InstallReferrerClientWrapper]). An interface so unit
 * tests substitute a deterministic fetcher (canned [FetchResult]) without an
 * emulator / the real `InstallReferrerClient`.
 */
internal interface ReferrerFetcher {

    /** Outcome of a single read attempt. */
    sealed class FetchResult {
        /** A successful single read. */
        data class Success(val snapshot: ReferrerSnapshot) : FetchResult()

        /** Recoverable on a later launch (service unavailable / disconnected). */
        data class TransientFailure(val reason: String) : FetchResult()

        /** Will never succeed (feature unsupported / lib stripped). */
        data class TerminalFailure(val reason: String) : FetchResult()
    }

    /** Bind, read once, and deliver exactly one [FetchResult] to [callback]. */
    fun fetch(callback: (FetchResult) -> Unit)
}
