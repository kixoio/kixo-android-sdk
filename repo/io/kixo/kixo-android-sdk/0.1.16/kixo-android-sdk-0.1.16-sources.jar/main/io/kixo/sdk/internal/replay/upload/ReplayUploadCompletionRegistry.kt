package io.kixo.sdk.internal.replay.upload

import java.util.concurrent.ConcurrentHashMap

/**
 * Process-local bridge from reflective WorkManager workers back to the live
 * uploader that owns their rescheduling listener. Process death clears both
 * sides; WorkManager remains authoritative for the durable request itself.
 */
internal object ReplayUploadCompletionRegistry {
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()

    fun register(localPath: String, callback: () -> Unit) {
        callbacks[localPath] = callback
    }

    fun unregister(localPath: String) {
        callbacks.remove(localPath)
    }

    fun notifyTerminal(localPath: String) {
        callbacks.remove(localPath)?.invoke()
    }
}
