package io.kixo.sdk.internal.replay

import android.graphics.Rect
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.EditText
import io.kixo.sdk.internal.screen.Role
import io.kixo.sdk.internal.screen.RoleClassifier
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Recursively walks a `View` tree producing a JSON DOM-like
 * structural snapshot. Companion to [FrameSnapshotter] — pixel and
 * structural data ship together so the dashboard player can render
 * Pixel / Structural / Hybrid / Wireframe / Compare modes.
 *
 * **iOS counterpart**: [StructuralSnapshotter.swift] which runs four
 * passes (UIView walk + a11y tree + CALayer walk + SwiftUI Mirror
 * reflection) and merges them. Android has no SwiftUI/CALayer
 * analogue — the View hierarchy IS the source of truth — so we get
 * away with one pass + the [RoleClassifier] tagger.
 *
 * **Privacy** (briefing §3 R2):
 *  1. Every text node passes through the injected [piiSanitizer]
 *     BEFORE entering the JSON. So a `TextView` showing
 *     `"hi alice@example.com"` lands in JSON as
 *     `"hi [email]"`.
 *  2. Whole subtrees rooted at a [shouldRedactSubtree] view (password
 *     `EditText`, [WebView], or `kxRedact`-tagged view per Agent 10's
 *     `StructuralRedactionRules`) are emitted as
 *     `{"redacted": true, "type": "...", "bounds": [...]}`
 *     with no children. The frame raster overlay is handled by Agent
 *     14's encoder.
 *
 * **Output schema** (mirrors iOS shape; Android-only fields marked):
 * ```
 * {
 *   "v": 2,
 *   "viewport": { "x": 0, "y": 0, "w": 1080, "h": 2400 },
 *   "build_hash": "abcdef…",
 *   "root": <Node>
 * }
 * Node = {
 *   "id": "resource_entry_name | null",
 *   "type": "Button | TextView | ImageView | ...",
 *   "role": "Button | Text | Image | ...",
 *   "bounds": [left, top, width, height],
 *   "text": "<sanitised text or null>",
 *   "redacted": false,
 *   "children": [ <Node>, … ]
 * }
 * ```
 *
 * **Performance budget** (mid-tier device, 200-node hierarchy):
 *  - Tree walk: ~2-3 ms (dominated by `View.getResources()` lookups)
 *  - PII regex per text: ~10-50 µs per node
 *  - JSON encode: handled by caller off-main
 *
 * **Thread**: MUST be called on the main thread — `View.getX/Y/Width`
 * are not thread-safe. Caller serialises the resulting `JsonObject`
 * off-main if needed.
 *
 * **Role tagger.** Uses Agent 9's [RoleClassifier] for the `role`
 * field. The tagger is content-invariant (briefing R8) so the same
 * screen across light/dark + locale + density yields the same role
 * tree.
 */
internal class StructuralSnapshotter(
    private val piiSanitizer: (String) -> String = { it },
    /**
     * Hook for Agent 10's `StructuralRedactionRules.shouldRedact(view)`.
     * Returns `true` if the entire subtree rooted at the supplied
     * View should be emitted as `{"redacted": true}` (no children,
     * no text). Defaults to a structural fallback that catches
     * password-input EditTexts + WebViews + the `kxRedact` tag —
     * the absolute minimum to comply with briefing R2 even when
     * Agent 10's wiring isn't yet in place.
     */
    private val shouldRedactSubtree: (View) -> Boolean = ::defaultShouldRedactSubtree,
    /** Maximum depth to walk before truncating — defends against pathological hierarchies. */
    private val maxDepth: Int = 12,
    /** Cap on total nodes captured. */
    private val maxNodes: Int = 200,
    /** Skip subtrees smaller than this on either axis (px). */
    private val minVisiblePx: Int = 4,
    /**
     * Defensive ceiling for the REDACTION walk ONLY (NOT the structural
     * digest — see [maxNodes]). The redaction walk MUST be complete
     * (partial masking = a privacy leak), so it does not share the small
     * digest cap; this is a very-high anti-runaway bound against a truly
     * pathological tree. On hitting it the walk FAILS SAFE — the caller
     * treats the frame as un-maskable and drops it, never ships a partial
     * mask. Chosen high enough (5000) that no real screen reaches it.
     */
    private val maxRedactionNodes: Int = 5000,
) {

    /**
     * Snapshot the supplied view at its current bounds. Returns
     * `null` when the view has zero bounds (off-screen or not laid
     * out yet). The returned [JsonObject] is the FULL document — has
     * `viewport`, `build_hash`, and `root` — ready for upload.
     *
     * Walks at most [maxNodes] views and at most [maxDepth] deep.
     */
    fun snapshot(view: View): JsonObject? {
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) return null

        // Build digest BEFORE the recursive walk so [stableHash]
        // doesn't see truncation due to the maxNodes cap. The hash
        // captures the structural skeleton — same screen across
        // sessions = same hash, regardless of content.
        val classDigest = StringBuilder(256)
        val nodeCount = IntArray(1)

        val rootNode = buildNode(
            view = view,
            depth = 0,
            digest = classDigest,
            nodeCounter = nodeCount,
        ) ?: return null

        return buildJsonObject {
            put("v", 2)
            put("viewport", buildJsonObject {
                put("x", 0)
                put("y", 0)
                put("w", width)
                put("h", height)
            })
            put("build_hash", stableHash(classDigest.toString()))
            put("root", rootNode)
        }
    }

    /**
     * **AND-CAP-02 skip-unchanged signature.** Compute a content-aware
     * signature WITHOUT allocating the full JSON doc. A static screen
     * yields an identical signature across captures so the controller
     * can skip the encode/upload; ANY visible change advances it.
     *
     * The signature folds in, per node (in deterministic depth-first
     * order): `depth:className`, the on-screen BOUNDS (left/top/width/
     * height in window space), the SCROLL OFFSET (scrollX/scrollY), and
     * for `TextView` / `EditText` a cheap HASH of the displayed text.
     * This defeats the "structure-stable but content-changed" freeze
     * cases the depth+class-only signature missed:
     *   - a `RecyclerView` feed scrolling (bounds + scroll offsets move,
     *     recycled rows show new text);
     *   - in-place text updates (same layout, new label).
     *
     * **Privacy.** The text is HASHED, never stored raw — the signature
     * is a 16-char FNV hex, so no PII leaves the device via this path.
     * We deliberately EXCLUDE volatile fields that would churn the
     * signature without a user-visible change: a focused `EditText`'s
     * cursor position / selection is ignored (only its text hash folds
     * in). Pure pixel churn inside identical structure+bounds+text
     * (video, `setImageBitmap` with the same layout) is NOT reflected
     * here — the controller handles that via the DRAW-lane bypass.
     *
     * Returns `null` for a zero-bounds view. Cheap — same walk as
     * [snapshot] but no node objects.
     *
     * **MUST be called on the main thread** (view geometry reads).
     */
    fun structuralSignature(view: View): String? {
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) return null
        val digest = StringBuilder(256)
        val counter = IntArray(1)
        val loc = IntArray(2)
        digestWalk(view, depth = 0, digest = digest, counter = counter, loc = loc)
        return stableHash(digest.toString())
    }

    private fun digestWalk(
        view: View,
        depth: Int,
        digest: StringBuilder,
        counter: IntArray,
        loc: IntArray,
    ) {
        if (counter[0] >= maxNodes) return
        if (view.visibility != View.VISIBLE) return
        if (view.alpha < 0.01f) return
        val w = view.width
        val h = view.height
        if (w < minVisiblePx || h < minVisiblePx) return
        // Window-space position — folds scroll-driven movement (a feed
        // row that scrolled up has a smaller `top`) into the signature.
        view.getLocationInWindow(loc)
        appendNodeDigest(
            digest = digest,
            depth = depth,
            className = view.javaClass.simpleName,
            left = loc[0],
            top = loc[1],
            width = w,
            height = h,
            scrollX = view.scrollX,
            scrollY = view.scrollY,
            textHash = textContentHash(view),
        )
        counter[0]++
        if (depth >= maxDepth || view !is ViewGroup) return
        for (i in 0 until view.childCount) {
            if (counter[0] >= maxNodes) break
            val child = view.getChildAt(i) ?: continue
            digestWalk(child, depth + 1, digest, counter, loc)
        }
    }

    /**
     * A cheap 64-bit FNV hash of a `TextView` / `EditText`'s displayed
     * text, or `null` for a non-text view / empty text. Used ONLY inside
     * the skip-unchanged signature so a content change on a
     * structurally-stable screen (new feed text, an updated label)
     * advances the signature. The raw text NEVER enters the signature —
     * only this hash — so no PII leaks. We include `EditText` text (typed
     * content DOES change the screen and must not be deduped away) but
     * NOT the cursor / selection (volatile, no user-visible change).
     */
    private fun textContentHash(view: View): String? {
        if (view is android.widget.TextView) {
            val raw = view.text?.toString() ?: return null
            if (raw.isEmpty()) return null
            return stableHash(raw)
        }
        return null
    }

    /**
     * **AND-CAP-01 masking source.** Walk the view tree and collect
     * window-space [Rect]s for every subtree that [shouldRedactSubtree]
     * flags (password fields, WebViews, `kxRedact`-tagged views,
     * SurfaceView/GL). These are the regions [FrameSnapshotter]
     * composites opaque rects over on the PixelCopy bitmap — PixelCopy
     * grabs raw window pixels with NO per-view redaction, so masking
     * comes from this pass (Sentry's model: pixels + view-tree-for-
     * mask).
     *
     * Rects are in WINDOW coordinates ([View.getLocationInWindow]) —
     * the same space PixelCopy captures — so they line up 1:1 before
     * the caller applies [ReplayConfig.captureScale]. Clipped to the
     * decor bounds. Returns an empty list for a screen with no PII.
     *
     * **Completeness is a hard safety requirement.** Unlike [snapshot] /
     * [structuralSignature] (which cap at [maxNodes] / [maxDepth] to
     * bound the uploaded JSON + de-dup cost), the redaction walk must be
     * COMPLETE — a sensitive view missed on a complex screen ships
     * UNMASKED. So this walk does NOT apply the small digest node cap and
     * does NOT stop at [maxDepth]. It stays cheap by SELF-PRUNING:
     *  - a `View.GONE` subtree is skipped entirely — it's zero-size, not
     *    laid out, absent from the PixelCopy pixels, and can't become
     *    visible without a layout pass that re-triggers dirty;
     *  - a [shouldRedactSubtree] view adds ONE rect and we do NOT descend
     *    (the whole subtree is masked by that rect).
     * That bounds cost to the laid-out, non-redacted node count.
     *
     * **REDACTION MUST OVER-MASK — it is NOT the digest walk.** Unlike the
     * digest / [buildNode] walk (which prunes `INVISIBLE` / `alpha≈0`
     * subtrees for dedup + JSON fidelity), the redaction walk NEVER prunes
     * on visibility-below-GONE or on alpha, because:
     *  - PixelCopy reads POST-COMPOSITE surface pixels off SurfaceFlinger,
     *    NOT a draw-time visibility cull — a view at alpha in (0, 0.01) is
     *    faintly composited and its legible pixels ARE in the readback;
     *  - the rects are collected synchronously at request time but the
     *    PixelCopy composite happens ~2-16 ms LATER on the callback thread
     *    (TOCTOU) — a redacted view that is `INVISIBLE` / alpha≈0 NOW but
     *    `VISIBLE` a frame later at composite time (every fade / slide
     *    enter animation of a login / bottom-sheet password/email field —
     *    the [DirtyTracker] `OnDrawListener` fires each animation frame and
     *    schedules a mid-fade capture) would otherwise ship UNMASKED.
     * Over-masking a currently-invisible / transparent sensitive view is
     * SAFE (it blacks out that view's own blank layout region — no visual
     * harm, no leak); "barely visible / transiently hidden" is NOT "nothing
     * to mask". So we descend into non-GONE ancestors regardless of their
     * visibility/alpha and emit a rect for any [shouldRedactSubtree] view.
     *
     * **Fail-safe, never partial.** Against a truly pathological tree a
     * defensive [maxRedactionNodes] ceiling applies; on hitting it we do
     * NOT return a partial list — we return `null`, the un-maskable
     * sentinel, so the caller DROPS the frame (over-mask by dropping)
     * rather than shipping some views unmasked.
     *
     * **MUST be called on the main thread** (view geometry reads).
     *
     * @return the collected rects, or `null` when the walk could not be
     *   completed (defensive ceiling hit) → caller must drop the frame.
     */
    fun collectRedactionRects(view: View): List<Rect>? {
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) return emptyList()
        val out = ArrayList<Rect>(4)
        val origin = IntArray(2)
        view.getLocationInWindow(origin)
        val originX = origin[0]
        val originY = origin[1]
        val bounds = Rect(originX, originY, originX + width, originY + height)
        val counter = IntArray(1)
        val complete = collectRects(view, depth = 0, bounds = bounds, out = out, counter = counter)
        // Incomplete walk (pathological tree hit the ceiling) → un-maskable
        // sentinel. Never ship a partially-masked frame.
        return if (complete) out else null
    }

    /**
     * Recursive redaction collector. Returns `false` when the walk
     * aborted on the defensive [maxRedactionNodes] ceiling (un-maskable),
     * `true` when it completed (possibly self-pruned). A `View.GONE`
     * subtree is skipped (zero-size, not laid out, not composited → no
     * mask needed) but still counts as a COMPLETE prune. A redacted
     * subtree adds one rect and does not descend.
     *
     * OVER-MASKS by design — see [collectRedactionRects]: this walk does
     * NOT prune on `INVISIBLE` / `alpha≈0` (post-composite pixels + async
     * TOCTOU make "barely visible / transiently hidden" reachable in the
     * shipped frame). It emits a rect for a redactable view even when that
     * view is `INVISIBLE` / low-alpha, and descends into a non-GONE (but
     * currently-invisible / low-alpha) ancestor so a redactable descendant
     * under it is still found and masked.
     */
    private fun collectRects(
        view: View,
        depth: Int,
        bounds: Rect,
        out: MutableList<Rect>,
        counter: IntArray,
    ): Boolean {
        // Defensive anti-runaway ceiling — NOT the structural digest cap.
        // Hitting it means we could NOT enumerate the tree; signal
        // incomplete so the caller drops the frame.
        if (counter[0] >= maxRedactionNodes) return false
        counter[0]++

        // Prune ONLY GONE: zero-size, not laid out, not composited, and
        // can't become visible without a layout pass that re-triggers
        // dirty (a fresh redaction walk). NEVER prune on INVISIBLE or on
        // alpha — those are still composited (or become so mid-fade a
        // frame after collection, before the async PixelCopy composite),
        // so their sensitive pixels can reach the shipped frame. We
        // over-mask them instead (see [collectRedactionRects]).
        if (view.visibility == View.GONE) return true

        if (shouldRedactSubtree(view)) {
            // Window-space bounds valid even for a laid-out-but-INVISIBLE /
            // low-alpha view — getLocationInWindow + width/height, NOT
            // getGlobalVisibleRect (which returns false / an empty rect for
            // an invisible view), so an over-masked invisible view still
            // yields a real rect.
            val loc = IntArray(2)
            view.getLocationInWindow(loc)
            val r = Rect(loc[0], loc[1], loc[0] + view.width, loc[1] + view.height)
            if (r.intersect(bounds) && r.width() > 0 && r.height() > 0) {
                out.add(r)
            }
            // Whole subtree is masked by this one rect — do not descend.
            return true
        }

        // NB: NO maxDepth cap here — the walk must be complete. It
        // self-prunes on hidden + redacted subtrees above, which bounds
        // cost to visible, non-redacted nodes.
        if (view !is ViewGroup) return true
        for (i in 0 until view.childCount) {
            val child = view.getChildAt(i) ?: continue
            if (!collectRects(child, depth + 1, bounds, out, counter)) return false
        }
        return true
    }

    /**
     * Recursive walker. Returns `null` for nodes we elect to skip
     * entirely (off-screen / too small / over-cap). The decision to
     * include or skip is layered:
     *
     *   1. Cap reached → skip (would force truncation anyway)
     *   2. Depth reached → emit a leaf with no children
     *   3. Hidden / `View.GONE` / alpha=0 → skip
     *   4. Bounds < [minVisiblePx] → skip
     *   5. [shouldRedactSubtree] true → emit redacted leaf, no children
     *   6. Default → emit node + recurse children
     */
    private fun buildNode(
        view: View,
        depth: Int,
        digest: StringBuilder,
        nodeCounter: IntArray,
    ): JsonElement? {
        if (nodeCounter[0] >= maxNodes) return null
        if (view.visibility != View.VISIBLE) return null
        if (view.alpha < 0.01f) return null
        val width = view.width
        val height = view.height
        if (width < minVisiblePx || height < minVisiblePx) return null

        val role = RoleClassifier.classify(view)
        val type = view.javaClass.simpleName

        // Append to digest BEFORE bumping the counter so the hash
        // reflects the actual walk order even on truncation.
        digest.append(depth).append(':').append(type).append('|')
        nodeCounter[0]++

        val resourceId: String? = try {
            val rid = view.id
            if (rid == View.NO_ID || rid == 0) null
            else view.resources.getResourceEntryName(rid)
        } catch (_: Throwable) {
            null
        }

        val absLeft = IntArray(2)
        view.getLocationInWindow(absLeft)

        // Redaction: emit a placeholder node. No text, no children.
        // Agent 14's encoder rasterises the matching opaque rect
        // into the bitmap before encode (briefing R2: "frames with
        // PII never leave device unredacted").
        if (shouldRedactSubtree(view)) {
            return buildJsonObject {
                put("id", resourceId?.let(::JsonPrimitive) ?: JsonNull)
                put("type", type)
                put("role", role.wireName())
                put("bounds", boundsArray(absLeft[0], absLeft[1], width, height))
                put("text", JsonNull)
                put("redacted", true)
                put("children", JsonArray(emptyList()))
            }
        }

        val sanitisedText: String? = extractText(view)?.let { raw ->
            if (raw.isEmpty()) null else piiSanitizer(raw)
        }

        val children: List<JsonElement> =
            if (depth >= maxDepth || view !is ViewGroup) {
                emptyList()
            } else {
                buildList {
                    for (i in 0 until view.childCount) {
                        val child = view.getChildAt(i) ?: continue
                        if (nodeCounter[0] >= maxNodes) break
                        buildNode(child, depth + 1, digest, nodeCounter)
                            ?.let(::add)
                    }
                }
            }

        return buildJsonObject {
            put("id", resourceId?.let(::JsonPrimitive) ?: JsonNull)
            put("type", type)
            put("role", role.wireName())
            put("bounds", boundsArray(absLeft[0], absLeft[1], width, height))
            put("text", sanitisedText?.let(::JsonPrimitive) ?: JsonNull)
            put("redacted", false)
            put("children", JsonArray(children))
        }
    }

    /**
     * Build the standard `[left, top, width, height]` JSON array.
     * Centralised because the redacted-leaf and full-node paths
     * both emit the same shape — and `JsonArrayBuilder.add` accepts
     * only [JsonElement] so we wrap each Int in [JsonPrimitive] in
     * one place.
     */
    private fun boundsArray(left: Int, top: Int, width: Int, height: Int): JsonArray =
        JsonArray(
            listOf(
                JsonPrimitive(left),
                JsonPrimitive(top),
                JsonPrimitive(width),
                JsonPrimitive(height),
            )
        )

    /**
     * Pull a representative text label off a view if available.
     * Order of precedence (matches iOS [StructuralSnapshotter] and
     * the dashboard player's expectation):
     *   1. `TextView.text` — covers Button, EditText (non-password),
     *      and all Material variants.
     *   2. `View.contentDescription` — accessibility label.
     *
     * Returns `null` for views with no text. We deliberately do NOT
     * read `EditText.hint` — hints are content-invariant and would
     * still leak if a hint contained sensitive copy ("Enter your
     * SSN"). Hints stay as `null`; player surfaces "edit field"
     * placeholder generically.
     */
    private fun extractText(view: View): String? {
        // EditText family is NEVER read here. Password EditTexts are
        // caught by the redaction subtree above; non-password EditTexts
        // can still hold typed PII (the user's entered email mid-form,
        // unsubmitted message text, etc.) so we treat them as opaque.
        // The PII regex pass on whatever DOES make it to text would
        // still catch these on a per-string basis, but we err on the
        // side of "edit fields stay blank in the structural sidecar"
        // because their typed content is the most user-sensitive in
        // the whole hierarchy.
        if (view is EditText) return null

        if (view is android.widget.TextView) {
            val raw = view.text?.toString() ?: ""
            if (raw.isNotEmpty()) return raw
        }
        val cd = view.contentDescription?.toString()
        if (!cd.isNullOrEmpty()) return cd
        return null
    }

    companion object {
        /**
         * **AND-CAP-02 — pure per-node digest fold.** Appends one node's
         * content-aware skeleton to [digest] in a fixed field order.
         * Split out of [digestWalk] so the signature contract (bounds +
         * scroll + text-hash change the digest; cursor/selection does
         * NOT — it's never passed in) is unit-testable without a live
         * `View` tree. Field order is fixed and delimited so two nodes
         * can't alias by concatenation.
         *
         * [textHash] is a HASH of the text (via [textContentHash]) or
         * `null` for a non-text / empty node — the raw text never enters
         * the digest.
         */
        @JvmStatic
        internal fun appendNodeDigest(
            digest: StringBuilder,
            depth: Int,
            className: String,
            left: Int,
            top: Int,
            width: Int,
            height: Int,
            scrollX: Int,
            scrollY: Int,
            textHash: String?,
        ) {
            digest.append(depth).append(':').append(className)
                .append('@').append(left).append(',').append(top)
                .append('x').append(width).append(',').append(height)
                .append('s').append(scrollX).append(',').append(scrollY)
            if (textHash != null) digest.append('t').append(textHash)
            digest.append('|')
        }

        /**
         * FNV-1a 64-bit over the class-digest. Stable across SDK
         * versions because [RoleClassifier.code] is fixed and the
         * walker emits in deterministic depth-first order.
         *
         * Why FNV-1a, not SHA-256: this is for de-dup, not crypto.
         * FNV-1a is ~10× faster, has 0 collisions in our test
         * corpus, and produces a 16-char hex string which fits
         * cleanly in CH `LowCardinality(String)` column with low
         * cardinality.
         */
        internal fun stableHash(input: String): String {
            // FNV-1a 64-bit
            var hash = 0xcbf29ce484222325uL
            val prime = 0x00000100000001B3uL
            for (i in input.indices) {
                hash = hash xor input[i].code.toULong()
                hash *= prime
            }
            return hash.toString(16).padStart(16, '0')
        }

        /**
         * Default `shouldRedactSubtree` heuristic — used when
         * Agent 10's `StructuralRedactionRules` isn't wired yet.
         * Catches the briefing-R2 minimums:
         *   - Password [EditText] (any of 4 password input-type
         *     variants).
         *   - [WebView] (always opaque — DOM contents change every
         *     navigation).
         *   - SurfaceView / TextureView / GLSurfaceView **and any
         *     subclass** (matched by TYPE via the shared
         *     [FrameSnapshotter.isSurfaceLike] — see FIX 2): PixelCopy
         *     captures their raw pixels (camera / video / GL / map) so
         *     they MUST be masked, and `View.draw()` can't read them back
         *     anyway.
         *   - Any view tagged via `view.setTag(R.id.kixo_redact_tag, true)`
         *     by the host app — the public Agent 1 API
         *     `Kixo.markAsSensitive(view)` flips this. Captured here
         *     as a string-tag fallback for tests.
         */
        @JvmStatic
        fun defaultShouldRedactSubtree(view: View): Boolean {
            // EditText with any password input-type variation.
            if (view is EditText) {
                val variation = view.inputType and InputType.TYPE_MASK_VARIATION
                val cls = view.inputType and InputType.TYPE_MASK_CLASS
                val isPassword =
                    variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    (cls == InputType.TYPE_CLASS_NUMBER &&
                        variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
                if (isPassword) return true

                // Email + phone variants → still personally
                // identifying enough to warrant redaction.
                if (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    cls == InputType.TYPE_CLASS_PHONE
                ) {
                    return true
                }
            }
            if (view is WebView) return true

            // FIX 2 (2026-07-05) — detect surfaces by TYPE via the SINGLE
            // shared predicate the capture side also uses, so a custom
            // `SurfaceView` / `TextureView` SUBCLASS (e.g. a bespoke
            // camera-preview or video view) still gets a redaction rect.
            // The old exact-simpleName match here missed subclasses: they
            // were captured by PixelCopy but shipped UNMASKED. `GLSurfaceView`
            // is a `SurfaceView` subclass so it's covered by the base-type
            // check inside [FrameSnapshotter.isSurfaceLike].
            if (FrameSnapshotter.isSurfaceLike(view)) return true

            // Public Agent-1 markup. The tag key is a documented
            // Kixo convention — `view.setTag("kixo_redact", true)`
            // works without any resource id allocation. When Agent 1
            // ships the typed `setTag(R.id.…)` API, that path will
            // also flow through here.
            (view.getTag() as? String)?.let { tag ->
                if (tag == KX_REDACT_TAG_VALUE) return true
            }

            return false
        }

        /** Public marker string Agent 1 + Agent 10 also reference. */
        const val KX_REDACT_TAG_VALUE: String = "kixo_redact"
    }
}

/**
 * Bridge from Agent 9's [Role] enum to the wire string the dashboard
 * player expects. Lives at file scope (not on [Role]) because Agent
 * 13 doesn't own that file — adding methods there would violate
 * AGENT_BRIEFING §6 ownership.
 */
private fun Role.wireName(): JsonPrimitive = when (this) {
    Role.Text -> JsonPrimitive("text")
    Role.Button -> JsonPrimitive("button")
    Role.TextField -> JsonPrimitive("text_field")
    Role.Image -> JsonPrimitive("image")
    Role.List -> JsonPrimitive("list")
    Role.Web -> JsonPrimitive("web")
    Role.Container -> JsonPrimitive("container")
    Role.Input -> JsonPrimitive("input")
    Role.Navigation -> JsonPrimitive("navigation")
    Role.Other -> JsonPrimitive("other")
}
