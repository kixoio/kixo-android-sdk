package io.kixo.sdk.internal.attribution

import java.util.UUID

/**
 * Process-restorable coordinator around [AppLinkResolver].
 *
 * Submission durably reserves one open ID per OS delivery before local
 * `RECEIVED`. Callers that defer start can then emit `RECEIVED` before invoking
 * [start]. Retries never block navigation or reuse another delivery's identity.
 */
internal class DurableAppLinkResolveCoordinator(
    private val store: DirectLinkResolveStore,
    private val contextProvider: () -> Context?,
    private val isAllowed: () -> Boolean,
    private val isSignalAllowed: (DirectLinkResolveStore.Signal) -> Boolean = { true },
    private val transport: (
        DirectLinkResolveStore.Intent,
        (AppLinkResolver.Outcome) -> Unit,
    ) -> CancelHandle,
    private val commit: (
        DirectLinkResolveStore.Intent,
        AppLinkResolver.ResolvedAppLink,
        (Boolean) -> Unit,
    ) -> Unit,
    private val scheduler: (Long, Runnable) -> Unit,
    private val nowMs: () -> Long = System::currentTimeMillis,
) {
    internal data class Context(
        val anonymousId: String,
        val deviceId: String,
        val installId: String,
        val userId: String?,
        val sessionId: String,
        val fingerprint: String,
    )

    internal fun interface CancelHandle {
        fun cancel()
    }

    private data class Flight(
        val token: String,
        val generation: Long,
        var handle: CancelHandle = NOOP_CANCEL,
    )

    private val lock = Any()
    private val callbacks =
        LinkedHashMap<
            String,
            (DirectLinkResolveStore.Intent, AppLinkResolver.ResolvedAppLink) -> Unit,
        >()
    /** Live-process navigation details; the durable store strips targetUrl. */
    private val resolvedInMemory =
        LinkedHashMap<String, AppLinkResolver.ResolvedAppLink>()
    private val inFlight = HashMap<String, Flight>()
    private val committing = HashMap<String, String>()
    private val scheduled = HashSet<String>()
    private var generation = 0L

    fun submit(
        signal: DirectLinkResolveStore.Signal,
        openId: String,
        eventId: String,
        source: String,
        installAttributionCandidate: Boolean,
        routePathHash: String,
        startImmediately: Boolean = true,
        onResolved: (
            DirectLinkResolveStore.Intent,
            AppLinkResolver.ResolvedAppLink,
        ) -> Unit,
    ): DirectLinkResolveStore.Intent? {
        val context = contextProvider() ?: return null
        val intent = store.prepare(
            signal = signal,
            openId = openId,
            eventId = eventId,
            anonymousId = context.anonymousId,
            deviceId = context.deviceId,
            installId = context.installId,
            userId = context.userId,
            sessionId = context.sessionId,
            fingerprint = context.fingerprint,
            source = source,
            installAttributionCandidate = installAttributionCandidate,
            routePathHash = routePathHash,
        ) ?: return null
        val active = store.isActive(
            openId = intent.openId,
            eventId = intent.eventId,
            anonymousId = context.anonymousId,
            deviceId = context.deviceId,
            installId = context.installId,
        )
        if (!active) return intent
        synchronized(lock) {
            callbacks[intent.openId] = onResolved
        }
        if (startImmediately) pump(intent.openId)
        return intent
    }

    fun start(openId: String) = pump(openId)

    fun resume() {
        if (!isAllowed()) return
        if (!store.rearmIfBlocked()) return
        val context = contextProvider() ?: return
        store.allCurrent(
            anonymousId = context.anonymousId,
            deviceId = context.deviceId,
            installId = context.installId,
        ).forEach { pump(it.openId) }
    }

    fun invalidate(clearPersisted: Boolean) {
        val handles = synchronized(lock) {
            generation += 1
            callbacks.clear()
            resolvedInMemory.clear()
            val active = inFlight.values.map { it.handle }
            inFlight.clear()
            committing.clear()
            scheduled.clear()
            active
        }
        handles.forEach(CancelHandle::cancel)
        if (clearPersisted) store.blockAndClear()
    }

    /** Settle only after the backend explicitly accepts the stable event ID. */
    fun accepted(eventIds: Set<String>) {
        val settled = store.settleByEventIds(eventIds)
        settled.forEach { intent ->
            val live = synchronized(lock) { resolvedInMemory[intent.openId] }
            if (live != null) {
                deliverCallback(intent, live)
            }
            finishTerminal(intent.openId)
        }
    }

    /** Explicit per-event poison is terminal; batch-wide pauses are not. */
    fun permanentlyRejected(eventIds: Set<String>) {
        store.settleByEventIds(eventIds).forEach {
            finishTerminal(it.openId)
        }
    }

    /**
     * A server pause/queue purge invalidates local append completions, but the
     * canonical outbox remains retryable and is re-enqueued on the next Running
     * transition.
     */
    fun queueCleared() {
        val cancelled = synchronized(lock) {
            generation += 1
            val affected = (committing.keys + inFlight.keys).toSet()
            val active = inFlight.map { it.key to it.value.handle }
            committing.clear()
            inFlight.clear()
            scheduled.clear()
            affected to active
        }
        cancelled.second.forEach { (_, handle) -> handle.cancel() }
        cancelled.first.forEach(store::postpone)
    }

    private fun pump(openId: String) {
        if (!isAllowed()) return
        val context = contextProvider() ?: return
        val intent = store.current(
            openId = openId,
            anonymousId = context.anonymousId,
            deviceId = context.deviceId,
            installId = context.installId,
        ) ?: return finishTerminal(openId)
        if (!isSignalAllowed(intent.signal)) {
            store.settle(openId)
            finishTerminal(openId)
            return
        }
        val remaining = intent.nextAttemptAtMs - nowMs()
        if (remaining > 0) {
            schedule(openId, remaining)
            return
        }
        intent.result?.let {
            val liveResult = synchronized(lock) {
                resolvedInMemory[openId]
            }
            commitStored(intent, liveResult ?: it.toResolved())
            return
        }

        val token = UUID.randomUUID().toString()
        val flight = synchronized(lock) {
            if (inFlight.containsKey(openId)) return
            if (inFlight.size >= DirectLinkResolveStore.CAPACITY) {
                schedule(openId, ADMISSION_RETRY_MS)
                return
            }
            Flight(token = token, generation = generation).also {
                inFlight[openId] = it
            }
        }
        val attempted = store.beginAttempt(openId) ?: run {
            synchronized(lock) { inFlight.remove(openId, flight) }
            finishTerminal(openId)
            return
        }

        // AppLinkResolver may deliberately suppress a completion when privacy
        // or server policy changes mid-flight. Bound that silence so a later
        // Running transition can resume the durable intent.
        scheduler(RESOLVE_WATCHDOG_MS, Runnable {
            val abandoned = synchronized(lock) {
                val current = inFlight[openId]
                if (current?.token != token || generation != flight.generation) {
                    null
                } else {
                    inFlight.remove(openId)
                }
            }
            if (abandoned != null) {
                abandoned.handle.cancel()
                store.postpone(openId)
                if (isAllowed()) scheduleFromStore(openId)
            }
        })

        val completeOutcome: (AppLinkResolver.Outcome) -> Unit = complete@{ outcome ->
            val accepted = synchronized(lock) {
                val current = inFlight[openId]
                if (current?.token != token || generation != flight.generation) {
                    false
                } else {
                    inFlight.remove(openId)
                    true
                }
            }
            if (!accepted) return@complete
            when (outcome) {
                is AppLinkResolver.Outcome.Resolved -> {
                    val stored = store.recordResult(openId, outcome.link)
                    if (stored == null) {
                        store.postpone(openId)
                        scheduleFromStore(openId)
                    } else {
                        synchronized(lock) {
                            resolvedInMemory[openId] = outcome.link
                        }
                        commitStored(stored, outcome.link)
                    }
                }
                AppLinkResolver.Outcome.Unresolved -> {
                    if (attempted.result != null) {
                        commitStored(attempted, attempted.result.toResolved())
                    } else {
                        store.settle(openId)
                        finishTerminal(openId)
                    }
                }
                is AppLinkResolver.Outcome.Failed -> {
                    if (isRetryableFailure(outcome.reason)) {
                        store.postpone(openId)
                        scheduleFromStore(openId)
                    } else if (attempted.result != null) {
                        commitStored(attempted, attempted.result.toResolved())
                    } else {
                        store.settle(openId)
                        finishTerminal(openId)
                    }
                }
            }
        }
        val handle = runCatching {
            transport(attempted, completeOutcome)
        }.getOrElse {
            completeOutcome(AppLinkResolver.Outcome.Failed("transport_threw"))
            NOOP_CANCEL
        }
        val cancelReturnedHandle = synchronized(lock) {
            val current = inFlight[openId]
            if (current?.token == token) {
                current.handle = handle
                false
            } else {
                true
            }
        }
        if (cancelReturnedHandle) handle.cancel()
    }

    private fun commitStored(
        intent: DirectLinkResolveStore.Intent,
        result: AppLinkResolver.ResolvedAppLink,
    ) {
        if (!isAllowed()) return
        val token = UUID.randomUUID().toString()
        val expectedGeneration = synchronized(lock) {
            if (committing.containsKey(intent.openId)) return
            committing[intent.openId] = token
            generation
        }
        commit(intent, result) callback@{ committed ->
            val accepted = synchronized(lock) {
                generation == expectedGeneration &&
                    committing.remove(intent.openId, token)
            }
            if (!accepted) return@callback
            if (committed) {
                val callbackResult = synchronized(lock) {
                    resolvedInMemory[intent.openId]
                } ?: result
                deliverCallback(intent, callbackResult)
            } else {
                store.postpone(intent.openId)
                if (isAllowed()) scheduleFromStore(intent.openId)
            }
        }
    }

    private fun scheduleFromStore(openId: String) {
        val context = contextProvider() ?: return
        val intent = store.current(
            openId = openId,
            anonymousId = context.anonymousId,
            deviceId = context.deviceId,
            installId = context.installId,
        ) ?: return finishTerminal(openId)
        schedule(openId, (intent.nextAttemptAtMs - nowMs()).coerceAtLeast(0))
    }

    private fun schedule(openId: String, delayMs: Long) {
        val expectedGeneration = synchronized(lock) {
            if (!scheduled.add(openId)) return
            generation
        }
        scheduler(delayMs, Runnable {
            val current = synchronized(lock) {
                if (generation != expectedGeneration) return@Runnable
                scheduled.remove(openId)
                true
            }
            if (current) pump(openId)
        })
    }

    private fun deliverCallback(
        intent: DirectLinkResolveStore.Intent,
        result: AppLinkResolver.ResolvedAppLink,
    ) {
        val callback = synchronized(lock) {
            resolvedInMemory.remove(intent.openId)
            callbacks.remove(intent.openId)
        }
        callback?.invoke(intent, result)
    }

    private fun finishTerminal(openId: String) {
        val handle = synchronized(lock) {
            callbacks.remove(openId)
            resolvedInMemory.remove(openId)
            committing.remove(openId)
            scheduled.remove(openId)
            inFlight.remove(openId)?.handle
        }
        handle?.cancel()
    }

    companion object {
        internal const val RESOLVE_WATCHDOG_MS = 15_000L
        private const val ADMISSION_RETRY_MS = 250L
        private val NOOP_CANCEL = CancelHandle {}

        fun isRetryableFailure(reason: String): Boolean {
            if (!reason.startsWith("http_")) return true
            val status = reason.removePrefix("http_").toIntOrNull() ?: return true
            return status == 408 ||
                status == 425 ||
                status == 429 ||
                status in 500..599
        }
    }
}
