package io.kixo.sdk

/**
 * Standard user properties recognised by the Kixo backend and
 * promoted to the dedicated profile columns shown in the audience
 * explorer (`profile.email`, `profile.phone`, `profile.plan`, …).
 *
 * Reserved names carry a `$` prefix as their canonical spelling. This matches
 * Mixpanel / Amplitude / Segment conventions. Kixo also accepts common bare
 * identity and geo aliases such as `email`, `name`, and `country` and promotes
 * them to the same profile fields.
 *
 * Pass `Kixo.setUserProperty(StandardProperty.EMAIL.key, "…")` or the
 * raw string `"$email"` — both write `property_name = "$email"` on
 * the wire. Any other (non-`$`) key is stored as a custom trait,
 * queryable from segments and chat but NOT promoted to a `profile.*`
 * column.
 *
 * ## Packs
 *
 * The catalogue is organised into 8 packs (3 universal + 5 vertical):
 *
 *   - **Universal — always populated, every project:** Identity (6),
 *     Geo (6), Lifecycle (2).
 *   - **Vertical — rendered when populated; the dashboard adapts the
 *     profile layout per project's detected vertical:** SaaS (5),
 *     E-commerce (6), Media (4), Marketplace (5), Loyalty (3).
 *
 * Kixo is B2B. A customer who runs a SaaS product will populate the
 * Identity / Geo / Lifecycle / SaaS packs and leave Marketplace /
 * Loyalty empty — the dashboard hides empty vertical packs so the
 * profile column doesn't bloat. A marketplace customer populates
 * Identity / Geo / Lifecycle / Marketplace + maybe Loyalty.
 *
 * The `$`-prefixed spelling is canonical. Common bare identity and geo
 * aliases such as `email`, `name`, and `country` are accepted for migration
 * and promoted to the same profile fields by Kixo; unrelated bare keys remain
 * **custom traits**. Use those for product-specific signals that don't fit a
 * standard pack.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Identity/UserProperties.swift`
 * and `kixo-web-sdk/src/core/standard-properties.ts` byte-for-byte.
 * When iOS adds or renames a case, bump all three SDKs in the same
 * PR — the catalogue is intentionally a fixed contract per SDK
 * version (see `defaultConfig.buildConfigField "SDK_VERSION"`).
 */
public enum class StandardProperty(public val key: String, public val pack: Pack) {
    // ─── Identity (universal) ────────────────────────────────────
    EMAIL("\$email", Pack.IDENTITY),
    PHONE("\$phone", Pack.IDENTITY),
    NAME("\$name", Pack.IDENTITY),
    FIRST_NAME("\$first_name", Pack.IDENTITY),
    LAST_NAME("\$last_name", Pack.IDENTITY),
    AVATAR_URL("\$avatar_url", Pack.IDENTITY),

    // ─── Geo (universal) ─────────────────────────────────────────
    COUNTRY("\$country", Pack.GEO),
    CITY("\$city", Pack.GEO),
    REGION("\$region", Pack.GEO),
    TIMEZONE("\$timezone", Pack.GEO),
    LANGUAGE("\$language", Pack.GEO),
    LOCALE("\$locale", Pack.GEO),

    // ─── Lifecycle (universal) ───────────────────────────────────
    CREATED("\$created", Pack.LIFECYCLE),           // signup date (ISO8601)
    LAST_SEEN("\$last_seen", Pack.LIFECYCLE),       // last active date (ISO8601)

    // ─── SaaS (vertical) ─────────────────────────────────────────
    PLAN("\$plan", Pack.SAAS),                              // subscription tier slug
    SUBSCRIPTION_STATUS("\$subscription_status", Pack.SAAS), // active / trialing / paused / canceled
    TRIAL_ENDS("\$trial_ends", Pack.SAAS),                  // ISO8601
    MRR("\$mrr", Pack.SAAS),                                // monthly recurring revenue
    SUBSCRIPTION_STARTED("\$subscription_started", Pack.SAAS), // ISO8601

    // ─── E-commerce (vertical) ───────────────────────────────────
    LIFETIME_ORDERS("\$lifetime_orders", Pack.ECOMMERCE),
    LIFETIME_REVENUE("\$lifetime_revenue", Pack.ECOMMERCE),
    AOV("\$aov", Pack.ECOMMERCE),                           // average order value
    LAST_PURCHASE("\$last_purchase", Pack.ECOMMERCE),       // ISO8601
    FIRST_PURCHASE("\$first_purchase", Pack.ECOMMERCE),     // ISO8601
    CART_ABANDONED_COUNT("\$cart_abandoned_count", Pack.ECOMMERCE),

    // ─── Media (vertical) ────────────────────────────────────────
    CONTENT_TIER("\$content_tier", Pack.MEDIA),             // free / premium / vip
    SUBSCRIBED_CATEGORIES("\$subscribed_categories", Pack.MEDIA),
    WATCH_TIME_TOTAL("\$watch_time_total", Pack.MEDIA),     // seconds
    LAST_PLAYED("\$last_played", Pack.MEDIA),               // ISO8601

    // ─── Marketplace (vertical) ──────────────────────────────────
    SELLER_TIER("\$seller_tier", Pack.MARKETPLACE),
    BUYER_TIER("\$buyer_tier", Pack.MARKETPLACE),
    LISTINGS_COUNT("\$listings_count", Pack.MARKETPLACE),
    REVIEWS_COUNT("\$reviews_count", Pack.MARKETPLACE),
    VERIFIED("\$verified", Pack.MARKETPLACE),               // KYC / trust-flag boolean

    // ─── Loyalty (vertical) ──────────────────────────────────────
    LOYALTY_POINTS("\$loyalty_points", Pack.LOYALTY),
    VIP_LEVEL("\$vip_level", Pack.LOYALTY),
    REFERRAL_COUNT("\$referral_count", Pack.LOYALTY);

    /**
     * Catalogue grouping. Universal packs ([IDENTITY], [GEO], [LIFECYCLE])
     * apply to every project; vertical packs ([SAAS], [ECOMMERCE], [MEDIA],
     * [MARKETPLACE], [LOYALTY]) render in the dashboard only when the
     * project's detected vertical populates them.
     */
    public enum class Pack {
        IDENTITY,
        GEO,
        LIFECYCLE,
        SAAS,
        ECOMMERCE,
        MEDIA,
        MARKETPLACE,
        LOYALTY,
    }

    public companion object {
        /**
         * Look up the [Pack] for a raw `$`-prefixed property key. Returns
         * `null` for unrecognised keys (i.e. custom traits without
         * `$`-prefix, or `$`-prefixed keys reserved for future packs but
         * not in this SDK version).
         */
        @JvmStatic
        public fun packOf(key: String): Pack? = entries.firstOrNull { it.key == key }?.pack
    }
}
