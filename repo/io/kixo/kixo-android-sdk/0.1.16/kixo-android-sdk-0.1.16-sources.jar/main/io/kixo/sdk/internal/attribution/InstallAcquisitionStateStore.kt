package io.kixo.sdk.internal.attribution

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import java.io.File
import java.io.FileNotFoundException
import java.security.MessageDigest
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

/**
 * Durable identity and delivery state for one physical app installation.
 *
 * The production file lives under [Context.getNoBackupFilesDir], so Android
 * never restores it onto a reinstall or a different device. Process restarts
 * keep the same install/event IDs; uninstall + reinstall creates new IDs.
 */
internal class InstallAcquisitionStateStore(
    private val persistence: Persistence,
    private val nowMs: () -> Long = System::currentTimeMillis,
    private val uuid: () -> String = { UUID.randomUUID().toString().lowercase() },
) {
    data class Identity(
        val installId: String,
        val installEventId: String,
        val startedAtMs: Long,
    )

    @Serializable
    private data class State(
        val version: Int = STATE_VERSION,
        val installId: String,
        val installEventId: String,
        val startedAtMs: Long,
        val firstLaunchConsumedAtMs: Long? = null,
        val installAccepted: Boolean = false,
        val deliveryRejected: Boolean = false,
        val deliveryRejectReason: String? = null,
        val validationSettled: Boolean = false,
    )

    internal interface Persistence {
        sealed interface ReadResult {
            data object Missing : ReadResult
            data class Value(val raw: String) : ReadResult
            data object Failure : ReadResult
        }

        fun read(): ReadResult
        fun write(value: String): Boolean
    }

    private sealed interface StateRead {
        data object Missing : StateRead
        data object Failure : StateRead
        data class Found(val state: State) : StateRead
    }

    private val lock = Any()
    private var cached: State? = null

    /**
     * Load or durably mint the physical-install identity. Returns null when the
     * no-backup file cannot be committed: sending an unstable install ID would
     * be worse than skipping acquisition for this process.
     */
    fun bootstrap(): Identity? = synchronized(lock) {
        cached?.let { return@synchronized it.identity() }
        when (val existing = readStateLocked()) {
            is StateRead.Found -> {
                cached = existing.state
                return@synchronized existing.state.identity()
            }
            StateRead.Failure -> return@synchronized null
            StateRead.Missing -> Unit
        }

        val created = State(
            installId = uuid(),
            installEventId = uuid(),
            startedAtMs = nowMs(),
        )
        if (!valid(created) || !saveLocked(created)) return@synchronized null
        created.identity()
    }

    fun identity(): Identity? = synchronized(lock) {
        currentLocked()?.identity()
    }

    fun needsInstallDelivery(): Boolean = synchronized(lock) {
        currentLocked()?.let { !it.installAccepted && !it.deliveryRejected } == true
    }

    /**
     * Consume the one physical first-foreground candidate at the first observed
     * Activity intent. The permission is deliberately short-lived: a headless
     * process or an integration that never observed its first foreground cannot
     * reinterpret a link received hours or days later as acquisition.
     *
     * A failed durable write fails closed: the link still routes, but is not
     * allowed to claim install attribution.
     */
    fun consumeFirstLaunchEligibility(): Boolean = synchronized(lock) {
        val state = currentLocked() ?: return@synchronized false
        if (state.firstLaunchConsumedAtMs != null) return@synchronized false
        val observedAtMs = nowMs()
        val ageMs = observedAtMs - state.startedAtMs
        val eligible = ageMs in 0..MAX_FIRST_LAUNCH_ELIGIBILITY_MS
        val updated = state.copy(firstLaunchConsumedAtMs = observedAtMs)
        if (!saveLocked(updated)) return@synchronized false
        eligible
    }

    /**
     * Only an accepted per-event backend ACK settles app_install delivery.
     * A permanent reject is not silently upgraded into an accepted install.
     */
    fun markInstallAccepted(eventId: String): Boolean = synchronized(lock) {
        val state = currentLocked() ?: return@synchronized false
        if (state.installEventId != eventId) return@synchronized false
        if (state.deliveryRejected) return@synchronized false
        if (state.installAccepted) return@synchronized true
        saveLocked(state.copy(installAccepted = true))
    }

    /**
     * A per-event permanent backend error means the stable proposal itself is
     * invalid. Persist a terminal rejection instead of reconstructing the same
     * poison event on every process restart. Batch-level auth/project pauses do
     * not call this method and therefore remain recoverable.
     */
    fun markInstallRejected(eventId: String, reason: String): Boolean = synchronized(lock) {
        val state = currentLocked() ?: return@synchronized false
        if (state.installEventId != eventId || state.installAccepted) {
            return@synchronized false
        }
        if (state.deliveryRejected) return@synchronized true
        saveLocked(
            state.copy(
                deliveryRejected = true,
                deliveryRejectReason = reason.take(MAX_REJECT_REASON_LENGTH),
            ),
        )
    }

    fun deliveryRejectionReason(): String? = synchronized(lock) {
        currentLocked()?.deliveryRejectReason
    }

    /** Explicit opt-out/consent revocation cannot be undone into historical
     * acquisition on a later opt-in. Future analytics may resume, but this
     * installation proposal and first-launch candidate remain abandoned. */
    fun abandonForPrivacy(): Boolean = synchronized(lock) {
        val state = currentLocked() ?: return@synchronized false
        val updated = if (state.installAccepted) {
            state.copy(
                firstLaunchConsumedAtMs = state.firstLaunchConsumedAtMs ?: nowMs(),
                validationSettled = true,
            )
        } else {
            state.copy(
                firstLaunchConsumedAtMs = state.firstLaunchConsumedAtMs ?: nowMs(),
                deliveryRejected = true,
                deliveryRejectReason = state.deliveryRejectReason ?: PRIVACY_REJECTION_REASON,
                validationSettled = true,
            )
        }
        if (updated == state) true else saveLocked(updated)
    }

    fun needsValidation(): Boolean = synchronized(lock) {
        currentLocked()?.let { it.installAccepted && !it.validationSettled } == true
    }

    fun markValidationSettled(): Boolean = synchronized(lock) {
        val state = currentLocked() ?: return@synchronized false
        if (!state.installAccepted) return@synchronized false
        if (state.validationSettled) return@synchronized true
        saveLocked(state.copy(validationSettled = true))
    }

    private fun currentLocked(): State? {
        cached?.let { return it }
        val read = readStateLocked()
        if (read is StateRead.Found) {
            cached = read.state
            return read.state
        }
        return null
    }

    private fun readStateLocked(): StateRead =
        when (val result = persistence.read()) {
            Persistence.ReadResult.Missing -> StateRead.Missing
            Persistence.ReadResult.Failure -> StateRead.Failure
            is Persistence.ReadResult.Value -> {
                decode(result.raw)?.let { StateRead.Found(it) } ?: StateRead.Failure
            }
        }

    private fun saveLocked(state: State): Boolean {
        val written = persistence.write(JSON.encodeToString(State.serializer(), state))
        if (written) cached = state
        return written
    }

    private fun decode(raw: String?): State? {
        if (raw.isNullOrBlank()) return null
        return runCatching {
            JSON.decodeFromString(State.serializer(), raw)
        }.getOrNull()?.takeIf(::valid)
    }

    private fun valid(state: State): Boolean =
        state.version == STATE_VERSION &&
            INSTALL_ID_PATTERN.matches(state.installId) &&
            UUID_PATTERN.matches(state.installEventId) &&
            state.startedAtMs > 0

    private fun State.identity(): Identity = Identity(installId, installEventId, startedAtMs)

    companion object {
        private const val TAG = "Kixo.InstallState"
        private const val STATE_VERSION = 1
        internal const val MAX_FIRST_LAUNCH_ELIGIBILITY_MS = 10 * 60 * 1_000L
        private const val MAX_REJECT_REASON_LENGTH = 64
        private const val PRIVACY_REJECTION_REASON = "privacy_withdrawn"
        private val INSTALL_ID_PATTERN = Regex("^[A-Za-z0-9._:-]{8,128}$")
        private val UUID_PATTERN = Regex(
            "^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$",
        )
        private val JSON = Json {
            encodeDefaults = true
            ignoreUnknownKeys = true
        }

        fun create(context: Context, projectId: String): InstallAcquisitionStateStore {
            val appContext = context.applicationContext
            val projectHash = MessageDigest.getInstance("SHA-256")
                .digest(projectId.toByteArray(Charsets.UTF_8))
                .take(12)
                .joinToString("") { "%02x".format(it) }
            val directory = File(appContext.noBackupFilesDir, "kixo")
            val file = File(directory, "install-acquisition-$projectHash.json")
            return InstallAcquisitionStateStore(AtomicFilePersistence(file))
        }
    }

    private class AtomicFilePersistence(file: File) : Persistence {
        private val file = file
        private val atomicFile = AtomicFile(file)

        override fun read(): Persistence.ReadResult {
            return try {
                atomicFile.openRead().use { input ->
                    Persistence.ReadResult.Value(
                        input.readBytes().toString(Charsets.UTF_8),
                    )
                }
            } catch (_: FileNotFoundException) {
                Persistence.ReadResult.Missing
            } catch (t: Throwable) {
                Log.w(TAG, "Install state read failed", t)
                Persistence.ReadResult.Failure
            }
        }

        override fun write(value: String): Boolean {
            return try {
                file.parentFile?.mkdirs()
                val output = atomicFile.startWrite()
                try {
                    output.write(value.toByteArray(Charsets.UTF_8))
                    output.flush()
                    atomicFile.finishWrite(output)
                    true
                } catch (t: Throwable) {
                    atomicFile.failWrite(output)
                    throw t
                }
            } catch (t: Throwable) {
                Log.w(TAG, "Install state write failed", t)
                false
            }
        }
    }
}
