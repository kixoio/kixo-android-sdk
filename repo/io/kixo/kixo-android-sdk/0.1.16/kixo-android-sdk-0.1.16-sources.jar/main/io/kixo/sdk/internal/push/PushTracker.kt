package io.kixo.sdk.internal.push

import io.kixo.sdk.PushProvider
import io.kixo.sdk.internal.privacy.ConsentManager
import io.kixo.sdk.internal.push.Sha256Helper.sha256Hex
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Internal push subsystem singleton. The public-API methods on
 * `Kixo` (Agent 1) — `setPushToken`, `logPushReceived`,
 * `logPushOpened`, `logPushDismissed`, `logPushAction`,
 * `logPushSilent`, `logPushTokenInvalidated` — funnel through here.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/AutoTrack/PushTracker.swift` but
 * is a pure manual-API surface — no auto-wrapping equivalent of the
 * `UNUserNotificationCenter.delegate` swizzle exists on Android. The
 * closest match is the optional [KixoFirebaseMessagingService]
 * subclass that customers can extend; that path also funnels into
 * the same methods here.
 *
 * **Why a stateful object, not pure functions?** Two reasons:
 *
 *  1. The push token has to be deduped — re-calling `setPushToken`
 *     with an unchanged token must be a no-op so an app that calls
 *     `Kixo.setPushToken(...)` on every launch (the recommended FCM
 *     pattern) doesn't spam `/api/sdk/push/register`. The dedup
 *     state lives here as the SHA-256 of the last successfully-sent
 *     token.
 *  2. The sanitizer's [ContentMode] can change at runtime when the
 *     dashboard pushes a remote-config update. Holding the active
 *     `PushPayloadSanitizer` instance lets us swap cleanly without
 *     callers needing to know about the config plumbing.
 *
 * **Stub dependencies** (declared in [_PushAgentStubs]):
 *  - `EventQueue.enqueue(eventType, properties)` — Agent 5 owns. The
 *    real signature will likely take a `KixoEvent` builder; for the
 *    duration of parallel build, we declare the minimal surface we
 *    need and let Agent 5's published types replace the stub.
 *  - `IdentityDedup.shouldEmitPushToken(tokenSha256, provider)` —
 *    Agent 5 owns. Returns true the first time a (token, provider)
 *    pair is seen since process start; cached in-memory.
 *  - `PushTransport.registerToken(token, provider)` — Agent 4 owns.
 *    POSTs to `/api/sdk/push/register`. Per AGENT_BRIEFING.md R10
 *    this is the ONLY code path that ships the raw token.
 */
internal object PushTracker {
    internal class PushRoutingCapability internal constructor(
        internal val boundaryGeneration: Long,
    )

    internal data class PushOpenCommitResult(
        val committed: Boolean,
        val routingCapability: PushRoutingCapability?,
    )

    /**
     * Active sanitizer. Reassigned by [updateContentMode] when the
     * dashboard pushes a new remote-config value. `AtomicReference`
     * gives lock-free reads on the hot `logPush*` path.
     */
    private val sanitizerRef = AtomicReference(
        PushPayloadSanitizer(mode = ContentMode.HASH_ONLY)
    )

    /**
     * Bridges to the rest of the SDK. Set by `Kixo.configure(...)`
     * during init; null before that — all public methods short-circuit
     * to a debug log when bridges are missing rather than NPE.
     *
     * Held in an [AtomicReference] together so a partial swap can
     * never be observed (you either see all-old or all-new bridges).
     */
    private val bridgesRef = AtomicReference<PushBridges?>(null)

    /**
     * Serialises attribution commits with reset/privacy boundaries. Queue
     * persistence is asynchronous, so a callback admitted before logout or
     * opt-out must not reinstall the old window after that boundary completed.
     */
    private val attributionBoundaryLock = ReentrantLock()
    private val attributionBoundaryGeneration = AtomicLong(0L)

    /**
     * Wire the singleton to its dependencies. Called once from
     * `Kixo.configure(...)` after the queue / transport / dedup
     * subsystems have come up.
     */
    fun bind(bridges: PushBridges) {
        bridgesRef.set(bridges)
    }

    internal fun unbindForTesting() {
        bridgesRef.set(null)
        reset()
    }

    /**
     * Update the active redaction mode. Called when the dashboard
     * pushes a new `data_collection.push.contentMode` value via
     * remote config (Agent 6 owns the parsing).
     */
    fun updateContentMode(
        mode: ContentMode,
        titleLimit: Int = PushPayloadSanitizer.TITLE_PREVIEW_CHARS,
        bodyLimit: Int = PushPayloadSanitizer.BODY_PREVIEW_CHARS,
    ) {
        sanitizerRef.set(PushPayloadSanitizer(mode, titleLimit, bodyLimit))
    }

    /**
     * Reset internal caches. Called from `Kixo.reset()` (Agent 1).
     * The token-dedup cache lives in `IdentityDedup` (Agent 5) so
     * that side resets there; here we clear the attribution store.
     * Sanitizer mode is preserved across resets — the user's
     * identity changing doesn't change the project's redaction
     * policy.
     */
    fun reset() {
        // Retire push-originated router capabilities first. Both router
        // admission and this invalidation use Kixo's deep-link state monitor,
        // so the user-visible route linearises wholly before or wholly after
        // the boundary instead of slipping between two independent checks.
        io.kixo.sdk.Kixo.invalidatePushDeepLinkRouting()
        attributionBoundaryLock.withLock {
            attributionBoundaryGeneration.incrementAndGet()
            PushAttributionStore.clear()
        }
    }

    // ─── Public manual API (called from Kixo facade) ──────────────

    /**
     * Register a push token with the backend. Per
     * AGENT_BRIEFING.md R10, this is the ONE place the raw token
     * leaves the device — `/api/sdk/push/register` is the registered
     * destination. All event-stream references use SHA-256 only.
     *
     * Dedups via [IdentityDedup]: a re-call with the same token +
     * provider since process start returns immediately. Process
     * boundaries are the right grain — token rotations on the FCM
     * side fire `onNewToken` in a fresh process anyway.
     */
    fun setPushToken(token: String, provider: PushProvider) {
        if (token.isEmpty()) return
        // This is the only raw-token egress path. Local privacy must be the
        // first gate (including pre-config signals restored before wiring),
        // not merely the later server data-collection policy.
        if (ConsentManager.isOptedOut() || !ConsentManager.hasConsent()) return
        // HMS/APNS remain as deprecated source-compatible enum constants for
        // patch-release safety, but Android has no supported delivery bridge
        // for them. Never send a token that the backend cannot deliver.
        if (!provider.supportedOnAndroid) return
        // Coverage fix (May 2026):
        //  - data_collection.push.enabled == false  → skip both register + future events
        //  - data_collection.identity.collectPushTokens == false → skip register specifically
        // Default-allow on pre-init / missing field.
        if (!pushAllowedByDataCollection()) return
        if (!io.kixo.sdk.internal.queue.DataCollectionHolder
                .isAllowed { it.identity?.collectPushTokens }) {
            return
        }
        val bridges = bridgesRef.get() ?: return
        val tokenHash = token.sha256Hex()
        if (!bridges.identityDedup.shouldEmitPushToken(tokenHash, provider)) {
            return
        }
        // Fire-and-forget. The transport handles retry + circuit
        // breaker; we don't block the caller, and we don't wire
        // success back into our local state — `IdentityDedup` already
        // marked this token as "seen" pre-emptively, which is the
        // right behavior even on transient failure (we don't want to
        // re-spam the backend with the same token on every flush
        // attempt; the next genuine token rotation re-arms).
        // CRITICAL: This is the ONLY path where the plaintext FCM push token leaves the device. The token MUST go to /api/sdk/push/register and nowhere else. Do NOT log this token. Do NOT stash this in any KixoEvent. Per AGENT_BRIEFING §3 R10.
        bridges.transport.registerPushToken(token = token, provider = provider)
    }

    /**
     * Log `push_received`. Called on FCM message arrival from
     * [KixoFirebaseMessagingService] or directly by host apps that
     * have their own messaging service.
     *
     * @param appState typically `"foreground"` or `"background"` —
     *   matches the iOS `app_state` field. Customers can pass any
     *   tag; the wire format is opaque.
     */
    fun logPushReceived(payload: Map<String, Any?>, appState: String) {
        if (!pushAllowedByDataCollection()) return
        emit(KixoEventTypeWire.PUSH_RECEIVED, payload) { props ->
            props["app_state"] = appState
        }
    }

    /**
     * Log `push_open` and start an attribution window. Subsequent
     * non-push events emitted within [PushAttributionStore.DEFAULT_WINDOW_MS]
     * inherit the attribution properties.
     *
     * @param actionId optional notification-action identifier when
     *   the user tapped a custom action button (vs. the notification
     *   body itself).
     */
    fun logPushOpened(
        payload: Map<String, Any?>,
        actionId: String?,
        onCommitted: ((PushOpenCommitResult) -> Unit)? = null,
    ) {
        if (!pushAllowedByDataCollection()) {
            onCommitted?.invoke(
                PushOpenCommitResult(committed = false, routingCapability = null),
            )
            return
        }
        val sanitized = sanitizerRef.get().sanitize(payload)
        val props = LinkedHashMap<String, Any?>(sanitized)
        if (!actionId.isNullOrEmpty()) {
            props["action_id"] = actionId
            props["interaction_type"] = "custom_action"
        } else {
            props["interaction_type"] = "default"
        }
        val bridges = bridgesRef.get()
        if (bridges == null) {
            onCommitted?.invoke(
                PushOpenCommitResult(committed = false, routingCapability = null),
            )
            return
        }
        val expectedBoundary = attributionBoundaryLock.withLock {
            attributionBoundaryGeneration.get()
        }
        // The legacy API remains fire-and-forget, but now uses the same real
        // SQLite commit boundary as the acknowledged API. A random UUID is
        // sufficient here because the host did not supply an idempotency key.
        bridges.eventQueue.enqueueDurably(
            eventId = UUID.randomUUID().toString(),
            eventType = KixoEventTypeWire.PUSH_OPEN.wireValue,
            properties = props,
        ) { committed ->
            val attributionApplied = committed &&
                applyAttributionAfterCommit(sanitized, expectedBoundary)
            onCommitted?.invoke(
                PushOpenCommitResult(
                    committed = committed,
                    routingCapability = if (attributionApplied) {
                        PushRoutingCapability(expectedBoundary)
                    } else {
                        null
                    },
                ),
            )
        }
    }

    /**
     * Persist a push open under a caller-stable event id and acknowledge only
     * after the SDK queue has committed it to SQLite. Attribution starts after
     * that boundary, so a process death before commit can safely retry the same
     * id without creating a second logical event.
     */
    fun logPushOpenedDurably(
        payload: Map<String, Any?>,
        eventId: String,
        actionId: String?,
        onCommitted: (PushOpenCommitResult) -> Unit,
    ) {
        if (!pushAllowedByDataCollection()) {
            onCommitted(
                PushOpenCommitResult(committed = false, routingCapability = null),
            )
            return
        }
        val sanitized = sanitizerRef.get().sanitize(payload)
        val props = LinkedHashMap<String, Any?>(sanitized)
        if (!actionId.isNullOrEmpty()) {
            props["action_id"] = actionId
            props["interaction_type"] = "custom_action"
        } else {
            props["interaction_type"] = "default"
        }
        val bridges = bridgesRef.get()
        if (bridges == null) {
            onCommitted(
                PushOpenCommitResult(committed = false, routingCapability = null),
            )
            return
        }
        val expectedBoundary = attributionBoundaryLock.withLock {
            attributionBoundaryGeneration.get()
        }
        bridges.eventQueue.enqueueDurably(
            eventId = eventId,
            eventType = KixoEventTypeWire.PUSH_OPEN.wireValue,
            properties = props,
        ) { committed ->
            val attributionApplied = committed &&
                applyAttributionAfterCommit(sanitized, expectedBoundary)
            onCommitted(
                PushOpenCommitResult(
                    committed = committed,
                    routingCapability = if (attributionApplied) {
                        PushRoutingCapability(expectedBoundary)
                    } else {
                        null
                    },
                ),
            )
        }
    }

    /** Log `push_dismissed` (user swiped the notification away). */
    fun logPushDismissed(payload: Map<String, Any?>) {
        if (!pushAllowedByDataCollection()) return
        emit(KixoEventTypeWire.PUSH_DISMISSED, payload)
    }

    /**
     * Log `push_action` (user tapped a custom action button).
     *
     * **Reply text NEVER captured.** Even if the action is a
     * `RemoteInput` action with a typed reply, the SDK has zero
     * code paths that read the reply text — only the action id is
     * surfaced. Per AGENT_BRIEFING.md privacy rules.
     */
    fun logPushAction(payload: Map<String, Any?>, actionId: String) {
        if (!pushAllowedByDataCollection()) return
        emit(KixoEventTypeWire.PUSH_ACTION, payload) { props ->
            props["action_id"] = actionId
            props["interaction_type"] = "custom_action"
        }
    }

    /**
     * Log `push_silent` — content-available push with no visible
     * alert. Emitted when an FCM data-only message arrives (no
     * `notification` block) — these are background data syncs.
     */
    fun logPushSilent(payload: Map<String, Any?>) {
        if (!pushAllowedByDataCollection()) return
        emit(KixoEventTypeWire.PUSH_SILENT, payload)
    }

    /**
     * Log `push_token_invalidated`. Called when FCM tells us the
     * token is no longer valid (e.g. on an `onTokenInvalidated`
     * callback or when the backend returns a 410-equivalent on
     * delivery).
     *
     * Per AGENT_BRIEFING.md R10, the event payload contains ONLY the
     * SHA-256 of the token, never the raw token. The backend keys
     * `PushToken.tokenSha256` on this exact hash so the lookup
     * succeeds without re-transmitting the raw token.
     */
    fun logPushTokenInvalidated(token: String, provider: PushProvider) {
        if (token.isEmpty()) return
        if (!pushAllowedByDataCollection()) return
        // Critic Round 3 BLOCKER Android-B2 (May 2026): the queue-side
        // dedup pass at `EventQueue.kt:534-535` keys this event off
        // `push_token` + `push_provider` — the wire-canonical names the
        // backend dashboard / ClickHouse `push_token_invalidated_dedup`
        // materialised view expects. Pre-fix we wrote `token_sha256` +
        // `provider`, so `IdentityDedup.shouldEmitPushToken` got `null` /
        // `null` on every read → dedup state never updated → N events
        // per session for a single invalidated token. Aligning here
        // (the wire side is the contract) closes the leak without an
        // ingest-side migration.
        val props = LinkedHashMap<String, Any?>().apply {
            put("push_token", token.sha256Hex())
            put("push_provider", provider.wireValue)
        }
        bridgesRef.get()?.eventQueue?.enqueue(
            KixoEventTypeWire.PUSH_TOKEN_INVALIDATED.wireValue, props
        )
    }

    // ─── Internals ────────────────────────────────────────────────

    /**
     * Common emit path: sanitize + decorate hooks + enqueue. The
     * `extra` block runs AFTER sanitization so callers can layer in
     * properties that aren't in the raw payload (e.g. the `app_state`
     * tag for `push_received`).
     */
    private inline fun emit(
        type: KixoEventTypeWire,
        payload: Map<String, Any?>,
        extra: (MutableMap<String, Any?>) -> Unit = {},
    ) {
        val sanitized = sanitizerRef.get().sanitize(payload)
        val props = LinkedHashMap<String, Any?>(sanitized)
        extra(props)
        bridgesRef.get()?.eventQueue?.enqueue(type.wireValue, props)
    }

    /**
     * Apply the attribution decision from the sanitizer's canonical Kixo
     * metadata keys. Campaign, delivery, job, or the signed send claim identify
     * a real attributed delivery. Provider/ad-hoc push ids remain on the
     * push_open wire event but never establish attribution by themselves.
     */
    private fun updateAttributionWindow(sanitized: Map<String, Any?>) {
        PushAttributionStore.recordOpen(
            campaignId = sanitized["kixo_campaign_id"] as? String,
            deliveryId = sanitized["kixo_delivery_id"] as? String,
            pushId = sanitized["kixo_push_id"] as? String,
            jobId = sanitized["kixo_job_id"] as? String,
            sendId = sanitized["kixo_send_id"] as? String,
        )
    }

    /**
     * Linearise an asynchronous SQLite acknowledgement with reset/privacy
     * invalidation. If the event committed under an obsolete identity boundary
     * or collection is no longer allowed, leave the store empty.
     */
    private fun applyAttributionAfterCommit(
        sanitized: Map<String, Any?>,
        expectedBoundary: Long,
    ): Boolean = attributionBoundaryLock.withLock {
        if (attributionBoundaryGeneration.get() != expectedBoundary ||
            ConsentManager.isOptedOut() ||
            !ConsentManager.hasConsent() ||
            !pushAllowedByDataCollection()
        ) {
            return@withLock false
        }
        updateAttributionWindow(sanitized)
        true
    }

    internal fun isRoutingCapabilityCurrent(
        capability: PushRoutingCapability,
    ): Boolean =
        attributionBoundaryGeneration.get() == capability.boundaryGeneration &&
            !ConsentManager.isOptedOut() &&
            ConsentManager.hasConsent() &&
            pushAllowedByDataCollection()

    /**
     * Coverage check for `data_collection.push.enabled`. Default-allow
     * on pre-init / missing field.
     */
    private fun pushAllowedByDataCollection(): Boolean {
        return io.kixo.sdk.internal.queue.DataCollectionHolder.isAllowed { it.push?.enabled }
    }
}
