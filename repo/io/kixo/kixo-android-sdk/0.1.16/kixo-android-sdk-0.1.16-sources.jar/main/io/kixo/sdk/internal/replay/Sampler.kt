package io.kixo.sdk.internal.replay

import android.content.Context
import android.content.SharedPreferences
import kotlin.random.Random

/**
 * Decides whether a replay session records. Two verdict paths:
 *
 *  - **Session-deterministic (Wave 5, KIX-UNI-22 — the default now):**
 *    [sessionDeterministicVerdict] hashes the ANALYTICS session id into
 *    a stable 0..99 bucket and records when `bucket < rate*100`. The
 *    canonical cross-SDK gate — the SAME formula runs in the web SDK
 *    ([sampleBucket] below == web `src/utils/fingerprint.ts` `sampleBucket`)
 *    and iOS SDK, so a customer wiring replay across platforms samples
 *    an IDENTICAL set of sessions. See the golden-vector parity test.
 *
 *  - **Install-sticky (legacy):** [baselineVerdictForSession] rolls
 *    `Random.nextDouble() < sampleRate` ONCE per install, persists it,
 *    and re-rolls only on a rate increase from a prior "out". Kept for
 *    reference / potential opt-in; the production caller
 *    ([ReplayController.start]) now uses the session-deterministic path.
 *
 * **Why session-deterministic wins (Wave 5 decision):** the market
 * standard (PostHog `simpleHash(sessionId) % 100 < rate*100`) keys the
 * decision on the session, not the device — a device records SOME
 * sessions rather than all-or-nothing, and every SDK agrees on which
 * ones. Determinism also means no coin-flip drift: the same session id
 * always yields the same verdict on every platform and every replay.
 *
 * **Persistence keys** (legacy path only) live under a Kixo-specific
 * [SharedPreferences] file so they don't pollute the host app's main
 * `SharedPreferences`. The session-deterministic path is pure — no
 * persistence, no randomness.
 *
 * **Thread-safe.** [baselineVerdictForSession] and [reset] are
 * synchronised on the singleton instance; [sessionDeterministicVerdict]
 * / [sampleBucket] are pure functions — call from any thread.
 */
internal class Sampler internal constructor(
    private val prefs: SharedPreferences,
    private val random: () -> Double,
) {

    /**
     * Session-deterministic verdict (Wave 5, KIX-UNI-22). Records this
     * session iff `sampleBucket(sessionId) < rate*100`. Canonical
     * cross-SDK gate — byte-identical to web recorder.ts
     * `sampleBucket(session_id) < rate * 100` and the iOS port.
     *
     * Semantics matched to web (`recorder.ts`):
     *  - null / blank session id → FALSE (a recording keyed to no
     *    session couldn't be listed or played — fail closed).
     *  - rate ≤ 0 → FALSE (explicit off; also `bucket < 0` is never
     *    true so this is belt-and-suspenders).
     *  - rate clamped to [0,1]; the bucket is compared against the RAW
     *    float threshold `rate*100.0` (NO `.toInt()` truncation) so we
     *    stay byte-identical to web recorder.ts (`bucket < rate*100`)
     *    at off-integer rates — e.g. rate=0.29 → `bucket < 29.0`, so
     *    bucket 28 records and bucket 29 does not. Truncating to an Int
     *    threshold diverged from web at IEEE-754 off-integer rates
     *    (0.07,0.14,0.28,0.29,0.55,0.56,0.57,0.58) → ~1% of sessions
     *    got a different verdict → cross-SDK parity break (KIX-UNI-22).
     *
     * Pure + stable: the same (sessionId, rate) always returns the
     * same answer, on any thread, without persistence or randomness.
     */
    fun sessionDeterministicVerdict(sessionId: String?, sampleRate: Double): Boolean {
        if (sessionId.isNullOrBlank()) return false
        val clamped = sampleRate.coerceIn(0.0, 1.0)
        if (clamped <= 0.0) return false
        // Compare the Int bucket against the RAW float threshold — matches
        // web recorder.ts `sampleBucket(id) < rate * 100` exactly. Do NOT
        // (rate*100).toInt() : that truncation diverges from web at
        // off-integer IEEE-754 rates and breaks cross-SDK parity.
        return sampleBucket(sessionId) < clamped * 100.0
    }

    /**
     * Cached verdict for the lifetime of this Sampler instance. Set
     * once on first [baselineVerdictForSession] call; any subsequent
     * call returns the same answer regardless of [sampleRate]
     * fluctuations. Cleared by [reset] only.
     */
    @Volatile
    private var sessionVerdict: Boolean? = null

    /**
     * Resolve baseline verdict for the current install at the
     * configured rate. Idempotent across the singleton's lifetime —
     * the FIRST call locks in the answer for the whole session.
     *
     * Per [iOS Sampler.swift] semantics, the "rate-increase re-roll"
     * applies ONLY when the persisted verdict was `false`. Devices
     * already in stay in regardless of how the rate changes.
     */
    @Synchronized
    fun baselineVerdictForSession(sampleRate: Double): Boolean {
        sessionVerdict?.let { return it }

        val clamped = sampleRate.coerceIn(0.0, 1.0)
        val priorVerdict =
            if (prefs.contains(KEY_VERDICT)) prefs.getBoolean(KEY_VERDICT, false) else null
        // SharedPreferences uses Float for floating-point; we store as
        // String to avoid the f32→f64 precision drift on a 0.05 ↔ 5e-2
        // round-trip.
        val priorRate: Double? = prefs.getString(KEY_ROLLED_AT_RATE, null)?.toDoubleOrNull()

        // First-time roll OR configured rate increased above the rate
        // we previously rolled "out" at: re-roll using the current
        // rate. The "rate increase" path only re-rolls when prior
        // verdict was false — devices already in stay in.
        val needsRoll =
            priorVerdict == null ||
            (priorVerdict == false && (priorRate ?: 0.0) < clamped)

        val verdict: Boolean = if (needsRoll) {
            val rolled = random() < clamped
            // commit() not apply() — we want the durable write before
            // the SDK reports back, so a crash before next launch
            // doesn't re-roll and risk an inconsistent verdict.
            prefs.edit()
                .putBoolean(KEY_VERDICT, rolled)
                .putString(KEY_ROLLED_AT_RATE, clamped.toString())
                .commit()
            rolled
        } else {
            priorVerdict ?: false
        }

        sessionVerdict = verdict
        return verdict
    }

    /**
     * Force-include this session's recording regardless of the
     * persistent verdict. Used by trigger-based sampling when an
     * on-device pattern detector fires (rage-click / crash) or when
     * the customer's upstream code calls
     * `Kixo.replay.recordNow()`. Single-session — doesn't persist.
     */
    fun triggerOverride(): Boolean = true

    /**
     * Test-only / kill-switch helper. Wipes persisted verdict so the
     * NEXT [baselineVerdictForSession] call performs a fresh roll.
     * Useful for `Kixo.replay.optOut()` after a customer flips the
     * project replay setting OFF — gives them determinism that no
     * further sessions will be captured even if they later re-enable.
     */
    @Synchronized
    fun reset() {
        prefs.edit()
            .remove(KEY_VERDICT)
            .remove(KEY_ROLLED_AT_RATE)
            .commit()
        sessionVerdict = null
    }

    companion object {
        private const val PREFS_NAME = "io.kixo.replay.sampler"
        private const val KEY_VERDICT = "kixo.replay.verdict"
        private const val KEY_ROLLED_AT_RATE = "kixo.replay.rolledAtRate"

        /**
         * Canonical cross-SDK deterministic sampling bucket for a key
         * (KIX-UNI-22). Returns an integer in `[0, 100)`. Byte-identical
         * to the web SDK's `sampleBucket()`
         * (`kixo-web-sdk/src/utils/fingerprint.ts`) and the iOS port so
         * the SAME session id maps to the SAME bucket on every platform.
         *
         * Algorithm (djb2-style 32-bit string hash, unsigned fold):
         * ```
         * hash = 0                                  // JS `let hash = 0`
         * for c in key: hash = (hash << 5) - hash + c.code   // JS `|0`
         * bucket = (hash >>> 0) % 100
         * ```
         *
         * **Int-arithmetic parity with JS `|0`:** Kotlin [Int] is a
         * signed 32-bit two's-complement value, and `shl` / `-` / `+`
         * on it wrap modulo 2^32 exactly like JS's `|0` truncation —
         * NO `Long` promotion happens as long as every operand stays
         * `Int` (`c.code` is an `Int`). The final unsigned fold
         * `(hash.toLong() and 0xFFFFFFFFL) % 100` reproduces JS
         * `(hash >>> 0) % 100`: reinterpret the signed 32-bit hash as
         * an unsigned 32-bit value (0..2^32-1), then mod 100 → a
         * non-negative result in `[0, 100)`.
         *
         * **charCode note:** uses `Char.code` (the Unicode code point).
         * For ASCII this equals JS `charCodeAt`. All Kixo session ids
         * are ASCII (`ses_` / `boot_` + base36), so there is no
         * surrogate-pair / UTF-16-unit divergence to worry about.
         */
        fun sampleBucket(key: String): Int {
            var hash = 0
            for (c in key) {
                // Stays Int → wraps mod 2^32 exactly like JS `((h<<5)-h+c)|0`.
                hash = (hash shl 5) - hash + c.code
            }
            // (hash >>> 0) % 100 : unsigned 32-bit reinterpret, then mod 100.
            return ((hash.toLong() and 0xFFFFFFFFL) % 100).toInt()
        }

        /** Production singleton — uses `SharedPreferences` + `Math.random`. */
        @Volatile
        private var instance: Sampler? = null

        fun getInstance(context: Context): Sampler {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: Sampler(
                    prefs = context.applicationContext
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
                    random = { Random.Default.nextDouble() },
                ).also { instance = it }
            }
        }

        /**
         * Test-only constructor. Lets unit tests inject a fake
         * `SharedPreferences` (Robolectric supplies one) + a
         * deterministic random source.
         */
        @androidx.annotation.VisibleForTesting
        internal fun forTesting(
            prefs: SharedPreferences,
            random: () -> Double,
        ): Sampler = Sampler(prefs, random)
    }
}
