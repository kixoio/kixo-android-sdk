package io.kixo.sdk.internal.attribution

import java.net.URLDecoder

/**
 * Parses a Play Install Referrer string (a URL **query-string** fragment, e.g.
 * `utm_source=foo&utm_medium=bar&kixo_link_id=abc&kxc=<uuid>`) into the
 * canonical §0 wire params.
 *
 * Authoritative parsing + organic detection + fraud classification all run
 * **server-side**: the Play referrer enrichment is parsed by
 * `referrer-post-processor.ts` off the synthetic `install_referrer` batch event,
 * and the deferred click_id is claimed at `/api/sdk/link/resolve`. The SDK
 * parses only to:
 *   1. classify the `DeferredDeepLinkListener` callback (a `kixo_link_id` =>
 *      a deferred link; organic / empty => `null`) without a round-trip, and
 *   2. feed the [InstallAttributionStore] decorate window with the resolved
 *      ids.
 *
 * Keys reference [AttributionContract] — NEVER re-spelled inline (§0 mandate).
 */
internal object ReferrerParser {

    /**
     * @param raw the verbatim referrer string. May be empty, `(not set)`, a
     *   bare `utm_*` tuple, or contain Kixo ids.
     */
    fun parse(raw: String?): ParsedReferrer = canonicalise(raw.orEmpty(), parseQueryString(raw))

    /**
     * Canonicalise an already-extracted param map into a [ParsedReferrer].
     * Shared by [parse] (Play referrer query-string) and [DeepLinkUriParser]
     * (full deep-link URI) so the organic / linkId / clickId / utm logic lives
     * in ONE place.
     */
    fun canonicalise(rawReferrer: String, params: Map<String, String>): ParsedReferrer {
        val linkId = params[AttributionContract.KIXO_LINK_ID_KEY]?.takeIf { it.isNotBlank() }
        // click_id: accept the canonical key (preferred) OR the compact `kxc`
        // alias the redirector uses in the length-sensitive Play referrer.
        val clickId = (
            params[AttributionContract.KIXO_CLICK_ID_KEY]
                ?: params[AttributionContract.KIXO_CLICK_ID_PLAY_ALIAS]
            )?.takeIf { it.isNotBlank() }

        val source = params[AttributionContract.UTM_SOURCE]?.takeIf { it.isNotBlank() }
        val medium = params[AttributionContract.UTM_MEDIUM]?.takeIf { it.isNotBlank() }
        val campaign = (
            params[AttributionContract.UTM_CAMPAIGN]
                ?: params[AttributionContract.KIXO_CAMPAIGN_KEY]
            )?.takeIf { it.isNotBlank() }

        val organic = isOrganic(rawReferrer, source, medium, linkId, clickId)

        return ParsedReferrer(
            rawReferrer = rawReferrer,
            linkId = linkId,
            clickId = clickId,
            campaign = campaign,
            source = source,
            medium = medium,
            params = params,
            isOrganic = organic,
        )
    }

    /**
     * Organic = the Play store-browse sentinel (`utm_source=google-play &
     * utm_medium=organic`) OR an empty / `(not set)` referrer with no Kixo ids.
     * A referrer carrying a `kixo_link_id` / `kixo_click_id` is NEVER organic
     * even if it also carries the sentinel utm pair (campaign wins).
     */
    private fun isOrganic(
        raw: String?,
        source: String?,
        medium: String?,
        linkId: String?,
        clickId: String?,
    ): Boolean {
        if (linkId != null || clickId != null) return false
        val sentinel = source.equals(AttributionContract.ORGANIC_UTM_SOURCE, ignoreCase = true) &&
            medium.equals(AttributionContract.ORGANIC_UTM_MEDIUM, ignoreCase = true)
        if (sentinel) return true
        // Empty / "(not set)" / no attributable params => treat as organic for
        // the listener callback. The backend still records the install.
        val trimmed = raw?.trim().orEmpty()
        if (trimmed.isEmpty() || trimmed.equals("(not set)", ignoreCase = true)) return true
        // No campaign signal of any kind => organic.
        return source == null && medium == null
    }

    /**
     * Split a `key=value&key2=value2` string into a map, URL-decoding both
     * sides (UTF-8). Tolerant: missing `=`, empty segments, and a leading `?`
     * are handled; the LAST value wins on a duplicate key. Never throws.
     */
    private fun parseQueryString(raw: String?): Map<String, String> {
        val s = raw?.trim().orEmpty()
        if (s.isEmpty()) return emptyMap()
        val body = if (s.startsWith("?")) s.substring(1) else s
        val out = LinkedHashMap<String, String>()
        for (pair in body.split("&")) {
            if (pair.isEmpty()) continue
            val eq = pair.indexOf('=')
            val key: String
            val value: String
            if (eq < 0) {
                key = decode(pair)
                value = ""
            } else {
                key = decode(pair.substring(0, eq))
                value = decode(pair.substring(eq + 1))
            }
            if (key.isNotEmpty()) out[key] = value
        }
        return out
    }

    private fun decode(v: String): String = try {
        // Play referrer uses `+` for spaces and %-encoding (it's a URL query).
        URLDecoder.decode(v, "UTF-8")
    } catch (_: Throwable) {
        v
    }
}

/**
 * Parsed, canonical view of a referrer string. [isOrganic] true => the install
 * had no campaign / link (the listener fires `null`).
 */
internal data class ParsedReferrer(
    val rawReferrer: String,
    val linkId: String?,
    val clickId: String?,
    val campaign: String?,
    val source: String?,
    val medium: String?,
    val params: Map<String, String>,
    val isOrganic: Boolean,
)
