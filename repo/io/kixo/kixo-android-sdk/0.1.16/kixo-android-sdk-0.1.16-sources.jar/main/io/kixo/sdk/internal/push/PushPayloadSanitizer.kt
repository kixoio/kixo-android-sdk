package io.kixo.sdk.internal.push

import io.kixo.sdk.internal.push.Sha256Helper.sha256Hex

/**
 * Distills a raw FCM `RemoteMessage.data` map (or arbitrary
 * caller-supplied payload) into the privacy-aware property bundle
 * that lands in `push_*` events.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Push/PushPayloadSanitizer.swift`
 * with two intentional Android-specific differences:
 *
 *  1. **Default mode is [ContentMode.HASH_ONLY], not `.full`.** See
 *     [ContentMode] for rationale — the iOS default is a historical
 *     product decision; new platform ships safer.
 *  2. **No `aps` block.** APNs has a wrapping `aps` dict; FCM's data
 *     payload is flat, with conventional keys `title` / `body` (top
 *     level) plus `notification.title` / `notification.body` when the
 *     server uses the FCM "notification" message type. We tolerate
 *     both shapes.
 *
 * What ALWAYS escapes (regardless of mode):
 *   - `kixo_campaign_id` / `kixo_delivery_id` / `kixo_job_id` /
 *     `kixo_push_id` / `kixo_send_id` — Kixo-injected metadata the customer's send
 *     pipeline embeds. These are routing / attribution ids, not user
 *     content; they're safe at every mode.
 *   - `content_hash` — SHA-256 of `title + "" + body` (when
 *     either is present). Same content → same hash, lets the dashboard
 *     aggregate "one promo sent to 10k users" into a single row even
 *     when the body is fully redacted.
 *
 * What NEVER escapes (regardless of mode):
 *   - User-typed reply text (Android `RemoteInput` action results).
 *     The caller passes `actionId` to `Kixo.logPushAction(...)` but
 *     the SDK has zero code paths that read the reply text.
 *   - Raw deep-link URLs. If a `link` / `deep_link` key is present the
 *     sanitizer surfaces a `has_deep_link: true` flag — never the URL.
 *
 * **Pure**: no I/O, no global state, no thread affinity. Safe to call
 * from any thread; the `mode` is captured at construction and is
 * effectively final for the instance's lifetime.
 */
internal class PushPayloadSanitizer(
    /**
     * Captured at construction. PushTracker rebuilds the sanitizer
     * if the dashboard pushes a new mode via remote config — we
     * don't make this mutable so concurrent sanitize calls during
     * a config swap can't see a torn state.
     */
    private val mode: ContentMode,
    /** Title preview cap. Default 40 chars matches iOS. */
    private val titleLimit: Int = TITLE_PREVIEW_CHARS,
    /** Body preview cap. Default 80 chars matches iOS. */
    private val bodyLimit: Int = BODY_PREVIEW_CHARS,
) {

    /**
     * Distill [payload] into the property map attached to a `push_*`
     * event.
     *
     * @param payload Either the FCM `RemoteMessage.data` map (string
     *   values), or — for the manual-API path — a caller-built
     *   `Map<String, Any?>`. We tolerate non-string values and
     *   coerce via [toString] when surfacing.
     * @return Properties safe to ship per the configured [mode]. Keys
     *   are always lowercase snake_case (R3). Caller should NOT mutate
     *   the returned map after calling — we hand back a new mutable
     *   `LinkedHashMap` so insertion order is stable for tests.
     */
    fun sanitize(payload: Map<String, Any?>): Map<String, Any?> {
        val out: MutableMap<String, Any?> = LinkedHashMap()

        // Always-on Kixo metadata — these are not user content.
        // The send-pipeline injects them under flat keys for FCM
        // (matching the dashboard's send_push step in the workflow
        // engine — see project_pushes.md).
        payload.firstNonEmptyString(
            "kixo_campaign_id", "campaign_id"
        )?.let { out["kixo_campaign_id"] = it }
        payload.firstNonEmptyString(
            "kixo_delivery_id", "delivery_id"
        )?.let { out["kixo_delivery_id"] = it }
        payload.firstNonEmptyString(
            "kixo_job_id", "job_id"
        )?.let { out["kixo_job_id"] = it }
        payload.firstNonEmptyString(
            "kixo_push_id", "push_id"
        )?.let { out["kixo_push_id"] = it }
        payload.firstNonEmptyString(
            "kixo_send_id", "send_id"
        )?.let { out["kixo_send_id"] = it }

        // Echo the mode so dashboard / observability tooling can tell
        // at a glance which redaction tier the SDK was running in
        // when the event was emitted. Useful for debugging
        // "where did the title go?" tickets.
        out["content_mode"] = mode.wireValue

        // Has-deep-link flag (NEVER the URL). Both FCM "data message"
        // (`link`) and Kixo's own internal convention (`deep_link`)
        // are checked. We do NOT hash the URL — iOS does, but a URL
        // hash adds wire bytes for vanishing dashboard utility on
        // Android (no deep-link analytics exist for it yet).
        //
        // The key set + ORDER is the SINGLE owned constant
        // `PushDeepLinkExtractor.DEEP_LINK_KEYS` — the SAME list
        // `Kixo.logPushOpened` ROUTES on (AND-DL-11). Referencing it here
        // (rather than re-spelling `"deep_link","link","url"`) guarantees the
        // `has_deep_link` flag the dashboard sees and the URL the SDK routes
        // through `handleDeepLink` are decided by ONE list — a reorder can never
        // make the flag diverge from the routed URL.
        if (payload.firstNonEmptyString(
                *io.kixo.sdk.internal.attribution.PushDeepLinkExtractor.DEEP_LINK_KEYS.toTypedArray(),
            ) != null
        ) {
            out["has_deep_link"] = true
        }

        // Pull the alert strings up-front — both flat-FCM and
        // notification-message shapes are tolerated.
        val title = extractTitle(payload)
        val body = extractBody(payload)
        val subtitle = (payload["subtitle"] as? String).normalized()

        // Content hash is mode-independent. Computed even in FULL mode
        // so the dashboard's "group by content_hash" query works
        // uniformly regardless of which device sent which mode.
        // Skipped only when there's literally nothing to hash.
        contentHash(title = title, body = body)?.let { out["content_hash"] = it }

        when (mode) {
            ContentMode.FULL -> {
                title?.let { out["title"] = it }
                body?.let { out["body"] = it }
                subtitle?.let { out["subtitle"] = it }
            }
            ContentMode.PREVIEW -> {
                // No subtitle in PREVIEW — matches iOS. The product
                // rationale is that subtitle is rare and almost
                // always redundant with title; cutting it tightens
                // the privacy budget without hurting the dashboard.
                title?.preview(titleLimit)?.let { out["title"] = it }
                body?.preview(bodyLimit)?.let { out["body"] = it }
            }
            ContentMode.HASH_ONLY -> {
                // Nothing — only content_hash + Kixo metadata escape.
            }
        }

        return out
    }

    // ─── Helpers ────────────────────────────────────────────────

    /**
     * FCM data messages have `title` at the top level. FCM
     * notification messages put it under `notification.title` (which
     * the FCM SDK surfaces as `RemoteMessage.notification.title`, but
     * a customer who serializes the whole `RemoteMessage` to a map
     * for us can use either shape — we don't impose one).
     */
    private fun extractTitle(payload: Map<String, Any?>): String? {
        return (payload["title"] as? String).normalized()
            ?: ((payload["notification"] as? Map<*, *>)?.get("title") as? String).normalized()
    }

    private fun extractBody(payload: Map<String, Any?>): String? {
        return (payload["body"] as? String).normalized()
            ?: (payload["message"] as? String).normalized()
            ?: ((payload["notification"] as? Map<*, *>)?.get("body") as? String).normalized()
    }

    /**
     * Hash key identifying identical pushes. Includes title + body
     * with a unit-separator delimiter so `("hello", "world")` and
     * `("helloworld", "")` don't collide. Returns `null` when both
     * are empty — emitting a hash of "" everywhere would create
     * spurious aggregation buckets.
     */
    private fun contentHash(title: String?, body: String?): String? {
        if (title.isNullOrEmpty() && body.isNullOrEmpty()) return null
        //  = ASCII unit-separator. Vanishingly unlikely to
        // appear in real push copy; prevents the (a, bc) vs (ab, c)
        // collision cheaply without per-field length prefixes.
        val joined = (title.orEmpty()) + "" + (body.orEmpty())
        return joined.sha256Hex()
    }

    /**
     * Truncate to [limit] code points, append `…` when cut. Newlines
     * collapse into spaces and edge whitespace is trimmed so dashboard
     * tables render cleanly. Returns `null` when input becomes empty
     * post-trim.
     */
    private fun String.preview(limit: Int): String? {
        val collapsed = this
            .replace('\n', ' ')
            .replace('\r', ' ')
            .trim()
        if (collapsed.isEmpty()) return null
        // `length` here is UTF-16 code units. For pure ASCII / BMP
        // push copy this matches "characters" 1:1, which is what the
        // 40 / 80 limits target. Surrogate pairs cut mid-character
        // would be a bug only on emoji-heavy push copy — accepted as
        // a known minor display issue, not a privacy or correctness
        // regression. Same trade-off as iOS.
        if (collapsed.length <= limit) return collapsed
        return collapsed.substring(0, limit) + "…"
    }

    /** Treat blank strings as missing — avoids `title: ""` noise. */
    private fun String?.normalized(): String? {
        if (this == null) return null
        val trimmed = this.trim()
        return if (trimmed.isEmpty()) null else trimmed
    }

    /**
     * Look up the first non-empty string under any of [keys]. Used
     * for both Kixo metadata (where the wire-format key is
     * `kixo_campaign_id` but customers occasionally pass the bare
     * `campaign_id`) and deep-link detection.
     */
    private fun Map<String, Any?>.firstNonEmptyString(vararg keys: String): String? {
        for (k in keys) {
            val v = this[k] as? String
            if (!v.isNullOrEmpty()) return v
        }
        return null
    }

    companion object {
        /** Default title preview cap (chars). Matches iOS. */
        const val TITLE_PREVIEW_CHARS = 40

        /** Default body preview cap (chars). Matches iOS. */
        const val BODY_PREVIEW_CHARS = 80
    }
}
