package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

/** Small seam that keeps WorkManager scheduling deterministic in unit tests. */
internal fun interface ReplayWorkScheduler {
    fun enqueue(
        context: Context,
        workName: String,
        inputData: Data,
        captureOnCellular: Boolean,
        sessionId: String,
    ): Boolean
}

internal object WorkManagerReplayWorkScheduler : ReplayWorkScheduler {
    override fun enqueue(
        context: Context,
        workName: String,
        inputData: Data,
        captureOnCellular: Boolean,
        sessionId: String,
    ): Boolean {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(ReplayUploader.requiredNetworkType(captureOnCellular))
            .setRequiresBatteryNotLow(true)
            .build()
        val request = OneTimeWorkRequestBuilder<UploadWorker>()
            .setConstraints(constraints)
            .setInputData(inputData)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .addTag("kixo-replay")
            .addTag("kixo-replay-session-$sessionId")
            .build()
        return try {
            WorkManager.getInstance(context).enqueueUniqueWork(
                workName,
                ExistingWorkPolicy.REPLACE,
                request,
            )
            true
        } catch (t: Throwable) {
            // Host apps may disable the default WorkManager initialiser without
            // registering their own. Replay remains best-effort.
            Log.w(TAG, "WorkManager unavailable; couldn't schedule staged frame", t)
            false
        }
    }

    private const val TAG = "Kixo.ReplayUploader"
}
