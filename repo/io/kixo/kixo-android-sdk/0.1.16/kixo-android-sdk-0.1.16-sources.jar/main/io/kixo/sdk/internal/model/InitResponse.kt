package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Response body from `POST /api/sdk/init`. The backend route is
 * defined in `kixo-backend/apps/web/src/app/api/sdk/init/route.ts`
 * (~ line 209 + line 98 for the kill-switch branch).
 *
 * **Wire shape (happy path):**
 * ```json
 * {
 *   "release_id": "rel_…",
 *   "app_id": "app_…",
 *   "app_name": "MyApp iOS",
 *   "paused": false,
 *   "data_collection": { "events": true, "replay": false, ... },
 *   "max_batch_size": 200,
 *   "maintenance_message": "All systems normal"
 * }
 * ```
 *
 * **Wire shape (kill-switched):**
 * ```json
 * {
 *   "paused": true,
 *   "paused_reason": "sdk_version_disabled",
 *   "release_id": "",
 *   "app_id": "",
 *   "app_name": "",
 *   "data_collection": {}
 * }
 * ```
 *
 * **Field contracts:**
 *
 *  - `data_collection` is typed as the nested [DataCollection]
 *    model so every per-feature toggle (`core.pageViews`,
 *    `engagement.clicks`, `replay.enabled`, `push.contentMode`, …)
 *    routes through [io.kixo.sdk.internal.queue.DataCollectionHolder]
 *    on /init success. Pre-typed kotlinx.serialization handles the
 *    parsing automatically; missing or unknown fields decode to
 *    `null` (default-allow per consumer).
 *
 *  - `paused_reason` is null in the happy path. When `paused=true`
 *    it carries one of `"sdk_version_disabled" | "below_min_sdk_version"
 *    | "maintenance"` (open set — unknown values mean "stop sending").
 *
 *  - `max_batch_size` and `maintenance_message` are admin-overrides
 *    surfaced from `kixo-admin` SDK Defaults panel. Both null in
 *    the common case.
 *
 *  - All event-/replay-paused branches still return `release_id`
 *    + `app_id` + `app_name` (often empty strings) so the SDK can
 *    cache the response uniformly without conditional shape checks.
 */
@Serializable
internal data class InitResponse(
    @SerialName("release_id")
    val releaseId: String = "",

    @SerialName("app_id")
    val appId: String = "",

    @SerialName("app_name")
    val appName: String = "",

    @SerialName("paused")
    val paused: Boolean = false,

    @SerialName("paused_reason")
    val pausedReason: String? = null,

    @SerialName("data_collection")
    val dataCollection: DataCollection? = null,

    @SerialName("max_batch_size")
    val maxBatchSize: Int? = null,

    @SerialName("maintenance_message")
    val maintenanceMessage: String? = null,
)
