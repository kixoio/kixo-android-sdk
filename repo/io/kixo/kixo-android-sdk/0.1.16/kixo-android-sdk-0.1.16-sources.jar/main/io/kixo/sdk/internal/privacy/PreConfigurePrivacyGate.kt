package io.kixo.sdk.internal.privacy

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Linearises privacy calls that arrive before [io.kixo.sdk.Kixo.configure].
 *
 * Ordinary SDK calls may be buffered until the queue exists, but a privacy
 * signal cannot be: `/init`, lifecycle observers and push/replay wiring must
 * see the signal before they start. This gate records only the two independent
 * privacy bits and applies them synchronously when [activate] is called after
 * [ConsentManager.init], before any SDK subsystem is bootstrapped.
 *
 * The same lock covers activation and updates, so a concurrent `optOut()` can
 * never fall into the gap between "configure won its CAS" and "consent state
 * was restored from disk". Either it is part of the pending snapshot or it is
 * applied directly to the live manager.
 */
internal class PreConfigurePrivacyGate {
    private val lock = Any()

    private var active: Boolean = false
    private var pendingOptedOut: Boolean? = null
    private var pendingConsentGranted: Boolean? = null
    /** Last explicit project-replay veto issued in this process. */
    private var pendingReplayOptedOut: Boolean? = null
    /** Installed once project/context/replay policy wiring is available. */
    private var applyReplayOptedOut: ((Boolean) -> Unit)? = null
    /** Lock-free fence read by control-plane apply while a replay edge commits. */
    @Volatile private var replayTransitionInProgress: Boolean = false

    /**
     * Invalidates raw-data work that was authorised before a hard privacy
     * transition. Only disallowing transitions advance this epoch; redundant
     * opt-in/grant calls must not cancel otherwise-valid work.
     */
    private var collectionEpoch: Long = 0L

    /** Jobs whose block may cross a raw-data network boundary. */
    private val collectionJobs = LinkedHashSet<Job>()
    /** Calls atomically admitted in [collectionEpoch]. */
    private val collectionCalls = LinkedHashSet<Call>()

    internal class CollectionLease internal constructor(
        val epoch: Long,
        private val releaseOnce: () -> Unit,
    ) {
        private val closed = AtomicBoolean(false)
        fun close() {
            if (closed.compareAndSet(false, true)) releaseOnce()
        }
    }

    internal class CollectionCallRejectedException : IOException(
        "collection privacy boundary rejected network call",
    )

    /**
     * Linearised public opt-out transition. [afterUpdate] deliberately runs
     * under the same monitor as the state mutation, so queue/replay side
     * effects cannot be reordered by a concurrent opt-in call.
     */
    fun updateOptedOut(
        value: Boolean,
        apply: (Boolean) -> Unit,
        afterUpdate: () -> Unit,
    ) {
        synchronized(lock) {
            if (active) apply(value) else pendingOptedOut = value
            if (value) invalidateCollectionJobsLocked()
            afterUpdate()
        }
    }

    fun updateOptedOut(value: Boolean, apply: (Boolean) -> Unit) {
        updateOptedOut(value, apply, afterUpdate = {})
    }

    /** Same linearisation boundary as [updateOptedOut] for CMP consent. */
    fun updateConsentGranted(
        value: Boolean,
        apply: (Boolean) -> Unit,
        afterUpdate: () -> Unit,
    ) {
        synchronized(lock) {
            if (active) apply(value) else pendingConsentGranted = value
            if (!value) invalidateCollectionJobsLocked()
            afterUpdate()
        }
    }

    fun updateConsentGranted(value: Boolean, apply: (Boolean) -> Unit) {
        updateConsentGranted(value, apply, afterUpdate = {})
    }

    /** Apply the last explicit pre-config values, then switch to live mode. */
    fun activate(
        applyOptedOut: (Boolean) -> Unit,
        applyConsentGranted: (Boolean) -> Unit,
    ) {
        synchronized(lock) {
            if (active) return
            pendingOptedOut?.let(applyOptedOut)
            pendingConsentGranted?.let(applyConsentGranted)
            pendingOptedOut = null
            pendingConsentGranted = null
            active = true
        }
    }

    fun effectiveOptedOut(live: () -> Boolean): Boolean = synchronized(lock) {
        pendingOptedOut ?: live()
    }

    fun effectiveConsentGranted(live: () -> Boolean): Boolean = synchronized(lock) {
        pendingConsentGranted ?: live()
    }

    /**
     * Run a collection-state commit under the same privacy boundary used by
     * opt-out and consent transitions. Callers may take their own locks inside
     * [block], but must never acquire this gate while holding those locks.
     */
    fun <T> withCollectionAllowed(
        liveOptedOut: () -> Boolean,
        liveConsentGranted: () -> Boolean,
        denied: T,
        block: () -> T,
    ): T = synchronized(lock) {
        val optedOut = pendingOptedOut ?: liveOptedOut()
        val consentGranted = pendingConsentGranted ?: liveConsentGranted()
        if (optedOut || !consentGranted) denied else block()
    }

    /**
     * Record the local replay-only negative veto without granting positive
     * authority. Kixo.replayOptOut() separately stops ReplayController
     * immediately; this bit makes bootstrap and WorkManager see the same veto
     * before the buffered project-scoped persistence action can run.
     */
    fun recordReplayOptedOut(value: Boolean) {
        updateReplayOptedOut(value, afterUpdate = {})
    }

    /**
     * Linearise the replay-only veto together with its persisted-policy and
     * controller side effects. Without this boundary, concurrent
     * replayOptOut()/replayOptIn() calls could publish `false` as the newest
     * in-memory bit but let the slower opt-out commit `true` to disk last.
     */
    fun updateReplayOptedOut(value: Boolean, afterUpdate: () -> Unit) {
        synchronized(lock) {
            pendingReplayOptedOut = value
            replayTransitionInProgress = true
            try {
                afterUpdate()
                applyReplayOptedOut?.invoke(value)
            } finally {
                replayTransitionInProgress = false
            }
        }
    }

    /** Never takes [lock]: QueueWiring calls this while holding its own apply lock. */
    fun isReplayTransitionInProgress(): Boolean = replayTransitionInProgress

    /**
     * Atomically snapshot the effective replay veto, construct the scoped
     * policy/wiring from that value, and install its future transition callback.
     * Holding the replay mutation monitor across all three steps closes the
     * bootstrap gap where opt-out could land after the snapshot but before the
     * WorkManager-visible policy registry was published.
     */
    fun <T> installReplayWiring(
        liveOptedOut: () -> Boolean,
        build: (Boolean) -> T,
        apply: (T, Boolean) -> Unit,
    ): T = synchronized(lock) {
        val effective = pendingReplayOptedOut ?: liveOptedOut()
        val wiring = build(effective)
        if (applyReplayOptedOut == null) {
            applyReplayOptedOut = { value -> apply(wiring, value) }
            // Persist/apply an explicit pre-wiring override. With no override,
            // the freshly-built policy already reflects the live store.
            pendingReplayOptedOut?.let { apply(wiring, it) }
        }
        wiring
    }

    fun effectiveReplayOptedOut(live: () -> Boolean): Boolean = synchronized(lock) {
        pendingReplayOptedOut ?: live()
    }

    /**
     * Register cancellable work at the final raw-data boundary.
     *
     * The permission check, job registration and every disallowing privacy
     * transition share [lock]. Therefore either the job is registered first
     * and opt-out/revoke cancels it before returning, or privacy wins first
     * and no job is created. The coroutine re-checks the captured epoch before
     * entering [block], closing the queued-before-dispatch race as well.
     */
    fun launchCollectionTask(
        scope: CoroutineScope,
        liveOptedOut: () -> Boolean,
        liveConsentGranted: () -> Boolean,
        block: suspend (Long) -> Unit,
    ): Job? = synchronized(lock) {
        if (!active || liveOptedOut() || !liveConsentGranted()) return@synchronized null

        val authorisedEpoch = collectionEpoch
        lateinit var job: Job
        job = scope.launch(start = CoroutineStart.LAZY) {
            val stillAllowed = synchronized(lock) {
                authorisedEpoch == collectionEpoch &&
                    active &&
                    !liveOptedOut() &&
                    liveConsentGranted()
            }
            if (!stillAllowed) return@launch
            block(authorisedEpoch)
        }
        collectionJobs += job
        job.invokeOnCompletion {
            synchronized(lock) { collectionJobs.remove(job) }
        }
        job.start()
        job
    }

    /**
     * Register an already-created flush job before it reads any durable rows.
     * A reset/opt-out either cancels this exact job before returning or wins
     * before registration and the caller's subsequent lifecycle check fails.
     */
    fun registerCollectionTask(
        job: Job,
        liveOptedOut: () -> Boolean,
        liveConsentGranted: () -> Boolean,
    ): CollectionLease? = synchronized(lock) {
        if (!active || liveOptedOut() || !liveConsentGranted()) return@synchronized null
        val epoch = collectionEpoch
        collectionJobs += job
        val lease = CollectionLease(epoch) {
            synchronized(lock) { collectionJobs.remove(job) }
        }
        job.invokeOnCompletion { lease.close() }
        lease
    }

    /**
     * Final raw-data socket boundary shared by event batches and push tokens.
     * Check + active-call registration + `enqueue()` are indivisible from a
     * privacy/reset epoch rotation.
     */
    suspend fun executeCollectionCall(
        authorisedEpoch: Long,
        call: Call,
    ): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { runCatching { call.cancel() } }
        val admitted = try {
            synchronized(lock) {
                if (!active || authorisedEpoch != collectionEpoch) return@synchronized false
                collectionCalls += call
                try {
                    call.enqueue(object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                            unregisterCollectionCall(call)
                            if (continuation.isActive) {
                                continuation.resumeWith(Result.failure(e))
                            }
                        }

                        override fun onResponse(call: Call, response: Response) {
                            unregisterCollectionCall(call)
                            if (continuation.isActive) {
                                continuation.resume(response)
                            } else {
                                response.close()
                            }
                        }
                    })
                } catch (t: Throwable) {
                    collectionCalls.remove(call)
                    throw t
                }
                true
            }
        } catch (t: Throwable) {
            if (continuation.isActive) continuation.resumeWith(Result.failure(t))
            true
        }
        if (!admitted && continuation.isActive) {
            runCatching { call.cancel() }
            continuation.resumeWith(Result.failure(CollectionCallRejectedException()))
        }
    }

    /** Identity/server-pause boundary that does not itself revoke consent. */
    fun rotateCollectionBoundary() {
        synchronized(lock) { invalidateCollectionJobsLocked() }
    }

    private fun unregisterCollectionCall(call: Call) {
        synchronized(lock) { collectionCalls.remove(call) }
    }

    private fun invalidateCollectionJobsLocked() {
        collectionEpoch += 1L
        val jobs = collectionJobs.toList()
        collectionJobs.clear()
        jobs.forEach { it.cancel() }
        val calls = collectionCalls.toList()
        collectionCalls.clear()
        calls.forEach { runCatching { it.cancel() } }
    }
}
