package io.kixo.sdk.internal.queue

import io.kixo.sdk.internal.model.DataCollection
import java.util.concurrent.atomic.AtomicReference

/**
 * Process-wide snapshot of the latest `data_collection` payload
 * received from `/api/sdk/init`. Every tracker (ScreenTracker,
 * TouchInterceptor, CrashTracker, SessionTracker, ReplayController,
 * PushTracker, IdentityManager-side property setters, DeviceInfo
 * volatile reads) checks this at EMIT time so an operator dashboard
 * toggle takes effect on the very next event without re-installing
 * any per-Activity hook.
 *
 * Pre-config the snapshot is `null` → every `isAllowed(...)` call
 * defaults to `true` (allow). This keeps the cold-start window
 * — the ~50-500 ms between `Kixo.configure(...)` and the /init
 * response — from silently dropping events the operator might want.
 *
 * After /init lands, `QueueWiring.runInitWithRetry` sets the
 * snapshot. Subsequent /init re-runs (e.g. backend pushed a new
 * config) overwrite — last-writer-wins.
 *
 * **Threading**: backed by [AtomicReference] so reads on the hot
 * tracker paths (every tap, every screen visit) pay one volatile
 * load. Writes are lock-free.
 */
internal object DataCollectionHolder {
    private val ref = AtomicReference<DataCollection?>(null)

    /**
     * Replace the snapshot. Called from [QueueWiring.runInitWithRetry]
     * on every successful /init response. `null` clears (rare — only
     * used by tests).
     */
    fun set(dc: DataCollection?) {
        ref.set(dc)
    }

    /**
     * Read the current snapshot. Returns `null` when /init hasn't
     * landed yet (cold-start window) OR when the server omitted
     * `data_collection` entirely (kill-switched paused response).
     */
    fun snapshot(): DataCollection? = ref.get()

    /**
     * Convenience lookup with safe default. Pass [default] = true
     * for fields that should default-allow (most), false for fields
     * that should default-deny (the conservative privacy floor —
     * not used by current callers).
     *
     * Usage:
     * ```
     * if (!DataCollectionHolder.isAllowed { it.core?.pageViews }) return
     * ```
     */
    inline fun isAllowed(default: Boolean = true, lookup: (DataCollection) -> Boolean?): Boolean {
        val dc = snapshot() ?: return default
        return lookup(dc) ?: default
    }

    /**
     * Test-only — clear the holder so a fresh test sees the default
     * "allow everything" pre-config behaviour.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        ref.set(null)
    }
}
