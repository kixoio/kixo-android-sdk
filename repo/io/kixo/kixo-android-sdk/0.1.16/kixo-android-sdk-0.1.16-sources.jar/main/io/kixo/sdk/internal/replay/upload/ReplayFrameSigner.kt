package io.kixo.sdk.internal.replay.upload

import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException

/**
 * Issues a fresh, exact `(session, seq, kind)` upload lease at WorkManager
 * execution time. Staged frames can wait hours for Wi-Fi; carrying the
 * ten-minute URL captured with the frame would make a healthy delayed upload
 * fail permanently with 403 before it ever got a chance to send.
 */
internal class ReplayFrameSigner(
    private val httpClient: OkHttpClient,
    private val json: Json = Json { ignoreUnknownKeys = true; encodeDefaults = false },
) {
    internal data class Input(
        val baseUrl: String,
        val projectId: String,
        val apiKey: String,
        val sessionId: String,
        val installationId: String,
        val seq: Long,
        val kind: FrameKind,
        val expectedGcsPath: String,
        val policyToken: String,
    )

    internal sealed interface Outcome {
        data class Fresh(val lease: SignedUrlClient.SignedUrl) : Outcome
        data class PolicyRejected(val decision: ReplayRuntimePolicy.WorkerDecision) : Outcome
        data object Retry : Outcome
        data object PermanentFailure : Outcome
        data object RemotePaused : Outcome
    }

    @Serializable
    private data class SignRequest(
        @SerialName("project_id") val projectId: String,
        @SerialName("api_key") val apiKey: String,
        @SerialName("session_id") val sessionId: String,
        @SerialName("installation_id") val installationId: String,
        @SerialName("from_seq") val fromSeq: Long,
        @EncodeDefault(EncodeDefault.Mode.ALWAYS)
        @SerialName("count") val count: Int = 1,
        @EncodeDefault(EncodeDefault.Mode.ALWAYS)
        @SerialName("sealed_retry") val sealedRetry: Boolean = true,
        @SerialName("kind") val kind: String,
        @SerialName("expected_gcs_path") val expectedGcsPath: String,
        @EncodeDefault(EncodeDefault.Mode.ALWAYS)
        @SerialName("platform") val platform: String = "android",
    )

    suspend fun sign(
        input: Input,
        connected: Boolean,
        metered: Boolean,
    ): Outcome {
        if (input.baseUrl.isBlank() || input.projectId.isBlank() || input.apiKey.isBlank() ||
            input.sessionId.isBlank() || input.installationId.isBlank() || input.seq < 0L ||
            input.expectedGcsPath.isBlank()
        ) {
            return Outcome.PermanentFailure
        }
        val body = runCatching {
            json.encodeToString(
                SignRequest.serializer(),
                SignRequest(
                    projectId = input.projectId,
                    apiKey = input.apiKey,
                    sessionId = input.sessionId,
                    installationId = input.installationId,
                    fromSeq = input.seq,
                    kind = input.kind.wire,
                    expectedGcsPath = input.expectedGcsPath,
                ),
            )
        }.getOrElse { return Outcome.PermanentFailure }
        val request = runCatching {
            Request.Builder()
                .url(Endpoints.url(input.baseUrl, Endpoints.REPLAY_FRAMES_SIGN))
                .post(body.toRequestBody(JSON_MEDIA_TYPE))
                .header("Authorization", "Bearer ${input.apiKey}")
                .header("Content-Type", "application/json; charset=utf-8")
                .build()
        }.getOrElse { return Outcome.PermanentFailure }

        val guarded = try {
            ReplayRuntimePolicy.executeWorkerCall(
                token = input.policyToken,
                connected = connected,
                metered = metered,
                call = httpClient.newCall(request),
            )
        } catch (_: IOException) {
            return Outcome.Retry
        } catch (_: Throwable) {
            return Outcome.Retry
        }
        if (guarded is ReplayRuntimePolicy.WorkerCallResult.Rejected) {
            return Outcome.PolicyRejected(guarded.decision)
        }

        return (guarded as ReplayRuntimePolicy.WorkerCallResult.Executed).response.use { response ->
            when {
                response.code == 429 || response.code in 500..599 -> Outcome.Retry
                response.code == 409 -> {
                    // OPEN-read → concurrent session/end seal → watermark
                    // CAS conflict is retryable. Other 409s (notably an exact
                    // GCS-path mismatch) are permanent and must not retain raw
                    // pixels forever.
                    val error = runCatching {
                        json.parseToJsonElement(response.body?.string().orEmpty())
                            .jsonObject["error"]?.jsonPrimitive?.content
                    }.getOrNull()
                    if (error == WATERMARK_CHANGED_ERROR) Outcome.Retry
                    else Outcome.PermanentFailure
                }
                response.code in 400..499 -> Outcome.PermanentFailure
                !response.isSuccessful -> Outcome.Retry
                else -> {
                    val decoded = runCatching {
                        json.decodeFromString(
                            SignedUrlClient.SignMoreResponse.serializer(),
                            response.body?.string().orEmpty(),
                        )
                    }.getOrNull() ?: return@use Outcome.Retry
                    if (decoded.paused) {
                        ReplayRuntimePolicy.denyWorkerTokenUntilFreshPolicy(input.policyToken)
                        return@use Outcome.RemotePaused
                    }
                    if (!decoded.ok) return@use Outcome.PermanentFailure
                    val exact = decoded.signedUrls.firstOrNull {
                        it.seq == input.seq && it.kind == input.kind.wire
                    }
                    if (exact == null) {
                        return@use if (decoded.truncated) {
                            Outcome.PermanentFailure
                        } else {
                            Outcome.Retry
                        }
                    }
                    if (exact.url.isBlank() || exact.gcsPath != input.expectedGcsPath
                    ) {
                        return@use Outcome.PermanentFailure
                    }
                    Outcome.Fresh(exact)
                }
            }
        }
    }

    private companion object {
        val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        const val WATERMARK_CHANGED_ERROR = "Session lease watermark changed"
    }
}
