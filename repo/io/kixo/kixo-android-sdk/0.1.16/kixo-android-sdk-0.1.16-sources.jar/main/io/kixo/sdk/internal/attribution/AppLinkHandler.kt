package io.kixo.sdk.internal.attribution

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.util.Log
import io.kixo.sdk.internal.lifecycle.KixoActivityListener
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Auto-handles the **COLD-START launch intent** deep link (AND-DL-08).
 *
 * ### Why this is COLD-START ONLY (the load-bearing platform constraint)
 * The SDK's lifecycle layer observes `Application.ActivityLifecycleCallbacks`
 * via [KixoActivityListener] (`ActivityLifecycleObserver`) — which has
 * `onActivityCreated/Started/Resumed/Paused/Stopped/Destroyed` but **no
 * `onNewIntent`**. `onNewIntent` is an `Activity` method (not part of the
 * `Application` callback set), so a WARM tap into an already-running
 * `singleTask`/`singleTop` Activity — delivered ONLY to `Activity.onNewIntent`
 * — is invisible to the SDK. The warm path is therefore a documented HOST
 * contract: the host forwards `intent.data` via `Kixo.handleDeepLink(uri,
 * "applink")` (§2.2 / §3.4). This class closes the COLD case — the one the
 * SDK *can* see without a host call.
 *
 * ### Mechanism
 * On the **first** `onActivityResumed` after `configure()` (guarded by the
 * [launchIntentConsumed] `AtomicBoolean.compareAndSet(false,true)` so a config
 * change / return-from-background / a second Activity never re-reads it), close
 * the durable first-launch eligibility and read `activity.intent` (the launch
 * Intent). Closing eligibility at observation time, rather than `configure()`,
 * survives a process crash between `Application.onCreate` and the first
 * Activity. When it is an `ACTION_VIEW` with a
 * non-empty data URI that passes the [deepLinkHosts] allow-list, hand the URI to
 * [onColdDeepLink] (which routes into `Kixo.handleDeepLink(uri, "applink")` — the
 * SHARED single deep-link processing path, so the cold + warm + push opens all
 * emit the SAME `deep_link` event + open the SAME attribution window via ONE
 * code path, never a forked second implementation). The 2s same-uri dedup inside
 * `handleDeepLink` additionally protects against a host that ALSO calls
 * `handleDeepLink` from its own `onCreate`.
 *
 * ### Late-registration backfill ([backfillFromResumedActivity])
 * `ActivityLifecycleObserver` does NOT backfill listeners for an
 * already-resumed Activity (it only fans out FUTURE lifecycle events). For the
 * common case — `Kixo.configure()` from `Application.onCreate` — the listener is
 * registered BEFORE the launcher Activity reaches `onActivityResumed`, so the
 * `onActivityResumed` read fires normally. But a host that calls
 * `Kixo.configure()` from inside the launcher Activity's own `onCreate`/`onResume`
 * registers this listener too LATE: the launcher is already resumed, no further
 * `onActivityResumed` will arrive for it, and the cold VIEW launch intent would be
 * silently missed (no `deep_link` event, no attribution window). To close that,
 * `configure()` calls [backfillFromResumedActivity] with
 * `KixoInternalBootstrap.currentActivity()` right after registering — running the
 * SAME one-shot read against the already-resumed Activity. The shared
 * [launchIntentConsumed] CAS makes the two entry points mutually exclusive: only
 * the FIRST of (backfill, first onActivityResumed) reads the intent; the other
 * is a no-op. (The 2s `handleDeepLink` dedup is a second line of defence either
 * way.) The documented host fallback — calling `Kixo.handleDeepLink(uri,
 * "applink")` from `onCreate` (spec §3.4/§6.2) — remains available and is still
 * the belt-and-braces guidance for hosts on older SDK builds.
 *
 * ### Host allow-list ([deepLinkHosts])
 * Empty (the default) ⇒ accept ANY `http(s)` VIEW intent (we still only
 * *attribute* ones carrying a `kixo_link_id`/`kixo_click_id`; `handleDeepLink`
 * gates the attribution window on that). A non-empty set restricts the cold
 * auto-read to those hosts — so a host that ALSO opens unrelated `https` deep
 * links (its own `myapp.com` routes) can scope Kixo's auto-handler to just its
 * `<sub>.kixo.cc` subdomain and avoid a spurious `deep_link` event on every
 * unrelated VIEW launch. Custom-scheme intents (no host) are accepted only when
 * the allow-list is empty OR the scheme is explicitly listed.
 *
 * R6 anti-crash: every step is wrapped — a malformed Intent / Uri from a host
 * edge case is a logged no-op, never a host crash.
 */
internal class AppLinkHandler(
    private val deepLinkHosts: Set<String>,
    private val consumeFirstLaunchEligibility: () -> Boolean = { false },
    private val onColdDeepLink: (uri: String, installAttributionCandidate: Boolean) -> Unit,
) : KixoActivityListener {

    /** Read the cold launch intent EXACTLY ONCE per process (across config
     *  changes, multiple Activities, return-from-background, AND the
     *  late-registration backfill). */
    private val launchIntentConsumed = AtomicBoolean(false)

    override fun onActivityResumed(activity: Activity) {
        consumeLaunchIntent(activity)
    }

    /**
     * Backfill entry point for a host that registered this listener AFTER its
     * launcher Activity was already resumed (e.g. `Kixo.configure()` called from
     * the launcher's `onCreate`/`onResume`). `configure()` calls this with
     * `KixoInternalBootstrap.currentActivity()` right after registering — running
     * the SAME one-shot read against the already-resumed Activity that the
     * lifecycle observer will never re-fire `onActivityResumed` for.
     *
     * Shares the [launchIntentConsumed] one-shot CAS with [onActivityResumed], so
     * exactly one of (this backfill, the first future `onActivityResumed`) ever
     * reads the intent — never both. A `null` Activity (none resumed yet → the
     * normal `Application.onCreate` path) is a no-op and leaves the guard UNSET so
     * the upcoming `onActivityResumed` still does the read.
     */
    fun backfillFromResumedActivity(activity: Activity?) {
        if (activity == null) return
        consumeLaunchIntent(activity)
    }

    /** The one-shot cold read, shared by [onActivityResumed] + the backfill. */
    private fun consumeLaunchIntent(activity: Activity) {
        if (!launchIntentConsumed.compareAndSet(false, true)) return
        val installAttributionCandidate = try {
            consumeFirstLaunchEligibility()
        } catch (t: Throwable) {
            Log.w(TAG, "first-launch eligibility handling swallow", t)
            false
        }
        try {
            val intent = activity.intent ?: return
            if (intent.action != Intent.ACTION_VIEW) return
            val data: Uri = intent.data ?: return
            val uri = data.toString()
            if (uri.isBlank()) return
            // Allow-list gate via the SHARED DeepLinkUriParser.hostAllowed so the
            // cold path's accept/reject is byte-identical to the direct
            // handleDeepLink path (one spelling, no drift).
            if (!DeepLinkUriParser.hostAllowed(uri, deepLinkHosts)) {
                Log.d(TAG, "cold VIEW intent host not in deepLinkHosts; ignoring")
                return
            }
            onColdDeepLink(uri, installAttributionCandidate)
        } catch (t: Throwable) {
            // R6 — a launch-intent edge case can never crash the host.
            Log.w(TAG, "cold launch-intent handling swallow", t)
        }
    }

    /** Test seam — has the one-shot cold read already fired? */
    internal fun consumedForTests(): Boolean = launchIntentConsumed.get()

    private companion object {
        const val TAG = "Kixo.AppLink"
    }
}
