package io.kixo.sdk.internal.attribution

import android.content.Context
import android.util.Log
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Deterministic install-receipt validation (KIX-MMP-FRAUD-01) — the Android side.
 *
 * On first run, acquire a **Play Integrity** token and POST it to
 * `/api/sdk/install/validate`. The backend verifies the device-integrity verdict
 * + package, enforces single-use, and stamps the install `validated`
 * (anti-replay / anti-spoof).
 *
 * ### Honesty ceiling
 * A verified Play Integrity token proves the install is REAL (genuine binary on a
 * recognized device) — it does NOT prove the attribution SOURCE.
 *
 * ### Safety invariants
 *   - **Non-blocking:** runs on the queue's coroutine scope; NEVER delays/blocks
 *     event ingest or the existing Install Referrer flow. A failure is logged at
 *     debug and skipped.
 *   - **Privacy:** honored — when [isCollectionDenied] is true nothing is
 *     acquired/sent, and an active validation can be cancelled at opt-out or
 *     consent revocation.
 *   - **Graceful degradation:** the Play Integrity API (`com.google.android.play
 *     :integrity`) is an OPTIONAL host dependency. We acquire the token via
 *     reflection so the SDK builds + runs even when the host didn't add it; if
 *     the classes aren't present we record `unavailable` and skip (the backend
 *     fail-opens to `unvalidated`, never a fraud reject on absence).
 *   - **Routing:** the POST target uses the SDK's resolved [baseUrl].
 *   - **No PII:** the Play Integrity token is Google's signed blob.
 *     `install_id` is a random no-backup physical-install UUID; `device_id`
 *     remains the SDK's ordinary stable device identity.
 */
internal class InstallValidator(
    private val context: Context,
    private val httpClient: OkHttpClient,
    private val scope: CoroutineScope,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val installId: String,
    private val deviceId: String,
    private val cloudProjectNumber: Long?,
    private val isCollectionDenied: () -> Boolean,
    private val debug: Boolean,
    /** Marks the acquisition state only after a definitive server verdict. */
    private val onTerminal: () -> Unit = {},
    private val retryDelaysMs: LongArray = DEFAULT_RETRY_DELAYS_MS,
    /** Injectable token acquirer (tests substitute a fake). Returns the Play
     *  Integrity token or null when unavailable. */
    private val tokenProvider: suspend (Context, Long?) -> String? = ::acquirePlayIntegrityToken,
) {
    /** Validation statuses (mirrors the iOS contract + the backend vocabulary). */
    enum class Status(val wire: String) {
        NOT_RUN("not_run"),
        DISABLED("disabled"),
        OPTED_OUT("opted_out"),
        UNAVAILABLE("unavailable"),
        VALIDATED("validated"),
        REPLAYED("replayed"),
        INVALID_SIG("invalid_sig"),
        WRONG_BUNDLE("wrong_bundle"),
        ABSENT("absent"),
        ERROR("error"),
    }

    private val statusRef = AtomicReference(Status.NOT_RUN)
    private val started = AtomicBoolean(false)
    private val generation = AtomicLong(0L)
    private val activeJob = AtomicReference<Job?>(null)
    private val activeCall = AtomicReference<okhttp3.Call?>(null)
    val lastStatus: Status get() = statusRef.get()

    /**
     * Kick off validation in the background. Returns immediately; the result is
     * recorded into [lastStatus]. Safe to call once during configure — never
     * blocks the caller.
     */
    fun validateInBackground() {
        if (isCollectionDenied()) {
            statusRef.set(Status.OPTED_OUT)
            return
        }
        if (!started.compareAndSet(false, true)) return
        val expectedGeneration = generation.get()
        val job = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) {
            try {
                if (!isAllowed(expectedGeneration)) return@launch
                val bundleId = runCatching { context.packageName }
                    .getOrNull()
                    ?.trim()
                    .orEmpty()
                if (bundleId.isBlank()) {
                    // Do not spend a Play Integrity nonce or send a package-
                    // unbound receipt. This can happen in unusual wrapped/test
                    // Contexts; the SDK must remain a no-network no-op.
                    statusRef.set(Status.WRONG_BUNDLE)
                    return@launch
                }
                val token = tokenProvider(context, cloudProjectNumber)
                if (!isAllowed(expectedGeneration)) return@launch
                if (token.isNullOrEmpty()) {
                    statusRef.set(Status.UNAVAILABLE)
                    if (debug) Log.d(TAG, "Play Integrity unavailable — skipping validation (fail-open).")
                    return@launch
                }
                postWithRetry(token, bundleId, expectedGeneration)
            } catch (t: Throwable) {
                if (isAllowed(expectedGeneration)) statusRef.set(Status.ERROR)
                if (debug) Log.d(TAG, "install validation failed (non-fatal): ${t.message}")
            }
        }
        activeJob.set(job)
        job.invokeOnCompletion {
            activeJob.compareAndSet(job, null)
        }
        job.start()
    }

    /** Privacy boundary: invalidate late token callbacks and cancel network I/O. */
    fun cancelPending() {
        generation.incrementAndGet()
        activeCall.getAndSet(null)?.cancel()
        activeJob.getAndSet(null)?.cancel()
        started.set(false)
        statusRef.set(Status.OPTED_OUT)
    }

    private fun isAllowed(expectedGeneration: Long): Boolean =
        generation.get() == expectedGeneration && !isCollectionDenied()

    private suspend fun postWithRetry(
        token: String,
        bundleId: String,
        expectedGeneration: Long,
    ) {
        val payload = buildString {
            append("{")
            append("\"project_id\":").append(jsonStr(projectId)).append(",")
            append("\"api_key\":").append(jsonStr(apiKey)).append(",")
            append("\"platform\":\"android\",")
            append("\"sdk_version\":")
                .append(jsonStr(io.kixo.sdk.BuildConfig.SDK_VERSION)).append(",")
            append("\"install_id\":").append(jsonStr(installId)).append(",")
            append("\"device_id\":").append(jsonStr(deviceId)).append(",")
            append("\"bundle_id\":").append(jsonStr(bundleId)).append(",")
            append("\"integrity_token\":").append(jsonStr(token))
            append("}")
        }
        val url = Endpoints.url(baseUrl, Endpoints.INSTALL_VALIDATE)
        for (delayMs in retryDelaysMs) {
            if (delayMs > 0) delay(delayMs)
            if (!isAllowed(expectedGeneration)) {
                statusRef.set(Status.OPTED_OUT)
                return
            }
            val request = Request.Builder()
                .url(url)
                .post(payload.toRequestBody(JSON_MEDIA))
                .build()
            try {
                val call = httpClient.newCall(request)
                if (!activeCall.compareAndSet(null, call)) {
                    call.cancel()
                    statusRef.set(Status.ERROR)
                    return
                }
                val terminal = withContext(Dispatchers.IO) {
                    try {
                        call.execute().use { resp ->
                            if (resp.code == 409 || resp.code == 429 || resp.code >= 500) {
                                return@use null
                            }
                            val bodyStr = resp.body?.string().orEmpty()
                            parseStatus(bodyStr).takeIf {
                                it != Status.ERROR && it != Status.UNAVAILABLE
                            }
                        }
                    } finally {
                        activeCall.compareAndSet(call, null)
                    }
                }
                if (!isAllowed(expectedGeneration)) {
                    statusRef.set(Status.OPTED_OUT)
                    return
                }
                if (terminal != null) {
                    statusRef.set(terminal)
                    runCatching(onTerminal)
                    return
                }
            } catch (_: IOException) {
                // Retry below.
            } catch (t: Throwable) {
                if (debug) Log.d(TAG, "install validation attempt failed: ${t.message}")
            }
        }
        statusRef.set(
            if (!isAllowed(expectedGeneration)) Status.OPTED_OUT else Status.ERROR,
        )
    }

    private fun parseStatus(body: String): Status {
        return try {
            val obj = Json.parseToJsonElement(body) as? JsonObject ?: return Status.ERROR
            val s = (obj["validation_status"] as? JsonPrimitive)?.contentOrNull ?: return Status.ERROR
            Status.entries.firstOrNull { it.wire == s } ?: Status.ERROR
        } catch (_: Throwable) {
            Status.ERROR
        }
    }

    companion object {
        private const val TAG = "Kixo"
        private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
        private val DEFAULT_RETRY_DELAYS_MS = longArrayOf(0L, 1_000L, 5_000L)

        private fun jsonStr(v: String): String =
            "\"" + v.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

        /**
         * Acquire a Play Integrity token via REFLECTION so the SDK doesn't hard-
         * depend on `com.google.android.play:integrity`. Returns null when the
         * API isn't on the classpath or the request fails (caller treats null as
         * `unavailable` → backend fail-open). Uses the classic IntegrityManager
         * (`IntegrityManagerFactory.create` → `requestIntegrityToken`).
         *
         * NOTE: a real production integration should use the STANDARD request
         * (warm-up + per-request) for lower latency; the classic request kept
         * here is the dependency-light path that works without a server warm-up
         * round-trip and is adequate for a one-shot first-run install proof.
         */
        suspend fun acquirePlayIntegrityToken(context: Context, cloudProjectNumber: Long?): String? {
            return try {
                val factoryClass = Class.forName(
                    "com.google.android.play.core.integrity.IntegrityManagerFactory",
                )
                val manager = factoryClass
                    .getMethod("create", Context::class.java)
                    .invoke(null, context.applicationContext)

                val requestBuilderClass = Class.forName(
                    "com.google.android.play.core.integrity.IntegrityTokenRequest\$Builder",
                )
                val builder = requestBuilderClass.getConstructor().newInstance()
                // setNonce(String) — a per-request nonce; use a fresh random value.
                val nonce = java.util.UUID.randomUUID().toString().replace("-", "")
                requestBuilderClass.getMethod("setNonce", String::class.java).invoke(builder, nonce)
                if (cloudProjectNumber != null) {
                    runCatching {
                        requestBuilderClass
                            .getMethod("setCloudProjectNumber", Long::class.javaPrimitiveType)
                            .invoke(builder, cloudProjectNumber)
                    }
                }
                val request = requestBuilderClass.getMethod("build").invoke(builder)

                val requestMethod = manager.javaClass.methods.firstOrNull {
                    it.name == "requestIntegrityToken"
                } ?: return null
                val task = requestMethod.invoke(manager, request) ?: return null

                // Await the Play Task<IntegrityTokenResponse> via Tasks.await(task).
                val tasksClass = Class.forName("com.google.android.gms.tasks.Tasks")
                val taskClass = Class.forName("com.google.android.gms.tasks.Task")
                val response = withContext(Dispatchers.IO) {
                    tasksClass.getMethod("await", taskClass).invoke(null, task)
                } ?: return null

                response.javaClass.getMethod("token").invoke(response) as? String
            } catch (_: Throwable) {
                // ClassNotFound (dependency absent) / any reflection / API failure
                // → null → caller records `unavailable` and skips (fail-open).
                null
            }
        }
    }
}
