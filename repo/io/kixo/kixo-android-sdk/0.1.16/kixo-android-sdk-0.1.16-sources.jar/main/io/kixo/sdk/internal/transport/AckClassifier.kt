package io.kixo.sdk.internal.transport

import io.kixo.sdk.internal.model.BatchResponse
import io.kixo.sdk.internal.model.KixoEvent

/**
 * Pure function that partitions a batch's events into
 * **(accepted, permanent, transient)** id buckets given the server's
 * [BatchResponse]. Lives apart from [Transport] so the partition
 * logic can be unit-tested without spinning a MockWebServer.
 *
 * **Defensive default (briefing §3 R5).** If an `event_id` from the
 * outgoing batch appears in NEITHER `accepted_event_ids` NOR
 * `errors[]`, treat it as **transient**. A 2xx response is not proof that
 * an omitted event was stored: gateways, truncated response builders and
 * mixed backend versions can all return incomplete acknowledgement lists.
 * Deleting an unacknowledged durable row is irreversible data loss; retry
 * is bounded by the queue's existing cooldown/backoff machinery.
 *
 * **Conflict resolution.** If an event id appears in BOTH arrays
 * (server bug), `errors[]` wins — better to drop / retry per the
 * server's stated intent than to silently mark it accepted. Within
 * `errors[]`, `permanent=true` wins over `permanent=false` (drop is
 * stricter than retry).
 *
 * **Index fallback.** Some legacy backend codepaths populate
 * `errors[].index` instead of `errors[].event_id`. We honour both:
 * if `event_id` is empty but `index` is in range, we look up the id
 * by position in the original batch.
 */
internal object AckClassifier {

    /**
     * Classify the given batch against the server response.
     *
     * @return Triple of (accepted, permanent, transient) event-id lists.
     *         All three are deduplicated; an id never appears in more
     *         than one bucket. Iteration order matches the original
     *         batch's order to keep DELETE/UPDATE statements stable in
     *         the SQLite store.
     */
    fun classify(
        events: List<KixoEvent>,
        response: BatchResponse,
    ): Triple<List<String>, List<String>, List<String>> {
        val batchIds = events.map { it.eventId }
        val batchIdSet = batchIds.toSet()

        // Resolve errors[] entries to event ids. Prefer `event_id`
        // (the new contract); fall back to `index` (legacy). Skip any
        // entry that resolves to nothing — the backend may emit
        // batch-level errors without a per-event id, and those don't
        // map to any event we sent.
        val permanentIds = mutableSetOf<String>()
        val transientIds = mutableSetOf<String>()
        for (err in response.errors) {
            // Agent 2 declares `eventId: String` (non-nullable) but
            // backend may omit it on legacy paths; treat empty as
            // "use index instead". A kotlinx.serialization decode of a
            // missing key would have already thrown, so an empty
            // string here is a deliberate sentinel.
            val id: String = if (err.eventId.isNotEmpty()) {
                err.eventId
            } else {
                err.index?.let { idx -> events.getOrNull(idx)?.eventId }
                    ?: continue
            }
            // Defensive: if the backend echoes an id we didn't send,
            // ignore it. We can't decide what to do with an event that
            // isn't in our local buffer.
            if (id !in batchIdSet) continue
            if (err.permanent) {
                permanentIds.add(id)
            } else {
                transientIds.add(id)
            }
        }
        // permanent wins over transient if a buggy server lists the
        // same id twice with conflicting flags — drop is stricter.
        transientIds.removeAll(permanentIds)

        // accepted = listed by server, intersected with our batch,
        // minus anything also flagged in errors[] (errors win — server
        // told us not to commit it).
        val acceptedFromServer = response.acceptedEventIds.toMutableSet()
        acceptedFromServer.retainAll(batchIdSet)
        acceptedFromServer.removeAll(permanentIds)
        acceptedFromServer.removeAll(transientIds)

        // Defensive default — never delete a durable event without an
        // explicit accepted/permanent acknowledgement.
        val mentionedAnywhere =
            acceptedFromServer + permanentIds + transientIds
        val unmentioned = batchIds.filter { it !in mentionedAnywhere }
        transientIds.addAll(unmentioned)

        // Preserve original batch ordering in the returned lists so
        // downstream SQL / log lines aren't shuffled randomly between
        // runs — eases diffing test fixtures.
        val accepted = batchIds.filter { it in acceptedFromServer }
        val permanent = batchIds.filter { it in permanentIds }
        val transient = batchIds.filter { it in transientIds }
        return Triple(accepted, permanent, transient)
    }
}
