package io.kixo.sdk

/**
 * A resolved deferred deep link, surfaced to the host via
 * [DeferredDeepLinkListener] exactly once on first run after the Play Install
 * Referrer resolves (deferred) OR when an App Link / custom-scheme intent is
 * handled (direct).
 *
 * The SDK does **NOT** navigate for you — the host owns routing. [targetUrl]
 * is BACKEND-VALIDATED to be same-app-scoped (the App's registered
 * `deepLinkScheme://…`, its universal-link host, or a relative path) before
 * it is surfaced, closing the open-redirect surface; the host should still
 * route it through its own navigation allow-list (B2B: the customer-controller
 * owns final navigation policy).
 *
 * Mirrors the iOS `KixoDeferredLink` shape for cross-platform parity.
 */
public data class KixoDeferredLink(
    /** The link's configured app target path (backend-validated), or `null`
     *  if the resolved target was not same-app-scoped / not present. */
    public val targetUrl: String?,
    /** `kixo_link_id` (CUID), or `null` for an organic / id-less open. */
    public val linkId: String?,
    /** `utm_campaign` / link campaign label. */
    public val campaign: String?,
    /** `utm_source` / media source. */
    public val source: String?,
    /** `utm_medium`. */
    public val medium: String?,
    /** Parsed query params for advanced host routing. Direct resolved callbacks
     *  remove attribution-reserved keys so server-canonical fields cannot
     *  conflict with untrusted values from the incoming URI. */
    public val params: Map<String, String>,
    /** `true` when resolved via the Play Install Referrer (deferred); `false`
     *  for a direct/warm App-Link or custom-scheme open. */
    public val isDeferred: Boolean,
    /** Server-minted `kixo_click_id`, when the resolve endpoint recorded this
     *  direct/deferred open for deterministic attribution. */
    public val clickId: String? = null,
    /** Stable UUID generated once for a direct OS URI delivery. Identical on
     *  its `RECEIVED` and `RESOLVED` callbacks; null for deferred installs. */
    public val openId: String? = null,
    /** Direct-open lifecycle phase. Deferred installs are always `RESOLVED`. */
    public val phase: KixoDeepLinkPhase = KixoDeepLinkPhase.RESOLVED,
    /** Server-owned direct routing resolution method. */
    public val resolutionMethod: String? = null,
    /** Server-owned confidence for [resolutionMethod]. */
    public val resolutionConfidence: Double? = null,
    /** Device-local route hint for phase `RECEIVED`, stripped of scheme,
     *  authority, query, and fragment. Never sent to Kixo. */
    public val localRoute: String? = null,
    /** Server-owned deferred-install match method. Null for direct opens. */
    public val matchMethod: String? = null,
    /** Server-owned confidence for [matchMethod]. Null for direct opens. */
    public val matchConfidence: Double? = null,
)

/** Two-phase lifecycle for a direct Android App Link/custom-scheme delivery. */
public enum class KixoDeepLinkPhase {
    /** OS URI accepted locally; host routing remains fail-open while Kixo resolves. */
    RECEIVED,

    /** Canonical Link/target/click metadata returned by Kixo. */
    RESOLVED,
}

/**
 * Callback fired once for a deferred install, and in two phases for each direct
 * OS delivery: `RECEIVED` immediately, then `RESOLVED` after canonical server
 * resolution. Direct callbacks are dispatched on Android's main thread.
 *
 * `fun interface` so Kotlin callers can pass a lambda and Java callers a
 * single-method instance.
 */
public fun interface DeferredDeepLinkListener {
    /**
     * @param link a deferred-install result (`null` when organic), or a
     *   non-null direct result with phase `RECEIVED` / `RESOLVED`.
     */
    public fun onDeferredDeepLink(link: KixoDeferredLink?)
}
