package io.kixo.sdk.internal.attribution

import android.content.SharedPreferences
import android.util.Log
import io.kixo.sdk.KixoDeferredLink
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Owns the **read-once + bounded-retry + in-flight-guard** state machine for
 * the Play Install Referrer, persisted to a dedicated `kixo_attribution`
 * SharedPreferences file (sibling of `IdentityManager.PREFS_NAME`).
 *
 * State model (`referrer_read_state`):
 *  - `UNREAD`               (default) — eligible to read.
 *  - `READ_OK_POST_PENDING` — read succeeded, POST not yet 2xx-acked. A cached
 *                             `referrer_snapshot` blob means a re-POST on next
 *                             launch needs NO re-read (§3.2.1, idempotent via
 *                             the backend `@@unique(projectId, deviceId)` upsert).
 *  - `DONE`                 — never read/POST again (POST-acked, OR terminal
 *                             read failure, OR read attempts exhausted, OR POST
 *                             attempts exhausted).
 *
 * Two **distinct** bounded counters (the §3.2.1 fix — a failed POST must NOT
 * burn read attempts):
 *  - `referrer_read_attempts`  cap [MAX_READ_ATTEMPTS]  (transient read fails).
 *  - `referrer_post_attempts`  cap [MAX_POST_ATTEMPTS]  (5xx/network POST fails).
 *
 * In-process **in-flight guard** ([readInFlight] AtomicBoolean) closes the
 * `fetchInstallReferrer()` race: both the auto-read on `configure()` and a
 * manual `fetchInstallReferrer()` must `compareAndSet(false,true)` before
 * binding; a second concurrent call returns immediately. The persisted `DONE`
 * guard alone is insufficient (two concurrent binds could otherwise occur).
 *
 * **Consent (§0 §6 / §8):** while opted out we do NOT read the referrer at all
 * and leave state `UNREAD` (the referrer is immutable for 90d, so reading later
 * loses nothing — and we must NOT consume the one-shot read while we can't POST
 * it). The caller passes the consent decision in via [start].
 *
 * **Threading:** the read + POST happen on the injected [executor] (production:
 * a background dispatcher). The persisted state writes use SharedPreferences
 * `apply()` (non-blocking). [activeAttempt] stays occupied until the async Play
 * callback and any resolve POST have both completed.
 */
internal class InstallReferrerController(
    private val prefs: SharedPreferences,
    private val wrapper: ReferrerFetcher,
    private val poster: ReferrerPoster,
    private val contextProvider: () -> ReferrerPoster.Context?,
    private val executor: (Runnable) -> Unit,
    private val isPrivacyDenied: () -> Boolean = { false },
    private val privacyCommit: ((() -> Unit) -> Boolean) = { block ->
        if (isPrivacyDenied()) false else {
            block()
            true
        }
    },
    private val callbackDispatcher: ((() -> Unit) -> Unit) = { it() },
    private val installSignalObserver: (InstallReferrerReadOutcome) -> Unit = {},
) {

    /** Attempt token remains held until the async Play callback and POST finish. */
    private val attemptEpoch = AtomicLong(0L)
    private val activeAttempt = AtomicReference<Long?>(null)
    private val stateLock = Any()

    /** Listener set by the host. Fires once with the resolved link (or null). */
    private val listener = AtomicReference<io.kixo.sdk.DeferredDeepLinkListener?>(null)

    /** Cached resolved link, so a late listener registration fires immediately. */
    private val cachedLink = AtomicReference<KixoDeferredLink?>(null)

    /** Whether the listener has already been fired this process (one-shot). */
    private val listenerFired = java.util.concurrent.atomic.AtomicBoolean(false)

    /** Whether the deferred resolution has completed (so a late register can fire). */
    private val resolved = java.util.concurrent.atomic.AtomicBoolean(false)

    // ─── Public-facade-facing entry points ──────────────────────────

    /**
     * Auto-read entry on `configure()`. No-op when [consentAllows] is false
     * (we leave state UNREAD), when state is already DONE, or when a read is
     * in flight. [fetchInstallReferrer] is the explicit opt-in re-trigger.
     */
    fun start(consentAllows: Boolean) {
        if (!consentAllows) {
            // Do NOT read while opted out — leave UNREAD (§8). The referrer is
            // immutable for 90d; fetchInstallReferrer() reads on opt-in.
            return
        }
        attemptReadOrRepost()
    }

    /** Force a (re-)attempt. No-op if DONE or a read/post is in flight. */
    fun fetchInstallReferrer() {
        attemptReadOrRepost()
    }

    /** Invalidate async read/resolve work at reset, opt-out, or consent revoke. */
    fun cancelPending() {
        synchronized(stateLock) {
            attemptEpoch.incrementAndGet()
            activeAttempt.set(null)
            cachedLink.set(null)
            resolved.set(false)
            listenerFired.set(false)
        }
        poster.cancelPending()
    }

    /**
     * Register the deferred-deep-link listener. If resolution already happened,
     * fire immediately with the cached result (race-safe).
     */
    fun setDeferredDeepLinkListener(l: io.kixo.sdk.DeferredDeepLinkListener) {
        val pending = synchronized(stateLock) {
            listener.set(l)
            if (resolved.get() && listenerFired.compareAndSet(false, true)) {
                cachedLink.get() to attemptEpoch.get()
            } else {
                null
            }
        }
        pending?.let { (link, epoch) -> safeFire(link, epoch) }
    }

    // ─── State machine ──────────────────────────────────────────────

    private fun attemptReadOrRepost() {
        if (isPrivacyDenied()) return
        val state = readState()
        if (state == STATE_DONE) {
            notifyInstallSignal(InstallReferrerReadOutcome.Unavailable("already_done"))
            // Already finished — but if a listener is waiting and we resolved,
            // make sure it fired (covers register-after-DONE in the same run).
            fireIfPendingAndResolved()
            return
        }
        val epoch = attemptEpoch.get()
        if (!activeAttempt.compareAndSet(null, epoch)) return

        // Persist IN_FLIGHT intent before the async call so a mid-read crash is
        // recoverable — we bump the read-attempt counter here for the read path.
        if (state == STATE_UNREAD) {
            val attempts = prefs.getInt(KEY_READ_ATTEMPTS, 0)
            if (attempts >= MAX_READ_ATTEMPTS) {
                // Exhausted before we even started (e.g. set from a prior crash
                // loop) — terminal.
                markDone(postFailed = false)
                notifyInstallSignal(InstallReferrerReadOutcome.Unavailable("read_attempts_exhausted"))
                finishAttempt(epoch)
                return
            }
            prefs.edit().putInt(KEY_READ_ATTEMPTS, attempts + 1).apply()
        }

        val scheduled = execute {
            if (!isAllowed(epoch)) {
                finishAttempt(epoch)
                return@execute
            }
            if (state == STATE_READ_OK_POST_PENDING) {
                try {
                    // We already have a cached snapshot — skip the read, re-POST.
                    val cached = loadCachedSnapshot()
                    if (cached == null) {
                        // Snapshot blob lost/corrupt (extremely rare — SharedPrefs
                        // wipe). The one-shot read is already consumed, so we
                        // can't safely re-read; terminate rather than risk an
                        // infinite POST_PENDING loop across launches.
                        Log.w(TAG, "POST_PENDING but cached snapshot missing; terminating.")
                        markDone(postFailed = true)
                        notifyInstallSignal(
                            InstallReferrerReadOutcome.Unavailable("cached_snapshot_missing"),
                        )
                    } else {
                        notifyInstallSignal(
                            InstallReferrerReadOutcome.Enriched(
                                installSignalProperties(cached.first, cached.second),
                            ),
                        )
                        doPost(cached.first, cached.second, epoch)
                    }
                } catch (t: Throwable) {
                    Log.w(TAG, "referrer re-post cycle threw", t)
                } finally {
                    finishAttempt(epoch)
                }
            } else {
                startRead(epoch)
            }
        }
        if (!scheduled) {
            // The app/SDK scope may reject work during a teardown race. If a
            // successful Play read was already persisted on a prior launch,
            // release that known enrichment synchronously instead of letting
            // the install timeout to organic. The network re-POST remains
            // pending for a future process with a healthy executor.
            if (state == STATE_READ_OK_POST_PENDING && isAllowed(epoch)) {
                val cached = loadCachedSnapshot()
                notifyInstallSignal(
                    if (cached == null) {
                        InstallReferrerReadOutcome.Unavailable("cached_snapshot_missing")
                    } else {
                        InstallReferrerReadOutcome.Enriched(
                            installSignalProperties(cached.first, cached.second),
                        )
                    },
                )
            }
            finishAttempt(epoch)
        }
    }

    private fun startRead(epoch: Long) {
        try {
            wrapper.fetch { result ->
                val scheduled = execute {
                    try {
                        if (!isAllowed(epoch)) return@execute
                        processReadResult(result, epoch)
                    } finally {
                        finishAttempt(epoch)
                    }
                }
                if (!scheduled) {
                    try {
                        if (isAllowed(epoch)) {
                            // The Play callback already delivered a terminal
                            // local result. Commit/forward that small result on
                            // the callback thread so executor shutdown cannot
                            // permanently downgrade an available referrer to
                            // organic. Never POST here: networking remains
                            // deferred to the persisted POST_PENDING restart.
                            processReadResult(result, epoch, postWhenReady = false)
                        }
                    } finally {
                        finishAttempt(epoch)
                    }
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "referrer read start threw", t)
            notifyInstallSignal(InstallReferrerReadOutcome.Unavailable("read_start_failed"))
            finishAttempt(epoch)
        }
    }

    private fun processReadResult(
        result: ReferrerFetcher.FetchResult,
        epoch: Long,
        postWhenReady: Boolean = true,
    ) {
        when (result) {
            is ReferrerFetcher.FetchResult.Success -> {
                val snapshot = result.snapshot
                val parsed = ReferrerParser.parse(snapshot.referrerUrl)
                // Cache snapshot + flip to POST-pending BEFORE the POST so a
                // crash mid-POST re-POSTs (not re-reads) next launch.
                if (!commitIfAllowed(epoch) {
                    persistSnapshot(snapshot)
                    setReadState(STATE_READ_OK_POST_PENDING)
                }) return
                notifyInstallSignal(
                    InstallReferrerReadOutcome.Enriched(
                        installSignalProperties(snapshot, parsed),
                    ),
                )
                if (postWhenReady) doPost(snapshot, parsed, epoch)
            }

            is ReferrerFetcher.FetchResult.TransientFailure -> {
                // Leave UNREAD (counter already bumped) so the next launch
                // retries, up to MAX_READ_ATTEMPTS. If exhausted, DONE.
                val committed = commitIfAllowed(epoch) {
                    val attempts = prefs.getInt(KEY_READ_ATTEMPTS, 0)
                    if (attempts >= MAX_READ_ATTEMPTS) {
                        Log.w(TAG, "referrer read exhausted (${result.reason}); giving up.")
                        markDone(postFailed = false)
                    }
                }
                if (committed) {
                    notifyInstallSignal(
                        InstallReferrerReadOutcome.Unavailable("transient_read_failure"),
                    )
                }
                // else: stay UNREAD; natural next-launch retry.
            }

            is ReferrerFetcher.FetchResult.TerminalFailure -> {
                // Old/absent Play Store or lib stripped — never retry.
                val committed = commitIfAllowed(epoch) {
                    markDone(postFailed = false)
                }
                if (committed) {
                    notifyInstallSignal(
                        InstallReferrerReadOutcome.Unavailable("terminal_read_failure"),
                    )
                }
            }
        }
    }

    private fun notifyInstallSignal(outcome: InstallReferrerReadOutcome) {
        try {
            installSignalObserver(outcome)
        } catch (t: Throwable) {
            // A diagnostic/coordinator observer must never break the referrer
            // state machine; its independent finite timeout remains the backstop.
            Log.w(TAG, "install signal observer threw; bounded timeout will recover", t)
        }
    }

    private fun doPost(snapshot: ReferrerSnapshot, parsed: ParsedReferrer, epoch: Long) {
        if (!isAllowed(epoch)) return
        val ctx = contextProvider()
        if (ctx == null) {
            // Creds not ready (shouldn't happen post-configure) — leave
            // POST_PENDING so next launch re-POSTs the cached snapshot.
            Log.w(TAG, "referrer POST context unavailable; will retry next launch.")
            return
        }
        val result = poster.post(ctx, snapshot, parsed) { !isAllowed(epoch) }
        commitIfAllowed(epoch) {
            when (val r = result) {
                is ReferrerPoster.Result.Acked -> {
                    markDone(postFailed = false)
                    clearSnapshot()
                    resolveAndFire(parsed, r.deferredLink, epoch)
                }
                is ReferrerPoster.Result.Terminal -> {
                // 4xx won't fix itself — terminal immediately. §4.5 (June 2026):
                // a 4xx is an auth/validation REJECTION. The open-redirect /
                // click_id-integrity (§3) contract rests on the backend's
                // server-side existence + ownership + single-use check, which on
                // a 4xx NEVER RAN. We must NOT attribute on a server-rejected
                // install: fire `null` (not the locally-parsed, unvalidated
                // campaign/source) and do NOT open the attribution window. The
                // host gets the unambiguous "unattributed" signal rather than a
                // navigable-looking object whose backend write was rejected.
                    Log.w(TAG, "referrer POST terminal (${r.code}); rejecting attribution.")
                    markDone(postFailed = true)
                    clearSnapshot()
                    resolveRejected(epoch)
                }
                is ReferrerPoster.Result.Retryable -> {
                    val attempts = prefs.getInt(KEY_POST_ATTEMPTS, 0) + 1
                    prefs.edit().putInt(KEY_POST_ATTEMPTS, attempts).apply()
                    if (attempts >= MAX_POST_ATTEMPTS) {
                    // Retries exhausted: the backend never returned a verdict, so
                    // — like a 4xx — there is no server-validated link to
                    // attribute to. Fire `null`, no window. (Same §4.5 rationale:
                    // attribution rests on backend validation, never on
                    // locally-parsed unvalidated referrer metadata.)
                        Log.w(TAG, "referrer POST exhausted (${r.reason}); rejecting attribution.")
                        markDone(postFailed = true)
                        clearSnapshot()
                        resolveRejected(epoch)
                    }
                    // else: stay READ_OK_POST_PENDING; re-POST cached snapshot next launch.
                }
            }
        }
    }

    // ─── Listener resolution ─────────────────────────────────────────

    private fun resolveAndFire(
        parsed: ParsedReferrer,
        deferredLink: ReferrerPoster.ResolvedDeferredLink?,
        epoch: Long,
    ) {
        if (!isCurrentEpoch(epoch)) return
        val link: KixoDeferredLink? = buildDeferredLink(parsed, deferredLink)
        cachedLink.set(link)
        resolved.set(true)
        // Open the attribution window so the dashboard can attribute downstream
        // conversions without a backend join (first-write-wins, 30-min window).
        if (link != null) {
            InstallAttributionStore.recordOpen(
                linkId = link.linkId,
                clickId = parsed.clickId,
                campaign = link.campaign,
                source = link.source,
                medium = link.medium,
                kind = AttributionContract.ATTR_KIND_INSTALL_REFERRER,
            )
        }
        val l = listener.get()
        if (l != null && listenerFired.compareAndSet(false, true)) {
            safeFire(link, epoch)
        }
    }

    /**
     * Resolve as UNATTRIBUTED after a server rejection (4xx) or exhausted POST
     * retries. Caches + fires `null` and — crucially — does NOT open the
     * attribution window (§4.5): nothing should inherit `attribution_*` for an
     * install the backend never validated. Idempotent via the same
     * [listenerFired] CAS as [resolveAndFire].
     */
    private fun resolveRejected(epoch: Long) {
        if (!isCurrentEpoch(epoch)) return
        cachedLink.set(null)
        resolved.set(true)
        val l = listener.get()
        if (l != null && listenerFired.compareAndSet(false, true)) {
            safeFire(null, epoch)
        }
    }

    private fun fireIfPendingAndResolved() {
        val pending = synchronized(stateLock) {
            if (listener.get() != null &&
                resolved.get() &&
                listenerFired.compareAndSet(false, true)
            ) {
                cachedLink.get() to attemptEpoch.get()
            } else {
                null
            }
        }
        pending?.let { (link, epoch) -> safeFire(link, epoch) }
    }

    /**
     * Build the host-facing link FOR AN ACKED (backend-validated) install only.
     * The 4xx-reject + exhausted-retry paths bypass this and call
     * [resolveRejected] (fire `null`, no window) — so this is reached ONLY when
     * the backend accepted the POST. Organic (no link id, no resolved link) =>
     * `null` (the listener convention for an unattributed install) unless the
     * backend returned a complete canonical deferred match. A 2xx unresolved or
     * incomplete response stays unattributed; local query fields never become a
     * fallback Link identity.
     */
    private fun buildDeferredLink(
        parsed: ParsedReferrer,
        resolvedLink: ReferrerPoster.ResolvedDeferredLink?,
    ): KixoDeferredLink? {
        if (resolvedLink == null) return null
        return KixoDeferredLink(
            targetUrl = resolvedLink.targetUrl,
            linkId = resolvedLink.linkId,
            campaign = resolvedLink.campaign,
            source = resolvedLink.source,
            medium = resolvedLink.medium,
            params = if (resolvedLink.params.isNotEmpty()) resolvedLink.params else parsed.params,
            isDeferred = true,
            clickId = parsed.clickId,
            matchMethod = resolvedLink.matchMethod,
            matchConfidence = resolvedLink.matchConfidence,
        )
    }

    private fun safeFire(link: KixoDeferredLink?, epoch: Long) {
        callbackDispatcher {
            if (!isAllowed(epoch)) return@callbackDispatcher
            val currentListener = listener.get() ?: return@callbackDispatcher
            try {
                currentListener.onDeferredDeepLink(link)
            } catch (t: Throwable) {
                // R6 — a buggy host listener can never crash the SDK.
                Log.w(TAG, "DeferredDeepLinkListener threw; swallowed", t)
            }
        }
    }

    private fun isAllowed(epoch: Long): Boolean =
        isCurrentEpoch(epoch) && !isPrivacyDenied()

    private fun isCurrentEpoch(epoch: Long): Boolean = epoch == attemptEpoch.get()

    /**
     * Production acquires privacy first, then [stateLock], matching the
     * opt-out/revoke cancellation order and avoiding lock inversion.
     */
    private fun commitIfAllowed(epoch: Long, block: () -> Unit): Boolean =
        run {
            var committed = false
            val privacyAllowed = privacyCommit {
                synchronized(stateLock) {
                    if (isCurrentEpoch(epoch)) {
                        block()
                        committed = true
                    }
                }
            }
            privacyAllowed && committed
        }

    private fun finishAttempt(epoch: Long) {
        activeAttempt.compareAndSet(epoch, null)
    }

    private fun execute(block: () -> Unit): Boolean =
        try {
            executor(Runnable(block))
            true
        } catch (t: Throwable) {
            Log.w(TAG, "referrer executor rejected work", t)
            false
        }

    // ─── Persistence helpers ─────────────────────────────────────────

    private fun readState(): String = prefs.getString(KEY_READ_STATE, STATE_UNREAD) ?: STATE_UNREAD

    private fun setReadState(state: String) {
        prefs.edit().putString(KEY_READ_STATE, state).apply()
    }

    private fun markDone(postFailed: Boolean) {
        val editor = prefs.edit().putString(KEY_READ_STATE, STATE_DONE)
        if (postFailed) editor.putBoolean(KEY_POST_FAILED, true)
        editor.apply()
    }

    private fun persistSnapshot(s: ReferrerSnapshot) {
        prefs.edit().putString(KEY_SNAPSHOT, ReferrerSnapshot.toJson(s)).apply()
    }

    private fun clearSnapshot() {
        prefs.edit().remove(KEY_SNAPSHOT).apply()
    }

    /** Load the cached snapshot + its parsed referrer, or null if absent/corrupt. */
    private fun loadCachedSnapshot(): Pair<ReferrerSnapshot, ParsedReferrer>? {
        val blob = prefs.getString(KEY_SNAPSHOT, null) ?: return null
        return try {
            val obj = kotlinx.serialization.json.Json.parseToJsonElement(blob)
                as? kotlinx.serialization.json.JsonObject ?: return null
            fun s(k: String): String? =
                (obj[k] as? kotlinx.serialization.json.JsonPrimitive)
                    ?.content
                    ?.takeIf { it != "null" }
            fun l(k: String): Long =
                (obj[k] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toLongOrNull() ?: 0L
            fun b(k: String): Boolean =
                (obj[k] as? kotlinx.serialization.json.JsonPrimitive)?.content?.toBoolean() ?: false
            val snapshot = ReferrerSnapshot(
                referrerUrl = s("referrer_url").orEmpty(),
                clickTsSeconds = l("click_seconds"),
                installBeginTsSeconds = l("install_begin_seconds"),
                installVersion = s("install_version"),
                googlePlayInstantParam = b("google_play_instant"),
            )
            snapshot to ReferrerParser.parse(snapshot.referrerUrl)
        } catch (t: Throwable) {
            Log.w(TAG, "cached snapshot parse failed", t)
            null
        }
    }

    // ─── Diagnostics (AC-7) ─────────────────────────────────────────

    /** Current persisted read state, for [io.kixo.sdk.KixoDiagnostics]. */
    fun stateForDiagnostics(): String = readState()

    /** Whether the POST permanently failed (4xx or exhausted retries). */
    fun postFailedForDiagnostics(): Boolean = prefs.getBoolean(KEY_POST_FAILED, false)

    companion object {
        private const val TAG = "Kixo.InstallReferrer"

        /**
         * FIX 4 — build the install-event referrer bag from the persisted
         * `referrer_snapshot` blob (the "InstallReferrerController result"),
         * keyed under the FROZEN §0 [AttributionContract] constants so the
         * backend can detect Play-referrer match / click-injection from the
         * canonical `app_install` event itself.
         *
         * Returns a single-entry map `{ INSTALL_REFERRER_PROP -> { referrer_url,
         * referrer_click_ts, install_begin_ts, [install_version],
         * google_play_instant } }` (the §0 nested-object shape — `INSTALL_REFERRER_PROP`
         * is the bag key, the inner keys are the frozen [REFERRER_PROP_*]
         * field names), OR empty when no referrer snapshot has been persisted.
         * Production's canonical install no longer reads this method before the
         * async result; [installSignalProperties] receives the successful snapshot
         * directly. This persisted form remains the restart/re-post seam.
         *
         * Reads from the SAME `kixo_attribution` prefs the controller persists
         * to ([KEY_SNAPSHOT]); the persisted blob's internal field names
         * (`referrer_url` / `click_seconds` / `install_begin_seconds` /
         * `install_version` / `google_play_instant`) are an implementation
         * detail of [ReferrerSnapshot.toJson] — the OUTPUT keys here are the
         * frozen wire contract constants, never re-spelled. Never throws (a
         * corrupt blob yields an empty bag, exactly like a fresh install).
         */
        fun referrerBagFromPrefs(prefs: SharedPreferences): Map<String, Any?> {
            val blob = prefs.getString(KEY_SNAPSHOT, null) ?: return emptyMap()
            return try {
                val obj = kotlinx.serialization.json.Json.parseToJsonElement(blob)
                    as? kotlinx.serialization.json.JsonObject ?: return emptyMap()
                fun prim(k: String): kotlinx.serialization.json.JsonPrimitive? =
                    obj[k] as? kotlinx.serialization.json.JsonPrimitive
                fun str(k: String): String? = prim(k)?.content?.takeIf { it != "null" }
                fun long(k: String): Long = prim(k)?.content?.toLongOrNull() ?: 0L
                fun bool(k: String): Boolean = prim(k)?.content?.toBoolean() ?: false

                val referrerUrl = str("referrer_url").orEmpty()
                // An empty referrer carries no Play payload worth attaching.
                if (referrerUrl.isEmpty()) return emptyMap()

                val bag = LinkedHashMap<String, Any?>(5)
                bag[AttributionContract.REFERRER_PROP_REFERRER_URL] = referrerUrl
                bag[AttributionContract.REFERRER_PROP_REFERRER_CLICK_TS] = long("click_seconds")
                bag[AttributionContract.REFERRER_PROP_INSTALL_BEGIN_TS] = long("install_begin_seconds")
                str("install_version")?.let {
                    bag[AttributionContract.REFERRER_PROP_INSTALL_VERSION] = it
                }
                bag[AttributionContract.REFERRER_PROP_GOOGLE_PLAY_INSTANT] = bool("google_play_instant")

                mapOf(AttributionContract.INSTALL_REFERRER_PROP to bag)
            } catch (t: Throwable) {
                Log.w(TAG, "referrer bag read failed; install fires without it", t)
                emptyMap()
            }
        }

        /**
         * Rebuild the complete install payload after a process restart while
         * app_install is still unacknowledged. This preserves both the nested
         * Play receipt and the canonical click/link echo.
         */
        fun installSignalPropertiesFromPrefs(
            prefs: SharedPreferences,
        ): Map<String, Any?> {
            val bag = referrerBagFromPrefs(prefs)
            @Suppress("UNCHECKED_CAST")
            val referrer = bag[AttributionContract.INSTALL_REFERRER_PROP]
                as? Map<String, Any?>
                ?: return emptyMap()
            val raw = referrer[AttributionContract.REFERRER_PROP_REFERRER_URL]
                as? String
                ?: return bag
            val parsed = ReferrerParser.parse(raw)
            val out = LinkedHashMap<String, Any?>(3)
            parsed.clickId
                ?.takeIf(AppLinkResolver::isCanonicalClickId)
                ?.let { out[AttributionContract.KIXO_CLICK_ID_KEY] = it }
            parsed.linkId
                ?.takeIf { it.isNotBlank() && it.length <= 128 }
                ?.let { out[AttributionContract.KIXO_LINK_ID_KEY] = it }
            out.putAll(bag)
            return out
        }

        /**
         * SharedPreferences can be restored by a host's Android Auto Backup
         * policy, while [InstallAcquisitionStateStore] deliberately lives in
         * no-backup storage. Bind the referrer cache to that physical-install
         * identity so a reinstall cannot inherit a stale click or read-once
         * marker from the previous installation.
         */
        fun scopeToPhysicalInstall(
            prefs: SharedPreferences,
            installId: String,
        ): Boolean {
            if (!INSTALL_ID_PATTERN.matches(installId)) return false
            if (prefs.getString(KEY_PHYSICAL_INSTALL_ID, null) == installId) return true
            return prefs.edit()
                .clear()
                .putString(KEY_PHYSICAL_INSTALL_ID, installId)
                .commit()
        }

        /**
         * Build the canonical install properties as soon as the Play payload is
         * locally available. The click id remains server-validated by the shared
         * claim path; malformed ids are not echoed.
         */
        fun installSignalProperties(
            snapshot: ReferrerSnapshot,
            parsed: ParsedReferrer = ReferrerParser.parse(snapshot.referrerUrl),
        ): Map<String, Any?> {
            val out = LinkedHashMap<String, Any?>(3)
            parsed.clickId
                ?.takeIf(AppLinkResolver::isCanonicalClickId)
                ?.let { out[AttributionContract.KIXO_CLICK_ID_KEY] = it }
            parsed.linkId
                ?.takeIf { it.isNotBlank() && it.length <= 128 }
                ?.let { out[AttributionContract.KIXO_LINK_ID_KEY] = it }
            out.putAll(referrerBag(snapshot))
            return out
        }

        private fun referrerBag(snapshot: ReferrerSnapshot): Map<String, Any?> {
            if (snapshot.referrerUrl.isEmpty()) return emptyMap()
            val bag = LinkedHashMap<String, Any?>(5)
            bag[AttributionContract.REFERRER_PROP_REFERRER_URL] = snapshot.referrerUrl
            bag[AttributionContract.REFERRER_PROP_REFERRER_CLICK_TS] =
                snapshot.clickTsSeconds
            bag[AttributionContract.REFERRER_PROP_INSTALL_BEGIN_TS] =
                snapshot.installBeginTsSeconds
            snapshot.installVersion?.let {
                bag[AttributionContract.REFERRER_PROP_INSTALL_VERSION] = it
            }
            bag[AttributionContract.REFERRER_PROP_GOOGLE_PLAY_INSTANT] =
                snapshot.googlePlayInstantParam
            return mapOf(AttributionContract.INSTALL_REFERRER_PROP to bag)
        }

        /** Dedicated SharedPreferences file — sibling of `kixo_identity`. */
        const val PREFS_NAME = "kixo_attribution"
        internal const val KEY_PHYSICAL_INSTALL_ID = "physical_install_id"
        private val INSTALL_ID_PATTERN = Regex("^[A-Za-z0-9._:-]{8,128}$")

        const val KEY_READ_STATE = "referrer_read_state"
        const val KEY_READ_ATTEMPTS = "referrer_read_attempts"
        const val KEY_POST_ATTEMPTS = "referrer_post_attempts"
        const val KEY_SNAPSHOT = "referrer_snapshot"
        const val KEY_POST_FAILED = "referrer_post_failed"

        const val STATE_UNREAD = "UNREAD"
        const val STATE_READ_OK_POST_PENDING = "READ_OK_POST_PENDING"
        const val STATE_DONE = "DONE"

        const val MAX_READ_ATTEMPTS = 3
        const val MAX_POST_ATTEMPTS = 5
    }
}
