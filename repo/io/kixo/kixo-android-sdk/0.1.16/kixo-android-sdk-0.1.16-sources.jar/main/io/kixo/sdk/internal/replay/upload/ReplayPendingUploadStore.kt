package io.kixo.sdk.internal.replay.upload

import android.content.Context
import androidx.work.Data
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.replay.upload.JpegEncoder.writeToFile
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Durable companion metadata for raw frames waiting in WorkManager. WorkData
 * cannot be read back through WorkManager's public API, so this sidecar is what
 * lets a fresh SDK process replace an old UNMETERED request when the dashboard
 * later enables cellular replay. The entire directory is synchronously purged
 * at privacy/identity boundaries and excluded from Android backup.
 */
internal object ReplayPendingUploadStore {
    @Serializable
    private data class Descriptor(
        val version: Int = VERSION,
        val workName: String,
        val localFilePath: String,
        val baseUrl: String,
        val projectId: String,
        val apiKey: String,
        val sessionId: String,
        val installationId: String,
        val frameSeq: Long,
        val frameKind: String,
        val expectedGcsPath: String,
        val signedUrl: String? = null,
        val signedUrlExpiresAt: String? = null,
        val contentType: String? = null,
        val maxBytes: Long? = null,
        val leaseFrameSeq: Long? = null,
        val leaseFrameKind: String? = null,
        val leaseGcsPath: String? = null,
        val leaseContentType: String? = null,
        val leaseMaxBytes: Long? = null,
        val policyToken: String,
        val stagedBytes: Long,
    )

    internal data class PendingStats(
        val frameCount: Int,
        val totalBytes: Long,
        val lastFrameSeq: Long?,
    )

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    fun persist(rawFile: File, workName: String, inputData: Data): Boolean {
        val descriptor = Descriptor(
            workName = workName,
            localFilePath = rawFile.absolutePath,
            baseUrl = inputData.getString(UploadWorker.KEY_API_BASE_URL).orEmpty(),
            projectId = inputData.getString(UploadWorker.KEY_PROJECT_ID).orEmpty(),
            apiKey = inputData.getString(UploadWorker.KEY_API_KEY).orEmpty(),
            sessionId = inputData.getString(UploadWorker.KEY_SESSION_ID).orEmpty(),
            installationId = inputData.getString(UploadWorker.KEY_INSTALLATION_ID).orEmpty(),
            frameSeq = inputData.getLong(UploadWorker.KEY_FRAME_SEQ, -1L),
            frameKind = inputData.getString(UploadWorker.KEY_FRAME_KIND).orEmpty(),
            expectedGcsPath = inputData.getString(UploadWorker.KEY_EXPECTED_GCS_PATH).orEmpty(),
            signedUrl = inputData.getString(UploadWorker.KEY_SIGNED_URL),
            signedUrlExpiresAt = inputData.getString(UploadWorker.KEY_SIGNED_URL_EXPIRES_AT),
            contentType = inputData.getString(UploadWorker.KEY_CONTENT_TYPE),
            maxBytes = inputData.getLong(UploadWorker.KEY_MAX_BYTES, -1L).takeIf { it > 0L },
            leaseFrameSeq = inputData.getLong(
                UploadWorker.KEY_LEASE_FRAME_SEQ,
                -1L,
            ).takeIf { it >= 0L },
            leaseFrameKind = inputData.getString(UploadWorker.KEY_LEASE_FRAME_KIND),
            leaseGcsPath = inputData.getString(UploadWorker.KEY_LEASE_GCS_PATH),
            leaseContentType = inputData.getString(UploadWorker.KEY_LEASE_CONTENT_TYPE),
            leaseMaxBytes = inputData.getLong(
                UploadWorker.KEY_LEASE_MAX_BYTES,
                -1L,
            ).takeIf { it > 0L },
            policyToken = inputData.getString(UploadWorker.KEY_REPLAY_POLICY_TOKEN).orEmpty(),
            stagedBytes = rawFile.length(),
        )
        if (!descriptor.isValid() || descriptor.stagedBytes <= 0L) return false
        return runCatching {
            json.encodeToString(Descriptor.serializer(), descriptor)
                .toByteArray(Charsets.UTF_8)
                .writeToFile(sidecarFor(rawFile))
        }.getOrDefault(false)
    }

    fun delete(rawFile: File) {
        runCatching { sidecarFor(rawFile).delete() }
    }

    /** Recreate CONNECTED work from disk after the owning uploader process died. */
    fun rescheduleAllForCellular(
        context: Context,
        runtimePolicy: ReplayRuntimePolicy,
        scheduler: ReplayWorkScheduler = WorkManagerReplayWorkScheduler,
    ): Int = reconcileAll(
        context = context,
        runtimePolicy = runtimePolicy,
        captureOnCellular = true,
        scheduler = scheduler,
    )

    /** Repair missing WorkSpecs and re-apply the restored project constraint. */
    fun reconcileAll(
        context: Context,
        runtimePolicy: ReplayRuntimePolicy,
        captureOnCellular: Boolean,
        scheduler: ReplayWorkScheduler = WorkManagerReplayWorkScheduler,
    ): Int {
        val root = replayRoot(context) ?: return 0
        var scheduled = 0
        descriptorFiles(root).forEach { sidecar ->
            val descriptor = read(sidecar)
            if (descriptor == null || !descriptor.isValid()) {
                discardInvalid(sidecar, root)
                return@forEach
            }
            val raw = File(descriptor.localFilePath)
            if (!isInside(raw, root) || !sameFile(sidecarFor(raw), sidecar) ||
                !raw.exists() || raw.length() <= 0L
            ) {
                discardInvalid(sidecar, root)
                return@forEach
            }
            var accepted = false
            runtimePolicy.runIfCallAllowed(
                token = descriptor.policyToken,
                authority = ReplayRuntimePolicy.CallAuthority.DATA,
            ) {
                accepted = scheduler.enqueue(
                    context = context,
                    workName = descriptor.workName,
                    inputData = descriptor.toData(),
                    captureOnCellular = captureOnCellular,
                    sessionId = descriptor.sessionId,
                )
            }
            if (accepted) scheduled++
        }
        return scheduled
    }

    /** Pending raw files are the crash-safe lower bound for session/end. */
    fun pendingStats(
        context: Context,
        sessionId: String,
        installationId: String,
    ): PendingStats {
        val root = replayRoot(context) ?: return PendingStats(0, 0L, null)
        val descriptors = descriptorFiles(root).mapNotNull(::read).filter {
            it.isValid() && it.sessionId == sessionId && it.installationId == installationId &&
                File(it.localFilePath).let { raw ->
                    isInside(raw, root) && raw.exists() && raw.length() > 0L
                }
        }.toList()
        return PendingStats(
            frameCount = descriptors.size,
            totalBytes = descriptors.sumOf { it.stagedBytes.coerceAtLeast(0L) },
            lastFrameSeq = descriptors.maxOfOrNull { it.frameSeq },
        )
    }

    private fun Descriptor.toData(): Data {
        val builder = Data.Builder()
            .putString(UploadWorker.KEY_LOCAL_FILE_PATH, localFilePath)
            .putString(UploadWorker.KEY_REPLAY_POLICY_TOKEN, policyToken)
            .putString(UploadWorker.KEY_API_BASE_URL, baseUrl)
            .putString(UploadWorker.KEY_PROJECT_ID, projectId)
            .putString(UploadWorker.KEY_API_KEY, apiKey)
            .putString(UploadWorker.KEY_SESSION_ID, sessionId)
            .putString(UploadWorker.KEY_INSTALLATION_ID, installationId)
            .putLong(UploadWorker.KEY_FRAME_SEQ, frameSeq)
            .putString(UploadWorker.KEY_FRAME_KIND, frameKind)
            .putString(UploadWorker.KEY_EXPECTED_GCS_PATH, expectedGcsPath)
        signedUrl?.let { builder.putString(UploadWorker.KEY_SIGNED_URL, it) }
        signedUrlExpiresAt?.let {
            builder.putString(UploadWorker.KEY_SIGNED_URL_EXPIRES_AT, it)
        }
        contentType?.let { builder.putString(UploadWorker.KEY_CONTENT_TYPE, it) }
        maxBytes?.let { builder.putLong(UploadWorker.KEY_MAX_BYTES, it) }
        leaseFrameSeq?.let { builder.putLong(UploadWorker.KEY_LEASE_FRAME_SEQ, it) }
        leaseFrameKind?.let { builder.putString(UploadWorker.KEY_LEASE_FRAME_KIND, it) }
        leaseGcsPath?.let { builder.putString(UploadWorker.KEY_LEASE_GCS_PATH, it) }
        leaseContentType?.let {
            builder.putString(UploadWorker.KEY_LEASE_CONTENT_TYPE, it)
        }
        leaseMaxBytes?.let { builder.putLong(UploadWorker.KEY_LEASE_MAX_BYTES, it) }
        return builder.build()
    }

    private fun Descriptor.isValid(): Boolean = version == VERSION &&
        workName.isNotBlank() && localFilePath.isNotBlank() && baseUrl.isNotBlank() &&
        projectId.isNotBlank() && apiKey.isNotBlank() && sessionId.isNotBlank() &&
        installationId.isNotBlank() && frameSeq >= 0L &&
        FrameKind.fromWire(frameKind) != null && expectedGcsPath.isNotBlank() &&
        policyToken.isNotBlank() && (
            signedUrl == null || (
                signedUrlExpiresAt != null &&
                    contentType != null &&
                    maxBytes != null &&
                    leaseFrameSeq != null &&
                    leaseFrameKind != null &&
                    leaseGcsPath != null &&
                    leaseContentType != null &&
                    leaseMaxBytes != null
                )
            )

    private fun read(file: File): Descriptor? = runCatching {
        json.decodeFromString(Descriptor.serializer(), file.readText())
    }.getOrNull()

    private fun replayRoot(context: Context): File? = runCatching {
        val path = context.cacheDir.absolutePath.takeIf { it.isNotBlank() } ?: return null
        File(path, "kixo-replay").canonicalFile
    }.getOrNull()

    private fun descriptorFiles(root: File): Sequence<File> = if (!root.exists()) {
        emptySequence()
    } else {
        root.walkTopDown().filter { it.isFile && it.name.endsWith(SIDECAR_SUFFIX) }
    }

    private fun sidecarFor(rawFile: File): File = File(rawFile.absolutePath + SIDECAR_SUFFIX)

    private fun isInside(file: File, root: File): Boolean = runCatching {
        val rootPrefix = root.canonicalPath.trimEnd(File.separatorChar) + File.separator
        file.canonicalPath.startsWith(rootPrefix)
    }.getOrDefault(false)

    private fun sameFile(first: File, second: File): Boolean = runCatching {
        first.canonicalFile == second.canonicalFile
    }.getOrDefault(false)

    private fun discardInvalid(sidecar: File, root: File) {
        val rawPath = sidecar.absolutePath.removeSuffix(SIDECAR_SUFFIX)
        val raw = File(rawPath)
        if (isInside(raw, root)) UploadWorker.discardPermanentlyRejectedFile(raw)
        runCatching { sidecar.delete() }
    }

    private const val VERSION = 2
    private const val SIDECAR_SUFFIX = ".kixo-work.json"
}
