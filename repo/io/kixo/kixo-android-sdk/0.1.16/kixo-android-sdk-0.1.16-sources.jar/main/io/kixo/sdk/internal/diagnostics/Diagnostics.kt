package io.kixo.sdk.internal.diagnostics

import io.kixo.sdk.KixoDiagnostics
import io.kixo.sdk.internal.queue.ConfigHolder
import io.kixo.sdk.internal.queue.LifecycleState

/**
 * Assembles a [KixoDiagnostics] snapshot for the public
 * `Kixo.diagnostics()` API. Pure aggregator — no state of its own,
 * just reads from the live subsystems and packages their state into
 * the host-facing data class.
 *
 * Mirrors the iOS `Diagnostics.swift` `snapshot()` helper one-for-one.
 *
 * # Why a separate type and not inline in [io.kixo.sdk.Kixo]?
 *
 *  1. The Kixo facade (Agent 1) is huge — every public API surface
 *     lives there. Splitting the diagnostics aggregation out gives it
 *     its own home + its own tests.
 *  2. The aggregator depends on five subsystems (queue, replay,
 *     consent, identity, config). Each is owned by a different agent.
 *     Doing the wiring in a single file makes the cross-agent
 *     coupling visible at a glance.
 *  3. Several tests (queue health under load, replay-active flag
 *     transitions) want to call the assembler directly without going
 *     through the public facade. A standalone helper makes that easy.
 *
 * # Cross-agent stubs
 *
 * Per AGENT_BRIEFING.md §6, when an agent needs types from another
 * agent's folder that haven't landed yet, declare the minimal
 * interface in your folder. The facade (Agent 1) supplies the live
 * implementations at runtime via [snapshot]. We accept all the
 * sources as constructor / parameter dependencies rather than
 * importing a concrete singleton — this keeps the aggregator
 * compile-clean even before Agents 5 / 13 finish their primary
 * surfaces.
 *
 * # Field-by-field source
 *
 * (See [KixoDiagnostics] doc for the host-visible field semantics.)
 *
 *   - `initialised`             ← [ConfigHolder.snapshot] `.isInitialised`
 *   - `paused`                  ← [LifecycleState] is [LifecycleState.PausedByServer]
 *   - `environment`             ← [ConfigHolder.snapshot] `.environment`
 *   - `apiHost`                 ← [ConfigHolder.snapshot] `.apiHost`
 *   - `lifecycleState` (string) ← [LifecycleState.name]
 *   - `lastFlushAtMillis`       ← [QueueDiagnosticSource.lastFlushAtMillis]
 *   - `lastError`               ← [QueueDiagnosticSource.lastError]
 *   - `queue.bufferedEventCount`← [QueueDiagnosticSource.pendingEventCount]
 *                                 + [QueueDiagnosticSource.inflightEventCount]
 *   - `queue.bufferCap`         ← [ConfigHolder.snapshot] `.maxBufferSize`
 *   - `queue.consecutiveFailures` ← [QueueDiagnosticSource.consecutiveFailures]
 *   - `queue.isFlushing`        ← [QueueDiagnosticSource.isFlushing]
 *   - `queue.retryTier`         ← [QueueDiagnosticSource.retryTier]
 *
 * The briefing also lists `replayActive` / `optedOut` /
 * `consentGranted` / `sdkVersion` / `releaseId`. The current public
 * [KixoDiagnostics] data class doesn't surface those, but downstream
 * consumers (admin debug screens, customer support tooling) will
 * want them — see [DiagnosticsExtras] for a side-channel data class
 * that the host's debug screen can attach to its own crash report
 * alongside the public snapshot.
 */
internal object Diagnostics {

    /**
     * Build the public-facing [KixoDiagnostics] snapshot.
     *
     * Returns [KixoDiagnostics.Uninitialised] when [ConfigHolder] has
     * never been populated — keeps the public API non-throwing without
     * forcing the host to handle nullables.
     *
     * @param lifecycle Current SDK lifecycle state. Owned by Agent 1
     *   (the facade holds it as the source of truth and passes it in
     *   on every call). Must not be null.
     * @param queue     Live event-queue health source. Owned by
     *   Agent 5 — the Kixo facade injects an adapter at runtime.
     *   When null (queue not yet bootstrapped), buffer counts default
     *   to zero.
     */
    fun snapshot(
        lifecycle: LifecycleState,
        queue: QueueDiagnosticSource?,
    ): KixoDiagnostics {
        val cfg = ConfigHolder.snapshot()
        if (!cfg.isInitialised) return KixoDiagnostics.Uninitialised

        // Pending + in-flight together = "events not yet acknowledged
        // by the server". The host doesn't care about MPDB internals;
        // they just want one number for "stuff still on disk".
        val pending = queue?.pendingEventCount() ?: 0
        val inflight = queue?.inflightEventCount() ?: 0
        val buffered = pending + inflight

        return KixoDiagnostics(
            initialised = true,
            paused = lifecycle is LifecycleState.PausedByServer,
            environment = cfg.environment,
            apiHost = cfg.apiHost,
            lifecycleState = lifecycle.name,
            lastFlushAtMillis = queue?.lastFlushAtMillis(),
            lastError = queue?.lastError(),
            queue = KixoDiagnostics.QueueHealth(
                bufferedEventCount = buffered,
                bufferCap = cfg.maxBufferSize,
                consecutiveFailures = queue?.consecutiveFailures() ?: 0,
                isFlushing = queue?.isFlushing() ?: false,
                retryTier = queue?.retryTier() ?: "healthy",
            ),
            // SDK self-test routing flag, internal use only.
            internalDevForced = System.getProperty("kixo.internal.dev") == "1" ||
                System.getenv("KIXO_INTERNAL_DEV") == "1",
        )
    }

    /**
     * Side-channel snapshot of state the public [KixoDiagnostics] class
     * doesn't expose but a debug screen / admin support flow may need.
     *
     * Not part of the public API. Internal callers (e.g. an admin
     * customer-support endpoint that captures full SDK state) read this
     * directly. Subject to change without notice.
     */
    fun extras(
        replay: ReplayDiagnosticSource?,
        consent: ConsentDiagnosticSource?,
    ): DiagnosticsExtras {
        val cfg = ConfigHolder.snapshot()
        return DiagnosticsExtras(
            sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
            releaseId = cfg.releaseId.takeIf { it.isNotEmpty() },
            replayActive = replay?.isReplayActive() ?: false,
            optedOut = consent?.isOptedOut() ?: false,
            consentGranted = consent?.hasConsent() ?: true,
        )
    }
}

/**
 * Snapshot of the SDK state that doesn't fit in the public
 * [KixoDiagnostics] but is still useful for debug screens, customer-
 * support tooling, and operator triage. Internal for now — promote
 * to public when there's a host need.
 *
 * Mirrors the same trade-off the briefing names: [KixoDiagnostics]
 * carries the host-facing health view; [DiagnosticsExtras] adds
 * privacy + replay state that an internal admin tool might want.
 */
internal data class DiagnosticsExtras(
    val sdkVersion: String,
    val releaseId: String?,
    val replayActive: Boolean,
    val optedOut: Boolean,
    val consentGranted: Boolean,
)

/**
 * Stub interface — Agent 5's `EventQueue` (or its dedicated
 * `QueueDiagnostics` companion) implements this to feed live
 * counters / lastFlushAt / retry tier into the aggregator.
 *
 * Per AGENT_BRIEFING.md §6 file-ownership rule, this is declared
 * locally so we don't reach into queue/ for a real type that
 * may not exist yet. When Agent 5 lands a `QueueDiagnostics`
 * concrete type, the facade adapts it to this interface in
 * `Kixo.diagnostics()`.
 *
 * **Performance contract:** every method must be O(1) and
 * non-blocking. The aggregator is called from the host's debug
 * screen on every render — a slow source freezes the UI.
 */
internal interface QueueDiagnosticSource {
    /** Events stored locally with `flag=PENDING` (eligible for next checkout). */
    fun pendingEventCount(): Int

    /** Events checked out + waiting for ack (`flag=IN_FLIGHT`). */
    fun inflightEventCount(): Int

    /** Wall-clock millis of the most recent SUCCESSFUL flush; null if never. */
    fun lastFlushAtMillis(): Long?

    /** Truncated last-error string (≤ ~256 chars); null if no failures. */
    fun lastError(): String?

    /** Consecutive failed batches since the last 200 OK. */
    fun consecutiveFailures(): Int

    /** True while a flush is in flight. */
    fun isFlushing(): Boolean

    /** Retry tier name: "healthy" / "rapid" / "slow" / "cooldown". */
    fun retryTier(): String
}

/**
 * Stub interface — Agent 13's `ReplayController` implements this so
 * the diagnostics aggregator can report whether a replay session is
 * currently capturing frames.
 *
 * Same locality rationale as [QueueDiagnosticSource].
 */
internal interface ReplayDiagnosticSource {
    /** True iff a replay session is OPEN + capturing on the device. */
    fun isReplayActive(): Boolean
}

/**
 * Stub interface — Agent 10's `ConsentManager` already exists with
 * exactly these methods (`isOptedOut()`, `hasConsent()`); this
 * interface is here to keep the aggregator decoupled and unit-testable
 * without pulling the privacy-package dep into our test module.
 */
internal interface ConsentDiagnosticSource {
    fun isOptedOut(): Boolean
    fun hasConsent(): Boolean
}
