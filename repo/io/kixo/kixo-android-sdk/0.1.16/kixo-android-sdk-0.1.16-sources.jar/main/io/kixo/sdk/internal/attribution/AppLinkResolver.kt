package io.kixo.sdk.internal.attribution

import android.util.Log
import io.kixo.sdk.BuildConfig
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference

/**
 * Resolves a direct installed-app open without blocking its routing path.
 *
 * The caller emits the local `received` callback first. This class then waits
 * for canonical app identity from `/init`, performs one authenticated resolve
 * off-main, and returns only server-canonical routing/engagement fields.
 */
internal class AppLinkResolver(
    private val sender: Sender,
    private val executor: (Runnable) -> Unit,
    private val contextProvider: () -> Context?,
    private val isPrivacyDenied: () -> Boolean,
    private val sleep: (Long) -> Unit = Thread::sleep,
) {
    private val resolutionEpoch = AtomicLong(0L)

    data class Context(
        val baseUrl: String,
        val projectId: String,
        val apiKey: String,
        val appId: String,
        val deviceId: String,
        val installId: String,
        val collectionRunning: Boolean = true,
    )

    sealed class Signal {
        data class LinkUrl(val value: String) : Signal()
        data class ClickId(val value: String) : Signal()
    }

    data class ResolvedAppLink(
        val targetUrl: String?,
        val linkId: String,
        val clickId: String,
        val campaign: String?,
        val mediaSource: String?,
        val medium: String?,
        val resolutionMethod: String,
        val resolutionConfidence: Double,
    )

    sealed class Outcome {
        data class Resolved(val link: ResolvedAppLink) : Outcome()
        data object Unresolved : Outcome()
        data class Failed(val reason: String) : Outcome()
    }

    fun interface Sender {
        fun send(
            url: String,
            body: String,
            apiKey: String,
            sdkVersion: String,
            cancellation: Cancellation,
        ): HttpOutcome

        fun cancelPending() = Unit
    }

    internal fun interface CancelHandle {
        fun cancel()
    }

    internal class Cancellation : CancelHandle {
        private val cancelled = AtomicBoolean(false)
        private val action = AtomicReference<(() -> Unit)?>(null)

        fun isCancelled(): Boolean = cancelled.get()

        fun attach(cancelAction: () -> Unit): () -> Unit {
            action.set(cancelAction)
            if (cancelled.get() && action.compareAndSet(cancelAction, null)) {
                cancelAction()
            }
            return { action.compareAndSet(cancelAction, null) }
        }

        override fun cancel() {
            if (cancelled.compareAndSet(false, true)) {
                action.getAndSet(null)?.invoke()
            }
        }
    }

    sealed class HttpOutcome {
        data class Ok(val responseBody: String) : HttpOutcome()
        data class Http(val code: Int) : HttpOutcome()
        data class Network(val reason: String) : HttpOutcome()
    }

    /**
     * Resolve [signal] for one OS delivery identified by [openId]. The same
     * `open_id` is sent to the backend and later exposed in the resolved callback.
     */
    fun resolve(
        signal: Signal,
        openId: String,
        installAttributionCandidate: Boolean = false,
        onComplete: (Outcome) -> Unit,
    ): CancelHandle {
        if (!validSignal(signal) || !isUuid(openId) || isPrivacyDenied()) {
            return NOOP_CANCEL
        }
        val epoch = resolutionEpoch.get()
        val cancellation = Cancellation()
        val task = Runnable {
            if (!isAllowed(epoch, cancellation)) return@Runnable
            val ctx = awaitResolvedContext(epoch, cancellation)
            if (ctx == null) {
                deliverIfAllowed(
                    epoch,
                    cancellation,
                    Outcome.Failed("app_identity_unavailable"),
                    onComplete,
                )
                return@Runnable
            }

            val body = buildResolveBody(
                ctx,
                signal,
                openId,
                installAttributionCandidate,
            )
            val url = Endpoints.url(ctx.baseUrl, Endpoints.LINK_RESOLVE)
            val response = try {
                sender.send(url, body, ctx.apiKey, SDK_VERSION, cancellation)
            } catch (t: Throwable) {
                Log.w(TAG, "App Link resolve sender threw", t)
                HttpOutcome.Network("sender_threw")
            }
            val outcome = when (response) {
                is HttpOutcome.Ok -> parseOutcome(response.responseBody)
                is HttpOutcome.Http -> Outcome.Failed("http_${response.code}")
                is HttpOutcome.Network -> Outcome.Failed(response.reason)
            }
            deliverIfAllowed(epoch, cancellation, outcome, onComplete)
        }

        try {
            executor(task)
        } catch (t: Throwable) {
            Log.w(TAG, "App Link resolve executor rejected work", t)
            deliverIfAllowed(
                epoch,
                cancellation,
                Outcome.Failed("executor_rejected"),
                onComplete,
            )
        }
        return cancellation
    }

    /** Invalidate queued work and cancel only this resolver's active HTTP calls. */
    fun cancelPending() {
        resolutionEpoch.incrementAndGet()
        sender.cancelPending()
    }

    private fun awaitResolvedContext(epoch: Long, cancellation: Cancellation): Context? {
        repeat(CONTEXT_POLL_ATTEMPTS) { attempt ->
            if (!isAllowed(epoch, cancellation)) return null
            contextProvider()?.takeIf(::validContext)?.let { return it }
            if (attempt + 1 < CONTEXT_POLL_ATTEMPTS) {
                try {
                    sleep(CONTEXT_POLL_INTERVAL_MS)
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                    return null
                } catch (t: Throwable) {
                    Log.w(TAG, "App identity wait interrupted", t)
                    return null
                }
            }
        }
        return null
    }

    private fun isAllowed(epoch: Long, cancellation: Cancellation): Boolean =
        !cancellation.isCancelled() &&
            epoch == resolutionEpoch.get() &&
            !isPrivacyDenied()

    private fun deliverIfAllowed(
        epoch: Long,
        cancellation: Cancellation,
        outcome: Outcome,
        onComplete: (Outcome) -> Unit,
    ) {
        if (!isAllowed(epoch, cancellation)) return
        try {
            onComplete(outcome)
        } catch (t: Throwable) {
            Log.w(TAG, "App Link resolve callback threw", t)
        }
    }

    private fun validSignal(signal: Signal): Boolean = when (signal) {
        is Signal.LinkUrl -> signal.value.isNotBlank() && signal.value.length <= MAX_LINK_URL_LENGTH
        is Signal.ClickId -> isUuid(signal.value)
    }

    private fun validContext(ctx: Context): Boolean =
        ctx.collectionRunning &&
        ctx.baseUrl.isNotBlank() &&
            ctx.projectId.isNotBlank() &&
            ctx.apiKey.isNotBlank() &&
            APP_ID_PATTERN.matches(ctx.appId) &&
            DEVICE_ID_PATTERN.matches(ctx.deviceId) &&
            INSTALL_ID_PATTERN.matches(ctx.installId)

    private fun buildResolveBody(
        ctx: Context,
        signal: Signal,
        openId: String,
        installAttributionCandidate: Boolean,
    ): String =
        buildString(384) {
            append('{')
            field("project_id", ctx.projectId)
            append(',')
            field("api_key", ctx.apiKey)
            append(',')
            field("app_id", ctx.appId)
            append(',')
            field("device_id", ctx.deviceId)
            append(',')
            field(AttributionContract.INSTALL_ID_KEY, ctx.installId)
            append(',')
            field(
                AttributionContract.INSTALL_ATTRIBUTION_CANDIDATE_KEY,
                installAttributionCandidate,
            )
            append(',')
            field(AttributionContract.DL_PROP_OPEN_ID, openId)
            append(',')
            field("platform", PLATFORM_ANDROID)
            append(',')
            when (signal) {
                is Signal.LinkUrl -> field(LINK_URL_KEY, signal.value)
                is Signal.ClickId -> field(AttributionContract.KIXO_CLICK_ID_KEY, signal.value)
            }
            append('}')
        }

    private fun StringBuilder.field(key: String, value: String) {
        append(jsonString(key)).append(':').append(jsonString(value))
    }

    private fun StringBuilder.field(key: String, value: Boolean) {
        append(jsonString(key)).append(':').append(value)
    }

    /**
     * The public path slug is never a fallback. A successful result requires
     * the canonical database Link id and the direct-routing resolution method.
     */
    private fun parseOutcome(responseBody: String): Outcome {
        if (responseBody.isBlank()) return Outcome.Unresolved
        return try {
            val root = JSON.parseToJsonElement(responseBody) as? JsonObject
                ?: return Outcome.Unresolved
            if ((root["resolved"] as? JsonPrimitive)?.booleanOrNull != true) {
                return Outcome.Unresolved
            }
            val method = root.string("resolution_method")
            if (method != AttributionContract.RESOLUTION_METHOD_DIRECT_APP_LINK) {
                return Outcome.Unresolved
            }
            val link = root["link"] as? JsonObject ?: return Outcome.Unresolved
            val linkId = link.string("id")
                ?.takeIf(LINK_ID_PATTERN::matches)
                ?: return Outcome.Unresolved
            val clickId = root.string(AttributionContract.KIXO_CLICK_ID_KEY)
                ?.takeIf(::isUuid)
                ?: return Outcome.Unresolved
            val confidence = (root["resolution_confidence"] as? JsonPrimitive)
                ?.doubleOrNull
                ?.takeIf { it in 0.0..1.0 }
                ?: return Outcome.Unresolved
            Outcome.Resolved(
                ResolvedAppLink(
                    targetUrl = link.string("target_path"),
                    linkId = linkId,
                    clickId = clickId,
                    campaign = root.string("campaign"),
                    mediaSource = root.string("media_source"),
                    medium = root.string("medium") ?: root.string(AttributionContract.UTM_MEDIUM),
                    resolutionMethod = method,
                    resolutionConfidence = confidence,
                ),
            )
        } catch (t: Throwable) {
            Log.w(TAG, "App Link resolve response parse failed", t)
            Outcome.Unresolved
        }
    }

    private fun JsonObject.string(key: String): String? =
        (this[key] as? JsonPrimitive)?.contentOrNull
            ?.takeIf { it.isNotBlank() && it != "null" }

    companion object {
        private const val TAG = "Kixo.AppLinkResolver"
        private const val LINK_URL_KEY = "link_url"
        private const val PLATFORM_ANDROID = "android"
        private const val MAX_LINK_URL_LENGTH = 2_048
        private const val CONTEXT_POLL_INTERVAL_MS = 100L
        private const val CONTEXT_POLL_ATTEMPTS = 100
        private val APP_ID_PATTERN = Regex("^[A-Za-z0-9._:-]{1,128}$")
        private val DEVICE_ID_PATTERN = Regex("^[A-Za-z0-9._:-]{1,128}$")
        private val INSTALL_ID_PATTERN = Regex("^[A-Za-z0-9._:-]{8,128}$")
        private val LINK_ID_PATTERN = Regex("^[A-Za-z0-9_-]{1,128}$")
        private val SDK_VERSION: String = runCatching { BuildConfig.SDK_VERSION }.getOrDefault("")
        private val JSON = Json { ignoreUnknownKeys = true; isLenient = true }
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private val NOOP_CANCEL = CancelHandle {}

        internal fun isCanonicalClickId(value: String): Boolean = isUuid(value)

        private fun isUuid(value: String): Boolean =
            runCatching { UUID.fromString(value).toString().equals(value, ignoreCase = true) }
                .getOrDefault(false)

        private fun jsonString(value: String): String = buildString(value.length + 2) {
            append('"')
            for (char in value) {
                when (char) {
                    '"' -> append("\\\"")
                    '\\' -> append("\\\\")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    '\t' -> append("\\t")
                    else -> if (char < ' ') {
                        append("\\u").append(char.code.toString(16).padStart(4, '0'))
                    } else {
                        append(char)
                    }
                }
            }
            append('"')
        }

        fun okHttpSender(httpClient: OkHttpClient): Sender = object : Sender {
            private val activeCalls = ConcurrentHashMap.newKeySet<okhttp3.Call>()

            override fun send(
                url: String,
                body: String,
                apiKey: String,
                sdkVersion: String,
                cancellation: Cancellation,
            ): HttpOutcome {
                val request = Request.Builder()
                    .url(url)
                    .post(body.toRequestBody(JSON_MEDIA_TYPE))
                    .header("Authorization", "Bearer $apiKey")
                    .header("Content-Type", "application/json; charset=utf-8")
                    .header("X-Kixo-Sdk-Version", sdkVersion)
                    .build()
                val call = httpClient.newCall(request)
                activeCalls += call
                val detach = cancellation.attach(call::cancel)
                return try {
                    if (cancellation.isCancelled()) {
                        call.cancel()
                        return HttpOutcome.Network("cancelled")
                    }
                    call.execute().use { response ->
                        if (response.isSuccessful) {
                            HttpOutcome.Ok(response.body?.string().orEmpty())
                        } else {
                            HttpOutcome.Http(response.code)
                        }
                    }
                } catch (error: IOException) {
                    HttpOutcome.Network(error.message ?: "io_error")
                } catch (error: Throwable) {
                    HttpOutcome.Network(error.message ?: "unknown")
                } finally {
                    detach()
                    activeCalls -= call
                }
            }

            override fun cancelPending() {
                activeCalls.forEach { it.cancel() }
            }
        }
    }
}
