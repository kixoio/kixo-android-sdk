package io.kixo.sdk.internal.context

import android.content.Context

/**
 * Resolves the SDK's runtime environment string. ALWAYS defaults to
 * `"production"` for customer apps — auto-detection of debug builds
 * has been removed (was: FLAG_DEBUGGABLE → "development", which could
 * route a customer's internal QA / sideloaded debug build to Kixo's
 * internal dev backend instead of their own Kixo project on prod).
 *
 * The only path to "development" is for the operator
 * (us, internal team) to pass `.environment("development")` explicitly
 * via `KixoConfiguration.Builder`. The Builder setter is intentionally
 * public but documented as Kixo-internal-use-only — customer release
 * AND debug builds both route to prod with zero config.
 *
 * Resolution order (first wins):
 *   1. **Operator override** (from `KixoConfiguration.environment`).
 *      `development` / `production` are accepted. Unsupported strings,
 *      including unprovisioned `staging`, fail explicitly.
 *   2. **Default** → `"production"`. No conditional on the host app's
 *      `ApplicationInfo` flags — this used to flip to "development"
 *      on `FLAG_DEBUGGABLE`, which leaked customer debug-build events
 *      to Kixo's internal dev backend. Fixed in v0.1.2.
 *
 * @see io.kixo.sdk.KixoConfiguration for the operator-facing override.
 */
internal object EnvironmentDetector {

    /** Supported canonical environment strings. */
    private const val DEV = "development"
    private const val PROD = "production"

    // Hosts live in [io.kixo.sdk.internal.KixoEndpoints] — single source
    // of truth (Wave 5 SoT cleanup). Don't add new const here; add the
    // env there + map in [hostFor].

    /**
     * Detect the SDK environment.
     *
     * @param context Any Android [Context]. Application context is
     *   preferred to avoid leaking activities. Unused since v0.1.2
     *   (auto-detection removed) but kept on the signature for
     *   source compatibility with internal callers.
     * @param override Optional operator-provided value. Supported values
     *   are case-insensitive. Anything else fails explicitly.
     */
    @Suppress("UNUSED_PARAMETER")
    fun detect(context: Context, override: String? = null): String {
        // 1. Operator override — only if it normalises to a known value.
        val normalised = override?.trim()?.lowercase()
        if (normalised == DEV || normalised == PROD) return normalised
        require(normalised.isNullOrEmpty()) {
            "Unsupported Kixo environment '$override'. Use 'production' or 'development'."
        }

        // 2. Default = production. FLAG_DEBUGGABLE auto-detect removed
        //    in v0.1.2 — customers' debug builds now route to prod
        //    (their Kixo project) instead of Kixo's internal dev backend.
        return PROD
    }

    /**
     * Resolve the API host base URL for a given environment string.
     * Used by Agent 4 (transport) so the host->URL mapping lives in
     * one place. Unsupported values fail explicitly.
     */
    fun apiHost(environment: String): String =
        io.kixo.sdk.internal.KixoEndpoints.forEnvironment(environment)
}
