package io.kixo.sdk.internal.queue

import io.kixo.sdk.internal.model.DataCollection
import io.kixo.sdk.internal.model.KixoEventType

/**
 * Maps a resolved `data_collection` policy onto the event types it
 * EXPLICITLY switches off.
 *
 * Every tracker already consults [DataCollectionHolder] at emit time,
 * so once a policy is resolved nothing new is admitted for a disabled
 * category. This object exists for the events admitted BEFORE that —
 * the cold-start window between `Kixo.configure(...)` and the first
 * `/api/sdk/init` response, where [DataCollectionHolder] is still
 * `null` and every gate default-allows.
 *
 * **Deliberately conservative.**
 *  - Only an explicit `false` counts. `null` (field absent, block
 *    absent, whole policy absent) is never a denial — same
 *    default-allow convention every emit-time gate uses.
 *  - Only categories that have a real emit-time gate are listed, and
 *    each entry mirrors that gate's lookup exactly:
 *      * `core.sessions`      → `SessionTracker`
 *      * `core.errors`        → `CrashTracker` / `AnrWatchdog` /
 *                               `NativeCrashDrain`
 *      * `engagement.clicks`  → `TouchInterceptor`
 *      * `push.enabled`       → `PushTracker`
 *  - Customer-authored events (`custom` from `Kixo.track`, `identify`,
 *    `user_property`, `goal`) and the canonical install/attribution
 *    ledger are NEVER matched. The operator's auto-capture switches
 *    say what the SDK may observe on its own; they do not retract
 *    what the host app explicitly asked us to record.
 *
 * If a gate is added to a tracker, add the matching entry here so the
 * pre-policy buffer and the live stream keep agreeing.
 */
internal object DataCollectionEventGate {

    /**
     * True when [dc] affirmatively disables the category that produces
     * [type]. False for "allowed" and for "policy says nothing".
     */
    fun isExplicitlyDisabled(dc: DataCollection, type: KixoEventType): Boolean = when (type) {
        KixoEventType.SessionStart,
        KixoEventType.SessionEnd,
        -> dc.core?.sessions == false

        KixoEventType.Crash -> dc.core?.errors == false

        KixoEventType.Tap -> dc.engagement?.clicks == false

        KixoEventType.PushReceived,
        KixoEventType.PushOpen,
        KixoEventType.PushDismissed,
        KixoEventType.PushAction,
        KixoEventType.PushSilent,
        KixoEventType.PushPermission,
        KixoEventType.PushTokenInvalidated,
        -> dc.push?.enabled == false

        else -> false
    }
}
