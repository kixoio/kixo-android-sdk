package io.kixo.sdk.internal.replay

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import android.view.View
import android.view.Window
import io.kixo.sdk.internal.interaction.InteractionMeta
import io.kixo.sdk.internal.privacy.StructuralRedactionRules
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.random.Random

/**
 * Top-level orchestrator for the replay capture pipeline. Wires
 * together the rest of the [io.kixo.sdk.internal.replay] package:
 *
 *  - [Sampler] — session-deterministic sampling decision (KIX-UNI-22)
 *  - [ThermalBackoff] — pauses capture under thermal / battery / power load
 *  - [CaptureSlot] — bounded concurrency on in-flight captures
 *  - [RingBuffer] — single-slot pre-tap frame holder
 *  - [FrameSnapshotter] — `Bitmap` raster from a `View`
 *  - [StructuralSnapshotter] — JSON DOM-like view-tree sidecar
 *  - [OcrExtractor] — on-device ML Kit text recognition
 *  - [ScreenIdentityHelper] — joins frames to Agent 9's screen tracker
 *
 * Mirrors iOS [ReplayController.swift] semantics adapted for Android:
 *  - The iOS WindowEventInterceptor is replaced by Agent 8's touch
 *    tracker which calls [handleTap] directly with a classified
 *    [InteractionMeta].
 *  - The iOS post-frame "next vsync" callback is implemented via
 *    [Choreographer.postFrameCallback].
 *  - The iOS `BackgroundUploader` is owned by Agent 14 — this
 *    controller hands it the captured assets via [ReplayUploaderRef].
 *
 * **Lifecycle:**
 *  - [start] — invoked after resolved project policy when
 *    [ReplayConfig.replaySampleRate] passes the sampler verdict AND
 *    the device-tier check (handled upstream). Wires the thermal
 *    listener and retries `/replay/session/start`; capture transitions
 *    to `isActive=true` only after the server returns a usable session.
 *  - [onProcessBackground] — seals the in-flight session and blocks late
 *    remote-config opens until [resumeAfterProcessForeground].
 *  - [optOut] / [optIn] — customer kill switches.
 *
 * **Anti-crash. Per AGENT_BRIEFING §3 R6** all error paths swallow
 * + log. Network fail → upload re-enqueued by Agent 14. Bitmap OOM
 * → frame dropped, event still emitted with metadata. Memory
 * warning → [CaptureSlot.tightenForMemoryPressure] +
 * [ThermalBackoff.externalPause]. The host app must NEVER crash
 * because replay misbehaved.
 */
internal object ReplayController {

    private const val TAG = "Kixo"
    private const val SESSION_OPEN_RETRY_INITIAL_MS = 1_000L
    private const val SESSION_OPEN_RETRY_MAX_MS = 30_000L

    /** Singleton scope — supervisor so a single failure doesn't tear down peers. */
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val started = AtomicBoolean(false)

    /**
     * Composite gate: `false` while in any of:
     *  - sampler verdict was "out"
     *  - operator called [optOut]
     *  - thermal / power / battery / memory trip is active
     *
     * The closure handed to [ThermalBackoff.onStateChange] flips
     * this on trip; the trip recovery flips it back.
     */
    private val active = AtomicBoolean(false)

    /** True only after `/replay/session/start` published a usable uploader. */
    private val sessionOpened = AtomicBoolean(false)

    /** Invalidates late async open responses across stop/restart boundaries. */
    private val sessionGeneration = AtomicLong(0L)

    /** Process-level authority: false until ProcessLifecycleOwner confirms foreground. */
    private val processForeground = AtomicBoolean(false)
    private val processLifecycleGeneration = AtomicLong(0L)

    /** Serialized with server-open publication to avoid thermal/open lost updates. */
    private val thermalAllowed = AtomicBoolean(false)

    @Volatile
    private var sessionOpenRetryDelayForTesting: Long? = null

    private val optedOut = AtomicBoolean(false)

    /**
     * Sticky across an async normal close. If a hard privacy/identity discard
     * arrives after `started` already flipped false, the old close must not
     * repopulate resume watermarks/totals in its finally block.
     */
    private val hardDiscardRequested = AtomicBoolean(false)
    /** Active opt-out closes seal the server row after raw artifacts are purged. */
    private val explicitOptOutSealRequested = AtomicBoolean(false)
    /** Identity reset is stronger than opt-out: it permits no final RPC. */
    private val identityDiscardRequested = AtomicBoolean(false)

    /**
     * Pre-tap frame holder. Set after each `View.draw()` capture so
     * the next tap can grab "the frame just before the user touched
     * the screen." Cleared on memory warning + stop.
     */
    private val ringBuffer = RingBuffer<Bitmap>()

    /**
     * Last-known screen identity so [handleTap] can detect "same
     * screen as last tap" and skip redundant uploads when
     * [ReplayConfig] is tuned for dedup. Mirrors iOS
     * `lastScreenIdentity`. Atomic because reads happen on main
     * (capture pipeline) and writes happen on Default (the upload
     * coroutine).
     */
    @Volatile
    private var lastScreenIdentity: ScreenIdentity? = null

    /**
     * Increments per captured tap. Aligned 1:1 with the seq the
     * upload pipeline (Agent 14) uses to pre-allocate signed URLs.
     */
    private val nextSeq = AtomicLong(0L)

    /**
     * Last scroll-end capture wall time (`SystemClock.elapsedRealtime`).
     * Honours [ReplayConfig.scrollEndMinIntervalSec] rate-limit so a
     * long flick stream produces ≤ 1 frame per N-second window.
     */
    @Volatile
    private var lastScrollEndElapsedMs: Long = 0L

    /** Held during the lifetime of this start; cleared by [stop]. */
    @Volatile
    private var config: ReplayConfig? = null

    /**
     * FIX 4 (2026-07-05) — the COMPILED-DEFAULT baseline (the builder
     * [ReplayConfig] handed to [start], BEFORE any remote knobs). Each
     * latest `/api/sdk/init` or `/api/sdk/config` payload is authoritative, so a
     * knob ABSENT from a new payload must revert to this compiled default
     * — not retain the prior override. [applyRemoteReplayKnobs] therefore
     * resolves the LATEST [pendingKnobs] against THIS baseline (via
     * [ReplayKnobs.applyTo]), never against the already-overridden live
     * [config]. Set in [start]; cleared by [stop] / [resetForTesting].
     */
    @Volatile
    private var baseConfig: ReplayConfig? = null

    @Volatile
    private var captureSlot: CaptureSlot? = null

    @Volatile
    private var thermalBackoff: ThermalBackoff? = null

    @Volatile
    private var ocrExtractor: OcrExtractor? = null

    @Volatile
    private var structuralSnapshotter: StructuralSnapshotter? = null

    @Volatile
    private var screenIdentity: ScreenIdentityHelper? = null

    @Volatile
    private var sampler: Sampler? = null

    /** Analytics session currently authorized by deterministic sampling. */
    @Volatile
    private var sampledAnalyticsSessionId: String? = null

    /**
     * Last server-resolved sample rate (S3 / KIX-UNI-22 parity). It remains
     * authoritative across replay stints until a newer control-plane response
     * replaces it. A one-shot override makes opt-in consume the grant and a
     * following reset fall back to the compiled fail-closed 0% rate.
     */
    @Volatile
    private var serverSampleRateOverride: Double? = null

    /**
     * P1 (Codex, 2026-07-03) — deferred-start latch. Mirrors iOS
     * `replayBootstrapPending` (Kixo.swift:170). `Kixo.configure(...)`
     * runs synchronously at app start, BEFORE the control plane resolves
     * the server replay policy; starting replay there would sample the
     * first session without project permission and could open `/session/start` +
     * ship frames for a project whose resolved policy is
     * `replay.enabled == false`, in the window before the config-disable
     * side-effect lands.
     *
     * So `configure()` no longer starts replay directly — it ARMS this
     * latch with a fully-wired start thunk (the thunk closes over the
     * app context, uploader adapter, screen-identity helper, PII
     * sanitizer + analytics-session provider that only the facade can
     * assemble). The latch is consumed exactly once, from
     * [io.kixo.sdk.internal.queue.QueueWiring]'s control-plane success
     * path, and ONLY when the resolved server policy is
     * `replay.enabled == true` (release_id known, server sampleRate
     * already threaded in via [updateSampleRate]). Whichever way the
     * server answers, project config is the single start authority, exactly like iOS
     * `maybeStartReplayFromResolvedConfig`.
     *
     * Guarded by [pendingLock]: armed on the main thread in `configure`,
     * consumed on the init coroutine.
     */
    private val pendingLock = Any()
    private var pendingStart: (() -> Boolean)? = null
    private var retainedStart: (() -> Boolean)? = null
    private val remoteRestartAllowed = AtomicBoolean(false)
    /** Serializes the close-in-flight latch with deferred restart selection. */
    private val lifecycleTransitionLock = Any()
    private val stopInFlight = AtomicBoolean(false)
    private val restartRequestedAfterStop = AtomicBoolean(false)

    /** Deterministic race-test seam; invoked while [lifecycleTransitionLock] is held. */
    @Volatile
    private var startClaimedHookForTesting: (() -> Unit)? = null

    /**
     * Agent 14's upload-pipeline reference. Stub interface to keep
     * this folder package-isolated; the real type lives in
     * `io.kixo.sdk.internal.replay.upload.ReplayUploader`. See the
     * companion stub below.
     */
    @Volatile
    private var uploader: ReplayUploaderRef? = null

    /**
     * Cold-start cancellation token — when [stop] fires, the
     * post-frame callback retains the [Job] reference and aborts so
     * we don't post an upload past the session boundary.
     */
    @Volatile
    private var sessionJob: Job? = null

    /** Project-controlled wall-clock end cap for the current stint. */
    @Volatile
    private var maxDurationJob: Job? = null

    @Volatile
    private var replayStartedElapsedMs: Long = -1L

    /** Main-looper handler for the dirty-settle + heartbeat scheduler. */
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * AND-CAP-02 — resolves the currently-foregrounded window for
     * dirty/heartbeat/screen-entry captures (which have no gesture-
     * supplied View). Bound at [start] to
     * `KixoInternalBootstrap.currentActivity()?.window`. Null when no
     * Activity is foregrounded (backgrounded / cold-start pre-resume).
     */
    @Volatile
    private var windowProvider: () -> Window? = { null }

    /**
     * AND-CAP-02 skip-unchanged — the structural signature of the LAST
     * SHIPPED frame. A settle/heartbeat capture whose fresh signature
     * equals this is skipped (static screen ⇒ zero encode/upload).
     * Written on the capture thread, read on the capture thread.
     */
    private val lastShippedSignature = AtomicReference<String?>(null)

    /**
     * AND-CAP-02 cadence floor — elapsed-ms of the last capture ATTEMPT
     * (M3, 2026-07-05: advanced on dispatch/commit via [noteCaptureAttempt],
     * NOT only on a successful frame). A dirty/heartbeat capture within
     * [ReplayConfig.captureMinIntervalMs] of this is throttled + re-armed.
     * Keying on attempt (not success) means a screen whose captures keep
     * failing is still throttled to ≤ 1 attempt per floor interval rather
     * than storming at the settle cadence. Reset to 0 on stop so the first
     * frame of a stint is never throttled.
     */
    @Volatile
    private var lastRenderElapsedMs: Long = 0L

    /**
     * M3 — elapsed-ms of the last SUCCESSFUL render (postFrame != null),
     * distinct from the attempt-keyed [lastRenderElapsedMs] the floor
     * uses. Informational; kept separate so the floor's attempt semantics
     * don't clobber a "last actually shipped" reading. Reset to 0 on stop.
     */
    @Volatile
    private var lastSuccessfulRenderElapsedMs: Long = 0L

    /**
     * Heartbeat ticker; posted while a stint is active + foregrounded.
     * `@Volatile` (mirroring the other session fields) — written on main
     * by [startHeartbeat] / the runnable's repost AND read/written by
     * [stopHeartbeat], which now always runs on main via the posted
     * teardown but stays volatile as belt-and-suspenders against a stray
     * unsynchronized read.
     */
    @Volatile
    private var heartbeatRunnable: Runnable? = null

    /**
     * Bring the replay subsystem online. Idempotent — calling twice
     * is a cheap no-op. The actual `/api/sdk/replay/session/start`
     * POST is delegated to Agent 14's [uploader] which calls back
     * with the initial signed-URL pool.
     *
     * Sampler verdict gates everything — when "out", this method
     * returns without wiring anything (saves the entire memory +
     * lifecycle observer cost on the 95% of installs not in the
     * reservoir).
     *
     * **Returns** `true` when this call claimed and launched a server-open
     * attempt — i.e. the sampler verdict passed AND all fields were wired.
     * [isActive] remains false until that asynchronous open succeeds.
     * Returns `false` on opt-out, the idempotent second-start no-op,
     * and the sampler-"out" early return (S4 — so the caller can keep
     * `replayActive` honest instead of unconditionally flipping it
     * true and installing a dead tap-hook path).
     */
    fun start(
        context: Context,
        config: ReplayConfig,
        uploader: ReplayUploaderRef,
        sampler: Sampler = Sampler.getInstance(context),
        thermalBackoff: ThermalBackoff = ThermalBackoff.from(context),
        screenIdentityHelper: ScreenIdentityHelper = ScreenIdentityHelper(),
        piiSanitizer: (String) -> String = { it },
        /** Live project `replay.maskInputs`; missing policy masks by default. */
        maskInputsProvider: () -> Boolean = { true },
        /**
         * Current ANALYTICS session id (nullable pre-bootstrap).
         * Wave 1 (KIX-UNI-01) resume contract: when it matches the
         * last ended stint's id, the seq counter continues instead
         * of restarting at 0 — see [ReplayResumeState].
         */
        analyticsSessionIdProvider: () -> String? = { null },
        /**
         * AND-CAP-02 — resolves the foregrounded [Window] for dirty /
         * heartbeat / screen-entry captures (no gesture View). Bound to
         * `KixoInternalBootstrap.currentActivity()?.window` at the call
         * site. Default null-provider = only gesture captures run.
         */
        windowProvider: () -> Window? = { null },
    ): Boolean = synchronized(lifecycleTransitionLock) {
        if (optedOut.get() || stopInFlight.get() || !processForeground.get()) {
            Log.d(TAG, "Replay start skipped: opted out")
            return@synchronized false
        }
        if (!started.compareAndSet(false, true)) {
            // Idempotent — second start is a no-op.
            return@synchronized false
        }
        startClaimedHookForTesting?.invoke()
        hardDiscardRequested.set(false)
        explicitOptOutSealRequested.set(false)
        identityDiscardRequested.set(false)

        // Resolve the analytics session id ONCE — it keys both the
        // deterministic sampler verdict (Wave 5, KIX-UNI-22) and the
        // resume-seq lookup below, and we want the SAME value for both.
        val analyticsSessionId = analyticsSessionIdProvider()

        // S3 (KIX-UNI-22 parity): the latest server-resolved rate wins over the
        // fail-closed compiled bootstrap for every stint until a newer policy
        // replaces it. Without this the dashboard sample-rate
        // slider is a no-op on Android (only a full server 0 disabled it,
        // and only at tap time) — web + iOS both thread the server rate
        // into the verdict. Mirrors iOS `effectiveRate` (ReplayController.swift:471-478).
        val effectiveRate = serverSampleRateOverride ?: config.replaySampleRate

        // Wave 5 (KIX-UNI-22): session-deterministic sampling. Records
        // iff `sampleBucket(sessionId) < rate*100` — the canonical
        // cross-SDK gate (byte-identical to web + iOS), so a customer
        // wiring replay across platforms records the SAME set of
        // sessions. A null/blank session id fails closed (a recording
        // keyed to no session couldn't be listed/played), matching web
        // recorder.ts.
        if (!sampler.sessionDeterministicVerdict(analyticsSessionId, effectiveRate)) {
            // Sampler said "out" — wire nothing, leave the singleton
            // dormant. A future trigger-override (rage-click / crash)
            // would re-evaluate; we don't wire that path until the
            // Agent 12 / 15 detectors are in.
            started.set(false)
            return@synchronized false
        }

        // Seed the seq counter BEFORE the active gate opens so no tap
        // can mint a colliding low seq during a resumed stint. Fresh
        // stints (different / unknown session id → null) seed 0; the
        // fresh-vs-resume distinction itself is the adapter's job
        // (it sends `next_seq` on the wire) — here only the numeric
        // watermark matters.
        nextSeq.set(ReplayResumeState.resumeSeqFor(analyticsSessionId) ?: 0L)

        // AND-CAP-04 — fold in any server perf knobs that arrived
        // before this (deferred) start so the session honours them from
        // frame one (e.g. remote structural/ocr re-enable, tuned
        // cadence). Builder config is the base; server knobs overlay.
        //
        // FIX 4 (2026-07-05) — stash the COMPILED-DEFAULT baseline so a
        // later /init that OMITS a knob reverts that knob to this default
        // instead of retaining the prior override. [pendingKnobs] holds the
        // LATEST /init payload (not an accumulation), so applying it to the
        // baseline yields an authoritative effective config.
        this.baseConfig = config
        val effectiveConfig = pendingKnobs.applyTo(config)

        this.config = effectiveConfig
        this.sampler = sampler
        this.sampledAnalyticsSessionId = analyticsSessionId
        this.thermalBackoff = thermalBackoff
        this.captureSlot = CaptureSlot(baseline = effectiveConfig.maxConcurrentCaptures)
        this.ocrExtractor = OcrExtractor(
            config = effectiveConfig,
            piiSanitizer = piiSanitizer,
            // P2 (2026-07-05) — read the LIVE ocrEnabled so a remote /init
            // flip takes effect on this already-started session.
            liveOcrEnabled = { this.config?.ocrEnabled == true },
            liveMaxConcurrentOcr = { this.config?.maxConcurrentOcr ?: 4 },
        )
        this.structuralSnapshotter = StructuralSnapshotter(
            piiSanitizer = piiSanitizer,
            shouldRedactSubtree = { view ->
                StructuralRedactionRules.shouldRedact(
                    view = view,
                    maskAllInputs = maskInputsProvider(),
                )
            },
        )
        this.screenIdentity = screenIdentityHelper
        this.uploader = uploader
        this.windowProvider = windowProvider
        lastShippedSignature.set(null)
        lastRenderElapsedMs = 0L
        lastSuccessfulRenderElapsedMs = 0L

        val generation = sessionGeneration.incrementAndGet()
        thermalAllowed.set(thermalBackoff.isCaptureAllowed())

        // Thermal recovery must never open capture before the server session,
        // and an old listener must not mutate a successor stint.
        thermalBackoff.onStateChange = stateChange@ { shouldPause, reason ->
            if (sessionGeneration.get() != generation ||
                !started.get() ||
                this.thermalBackoff !== thermalBackoff
            ) {
                return@stateChange
            }
            val changed = synchronized(lifecycleTransitionLock) {
                if (sessionGeneration.get() != generation ||
                    !started.get() ||
                    this.thermalBackoff !== thermalBackoff
                ) {
                    false
                } else {
                    thermalAllowed.set(!shouldPause)
                    val shouldCapture = sessionOpened.get() && !shouldPause
                    val wasActive = active.getAndSet(shouldCapture)
                    wasActive != shouldCapture
                }
            }
            if (changed) {
                Log.d(TAG, "Replay state change: paused=$shouldPause reason=${reason.wire}")
                reconcileDirtyEngine()
            }
        }
        thermalBackoff.start()
        synchronized(lifecycleTransitionLock) {
            if (sessionGeneration.get() == generation &&
                started.get() &&
                this.thermalBackoff === thermalBackoff
            ) {
                thermalAllowed.set(thermalBackoff.isCaptureAllowed())
            }
        }
        sessionOpened.set(false)
        active.set(false)

        // Capture remains closed until the backend publishes a usable uploader.
        // There is deliberately no pre-session bitmap queue: retaining frames
        // while offline would create unbounded memory pressure in host apps.
        val openingJob = scope.launch {
            var retryDelayMs = sessionOpenRetryDelayForTesting ?: SESSION_OPEN_RETRY_INITIAL_MS
            while (started.get() &&
                sessionGeneration.get() == generation &&
                !optedOut.get() &&
                processForeground.get()
            ) {
                val result = try {
                    uploader.beginSession(config = effectiveConfig)
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (t: Throwable) {
                    Log.w(TAG, "uploader.beginSession failed", t)
                    ReplaySessionOpenResult.Retryable
                }
                when (result) {
                    is ReplaySessionOpenResult.Opened -> {
                        val activated = synchronized(lifecycleTransitionLock) {
                            if (started.get() &&
                                sessionGeneration.get() == generation &&
                                !optedOut.get() &&
                                processForeground.get() &&
                                !hardDiscardRequested.get()
                            ) {
                                ReplayResumeState.onStintOpen(result.clientSessionId)
                                sessionOpened.set(true)
                                active.set(thermalAllowed.get())
                                replayStartedElapsedMs = SystemClock.elapsedRealtime()
                                scheduleMaxDuration()
                                true
                            } else {
                                if (!hardDiscardRequested.get()) {
                                    ReplayResumeState.onStintOpen(result.clientSessionId)
                                    ReplayResumeState.onStintEnd(nextSeq.get())
                                }
                                false
                            }
                        }
                        if (activated) reconcileDirtyEngine()
                        return@launch
                    }
                    ReplaySessionOpenResult.Terminal,
                    ReplaySessionOpenResult.PolicyPaused -> {
                        stopForRemotePolicy()
                        return@launch
                    }
                    ReplaySessionOpenResult.Retryable -> Unit
                }
                if (!started.get() ||
                    sessionGeneration.get() != generation ||
                    optedOut.get() ||
                    !processForeground.get()
                ) {
                    return@launch
                }
                val delayMs = sessionOpenRetryDelayForTesting ?: Random.nextLong(
                    from = 1L,
                    until = retryDelayMs.coerceAtLeast(1L) + 1L,
                )
                delay(delayMs)
                retryDelayMs = sessionOpenRetryDelayForTesting
                    ?: (retryDelayMs * 2).coerceAtMost(SESSION_OPEN_RETRY_MAX_MS)
            }
        }
        sessionJob = openingJob
        openingJob.invokeOnCompletion {
            synchronized(lifecycleTransitionLock) {
                if (sessionJob === openingJob) sessionJob = null
            }
        }

        // The attempt is live, but isActive() stays false until the server
        // confirms the session and signed URL pool.
        true
    }

    /**
     * M4 (2026-07-05) — SYMMETRIC, config-authoritative reconcile of the
     * dirty-driven cadence. Replaces the old asymmetric arm (partly
     * synchronous) / disarm (fully posted) pair whose true→false→true
     * ordering race left a dead engine (disarm's `setEnabled(false)`
     * clobbering arm's synchronous `setEnabled(true)`, then arm's posted
     * attach re-attaching listeners while `enabled=false`).
     *
     * The ENTIRE body is posted to [mainHandler] — arm AND disarm — so
     * concurrent config pushes serialize in FIFO push order on the main
     * looper. And the desired state is read at RUN TIME from the live
     * [config] (+ [isActive]) inside the posted block, so whichever push
     * ran LAST wins regardless of arm/disarm ordering:
     *   - desired ENABLED  → onDirty sink set, tracker enabled, listeners
     *     attached, FIRST-frame screen-entry mark, heartbeat started;
     *   - desired DISABLED → tracker disabled (which also detaches the
     *     ViewTreeObserver listeners), onDirty cleared, heartbeat stopped.
     * No path leaves `DirtyTracker.enabled` disagreeing with the live
     * config, and no listener/heartbeat leaks while disabled.
     *
     * Idempotent — the DirtyTracker + heartbeat both self-clear before
     * re-arming, and setEnabled(true/false) is safe to repeat.
     */
    private fun reconcileDirtyEngine() {
        mainHandler.post { reconcileDirtyEngineNow() }
    }

    /**
     * M4 — the reconcile body. MUST run on main. Drives the DirtyTracker
     * + heartbeat to match the CURRENT live [config.frameCaptureEnabled]
     * (re-read here, not captured at post time) while a session is active.
     * When replay is no longer active (stopped/opted-out) the desired
     * state is DISABLED regardless of the flag.
     */
    private fun reconcileDirtyEngineNow() {
        val desiredEnabled = dirtyEngineDesiredEnabled(
            active = isActive(),
            frameCaptureEnabled = config?.frameCaptureEnabled,
        )
        if (desiredEnabled) {
            // Install the sink BEFORE enabling (DirtyTracker contract),
            // then enable + attach + first-frame + heartbeat.
            DirtyTracker.onDirty = { source -> handleDirty(source) }
            DirtyTracker.setEnabled(true)
            attachDirtyToCurrentWindow()
            DirtyTracker.markDirty(DirtyTracker.Source.SCREEN_ENTRY)
            startHeartbeat()
        } else {
            // setEnabled(false) clears flags AND detaches the listeners.
            DirtyTracker.setEnabled(false)
            DirtyTracker.onDirty = null
            stopHeartbeat()
        }
    }

    /**
     * M4 — pure "final desired dirty-engine state" decision, extracted so
     * the reconcile contract is JVM-testable without the main looper. The
     * dirty engine is ENABLED iff replay is currently active AND the live
     * config's frame capture is on. A null flag (no live config) → false.
     * This is what makes the reconcile config-authoritative: whichever
     * config push ran last, the reconcile settles the engine to match its
     * flag. Kept at file/companion scope so a unit test can pin it.
     */
    internal fun dirtyEngineDesiredEnabled(active: Boolean, frameCaptureEnabled: Boolean?): Boolean =
        active && frameCaptureEnabled == true

    /**
     * AND-CAP-02 — dirty-engine teardown for [stop]: disable + detach the
     * DirtyTracker and stop the heartbeat.
     *
     * **MAIN THREAD ONLY.** `DirtyTracker.setEnabled(false)` → `detach()`
     * touches [android.view.ViewTreeObserver] (not thread-safe) and
     * `stopHeartbeat()` `removeCallbacks` on the main-posted runnable, so
     * this MUST run on main. [stop] is reached off main (QueueWiring on
     * Dispatchers.Default; optOut from any thread), so it POSTS this to
     * [mainHandler] rather than calling it inline; the LIVE
     * frameCaptureEnabled transitions in [applyRemoteReplayKnobs] use the
     * (also main-posted) [reconcileDirtyEngine].
     *
     * Idempotent + non-re-arming: it only disables + detaches + stops the
     * ticker, so a teardown that runs AFTER a concurrent restart's posted
     * reconcile cannot re-arm anything — and because both are posted to the
     * same looper, the LAST one enqueued wins (a restart's reconcile
     * re-reads the live [isActive]/config). A reconcile posted before stop
     * that runs after it re-checks [isActive] (false post-stop) → no-op.
     * Leaves the rest of the session (uploader, slot, sampler) intact.
     */
    private fun disarmDirtyEngine() {
        DirtyTracker.setEnabled(false)
        DirtyTracker.onDirty = null
        stopHeartbeat()
    }

    /**
     * Seal the in-flight session. Called by `Kixo.flush()` and on
     * `appBackgrounded`. Frames already on disk continue uploading
     * via Agent 14's WorkManager job — we just stop accepting new
     * captures.
     *
     * Idempotent.
     */
    fun stop() = stopInternal(discard = false, timeout = false)

    /** First half of foreground transition; keeps capture closed until session rotation. */
    fun onProcessForegroundObserved(): Long = synchronized(lifecycleTransitionLock) {
        processForeground.set(false)
        processLifecycleGeneration.incrementAndGet()
    }

    /** Process background closes this stint and invalidates posted foreground resumes. */
    fun onProcessBackground() {
        synchronized(lifecycleTransitionLock) {
            processLifecycleGeneration.incrementAndGet()
            processForeground.set(false)
        }
        stopInternal(discard = false, timeout = false, retainStartForRestart = true)
    }

    /** Called after SessionTracker has finalized the foreground session identity. */
    fun resumeAfterProcessForeground(expectedGeneration: Long): Boolean {
        val accepted = synchronized(lifecycleTransitionLock) {
            if (processLifecycleGeneration.get() != expectedGeneration) {
                false
            } else {
                processForeground.set(true)
                true
            }
        }
        if (!accepted) return false
        return startPendingIfArmed()
    }

    private fun stopForDurationLimit() = stopInternal(discard = false, timeout = true)

    private fun scheduleMaxDuration() {
        maxDurationJob?.cancel()
        maxDurationJob = null
        val cfg = config ?: return
        val startedAt = replayStartedElapsedMs
        if (startedAt < 0L) return
        val elapsed = (SystemClock.elapsedRealtime() - startedAt).coerceAtLeast(0L)
        val remaining = cfg.maxDurationMs.coerceIn(10_000L, 3_600_000L) - elapsed
        if (remaining <= 0L) {
            scope.launch { stopForDurationLimit() }
            return
        }
        maxDurationJob = scope.launch {
            delay(remaining)
            stopForDurationLimit()
        }
    }

    private fun stopInternal(
        discard: Boolean,
        timeout: Boolean = false,
        remotePolicyDiscard: Boolean = false,
        retainStartForRestart: Boolean = false,
    ) {
        // Publish the close-in-flight latch in the same critical section as
        // the active -> stopped transition. A config refresh/reset can request
        // a restart from another dispatcher; it must never open a new lifecycle
        // while the old lifecycle's async close is still able to clear it.
        var openedThisStint = false
        val shouldStop = synchronized(lifecycleTransitionLock) {
            if (!started.compareAndSet(true, false)) false
            else {
                stopInFlight.set(true)
                if (retainStartForRestart) remoteRestartAllowed.set(true)
                sessionGeneration.incrementAndGet()
                openedThisStint = sessionOpened.getAndSet(false)
                thermalAllowed.set(false)
                true
            }
        }
        if (!shouldStop) {
            if (discard) {
                hardDiscardRequested.set(true)
                restartRequestedAfterStop.set(false)
                sessionGeneration.incrementAndGet()
                sessionJob?.cancel()
                ReplayResumeState.discard()
                nextSeq.set(0L)
            }
            if (retainStartForRestart) remoteRestartAllowed.set(true)
            return
        }
        if (discard) hardDiscardRequested.set(true)
        active.set(false)
        // A normal process-background/flush close must not cancel a start
        // request that the server may already have accepted. The lifecycle
        // close coroutine serializes behind openSession's mutex and seals the
        // acknowledged stint as soon as its response arrives. Privacy,
        // timeout, and remote-policy stops still cancel immediately.
        if (discard || timeout || remotePolicyDiscard) {
            sessionJob?.cancel()
        }
        maxDurationJob?.cancel()
        maxDurationJob = null
        replayStartedElapsedMs = -1L

        // AND-CAP-02 — tear down the dirty engine + heartbeat. This is
        // main-thread-only work: DirtyTracker.setEnabled(false) → detach()
        // touches ViewTreeObserver (NOT thread-safe) and stopHeartbeat()
        // races startHeartbeat() on the main-posted runnable. But stop() is
        // reached OFF main (QueueWiring.applyDataCollectionSideEffects runs
        // on Dispatchers.Default; optOut() is callable from any thread), so
        // POST the teardown to main (mirroring the reconcile path). The
        // synchronous state flip above (started/active = false) already
        // gated captures off immediately, so a teardown that runs slightly
        // later can't ship a frame. The post is idempotent — it only
        // detaches + disables; a concurrent restart re-arms through the
        // posted reconcile which re-reads the live state on the same looper.
        mainHandler.post { disarmDirtyEngine() }
        lastShippedSignature.set(null)
        lastRenderElapsedMs = 0L
        lastSuccessfulRenderElapsedMs = 0L

        // Capture references before nulling fields so the
        // session-end coroutine can still reach them. Otherwise the
        // launch below would race the field-null assignments at the
        // bottom and observe `uploader = null`.
        val capturedUploader = uploader
        val capturedOcr = ocrExtractor
        val capturedThermal = thermalBackoff

        // Drop the pre-tap frame buffer immediately — held bitmap
        // is ~10 MB.
        ringBuffer.take()?.recycle()

        try {
            capturedOcr?.shutdown()
        } catch (_: Throwable) { /* swallow */ }

        try {
            capturedThermal?.onStateChange = null
            capturedThermal?.stop()
        } catch (_: Throwable) { /* swallow */ }

        // Save the continued counter AND reset it in ONE atomic step
        // (F9) so a follow-up stint under the SAME analytics session
        // resumes instead of overwriting the frames this stint
        // already shipped (KIX-UNI-01 resume contract). A separate
        // read-then-reset would let a straggler Choreographer
        // callback mint a seq BETWEEN the two — saved watermark then
        // undercounts and the next stint collides.
        if (discard) ReplayResumeState.discard()
        else if (openedThisStint) ReplayResumeState.onStintEnd(nextSeq.getAndSet(0L))
        else nextSeq.set(0L)
        if (discard) nextSeq.set(0L)
        lastScreenIdentity = null
        lastScrollEndElapsedMs = 0L

        captureSlot = null
        thermalBackoff = null
        ocrExtractor = null
        structuralSnapshotter = null
        screenIdentity = null
        sampler = null
        sampledAnalyticsSessionId = null
        config = null
        // FIX 4 — drop the compiled baseline with the session; the next
        // start() re-stashes it. (pendingKnobs deliberately survives stop so
        // a deferred re-start inherits the latest /init knobs.)
        baseConfig = null
        uploader = null

        // Tell Agent 14 to seal/discard only after every synchronous field
        // from the old stint has been cleared. A fast test double (or an empty
        // lifecycle) may complete immediately; releasing the restart barrier
        // before these assignments would let the old stop null out the newly
        // opened stint.
        if (capturedUploader != null) {
            val launchMode = if (explicitOptOutSealRequested.get() &&
                !identityDiscardRequested.get()
            ) {
                CoroutineStart.UNDISPATCHED
            } else {
                CoroutineStart.DEFAULT
            }
            scope.launch(start = launchMode) {
                try {
                    if (identityDiscardRequested.get() || remotePolicyDiscard) {
                        capturedUploader.discardSession()
                    }
                    else if (explicitOptOutSealRequested.get()) {
                        capturedUploader.endSessionForOptOut()
                    }
                    else if (discard || hardDiscardRequested.get()) capturedUploader.discardSession()
                    else if (timeout) capturedUploader.endSessionForTimeout()
                    else capturedUploader.endSession()
                } catch (t: Throwable) {
                    Log.w(TAG, "uploader session close failed", t)
                } finally {
                    // A normal close may have saved seq/totals synchronously
                    // just before a concurrent optOut/reset arrived. Re-wipe
                    // after its async lifecycle close so no late callback can
                    // resurrect cross-identity resume state.
                    if (hardDiscardRequested.get()) ReplayResumeState.discard()
                    completeStopTransition()
                }
            }
        } else {
            if (hardDiscardRequested.get()) ReplayResumeState.discard()
            completeStopTransition()
        }
    }

    /** Release the close barrier and service exactly one coalesced restart. */
    private fun completeStopTransition() {
        val shouldRestart = synchronized(lifecycleTransitionLock) {
            stopInFlight.set(false)
            restartRequestedAfterStop.getAndSet(false) && !optedOut.get()
        }
        if (shouldRestart) startPendingIfArmed()
    }

    /** Customer kill switch. Subsequent [start] calls are no-ops until [optIn]. */
    fun optOut() = synchronized(lifecycleTransitionLock) {
        hardDiscardRequested.set(true)
        explicitOptOutSealRequested.set(true)
        if (started.get()) remoteRestartAllowed.set(true)
        optedOut.set(true)
        sampler?.reset()
        stopInternal(discard = true)
    }

    /**
     * Identity reset boundary. Raw artifacts are purged like opt-out, but no
     * cleanup request may carry the retired installation/user identity.
     */
    fun discardForIdentityBoundary() = synchronized(lifecycleTransitionLock) {
        identityDiscardRequested.set(true)
        explicitOptOutSealRequested.set(false)
        hardDiscardRequested.set(true)
        restartRequestedAfterStop.set(false)
        if (started.get()) remoteRestartAllowed.set(true)
        optedOut.set(true)
        sampler?.reset()
        stopInternal(discard = true)
    }

    /**
     * A server disable/tightening is an artifact boundary, not an ordinary
     * background flush: purge staged/event/WorkManager work captured under
     * the superseded grant. The retained start and resume watermark survive
     * so a later fresh permissive policy can open a clean stint.
     */
    fun stopForRemotePolicy() {
        if (started.get()) remoteRestartAllowed.set(true)
        stopInternal(discard = false, remotePolicyDiscard = true)
    }

    /** Re-enable replay after a previous [optOut]. NEXT [start] call wires up. */
    fun optIn() = synchronized(lifecycleTransitionLock) {
        optedOut.set(false)
        // Cleared here only after the hard boundary has synchronously wiped
        // resume state. Any old async close also checks the current privacy
        // latch before it can write a final watermark.
        if (!stopInFlight.get()) {
            hardDiscardRequested.set(false)
            explicitOptOutSealRequested.set(false)
            identityDiscardRequested.set(false)
        }
    }

    /**
     * An explicit collection boundary (identity reset or privacy recovery)
     * must be able to reuse the process-wired start thunk even when the prior
     * replay stint had already ended normally. Ordinary config refreshes do
     * not call this: they must not turn max-duration/session seals into an
     * endless restart loop.
     */
    fun rearmRetainedStartForCollectionBoundary(): Boolean =
        synchronized(lifecycleTransitionLock) {
            synchronized(pendingLock) {
                when {
                    pendingStart != null -> true
                    retainedStart != null -> {
                        remoteRestartAllowed.set(true)
                        true
                    }
                    else -> false
                }
            }
        }

    /** Compact internal state for debug-only collection-boundary diagnostics. */
    fun boundaryDebugState(): String = synchronized(lifecycleTransitionLock) {
        synchronized(pendingLock) {
            "started=${started.get()},opened=${sessionOpened.get()}," +
                "foreground=${processForeground.get()},opted_out=${optedOut.get()}," +
                "stop_in_flight=${stopInFlight.get()}," +
                "restart_requested=${restartRequestedAfterStop.get()}," +
                "remote_restart=${remoteRestartAllowed.get()}," +
                "pending=${pendingStart != null},retained=${retainedStart != null}"
        }
    }

    /**
     * S3 (KIX-UNI-22 cross-SDK parity): retain a server-resolved sample
     * rate for this and subsequent [start] / session-open calls. Called
     * from [io.kixo.sdk.internal.queue.QueueWiring.applyDataCollectionSideEffects]
     * when the control-plane `data_collection.replay.sampleRate` resolves.
     *
     * [fractionalRate] is a 0-1 fraction (the caller converts the wire's
     * 0-100 percent). Clamped defensively. A live session is re-evaluated
     * against the same deterministic bucket immediately: if a Dashboard
     * reduction moves it out, capture is synchronously gated off and the
     * stint is sealed. A sampled-out retained start can likewise move in on
     * a later increase without an app relaunch.
     */
    fun updateSampleRate(fractionalRate: Double) {
        val clampedRate = fractionalRate.coerceIn(0.0, 1.0)
        var stopLiveSession = false
        synchronized(lifecycleTransitionLock) {
            serverSampleRateOverride = clampedRate
            if (started.get()) {
                val liveSampler = sampler
                val sessionId = sampledAnalyticsSessionId
                stopLiveSession = liveSampler == null ||
                    !liveSampler.sessionDeterministicVerdict(sessionId, clampedRate)
            } else {
                // A previously sampled-out start retains its wiring. A later
                // project rate change must be able to re-evaluate the deterministic
                // bucket without an app relaunch (retainedStart owns the wiring).
                synchronized(pendingLock) {
                    if (retainedStart != null && pendingStart == null) {
                        remoteRestartAllowed.set(true)
                    }
                }
            }
        }
        if (stopLiveSession) stopForRemotePolicy()
    }

    /**
     * AND-CAP-04 — apply the server-resolved perf knobs to the LIVE
     * [ReplayConfig]. Unlike sample rate (which is applied on the NEXT
     * session-open so an already-rolled verdict isn't invalidated), these
     * cadence/compression/gate knobs are read live
     * by the capture path, so they take effect immediately. Also
     * stashed into [pendingConfigOverride] so a session that starts
     * AFTER this call (deferred start) inherits them. Each argument is
     * null when the server didn't send that field → keep the current
     * value. All values are pre-clamped by [DirtyCadenceClamp].
     *
     * Called from
     * [io.kixo.sdk.internal.queue.QueueWiring.applyDataCollectionSideEffects].
     */
    fun applyRemoteReplayKnobs(knobs: ReplayKnobs) {
        // FIX 4 (2026-07-05) — each /init payload is AUTHORITATIVE. Stash
        // the LATEST payload (NOT an accumulation of prior payloads): a knob
        // omitted from this payload must revert to the compiled default, so
        // we must NOT carry forward a value some earlier payload set. A
        // deferred session picks this up in [start] via `applyTo(config)`
        // (baseline = compiled default); a live session applies it against
        // [baseConfig] below.
        pendingKnobs = knobs

        // Live config (if a session is running) — apply immediately and,
        // on a frameCaptureEnabled TRANSITION, reconcile the dirty engine
        // (FIX 3). The only OTHER arming site is the start gate, so a live
        // false→true flip would otherwise never arm (zero frames for a
        // session that started with capture off), and a live true→false
        // flip would leave the heartbeat + dirty listeners running.
        //
        // M4 (2026-07-05) — BOTH directions now go through the SAME posted,
        // config-authoritative [reconcileDirtyEngine]: no synchronous
        // setEnabled here, so a rapid true→false→true (two config pushes)
        // can't leave the engine dead via arm/disarm ordering. Whichever
        // push wrote `config` last is the state the reconcile — which
        // re-reads the live config on the main looper — settles to. We set
        // `config` (a @Volatile write) synchronously here so the LAST push
        // to run also holds the LAST config value the posted reconcile
        // reads; the reconciles serialize behind it in FIFO push order.
        //
        // FIX 4 — resolve the new config from the COMPILED BASELINE, not the
        // already-overridden live config, so a knob this payload OMITS
        // reverts to its default (e.g. operator set captureScale=0.5 in
        // init #1, then removed it in init #2 → we revert to the compiled
        // default, not keep 0.5). Falls back to the live config as the
        // baseline only if `baseConfig` is somehow unset (defensive).
        config?.let { live ->
            val wasEnabled = live.frameCaptureEnabled
            val newConfig = knobs.applyTo(baseConfig ?: live)
            config = newConfig
            if (live.maxDurationMs != newConfig.maxDurationMs) {
                // Preserve elapsed wall time: lowering 300s→60s at t=70s
                // ends immediately, rather than granting a fresh 60s.
                scheduleMaxDuration()
            }
            val nowEnabled = newConfig.frameCaptureEnabled
            if (live.maxConcurrentCaptures != newConfig.maxConcurrentCaptures) {
                captureSlot?.updateBaseline(newConfig.maxConcurrentCaptures)
            }
            if (wasEnabled != nowEnabled) {
                reconcileDirtyEngine()
            }
        }

        // If the heartbeat interval changed on a live + capturing stint,
        // re-arm the ticker at the new cadence. Skip when capture is off
        // (the reconcile above owns the armed/disarmed state). Re-reads the
        // live config inside the posted block so a concurrent capture-off
        // push wins.
        if (knobs.dirtyHeartbeatMs != null && isActive() &&
            config?.frameCaptureEnabled == true
        ) {
            mainHandler.post {
                if (isActive() && config?.frameCaptureEnabled == true) startHeartbeat()
            }
        }
    }

    /**
     * AND-CAP-04 — accumulated perf-knob override consumed by [start]
     * so a deferred session inherits knobs pushed via
     * [applyRemoteReplayKnobs] before it started. All-null = no override.
     */
    @Volatile
    private var pendingKnobs: ReplayKnobs = ReplayKnobs()

    /**
     * P1 (Codex, 2026-07-03) — arm the deferred start (see [pendingStart]).
     * Called from `Kixo.configure(...)` whenever replay dependencies exist.
     * Does NOT start
     * recording; [startPendingIfArmed] fires the thunk once the server
     * policy resolves. Overwrites any previously-armed thunk (configure
     * runs once per process, so this is belt-and-braces).
     */
    fun armPendingStart(start: () -> Boolean) {
        synchronized(pendingLock) {
            pendingStart = start
            retainedStart = start
        }
        // `/init` + the immediate `/config` fetch run asynchronously from
        // QueueWiring.build and can legitimately resolve before Kixo finishes
        // constructing this replay thunk. Close that ordering window here:
        // startPendingIfArmed re-checks the exact server policy and privacy
        // latch, so this is safe and still fail-closed pre-config. Sparse
        // wire contract (2026-07): a PRESENT replay block with an omitted
        // sampleRate means 100%; an absent block stays fail-closed.
        val dc = io.kixo.sdk.internal.queue.DataCollectionHolder.snapshot()
        val replay = dc?.replay
        if (dc?.paused != true && replay != null && replay.enabled == true &&
            replay.effectiveSampleRateFraction() > 0.0
        ) {
            startPendingIfArmed()
        }
    }

    /**
     * P1 (Codex, 2026-07-03) — consume + fire the armed start exactly
     * once. Called from [io.kixo.sdk.internal.queue.QueueWiring]'s
     * control-plane success path AFTER it has confirmed the resolved
     * server policy is `replay.enabled == true` (+ release_id stamped +
     * server sampleRate threaded in). Returns the thunk's `start()`
     * verdict (whether a server-open attempt was launched — the sampler may
     * still roll the session out), or `false` when nothing was armed / already
     * consumed. The latch is cleared under [pendingLock] before the thunk runs
     * so a re-entrant call can't double-start.
     */
    fun startPendingIfArmed(): Boolean {
        // Do not consume the retained start thunk while a local replay veto (or
        // replay-opt-in awaiting fresh policy) owns the controller latch. The
        // generation-current control-plane response will call optIn() first and
        // can then consume the exact same thunk.
        if (optedOut.get() || !processForeground.get()) return false
        // Defence in depth for every restart caller, including an async
        // stop-completion callback. QueueWiring persists the effective
        // top-level init pause in DataCollectionHolder, so a reset/opt-in
        // racing a remote stop cannot re-open replay behind the kill switch.
        // Sparse wire contract (2026-07): an absent replay block fails
        // closed; a present block with an omitted sampleRate means 100%,
        // and only an explicit rate <= 0 keeps the arm unconsumed.
        val dataCollection = io.kixo.sdk.internal.queue.DataCollectionHolder.snapshot()
        val replayPolicy = dataCollection?.replay
        if (dataCollection?.paused == true ||
            replayPolicy == null ||
            replayPolicy.enabled != true ||
            replayPolicy.effectiveSampleRateFraction() <= 0.0
        ) {
            return false
        }
        val thunk = synchronized(lifecycleTransitionLock) {
            if (optedOut.get() || !processForeground.get()) {
                null
            } else if (stopInFlight.get()) {
                restartRequestedAfterStop.set(true)
                null
            } else {
                synchronized(pendingLock) {
                    pendingStart?.also {
                        pendingStart = null
                        remoteRestartAllowed.set(false)
                    }
                        ?: if (remoteRestartAllowed.compareAndSet(true, false)) retainedStart else null
                }
            }
        } ?: return false
        val launched = thunk()
        if (!launched) {
            // Background can win after the arm is selected but before the
            // retained start thunk enters start(). Sampling can also reject a
            // session until a later server rate update. Preserve one restart
            // permission instead of silently consuming process wiring.
            synchronized(lifecycleTransitionLock) {
                synchronized(pendingLock) {
                    if (retainedStart != null) remoteRestartAllowed.set(true)
                }
            }
        }
        return launched
    }

    /**
     * P1 (Codex, 2026-07-03) — drop the armed start WITHOUT firing it.
     * Called when the resolved server policy says replay is off
     * (`replay.enabled == false` / paused / rate ≤ 0), so a later refresh
     * can't fire a stale arm. Mirrors iOS clearing `replayBootstrapPending`
     * on the config-disable arm (Kixo.swift:2069).
     */
    fun discardPendingStart() {
        synchronized(pendingLock) {
            pendingStart = null
            retainedStart = null
            remoteRestartAllowed.set(false)
        }
    }

    /** Whether replay is currently capturing. False while opening or paused. */
    fun isActive(): Boolean = started.get() && active.get() && !optedOut.get()

    /**
     * Called by Agent 8's touch tracker once a gesture has been
     * fully classified. The supplied `view` is the View that hit-
     * tested under the tap; `null` when the tap landed on system
     * chrome with no Activity-owned target.
     *
     * AND-CAP-01/02 pipeline (dirty-driven redesign):
     *
     *  1. `isActive()` + gate checks
     *  2. Mark the screen dirty (INTERACTION lane, flag-only — the tap
     *     pipeline schedules its OWN settle capture below so we don't
     *     double-dispatch).
     *  3. Pre-frame = the carry-forward ring-buffer frame (the last
     *     shipped PixelCopy frame).
     *  4. Async PixelCopy of the current window (off-UI-thread, GPU-
     *     backed, masked from the view-tree pass); Canvas fallback on
     *     failure. The captured_at_post stamp is the REAL callback
     *     wall-clock time.
     *  5. Structural (if enabled) + OCR (if enabled) off-main.
     *  6. Hand assets to Agent 14's uploader.
     */
    fun handleTap(meta: InteractionMeta, view: View?) {
        val cfg = config ?: return
        val slot = captureSlot ?: return
        val uploader = uploader ?: return

        // Coverage fix (May 2026): honour
        // `data_collection.replay.enabled == false` AT EMIT TIME so
        // an operator can disable frame capture without re-installing.
        // Missing/malformed policy fails closed; replay is server-authorised.
        // Sparse wire contract (2026-07): a PRESENT replay block with an
        // omitted sampleRate means 100% — only an explicit rate <= 0
        // hard-disables here; an ABSENT block still fails closed above.
        val dc = io.kixo.sdk.internal.queue.DataCollectionHolder.snapshot()
        val replayCfg = dc?.replay
        if (dc?.paused == true || replayCfg == null || replayCfg.enabled != true) return
        if (replayCfg.effectiveSampleRateFraction() <= 0.0) return

        if (!isActive()) return
        if (!cfg.frameCaptureEnabled) return

        // Keep the heartbeat honest — a tap changed the screen even if
        // the settle below drops. Flag-only (no dispatch): the tap
        // owns its settle capture.
        DirtyTracker.markDirty(DirtyTracker.Source.INTERACTION)

        if (!slot.tryAcquire()) return

        // Resolve the window to capture. Prefer the hit-test View's
        // window (most specific); fall back to the foregrounded window.
        val window = view?.let { runCatching { resolveWindow(it) }.getOrNull() }
            ?: windowProvider()
        if (window == null) {
            slot.release()
            return
        }

        val gestureTimeMs = System.currentTimeMillis()
        // Carry-forward pre-frame semantic (matches iOS `preFrame: nil`):
        // the player uses the PREVIOUS gesture's post-frame path as this
        // gesture's "before" state, so we do NOT re-upload a pre-frame.
        // The ring buffer only feeds on-device continuity.
        captureAndDispatch(
            cfg = cfg,
            slot = slot,
            uploader = uploader,
            window = window,
            captureView = window.decorView,
            meta = meta,
            tapKindOverride = null,
            capturedAtPreMs = gestureTimeMs,
            preFrame = null,
            forceEvenIfUnchanged = true,
        )
    }

    /**
     * AND-CAP-05 — screen-entry lane. Called by Agent 9's screen
     * tracker on every recorded screen visit. Marks the SCREEN_ENTRY
     * lane so a `screen_change` frame of the NEW screen exists before
     * the user's first tap on it (bypasses the generic debounce; see
     * [handleDirty]). Cheap when replay is off (one volatile read).
     */
    fun handleScreenEntry() {
        if (!isActive()) return
        if (config?.frameCaptureEnabled != true) return
        // Re-attach the dirty listeners to the (possibly new) window,
        // then mark the screen-entry lane. Main-thread callers only
        // (screen tracker runs on main).
        attachDirtyToCurrentWindow()
        DirtyTracker.markDirty(DirtyTracker.Source.SCREEN_ENTRY)
    }

    /**
     * AND-CAP-02 — [DirtyTracker.onDirty] sink. Runs on main. Schedules
     * a settle capture ~[ReplayConfig.postTapSettleMs] after the dirty
     * signal so the screen finishes its transition before we render.
     */
    private fun handleDirty(source: DirtyTracker.Source) {
        val lane = source.lane ?: return
        scheduleDirtySettle(lane, retriesLeft = 6)
    }

    private fun scheduleDirtySettle(lane: DirtyTracker.Lane, retriesLeft: Int) {
        val settleMs = config?.postTapSettleMs ?: 500L
        // First-frame guarantee: a screen-entry settle while nothing
        // has rendered yet uses a SHORT delay so a fast first tap lands
        // on an existing frame.
        val delay = if (lane == DirtyTracker.Lane.SCREEN_ENTRY && lastRenderElapsedMs == 0L) {
            minOf(150L, settleMs)
        } else {
            settleMs
        }
        mainHandler.postDelayed({ dirtySettleFired(lane, retriesLeft) }, delay)
    }

    private fun dirtySettleFired(lane: DirtyTracker.Lane, retriesLeft: Int) {
        val cfg = config
        if (!isActive() || cfg == null || !cfg.frameCaptureEnabled) {
            DirtyTracker.clearPending(lane)
            return
        }
        val slot = captureSlot ?: run { DirtyTracker.clearPending(lane); return }
        val uploader = uploader ?: run { DirtyTracker.clearPending(lane); return }
        val window = windowProvider() ?: run { DirtyTracker.clearPending(lane); return }

        // AND-CAP-02 pixel-churn bypass: read the DRAW-sourced flag
        // BEFORE any consumeDirty() clears it (see M3 below — the consume
        // is now deferred to the commit point). When set, pixels changed
        // even if the structural signature didn't (video / in-place
        // bitmap), so this capture must not be dedup-skipped downstream.
        val drawSourced = DirtyTracker.wasDrawSourced()

        // Release the lane FIRST so marks during/after the capture can
        // dispatch a fresh attempt.
        //
        // M3 (2026-07-05) — do NOT consumeDirty() here. Consuming before
        // we know we'll actually capture swallows the dirty state on a
        // throttle-with-retries-exhausted path (reachable with a remote
        // captureMinIntervalMs > ~3s): no capture, dirty=false, and the
        // heartbeat can't rescue it (it's gated on isDirty) → a real
        // content change ships no frame (freeze). We consume ONLY once we
        // commit to a capture (past the floor + slot acquired) below.
        DirtyTracker.clearPending(lane)

        // Cadence floor — throttle if a capture was ATTEMPTED too recently
        // (M3: keyed on attempt, not success); re-arm so a later settle/
        // heartbeat ships the change. This is what bounds a DRAW-bypass
        // video screen to ≤ 1 frame per floor. Dirty is still set here (we
        // deferred the consume), so on retry-exhaustion the change stays
        // dirty for the heartbeat to rescue.
        val nowElapsed = SystemClock.elapsedRealtime()
        if (DirtyTrigger.shouldThrottleCapture(
                nowElapsedMs = nowElapsed,
                lastAttemptElapsedMs = lastRenderElapsedMs,
                floorMs = cfg.captureMinIntervalMs,
            )
        ) {
            if (retriesLeft > 0 && DirtyTracker.rearmAfterThrottle(lane)) {
                scheduleDirtySettle(lane, retriesLeft - 1)
            }
            // retries exhausted → leave dirty set (NOT consumed) so the
            // heartbeat rescues the unshipped change.
            return
        }

        if (!slot.tryAcquire()) {
            // Slot full — leave the screen dirty (still not consumed) so
            // the heartbeat retries once the pipeline drains.
            DirtyTracker.markDirty(DirtyTracker.Source.INTERACTION)
            return
        }

        // COMMITTED to a capture: consume the dirty state now (changes
        // DURING the capture re-mark). The floor timestamp is advanced on
        // ATTEMPT inside captureAndDispatch (M3), covering every capture
        // path uniformly (gesture / dirty / heartbeat).
        DirtyTracker.consumeDirty()

        val trigger = if (lane == DirtyTracker.Lane.SCREEN_ENTRY) "screen_change" else "dirty"
        val nowMs = System.currentTimeMillis()
        // A dirty/screen capture has no gesture — synthesize a
        // sentinel SCROLL_END-style meta (player ignores its coords)
        // and override tap_kind to the trigger string.
        val syntheticMeta = InteractionMeta(
            tapKind = InteractionMeta.Kind.SCROLL_END,
            tapXNorm = 0f,
            tapYNorm = 0f,
            gestureDurationMs = 0L,
            touchCount = 1,
        )
        captureAndDispatch(
            cfg = cfg,
            slot = slot,
            uploader = uploader,
            window = window,
            captureView = window.decorView,
            meta = syntheticMeta,
            tapKindOverride = trigger,
            capturedAtPreMs = nowMs,
            preFrame = null,
            forceEvenIfUnchanged = false,
            bypassDedup = drawSourced,
        )
    }

    /**
     * AND-CAP-01 shared capture body — async PixelCopy (default) with
     * a synchronous Canvas fallback, masking composited from the view-
     * tree pass, and the real callback wall-clock as captured_at_post.
     *
     * @param captureView the decor view whose tree we read for masking
     *   rects + structural JSON + the Canvas fallback. Always the
     *   window's decor view (PixelCopy grabs the WHOLE window, so
     *   masking must consider the whole tree, not the hit-test view).
     * @param tapKindOverride non-null for non-gesture triggers
     *   (screen_change / dirty / heartbeat).
     * @param preFrame carry-forward "before" frame (gesture path only;
     *   NOT owned here — the ring buffer owns it).
     * @param forceEvenIfUnchanged gesture captures always ship (the
     *   gesture must land on the timeline); dirty/heartbeat captures
     *   skip when the structural signature is unchanged.
     * @param bypassDedup AND-CAP-02 pixel-churn bypass: `true` when the
     *   dirty that drove this capture was DRAW-sourced (`onDraw` fired ⇒
     *   pixels demonstrably changed). The structural signature is blind
     *   to pixels, so on a video / in-place `setImageBitmap` the
     *   signature is identical while the frame differs — we must NOT
     *   dedup-skip. Bounded by the cadence floor upstream so a
     *   constantly-animating screen yields ≤ 1 frame per floor interval.
     *   A LAYOUT / settle / screen-entry source passes `false`, so a
     *   true structural no-op can still be skipped.
     */
    private fun captureAndDispatch(
        cfg: ReplayConfig,
        slot: CaptureSlot,
        uploader: ReplayUploaderRef,
        window: Window,
        captureView: View,
        meta: InteractionMeta,
        tapKindOverride: String?,
        capturedAtPreMs: Long,
        preFrame: Bitmap?,
        forceEvenIfUnchanged: Boolean,
        bypassDedup: Boolean = false,
    ) {
        // Structural pass on main — used BOTH for the redaction rects
        // (masking, always) and the shipped JSON sidecar (only when
        // structuralSnapshotEnabled). Also yields the skip-unchanged
        // signature. Read on main; the rest is off-main.
        //
        // PRIVACY (AND-CAP-01): redaction rects are the ONLY masking
        // source under PixelCopy (raw window pixels, no per-view redact)
        // AND under the Canvas fallback (`View.draw()` does NOT redact).
        // So "we cannot determine what to mask" MUST drop the frame — it
        // must never degrade to "ship with no masking". Three uncertain
        // cases collapse to a null sentinel here:
        //   1. no snapshotter wired (structuralSnapshotter == null) — the
        //      old `?: emptyList()` shipped a ZERO-mask frame here;
        //   2. the walk threw;
        //   3. the walk could not be completed (returned its un-maskable
        //      sentinel — pathological tree past the defensive ceiling).
        val redactionRects: List<android.graphics.Rect>? = try {
            val snapshotter = structuralSnapshotter
            if (snapshotter == null) {
                Log.w(TAG, "no structural snapshotter — dropping frame (cannot mask)")
                null
            } else {
                // null here = redaction-walk-truncated sentinel (incomplete).
                snapshotter.collectRedactionRects(captureView)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "collectRedactionRects failed — dropping frame (over-mask)", t)
            null // null = "couldn't resolve what to mask" → DROP the frame
        }

        // Over-mask by dropping — never ship a possibly-unmasked frame.
        // Release the slot before minting a seq or doing any further work.
        if (redactionRects == null) {
            slot.release()
            return
        }

        // Skip-unchanged (AND-CAP-02): compute a cheap structural
        // signature (build_hash over the depth+class skeleton, no text /
        // cursor state) INDEPENDENTLY of whether we ship the JSON — so
        // dedup works even with structuralSnapshotEnabled=false (the new
        // default). Static screen ⇒ identical signature ⇒ dirty/heartbeat
        // captures skip. Gesture captures always ship.
        val signature: String? = try {
            structuralSnapshotter?.structuralSignature(captureView)
        } catch (t: Throwable) {
            Log.w(TAG, "structuralSignature failed", t)
            null
        }
        // Skip-unchanged verdict. A dirty/heartbeat capture with an
        // UNCHANGED structural signature is normally a no-op we drop.
        // EXCEPT when [bypassDedup] — the dirty was DRAW-sourced, so
        // pixels changed even though the structure/bounds/text signature
        // did not (video playing, in-place bitmap swap). The cadence
        // floor upstream already bounded how often we get here, so we
        // ship. Gesture captures ([forceEvenIfUnchanged]) always ship.
        if (!forceEvenIfUnchanged && !bypassDedup &&
            signature != null && signature == lastShippedSignature.get()
        ) {
            slot.release()
            return
        }

        // Ship the full structural JSON sidecar only when enabled.
        val structuralDoc: JsonObject? = if (cfg.structuralSnapshotEnabled) {
            try {
                structuralSnapshotter?.snapshot(captureView)
            } catch (t: Throwable) {
                Log.w(TAG, "structuralSnapshotter.snapshot failed", t)
                null
            }
        } else {
            null
        }

        // Mint the seq + pin the screen identity NOW so a straggler
        // can't collide after a stop().
        if (!isActive()) { slot.release(); return }
        val seq = nextSeq.getAndIncrement()
        val identity = screenIdentity?.currentScreenIdentity()
        lastScreenIdentity = identity

        // M3 (2026-07-05) — advance the cadence FLOOR on capture ATTEMPT
        // (we've committed: slot held, seq minted, snapshot about to be
        // requested), NOT only on a successful frame. This is the single
        // uniform floor-advance point for every capture path (gesture /
        // dirty / heartbeat), so a screen whose PixelCopy + Canvas keep
        // FAILING is still throttled to ≤ 1 attempt per captureMinIntervalMs
        // instead of storming at the settle cadence. Not reached on the
        // redaction-drop / dedup-skip early-returns above (those are clean
        // no-ops that release the slot without requesting a snapshot).
        noteCaptureAttempt()

        val onCaptured: (Bitmap?, Boolean) -> Unit = onCaptured@{ postFrame, viaCanvas ->
            // Runs on the PixelCopy callback thread OR (Canvas path)
            // the caller thread. Re-check the gate.
            if (!isActive()) {
                slot.release()
                recycleQuiet(postFrame)
                return@onCaptured
            }
            val capturedAtPostMs = System.currentTimeMillis()
            if (postFrame != null) {
                noteRenderPerformed()
                if (signature != null) lastShippedSignature.set(signature)
            }
            // Release the slot as soon as the frame is in hand — the
            // next capture can proceed while OCR+upload run. The
            // postFrame is handed to the uploader below which owns its
            // lifecycle (encode + recycle); the carry-forward "before"
            // frame is a PLAYER-side concern (previous post-frame path),
            // so we do NOT stash it on-device (matches iOS `preFrame:
            // nil`). The RingBuffer stays for the memory-warning drop
            // path only.
            slot.release()

            // PixelCopy already rendered at project captureScale. Canvas
            // fallback is full-size, so apply that SAME project scale once
            // during encode instead of the old hard-coded 0.4.
            val encodeDownscale = captureEncodeDownscale(viaCanvas, cfg.captureScale)
            scope.launch {
                handleCaptureAsync(
                    seq = seq,
                    meta = meta,
                    identity = identity,
                    preFrame = preFrame,
                    postFrame = postFrame,
                    structural = structuralDoc,
                    tapKindOverride = tapKindOverride,
                    capturedAtPreMs = capturedAtPreMs,
                    capturedAtPostMs = capturedAtPostMs,
                    jpegQuality = cfg.jpegQuality,
                    encodeDownscale = encodeDownscale,
                    uploader = uploader,
                )
            }
        }

        // AND-CAP-01 — default path is PixelCopy (rects are guaranteed
        // non-null here; the walk-threw case dropped above). PixelCopy
        // masks via these rects; on a non-SUCCESS status / throw we fall
        // back to Canvas, which composites the SAME rects (View.draw does
        // NOT redact on its own).
        FrameSnapshotter.snapshotViaPixelCopy(
            window = window,
            captureScale = cfg.captureScale,
            redactionRects = redactionRects,
        ) { bitmap ->
            if (bitmap != null) {
                onCaptured(bitmap, /* viaCanvas = */ false)
            } else {
                // PixelCopy returned a non-SUCCESS status / threw
                // (routine on real devices: secure window, surface not
                // ready, transient ERROR_*). Canvas fallback on main —
                // `View.draw()` does NOT redact, so we hand it the SAME
                // rects to composite (at scale 1.0; the Canvas bitmap is
                // full window size). A composite failure inside
                // snapshotViaCanvas returns null → frame dropped.
                mainHandler.post {
                    val canvasBmp = runCatching {
                        FrameSnapshotter.snapshotViaCanvas(captureView, redactionRects)
                    }.getOrNull()
                    onCaptured(canvasBmp, /* viaCanvas = */ true)
                }
            }
        }
    }

    /**
     * M3 (2026-07-05) — advance the cadence FLOOR timestamp on capture
     * ATTEMPT (slot acquired + snapshot about to be requested), NOT only
     * on a successful frame. The floor guard keys on [lastRenderElapsedMs];
     * before this fix it advanced ONLY in [noteRenderPerformed] (called
     * when `postFrame != null`), so a screen whose captures keep FAILING
     * (PixelCopy non-SUCCESS + Canvas null/OOM/throw) left the floor stuck
     * at its last-success value → unbounded ~settleMs full captures, each
     * running two main-thread tree walks. Keying the floor on attempt caps
     * a persistently-failing screen to ≤ 1 attempt per floor interval.
     *
     * MUST be called on main (the capture-dispatch thread), right after
     * the slot is acquired and before the snapshot request. Thread-safe
     * (volatile).
     */
    private fun noteCaptureAttempt() {
        lastRenderElapsedMs = SystemClock.elapsedRealtime()
    }

    /**
     * Record a SUCCESSFUL render. Kept separate from the floor timestamp
     * (which now advances on attempt via [noteCaptureAttempt]) so any
     * consumer that needs "when did we last actually ship a frame" reads
     * a truthful value. Currently informational — the floor no longer
     * keys on this. Thread-safe (volatile).
     */
    private fun noteRenderPerformed() {
        lastSuccessfulRenderElapsedMs = SystemClock.elapsedRealtime()
    }

    /**
     * AND-CAP-02 dirty heartbeat. A repeating main-handler tick that,
     * while a stint is foregrounded and the screen is dirty-but-
     * settled, forces a capture at [ReplayConfig.dirtyHeartbeatMs]
     * cadence. On a static screen it does nothing (dirty flag clear).
     */
    private fun startHeartbeat() {
        stopHeartbeat()
        val cfg = config ?: return
        val interval = cfg.dirtyHeartbeatMs.coerceAtLeast(1_000L)
        val runnable = object : Runnable {
            override fun run() {
                heartbeatFired(interval)
                if (isActive()) mainHandler.postDelayed(this, interval)
            }
        }
        heartbeatRunnable = runnable
        mainHandler.postDelayed(runnable, interval)
    }

    private fun stopHeartbeat() {
        heartbeatRunnable?.let { mainHandler.removeCallbacks(it) }
        heartbeatRunnable = null
    }

    private fun heartbeatFired(intervalMs: Long) {
        if (!isActive()) return
        // FIX 3 (remote control) — honour a LIVE `frameCaptureEnabled →
        // false` flip (via applyRemoteReplayKnobs). Without this guard
        // the heartbeat keeps shipping frames after every other capture
        // path has stopped, because it never re-reads the flag. Mirror
        // the guard in dirtySettleFired.
        if (config?.frameCaptureEnabled != true) return
        val cfg = config ?: return
        val slot = captureSlot ?: return
        val uploader = uploader ?: return
        val window = windowProvider() ?: return

        // FIX 3 (2026-07-05) — PLACEHOLDER MODEL. The M2 surface-heartbeat
        // (fire when a visible surface is present even if not dirty, to
        // "advance video") is REMOVED. Rationale: surfaces are MASKED by
        // the redaction walk (privacy-safe default for B2B — camera / video
        // / GL / map hidden), so a masked surface region never changes;
        // firing the heartbeat on surface presence captured an IDENTICAL
        // masked placeholder every tick for zero visual gain. A pure
        // full-screen-surface screen now shows a STATIC masked placeholder
        // (matches the iOS video-placeholder model). Any NON-surface UI
        // change (player chrome, comment overlay, progress bar — regular
        // views) still fires OnDrawListener/layout → dirty → capture, so the
        // replay advances normally. The heartbeat is therefore purely the
        // dirty-driven backstop again.
        if (!DirtyTracker.isDirty()) return

        // Heartbeat gate (dirty-driven lane): rate-limit the structurally-
        // dirty path against the interval.
        val sinceLastRender = SystemClock.elapsedRealtime() - lastRenderElapsedMs
        if (!DirtyTrigger.heartbeatShouldFire(isDirty = true, msSinceLastGateEval = sinceLastRender, intervalMs = intervalMs)) {
            return
        }

        // Cadence floor — bounds the dirty tick to ≤ 1 capture per
        // captureMinIntervalMs so a rapidly-dirtying screen can't storm.
        val nowElapsed = SystemClock.elapsedRealtime()
        if (DirtyTrigger.shouldThrottleCapture(
                nowElapsedMs = nowElapsed,
                lastAttemptElapsedMs = lastRenderElapsedMs,
                floorMs = cfg.captureMinIntervalMs,
            )
        ) {
            return
        }
        if (!slot.tryAcquire()) return
        // AND-CAP-02 pixel-churn bypass — read BEFORE consumeDirty clears
        // it (see dirtySettleFired). A screen that only draws (no layout)
        // between heartbeats — e.g. an in-place bitmap swap in a regular
        // view — has an unchanged structural signature but changed pixels;
        // ship it. (FIX 3: the removed surface-driven tick no longer
        // contributes here — masked surfaces produce no visual change.)
        // The floor timestamp is advanced on ATTEMPT inside
        // captureAndDispatch (M3).
        val bypassDedup = DirtyTracker.wasDrawSourced()
        DirtyTracker.consumeDirty()
        val nowMs = System.currentTimeMillis()
        val syntheticMeta = InteractionMeta(
            tapKind = InteractionMeta.Kind.SCROLL_END,
            tapXNorm = 0f,
            tapYNorm = 0f,
            gestureDurationMs = 0L,
            touchCount = 1,
        )
        captureAndDispatch(
            cfg = cfg,
            slot = slot,
            uploader = uploader,
            window = window,
            captureView = window.decorView,
            meta = syntheticMeta,
            tapKindOverride = "heartbeat",
            capturedAtPreMs = nowMs,
            preFrame = null,
            forceEvenIfUnchanged = false,
            bypassDedup = bypassDedup,
        )
    }

    // FIX 3 (2026-07-05) — `currentTreeHasVisibleSurface` (M2 surface-
    // heartbeat probe) removed: with the surface-heartbeat gone (masked
    // surfaces never visually change) nothing consults it any more.

    /** Attach the dirty listeners to the current foregrounded window. Main thread. */
    private fun attachDirtyToCurrentWindow() {
        val window = windowProvider() ?: return
        DirtyTracker.attachTo(window.decorView)
    }

    /** Resolve the [Window] owning a View, or null if not attached to one. */
    private fun resolveWindow(view: View): Window? {
        val ctx = view.context
        var c: android.content.Context? = ctx
        while (c is android.content.ContextWrapper) {
            if (c is Activity) return c.window
            c = c.baseContext
        }
        return windowProvider()
    }

    /**
     * Off-main capture pipeline: OCR + upload hand-off. Errors
     * swallow + log per AGENT_BRIEFING R6.
     */
    private suspend fun handleCaptureAsync(
        seq: Long,
        meta: InteractionMeta,
        identity: ScreenIdentity?,
        preFrame: Bitmap?,
        postFrame: Bitmap?,
        structural: JsonObject?,
        tapKindOverride: String?,
        capturedAtPreMs: Long,
        capturedAtPostMs: Long,
        jpegQuality: Int,
        encodeDownscale: Float,
        uploader: ReplayUploaderRef,
    ) {
        val ocr = ocrExtractor
        val ocrText: String = if (postFrame != null && ocr != null) {
            try {
                ocr.extract(postFrame)
            } catch (t: Throwable) {
                Log.w(TAG, "ocrExtractor.extract failed", t)
                ""
            }
        } else {
            ""
        }

        // FIX 1 (2026-07-05) — bitmap ownership hand-off. Under PixelCopy
        // the pre/postFrame are FRESH native RGB_565 bitmaps; if nobody
        // recycled them they'd pin ~5-10 MB per pair until GC — heap
        // pressure in the replay hot path. Ownership rule:
        //   - SUCCESS (uploadCapture returned): the adapter is the single
        //     owner — it recycles both frames in its own `finally` once
        //     the synchronous encode/stage fan-out completes. We set
        //     `ownershipTaken = true` so this `finally` does NOT touch
        //     them (no double recycle).
        //   - FAILURE (uploadCapture threw before handing off): the adapter
        //     never took ownership, so WE recycle here.
        // The `!isRecycled` guard in [recycleQuiet] is belt-and-braces —
        // it makes the failure-path recycle a safe no-op even in the
        // unlikely event the adapter partially recycled before throwing.
        var ownershipTaken = false
        try {
            uploader.uploadCapture(
                ReplayCapture(
                    seq = seq,
                    interaction = meta,
                    screenIdentity = identity,
                    preFrame = preFrame,
                    postFrame = postFrame,
                    structuralJson = structural,
                    ocrText = ocrText,
                    capturedAtPreMs = capturedAtPreMs,
                    capturedAtPostMs = capturedAtPostMs,
                    tapKindOverride = tapKindOverride,
                    jpegQuality = jpegQuality,
                    encodeDownscale = encodeDownscale,
                )
            )
            ownershipTaken = true
        } catch (t: Throwable) {
            Log.w(TAG, "uploader.uploadCapture failed (seq=$seq)", t)
        } finally {
            // Failure path only — the adapter owns + recycles on success.
            if (!ownershipTaken) {
                recycleQuiet(preFrame)
                recycleQuiet(postFrame)
            }
        }
    }

    /**
     * Recycle a Bitmap if non-null and not already recycled. Tolerates
     * `recycle()` itself throwing (it shouldn't, but R6 anti-crash).
     */
    private fun recycleQuiet(bitmap: Bitmap?) {
        if (bitmap == null) return
        if (bitmap.isRecycled) return
        try {
            bitmap.recycle()
        } catch (_: Throwable) { /* swallow */ }
    }

    /**
     * Memory-pressure response. Wired by [io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap]
     * via its `memoryPressure` Flow when Agent 7 detects
     * `TRIM_MEMORY_RUNNING_CRITICAL` / `TRIM_MEMORY_COMPLETE`.
     *
     * Three immediate mitigations (mirrors iOS `handleMemoryWarning`):
     *  1. Drop pre-tap frame ([RingBuffer.take]) — releases ~10 MB.
     *  2. Tighten capture slot to 1 → next tap drops to metadata-only
     *     until pressure subsides.
     *  3. Tell [ThermalBackoff] to externally pause so subsequent
     *     captures bail out at the gate rather than progressing
     *     through the pipeline only to drop.
     */
    fun onMemoryWarning() {
        ringBuffer.take()?.recycle()
        captureSlot?.tightenForMemoryPressure()
        thermalBackoff?.externalPause(ThermalBackoff.PauseReason.LowMemory)
        lastScreenIdentity = null
        // Drop the skip-unchanged signature so the next capture after
        // recovery always ships a fresh frame (we don't know what got
        // GC'd under pressure).
        lastShippedSignature.set(null)
    }

    /** Counterpart to [onMemoryWarning] — restore baseline cap on `NORMAL`. */
    fun onMemoryWarningCleared() {
        captureSlot?.restoreBaseline()
        thermalBackoff?.externalResume()
    }

    /**
     * Test-only reset hook. Cleans the singleton state between
     * tests without going through the full [stop] flow (which
     * touches Android system services).
     */
    @androidx.annotation.VisibleForTesting
    internal fun resetForTesting() {
        started.set(false)
        active.set(false)
        sessionOpened.set(false)
        sessionGeneration.incrementAndGet()
        sessionOpenRetryDelayForTesting = null
        processForeground.set(false)
        processLifecycleGeneration.incrementAndGet()
        thermalAllowed.set(false)
        optedOut.set(false)
        hardDiscardRequested.set(false)
        explicitOptOutSealRequested.set(false)
        identityDiscardRequested.set(false)
        nextSeq.set(0L)
        lastScreenIdentity = null
        lastScrollEndElapsedMs = 0L
        // FIX 4 — clear the process-lifetime knob accumulator so knobs
        // pushed in one test don't leak into a later test's start().
        pendingKnobs = ReplayKnobs()
        serverSampleRateOverride = null
        ringBuffer.take()?.recycle()
        captureSlot = null
        thermalBackoff = null
        ocrExtractor = null
        structuralSnapshotter = null
        screenIdentity = null
        sampler = null
        sampledAnalyticsSessionId = null
        config = null
        baseConfig = null
        uploader = null
        sessionJob?.cancel()
        sessionJob = null
        maxDurationJob?.cancel()
        maxDurationJob = null
        replayStartedElapsedMs = -1L
        windowProvider = { null }
        lastShippedSignature.set(null)
        lastRenderElapsedMs = 0L
        lastSuccessfulRenderElapsedMs = 0L
        stopHeartbeat()
        DirtyTracker.resetForTesting()
        synchronized(pendingLock) {
            pendingStart = null
            retainedStart = null
            remoteRestartAllowed.set(false)
        }
        synchronized(lifecycleTransitionLock) {
            stopInFlight.set(false)
            restartRequestedAfterStop.set(false)
        }
        startClaimedHookForTesting = null
    }

    /** Install/remove the deterministic start-vs-optOut race hook. */
    @androidx.annotation.VisibleForTesting
    internal fun setStartClaimedHookForTesting(hook: (() -> Unit)?) {
        startClaimedHookForTesting = hook
    }

    /** Test seam — current seq counter, for the resume-contract tests. */
    @androidx.annotation.VisibleForTesting
    internal fun nextSeqForTesting(): Long = nextSeq.get()

    /** Timer must begin only after the backend session is authoritative. */
    @androidx.annotation.VisibleForTesting
    internal fun sessionTimingStartedForTesting(): Boolean =
        replayStartedElapsedMs >= 0L && maxDurationJob != null

    @androidx.annotation.VisibleForTesting
    internal fun setSessionOpenRetryDelayForTesting(delayMs: Long?) {
        sessionOpenRetryDelayForTesting = delayMs?.coerceAtLeast(1L)
    }

    @androidx.annotation.VisibleForTesting
    internal fun assumeProcessForegroundForTesting() {
        processLifecycleGeneration.incrementAndGet()
        processForeground.set(true)
    }

    /**
     * Test seam — the LIVE [ReplayConfig.frameCaptureEnabled] flag (null
     * when no session is running). Lets the remote-knob transition tests
     * (FIX 3/4) assert a `frameCaptureEnabled` flip landed on the live
     * config without exposing the whole config.
     */
    @androidx.annotation.VisibleForTesting
    internal fun effectiveFrameCaptureEnabledForTesting(): Boolean? =
        config?.frameCaptureEnabled

    /**
     * FIX 4 test seam — the LIVE effective [ReplayConfig] (null when no
     * session is running). Lets the "each /init payload is authoritative"
     * test assert that a knob OMITTED from a later payload reverted to the
     * compiled default rather than retaining the prior override.
     */
    @androidx.annotation.VisibleForTesting
    internal fun effectiveConfigForTesting(): ReplayConfig? = config

    private fun captureEncodeDownscale(viaCanvas: Boolean, captureScale: Float): Float =
        if (viaCanvas) captureScale else 1.0f

    /** Canvas uses project scale; PixelCopy is already pre-scaled. */
    @androidx.annotation.VisibleForTesting
    internal fun captureEncodeDownscaleForTesting(
        viaCanvas: Boolean,
        captureScale: Float,
    ): Float = captureEncodeDownscale(viaCanvas, captureScale)

    /**
     * M4 test seam — run the reconcile body SYNCHRONOUSLY (bypassing the
     * main-handler post the JVM test can't pump). Lets a transition test
     * push a sequence of knobs (which mutate `config` synchronously) and
     * then drain the reconcile to assert the FINAL state matches the LAST
     * push, regardless of arm/disarm ordering. Runs the exact same logic
     * the posted [reconcileDirtyEngine] would.
     */
    @androidx.annotation.VisibleForTesting
    internal fun drainDirtyEngineReconcileForTesting() {
        reconcileDirtyEngineNow()
    }
}

/**
 * Single captured tap+frame bundle handed to Agent 14's upload
 * pipeline. Agent 14 owns serialisation, signed-URL acquisition,
 * GCS PUT, and `/api/sdk/replay/events` POST.
 *
 * @param seq Per-session monotonic counter for upload ordering.
 * @param interaction Classified gesture metadata (Agent 8's
 *   [InteractionMeta]).
 * @param screenIdentity Joins this frame to Agent 9's screen tracker.
 * @param preFrame Previous retained raster used as the before-state; `null`
 *   when the [RingBuffer] has no prior frame.
 * @param postFrame Post-tap raster — `null` when capture failed
 *   (rare; usually OOM during alloc).
 * @param structuralJson View-tree DOM-like sidecar — `null` when
 *   [ReplayConfig.structuralSnapshotEnabled] was off.
 * @param ocrText PII-sanitized concatenated text from on-device ML
 *   Kit — empty string when OCR disabled / dependency missing /
 *   recognition failed.
 */
/**
 * AND-CAP-04 — server-resolved perf-knob override. Each field is
 * null when the server didn't send it (keep the compiled/builder
 * default). [DirtyCadenceClamp] pre-clamps the raw wire values before
 * they land here. Merged onto a [ReplayConfig] via [applyTo].
 */
internal data class ReplayKnobs(
    val frameCaptureEnabled: Boolean? = null,
    val maxDurationMs: Long? = null,
    val structuralEnabled: Boolean? = null,
    val ocrEnabled: Boolean? = null,
    val captureMinIntervalMs: Long? = null,
    val scrollEndCaptureEnabled: Boolean? = null,
    val scrollEndMinIntervalSec: Double? = null,
    val postTapSettleMs: Long? = null,
    val dirtyHeartbeatMs: Long? = null,
    val jpegQuality: Int? = null,
    val captureScale: Float? = null,
    val maxConcurrentCaptures: Int? = null,
    val maxConcurrentOcr: Int? = null,
) {
    /** Overlay non-null fields onto [base], leaving the rest untouched. */
    fun applyTo(base: ReplayConfig): ReplayConfig = base.copy(
        frameCaptureEnabled = frameCaptureEnabled ?: base.frameCaptureEnabled,
        maxDurationMs = maxDurationMs ?: base.maxDurationMs,
        structuralSnapshotEnabled = structuralEnabled ?: base.structuralSnapshotEnabled,
        ocrEnabled = ocrEnabled ?: base.ocrEnabled,
        captureMinIntervalMs = captureMinIntervalMs ?: base.captureMinIntervalMs,
        scrollEndCaptureEnabled = scrollEndCaptureEnabled ?: base.scrollEndCaptureEnabled,
        scrollEndMinIntervalSec = scrollEndMinIntervalSec ?: base.scrollEndMinIntervalSec,
        postTapSettleMs = postTapSettleMs ?: base.postTapSettleMs,
        dirtyHeartbeatMs = dirtyHeartbeatMs ?: base.dirtyHeartbeatMs,
        jpegQuality = jpegQuality ?: base.jpegQuality,
        captureScale = captureScale ?: base.captureScale,
        maxConcurrentCaptures = maxConcurrentCaptures ?: base.maxConcurrentCaptures,
        maxConcurrentOcr = maxConcurrentOcr ?: base.maxConcurrentOcr,
    )

    // FIX 4 (2026-07-05) — `mergedWith` (accumulate successive payloads)
    // removed. Each /init payload is now AUTHORITATIVE: a knob it omits
    // reverts to the compiled default, so [applyRemoteReplayKnobs] stores
    // the LATEST payload and resolves it against the baseline via [applyTo]
    // — it never merges one payload onto another.
}

internal data class ReplayCapture(
    val seq: Long,
    val interaction: InteractionMeta,
    val screenIdentity: ScreenIdentity?,
    val preFrame: Bitmap?,
    val postFrame: Bitmap?,
    val structuralJson: JsonObject?,
    val ocrText: String,
    /**
     * AND-CAP-05 player contract. Real wall-clock capture stamps in
     * epoch millis. `capturedAtPreMs` = gesture / dirty-mark time;
     * `capturedAtPostMs` = the moment the PixelCopy callback fired (the
     * REAL frame time). For a non-gesture dirty/heartbeat capture both
     * equal the capture moment. The adapter formats these to ISO-8601
     * `captured_at_pre` / `captured_at_post` on the wire so the player
     * places the tap dot on the correct frame.
     */
    val capturedAtPreMs: Long,
    val capturedAtPostMs: Long,
    /**
     * AND-CAP-05 — free-form wire `tap_kind` for non-taxonomy triggers
     * (`"screen_change"`, `"dirty"`, `"heartbeat"`). When non-null it
     * OVERRIDES [interaction]'s enum-derived `tap_kind`. Matches iOS,
     * where these ship as raw strings the player special-cases. Null =
     * use the gesture taxonomy value.
     */
    val tapKindOverride: String? = null,
    /**
     * AND-CAP-06 — starting JPEG quality (from [ReplayConfig.jpegQuality]).
     */
    val jpegQuality: Int = 15,
    /**
     * AND-CAP-06 — additional JPEG downscale to apply at encode time.
     * PixelCopy frames are ALREADY downscaled by `captureScale`, so
     * they pass 1.0 (no double-downscale). Canvas-fallback frames pass
     * the effective project captureScale.
     */
    val encodeDownscale: Float = 1.0f,
)

/**
 * Stub interface for Agent 14's
 * [io.kixo.sdk.internal.replay.upload.ReplayUploader]. Per
 * AGENT_BRIEFING §6 file ownership rule, this folder declares only
 * the surface it calls — [beginSession] / [uploadCapture] /
 * [endSession]. The real implementation lives in `internal/replay/upload/`.
 *
 * **Why this lives here** (not in a separate stub file): only
 * Agent 13 calls Agent 14, so colocating the contract with the
 * caller keeps the file-graph minimal. When Agent 14 lands, the
 * real `ReplayUploader` implements this interface verbatim and
 * `ReplayController.start` swaps in the real reference.
 */
internal interface ReplayUploaderRef {
    /**
     * Open the backend session via `/api/sdk/replay/session/start`,
     * cache the initial signed-URL pool, prepare the WorkManager
     * upload job. Suspending — caller awaits the response so we
     * don't fire-and-forget into a black hole on Agent 14 errors.
     */
    suspend fun beginSession(config: ReplayConfig): ReplaySessionOpenResult

    /**
     * Take ownership of the supplied [ReplayCapture]'s assets,
     * upload the frame(s) to GCS via signed URL, and POST the
     * event metadata to `/api/sdk/replay/events`. Implementation
     * MUST recycle any non-null `preFrame` / `postFrame` Bitmap
     * exactly once.
     */
    suspend fun uploadCapture(capture: ReplayCapture)

    /**
     * Seal the session via `/api/sdk/replay/session/end`. Uploads
     * already in flight continue via WorkManager; this call is the
     * orderly close.
     */
    suspend fun endSession()

    /** Same orderly close, but stamps the canonical `timeout` end reason. */
    suspend fun endSessionForTimeout() = endSession()

    /**
     * Privacy close: purge content-bearing work and durably seal the server row
     * with `explicit_opt_out`.
     */
    suspend fun endSessionForOptOut() = endSession()

    /** Hard identity/policy boundary: cancel and delete local work without
     * final replay-event or session/end network calls. */
    suspend fun discardSession() = endSession()
}

internal sealed interface ReplaySessionOpenResult {
    data class Opened(val clientSessionId: String) : ReplaySessionOpenResult
    data object Retryable : ReplaySessionOpenResult
    data object Terminal : ReplaySessionOpenResult
    data object PolicyPaused : ReplaySessionOpenResult
}
