package io.kixo.sdk.internal.queue

import java.util.concurrent.atomic.AtomicReference

/**
 * Process-wide singleton for the live SDK configuration + the
 * app/release identity resolved from the first `/api/sdk/init` response.
 *
 * **Why a holder, not direct `KixoConfiguration` access:**
 *  1. Agent 1 (`Kixo.configure`) owns the public `KixoConfiguration`
 *     type. We don't want every internal subsystem (queue, transport,
 *     replay, push) to import the public type — that would make the
 *     internal/ package depend on the io.kixo.sdk root, which is
 *     backwards. The holder owns a small subset of fields each
 *     subsystem actually needs.
 *  2. `release_id` is set ASYNCHRONOUSLY after `/api/sdk/init` lands.
 *     The queue + transport need to read it on every batch send. A
 *     simple immutable `KixoConfiguration` couldn't carry it without
 *     either making the field nullable everywhere or defeating
 *     immutability with a `var`. A separate holder lets `release_id`
 *     live in an `AtomicReference` and the rest of the config stay
 *     immutable.
 *  3. Tests can swap the holder without touching the public API
 *     surface.
 *
 * **Agent ownership note:** this class lives in queue/ because the
 * queue is the primary consumer (every batch flush reads it). The
 * Kixo facade (Agent 1) WRITES to it from `configure(...)`. If a
 * future refactor makes a different agent the primary consumer, move
 * it. For now, the queue's `BatchPayloadAssembler` is the one
 * subsystem that actually needs ALL the fields populated, so the
 * coupling is here.
 *
 * **Thread-safety:** every field is either `@Volatile` or wrapped in
 * an `AtomicReference`. `set(...)` is called once at SDK init from
 * the public-API thread; `snapshot()` is called from the queue's
 * worker coroutine on every flush. No locks needed.
 */
internal object ConfigHolder {

    /**
     * Snapshot of the resolved config the queue + transport need on
     * every flush. Held atomically so a re-init (rare — host calling
     * `Kixo.configure` twice) swaps both projectId/apiKey/etc and
     * the cached releaseId in lock-step.
     *
     * Default value is the "uninitialised" snapshot — projectId/apiKey
     * empty, environment "production" (safest fallback if a host
     * accidentally calls `track` before `configure`). The queue
     * checks `isInitialised` and silently no-ops in that window.
     */
    private val current: AtomicReference<Snapshot> = AtomicReference(Snapshot.UNINITIALISED)

    /**
     * Set the live config. Called by `Kixo.configure(...)` exactly
     * once per process lifetime in the normal flow; callable a
     * second time only for the test seam. The new snapshot
     * REPLACES the current one — no field merge.
     */
    fun set(snapshot: Snapshot) {
        current.set(snapshot)
    }

    /**
     * Update the canonical App + Release pair after `/api/sdk/init` lands.
     * Other fields stay unchanged, and the pair is published atomically so
     * direct-link resolution cannot combine identities from different init
     * responses.
     *
     * Idempotent: setting the same release_id twice is a no-op
     * (same snapshot reference is unchanged after compareAndSet).
     */
    fun setResolvedApp(appId: String, releaseId: String) {
        while (true) {
            val cur = current.get()
            if (cur.appId == appId && cur.releaseId == releaseId) return
            val next = cur.copy(appId = appId, releaseId = releaseId)
            if (current.compareAndSet(cur, next)) return
            // CAS failure → retry against the new current. Realistic
            // concurrency: another resolved-app update or set() raced. Loop
            // is bounded — in practice we never iterate more than once.
        }
    }

    /**
     * Read the current snapshot. Cheap (atomic load + immutable
     * data class read). Safe to call from any thread.
     */
    fun snapshot(): Snapshot = current.get()

    /**
     * Reset to the uninitialised state. Test-only — production code
     * never tears down the SDK config.
     */
    internal fun resetForTest() {
        current.set(Snapshot.UNINITIALISED)
    }

    /**
     * Immutable bag of the config fields the queue + transport need
     * on every batch send. Kept narrow so a new optional field
     * elsewhere in `KixoConfiguration` doesn't force a queue rebuild.
     *
     * @property projectId         `kx_proj_…`. Wire `project_id`.
     * @property apiKey            `kx_key_…`.  Wire `api_key`.
     * @property environment       `"development"` / `"production"`.
     *                             Wire `environment`.
     * @property apiHost           Resolved base URL — the transport
     *                             prepends this to every endpoint.
     * @property appVersion        From `PackageInfo.versionName`.
     * @property bundleId          Application id (Java package).
     * @property releaseId         From `/api/sdk/init` — empty string
     *                             until the first init response lands.
     * @property maxBufferSize     FIFO cap on the durable buffer.
     * @property flushAt           Threshold to trigger an immediate
     *                             flush from `enqueue`.
     * @property flushIntervalMs   Periodic-flush cadence in ms.
     * @property debug             Verbose logcat output (debug builds).
     * @property appId             Canonical App id returned by `/api/sdk/init`.
     */
    internal data class Snapshot(
        val projectId: String,
        val apiKey: String,
        val environment: String,
        val apiHost: String,
        val appVersion: String,
        val bundleId: String,
        val releaseId: String,
        val maxBufferSize: Int,
        val flushAt: Int,
        val flushIntervalMs: Long,
        val debug: Boolean,
        val appId: String = "",
    ) {
        /** True iff `Kixo.configure(...)` has populated us with real values. */
        val isInitialised: Boolean
            get() = projectId.isNotEmpty() && apiKey.isNotEmpty()

        companion object {
            /**
             * Sentinel for the pre-`Kixo.configure` window. The queue
             * checks `isInitialised` and no-ops on flush. `set(...)`
             * replaces this with the host's actual config.
             */
            val UNINITIALISED: Snapshot = Snapshot(
                projectId = "",
                apiKey = "",
                environment = "production",
                apiHost = io.kixo.sdk.internal.KixoEndpoints.PROD,
                appVersion = "unknown",
                bundleId = "unknown",
                releaseId = "",
                maxBufferSize = 200,
                flushAt = 20,
                flushIntervalMs = 30_000L,
                debug = false,
                appId = "",
            )
        }
    }
}
