package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.util.concurrent.TimeUnit

/** WorkManager retry for a durable session/end record. */
internal class ReplayEndWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        val encoded = inputData.getString(KEY_RECORD)
            ?: return androidx.work.ListenableWorker.Result.failure()
        val store = ReplayPendingEndStore(
            applicationContext.getSharedPreferences(
                ReplayPendingEndStore.PREFS_NAME,
                Context.MODE_PRIVATE,
            ),
        )
        val record = store.decode(encoded)
            ?: return androidx.work.ListenableWorker.Result.failure()
        // A synchronous ACK or a newer cumulative close may have superseded
        // this WorkSpec before WorkManager got CPU time.
        if (!store.containsUnchanged(record)) {
            return androidx.work.ListenableWorker.Result.success()
        }
        val pendingEvents = ReplayPendingEventStore(applicationContext)
        if (record.discardPendingEvents) {
            ReplayPendingEventDrain.discardSession(
                store = pendingEvents,
                baseUrl = inputData.getString(KEY_BASE_URL).orEmpty(),
                projectId = inputData.getString(KEY_PROJECT_ID).orEmpty(),
                sessionId = record.sessionId,
                installationId = record.installationId,
            )
        }

        val client = UploadWorkerSingletons.httpClient
            ?: return androidx.work.ListenableWorker.Result.retry()

        if (!record.discardPendingEvents) {
            // A killed/offline process may have durable tap metadata that never
            // reached the foreground batcher. Drain it before sealing the session;
            // the event endpoint intentionally permits late metadata on SEALED,
            // but preserving this order avoids that race entirely.
            when (
                ReplayPendingEventDrain.drainSession(
                    context = applicationContext,
                    httpClient = client,
                    store = pendingEvents,
                    baseUrl = inputData.getString(KEY_BASE_URL).orEmpty(),
                    projectId = inputData.getString(KEY_PROJECT_ID).orEmpty(),
                    apiKey = inputData.getString(KEY_API_KEY).orEmpty(),
                    sessionId = record.sessionId,
                    installationId = record.installationId,
                )
            ) {
                ReplayPendingEventDrain.Outcome.RETRY ->
                    return androidx.work.ListenableWorker.Result.retry()
                ReplayPendingEventDrain.Outcome.DRAINED -> Unit
            }
        }
        return when (
            ReplayEndRequestExecutor.execute(
                httpClient = client,
                baseUrl = inputData.getString(KEY_BASE_URL).orEmpty(),
                projectId = inputData.getString(KEY_PROJECT_ID).orEmpty(),
                apiKey = inputData.getString(KEY_API_KEY).orEmpty(),
                policyToken = inputData.getString(KEY_POLICY_TOKEN),
                record = record,
            )
        ) {
            ReplayEndRequestExecutor.Outcome.RETRY ->
                androidx.work.ListenableWorker.Result.retry()
            ReplayEndRequestExecutor.Outcome.ACKNOWLEDGED,
            ReplayEndRequestExecutor.Outcome.TERMINAL,
            ReplayEndRequestExecutor.Outcome.POLICY_DISCARD,
            -> {
                store.removeIfUnchanged(record)
                androidx.work.ListenableWorker.Result.success()
            }
        }
    }

    companion object {
        const val KEY_BASE_URL = "replay_end_base_url"
        const val KEY_PROJECT_ID = "replay_end_project_id"
        const val KEY_API_KEY = "replay_end_api_key"
        const val KEY_POLICY_TOKEN = "replay_end_policy_token"
        const val KEY_RECORD = "replay_end_record"
    }
}

internal fun interface ReplayEndWorkScheduler {
    fun enqueue(
        context: Context,
        baseUrl: String,
        projectId: String,
        apiKey: String,
        policyToken: String,
        record: ReplayPendingEndStore.Record,
    ): Boolean
}

internal object WorkManagerReplayEndWorkScheduler : ReplayEndWorkScheduler {
    override fun enqueue(
        context: Context,
        baseUrl: String,
        projectId: String,
        apiKey: String,
        policyToken: String,
        record: ReplayPendingEndStore.Record,
    ): Boolean = runCatching {
        val encoded = ReplayPendingEndStore(
            context.getSharedPreferences(ReplayPendingEndStore.PREFS_NAME, Context.MODE_PRIVATE),
        ).encode(record)
        val input = Data.Builder()
            .putString(ReplayEndWorker.KEY_BASE_URL, baseUrl)
            .putString(ReplayEndWorker.KEY_PROJECT_ID, projectId)
            .putString(ReplayEndWorker.KEY_API_KEY, apiKey)
            .putString(ReplayEndWorker.KEY_POLICY_TOKEN, policyToken)
            .putString(ReplayEndWorker.KEY_RECORD, encoded)
            .build()
        val request = OneTimeWorkRequestBuilder<ReplayEndWorker>()
            .setInputData(input)
            .setConstraints(
                Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build(),
            )
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            .addTag("kixo-replay-end")
            .addTag("kixo-replay-end-${record.sessionId}")
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            workName(record),
            ExistingWorkPolicy.REPLACE,
            request,
        )
        true
    }.getOrElse {
        Log.d(TAG, "Unable to schedule durable replay end", it)
        false
    }

    private fun workName(record: ReplayPendingEndStore.Record): String =
        "kixo-replay-end-${record.sessionId}-${record.installationId}"

    private const val TAG = "Kixo.ReplayEndWorker"
}

internal object ReplayEndRequestExecutor {
    enum class Outcome { ACKNOWLEDGED, TERMINAL, RETRY, POLICY_DISCARD }

    @Serializable
    private data class RequestBody(
        @SerialName("project_id") val projectId: String,
        @SerialName("api_key") val apiKey: String,
        @SerialName("session_id") val sessionId: String,
        @SerialName("installation_id") val installationId: String,
        @SerialName("stint_id") val stintId: String,
        @SerialName("stint_epoch") val stintEpoch: Long,
        @SerialName("ended_at") val endedAt: String,
        @SerialName("frame_count") val frameCount: Int,
        @SerialName("total_bytes") val totalBytes: Long,
        @SerialName("last_frame_seq") val lastFrameSeq: Long? = null,
        @SerialName("end_reason") val endReason: String,
        @SerialName("frames_dropped") val framesDropped: Int = 0,
        @SerialName("drop_reasons") val dropReasons: Map<String, Int>? = null,
    )

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = false }
    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun execute(
        httpClient: OkHttpClient,
        baseUrl: String,
        projectId: String,
        apiKey: String,
        policyToken: String?,
        record: ReplayPendingEndStore.Record,
    ): Outcome {
        if (baseUrl.isBlank() || projectId.isBlank() || apiKey.isBlank()) return Outcome.TERMINAL
        val body = RequestBody(
            projectId = projectId,
            apiKey = apiKey,
            sessionId = record.sessionId,
            installationId = record.installationId,
            stintId = record.stintId,
            stintEpoch = record.stintEpoch,
            endedAt = record.endedAtIso,
            frameCount = record.frameCount,
            totalBytes = record.totalBytes,
            lastFrameSeq = record.lastFrameSeq,
            endReason = record.endReason,
            framesDropped = record.framesDropped,
            dropReasons = record.dropReasons,
        )
        val request = runCatching {
            Request.Builder()
                .url(Endpoints.url(baseUrl, Endpoints.REPLAY_SESSION_END))
                .post(json.encodeToString(RequestBody.serializer(), body).toRequestBody(mediaType))
                .header("Authorization", "Bearer $apiKey")
                .header("Content-Type", "application/json; charset=utf-8")
                .build()
        }.getOrElse { return Outcome.TERMINAL }
        val guarded = try {
            ReplayRuntimePolicy.executeWorkerCleanupCall(policyToken, httpClient.newCall(request))
        } catch (_: IOException) {
            return Outcome.RETRY
        } catch (_: Throwable) {
            return Outcome.RETRY
        }
        if (guarded is ReplayRuntimePolicy.WorkerCallResult.Rejected) {
            return if (guarded.decision == ReplayRuntimePolicy.WorkerDecision.DISCARD) {
                Outcome.POLICY_DISCARD
            } else {
                Outcome.RETRY
            }
        }
        return (guarded as ReplayRuntimePolicy.WorkerCallResult.Executed).response.use { response ->
            when {
                response.isSuccessful -> {
                    val root = runCatching {
                        json.parseToJsonElement(response.body?.string().orEmpty()).jsonObject
                    }.getOrNull() ?: return@use Outcome.RETRY
                    if (root["ok"]?.jsonPrimitive?.booleanOrNull == true &&
                        (root["sealed"]?.jsonPrimitive?.booleanOrNull == true ||
                            root["stale"]?.jsonPrimitive?.booleanOrNull == true)
                    ) Outcome.ACKNOWLEDGED else Outcome.RETRY
                }
                response.code == 408 || response.code == 409 || response.code == 429 ||
                    response.code in 500..599 -> Outcome.RETRY
                response.code in 400..499 -> Outcome.TERMINAL
                else -> Outcome.RETRY
            }
        }
    }
}
