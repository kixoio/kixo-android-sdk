package io.kixo.sdk.internal.goal

import android.util.Log
import io.kixo.sdk.internal.model.toJsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Cross-platform goal marker (Wave 7 #C2, May 2026) — Android side.
 *
 * Mirrors:
 *   - **iOS** `Kixo.markGoal(_:value:currency:properties:)`
 *     in `kixo-ios-sdk/Sources/Kixo/Kixo.swift`
 *   - **Web** `Kixo.markGoal(name, opts)` and the `data-kixo-goal`
 *     HTML attribute in `kixo-web-sdk/src/auto/goal-marker.ts`
 *
 * **Two surfaces, one event:**
 *   1. Programmatic — `Kixo.markGoal("checkout_complete", value=49.99)`
 *      from app code (the public facade in Agent 1 forwards to [mark]).
 *   2. Declarative — `<meta-data>` entries in the host `AndroidManifest.xml`,
 *      parsed by [ManifestGoalParser] into a registry the SDK can fire
 *      automatically when the matching trigger is observed (TODO:
 *      future work — see `ManifestGoalParser`).
 *
 * Both surfaces emit `KixoEvent(event_type=KixoEventType.Goal,
 * event_name=<name>, properties={goal_value?, goal_currency?, ...})`.
 * The backend auto-goals detector treats `event_type=goal` as ground
 * truth regardless of which platform / surface fired it; any AI-detected
 * candidate matching the same name is suppressed in favour of this
 * explicit mark (see kixo-backend Phase 4a `analyze_site_for_goals`).
 *
 * **Validation enforced here (matches iOS + web):**
 *   - `name` against `^[a-z0-9_-]{3,64}$` via [GoalNameValidator].
 *     Invalid names are dropped with a `Log.w` warning and the call
 *     becomes a silent no-op — never throws (per AGENT_BRIEFING.md R6
 *     "never crash the host app").
 *   - `value` (when non-null) must be `>= 0`. Negative revenue is a
 *     refund, which is a separate event type the AI categoriser
 *     handles distinctly; we drop the `goal_value` rather than
 *     rejecting the whole event so the goal still fires.
 *   - `currency` (when non-null) must match ISO-4217 (`^[A-Z]{3}$`).
 *     A bad currency code drops the `goal_currency` field but doesn't
 *     reject the goal — the dashboard will surface the value as
 *     "currency unknown" rather than losing the event entirely.
 *   - `properties` are passed through unchanged. The eventual
 *     [KixoEvent] construction is owned by the public facade (Agent 1)
 *     which runs the standard PII filter / super-property merge
 *     pipeline before handing to the queue.
 *
 * **Dedup:** by default a goal is emitted at most once per analytics
 * session (see [GoalDedup.DedupScope.Session] for rationale). Callers
 * can opt out via [DedupScope.Always] for cases where every emit
 * matters (e.g. multi-step funnel where the same step legitimately
 * fires multiple times).
 *
 * **Thread safety:** safe to call from any thread. The only mutable
 * state — the dedup set — is itself thread-safe.
 *
 * **Dependency on the EventQueue (owned by Agent 5):** at the time of
 * writing Agent 5 hasn't shipped the concrete `EventQueue`. Per the
 * briefing rule (§6) we declare a minimal [GoalEventSink] interface
 * here and the public facade (Agent 1) adapts it onto whichever queue
 * implementation lands. This keeps our compile-time surface independent
 * of Agent 5's API churn while giving them a tiny stable contract to
 * implement against.
 */
internal object GoalMarker {

    private const val TAG = "Kixo"

    /**
     * Wire field name for the optional revenue value. Cross-platform
     * contract — backend `lib/behavior-trail/extract.ts:421` reads
     * `props.$goal_value`. The `$`-prefix is the established standard-
     * property convention (mirrors web SDK `auto/goal-marker.ts`).
     *
     * Critic BLOCKER Android-B2 (May 2026) — previously shipped bare
     * `goal_value`; backend ClickHouse rollups silently fell back to
     * zero for every Android-marked goal until this rename.
     */
    private const val PROP_GOAL_VALUE = "\$goal_value"

    /**
     * Wire field name for the optional ISO-4217 currency code. Backend
     * reads `props.$goal_currency`. See [PROP_GOAL_VALUE].
     */
    private const val PROP_GOAL_CURRENCY = "\$goal_currency"

    /**
     * Wire field name for the goal source — `manual_kotlin` for
     * programmatic `Kixo.markGoal(...)` calls, `manual_html` for
     * declarative `<meta-data>` AndroidManifest entries (set by
     * [markFromManifest]). Backend reads `props.$goal_source` and
     * stores it in ClickHouse `signal_source`.
     */
    private const val PROP_GOAL_SOURCE = "\$goal_source"

    /**
     * Wire field name for the goal trigger — `"click"`, `"submit"`,
     * `"view"`, or `"manual"`. Programmatic marks always set this to
     * `"manual"` (cross-platform parity with web SDK's `auto/goal-marker.ts`
     * where `Kixo.markGoal()` defaults the trigger to `"api"` but
     * declarative HTML can override). Backend reads
     * `props.$goal_trigger` and stores it in ClickHouse `signal_subtype`.
     */
    private const val PROP_GOAL_TRIGGER = "\$goal_trigger"

    /** Source value for programmatic `Kixo.markGoal(...)` calls. */
    private const val SOURCE_MANUAL_KOTLIN = "manual_kotlin"

    /** Source value for declarative AndroidManifest `<meta-data>` goals. */
    private const val SOURCE_MANUAL_HTML = "manual_html"

    /** Default trigger for programmatic / manifest goal marks. */
    private const val TRIGGER_MANUAL = "manual"

    /** ISO-4217 currency code shape: exactly three uppercase letters. */
    private val CURRENCY_REGEX = Regex("^[A-Z]{3}$")

    /**
     * Side-channel into the event queue. The public facade installs
     * this once during `Kixo.configure()`; before that, [mark] calls
     * are buffered? — no, in fact they're dropped with a warning. The
     * iOS contract is the same: pre-configure calls are no-ops.
     *
     * Volatile so a configure-on-thread-A → mark-on-thread-B sequence
     * sees the install reliably without a lock.
     */
    @Volatile
    private var sink: GoalEventSink? = null

    /**
     * Wire the side-channel. Idempotent — a second install replaces
     * the previous sink (test-only path; in production [Kixo.configure]
     * is itself guarded by `isConfigured`).
     */
    fun installSink(sink: GoalEventSink) {
        this.sink = sink
    }

    /**
     * Detach the sink. Intended for test cleanup so a singleton state
     * leak between test methods can't affect other tests.
     */
    @androidx.annotation.VisibleForTesting
    internal fun uninstallSinkForTesting() {
        sink = null
    }

    /**
     * Mark a conversion goal. See class-level comment for the
     * full contract.
     *
     * @param name Goal identifier — must satisfy `^[a-z0-9_-]{3,64}$`.
     *   Invalid names are dropped with a warning (no exception).
     * @param value Optional revenue value. Stored under
     *   `goal_value` when non-null AND `>= 0`.
     * @param currency Optional ISO-4217 currency code. Stored under
     *   `goal_currency` when matching `^[A-Z]{3}$`.
     * @param properties Free-form extra properties merged in alongside
     *   `goal_value` / `goal_currency`. Pass-through (no validation).
     * @param dedupScope Controls per-session dedup (default: dedupe
     *   within session). Callers who explicitly want every emit pass
     *   [GoalDedup.DedupScope.Always].
     */
    fun mark(
        name: String,
        value: Double? = null,
        currency: String? = null,
        properties: Map<String, Any?> = emptyMap(),
        dedupScope: GoalDedup.DedupScope = GoalDedup.DedupScope.Session,
    ) {
        // 1. Name validation — invalid → log + drop. We deliberately
        // log via android.util.Log rather than throwing because the
        // public Kixo.markGoal() is called from arbitrary host-app
        // code paths (including UI thread); throwing would crash the
        // host (R6 violation).
        if (!GoalNameValidator.isValid(name)) {
            Log.w(
                TAG,
                "markGoal: invalid name '$name' " +
                    "— must match ^[a-z0-9_-]{3,64}$. Event dropped.",
            )
            return
        }

        // 2. Per-session dedup — silently absorbed when a duplicate.
        // No log: the contract is "fires at most once per session" and
        // the host doesn't need a warning when that contract fires.
        if (!GoalDedup.shouldEmit(name, dedupScope)) {
            return
        }

        // 3. Build the final property map. Strategy: start with the
        // caller's supplied map (so any caller-provided "$goal_value"
        // is overridable by the explicit named param when present),
        // then apply contract fields. We keep the precedence the way
        // iOS does: explicit named params win over caller-provided
        // properties, because that's the principle-of-least-surprise
        // for `markGoal("x", value=1.0, properties=mapOf("$goal_value" to 2.0))`.
        val finalProps: MutableMap<String, Any?> = LinkedHashMap(properties.size + 4)
        finalProps.putAll(properties)
        // Cross-platform standard-property stamps. Programmatic
        // [mark] calls always carry source=manual_kotlin and the
        // generic trigger=manual; [markFromManifest] overrides
        // source=manual_html afterwards. Callers can pre-seed a
        // different `$goal_trigger` (e.g. `"view"`) via the
        // `properties` map and we won't clobber it — only set if
        // absent so manifest/declarative paths can specialise.
        if (!finalProps.containsKey(PROP_GOAL_SOURCE)) {
            finalProps[PROP_GOAL_SOURCE] = SOURCE_MANUAL_KOTLIN
        }
        if (!finalProps.containsKey(PROP_GOAL_TRIGGER)) {
            finalProps[PROP_GOAL_TRIGGER] = TRIGGER_MANUAL
        }

        // 4. Optional value — drop silently if negative. A negative
        // revenue value is a refund, which is a separate event type
        // the AI categoriser handles distinctly; emitting a negative
        // goal_value would corrupt the dashboard's revenue rollup.
        if (value != null) {
            if (value >= 0.0 && value.isFinite()) {
                finalProps[PROP_GOAL_VALUE] = value
            } else {
                Log.w(
                    TAG,
                    "markGoal: ignoring goal_value=$value for '$name' " +
                        "(must be a finite, non-negative number).",
                )
            }
        }

        // 5. Optional currency — drop the field but keep the goal if
        // the code is malformed. Cross-platform contract — web SDK's
        // validator behaves identically (silent drop, goal still fires).
        if (currency != null) {
            if (CURRENCY_REGEX.matches(currency)) {
                finalProps[PROP_GOAL_CURRENCY] = currency
            } else {
                Log.w(
                    TAG,
                    "markGoal: ignoring goal_currency='$currency' for '$name' " +
                        "(must be ISO-4217: ^[A-Z]{3}$).",
                )
            }
        }

        // 6. Hand off to the sink. If the sink isn't installed yet
        // (Kixo.markGoal called before Kixo.configure), warn + drop —
        // matches the iOS contract where pre-configure calls are no-ops.
        val s = sink
        if (s == null) {
            Log.w(
                TAG,
                "markGoal('$name') called before Kixo.configure() — " +
                    "event dropped. Call Kixo.configure() first.",
            )
            return
        }

        // Convert the loose Map<String, Any?> to a JsonObject through the
        // shared PropertyValue boundary — same path the rest of the SDK's
        // public-API callers use. This drops unrepresentable values
        // (NaN, unsupported types, etc.) per AGENT_BRIEFING.md R6.
        val jsonProps: JsonObject = finalProps.toJsonElement()
        try {
            s.enqueueGoal(name = name, properties = jsonProps)
        } catch (t: Throwable) {
            // Per R6: never let a sink failure crash the host. The sink
            // should already swallow internally, but defence-in-depth
            // never hurts.
            Log.e(TAG, "markGoal: sink failed for '$name' (event dropped)", t)
        }
    }

    /**
     * Convenience for [ManifestGoalParser] internal use — register a
     * declarative goal sourced from `<meta-data>`. Today this is just
     * an alias of [mark]; once the manifest-trigger wiring lands the
     * declarative path will pre-attach `goal_source=manifest` so the
     * dashboard can distinguish manifest-declared from programmatic
     * marks.
     */
    fun markFromManifest(
        name: String,
        value: Double? = null,
        currency: String? = null,
        properties: Map<String, Any?> = emptyMap(),
    ) {
        // Manifest-sourced goals carry `$goal_source = "manual_html"`
        // for cross-platform parity with the web SDK's declarative
        // `data-kixo-goal` attribute path (see
        // `kixo-web-sdk/src/auto/goal-marker.ts:82-83`). We pre-seed
        // the source in `properties` so [mark]'s "only-set-if-absent"
        // guard preserves it.
        val annotated = LinkedHashMap<String, Any?>(properties.size + 1)
        annotated.putAll(properties)
        annotated[PROP_GOAL_SOURCE] = SOURCE_MANUAL_HTML
        mark(
            name = name,
            value = value,
            currency = currency,
            properties = annotated,
            dedupScope = GoalDedup.DedupScope.Session,
        )
    }
}

/**
 * Stub interface implemented by the public facade (Agent 1) and backed
 * by Agent 5's `EventQueue`. Declared inside the goal package so we do
 * not depend on Agent 5's not-yet-shipped types — see briefing §6.
 *
 * The contract is intentionally minimal:
 *
 *   1. The implementer is responsible for stamping `event_id`,
 *      `device_id`, `anonymous_id`, `user_id`, `session_id`,
 *      `fingerprint`, `timestamp`, and `context` onto the resulting
 *      [KixoEvent]. Goal markers don't have access to identity /
 *      session state directly — the facade owns those.
 *
 *   2. The implementer should run the standard PII filter, super-
 *      property merge, and lifecycle gate before handing to the queue.
 *      A pre-validated goal name + properties map is all we hand over.
 *
 *   3. Any failure during enqueue is the implementer's problem —
 *      [GoalMarker.mark] swallows + logs as a defence-in-depth layer
 *      but expects the implementer to not throw under normal load.
 *
 * This shape is deliberately NOT `(KixoEvent) -> Unit` because the
 * marker has no business minting `event_id` / `session_id` / etc.
 * — those are owned by the identity / session layers (Agents 6 & 7)
 * via the facade.
 */
internal interface GoalEventSink {
    /**
     * Enqueue a goal event. Implementer attaches identity / context
     * and routes to the configured event queue.
     *
     * @param name Already validated against `^[a-z0-9_-]{3,64}$`.
     * @param properties JsonObject with `goal_value` / `goal_currency`
     *   (when valid) and any caller-supplied extras already merged.
     */
    fun enqueueGoal(name: String, properties: JsonObject)
}
