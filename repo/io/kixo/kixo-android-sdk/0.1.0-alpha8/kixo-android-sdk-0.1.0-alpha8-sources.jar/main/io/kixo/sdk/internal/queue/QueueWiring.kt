package io.kixo.sdk.internal.queue

import android.content.Context
import io.kixo.sdk.KixoConfiguration
import io.kixo.sdk.internal.context.DeviceInfo
import io.kixo.sdk.internal.identity.IdentityManager
import io.kixo.sdk.internal.model.InitRequest
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.model.toJsonElement
import io.kixo.sdk.internal.storage.EventStorageHelper
import io.kixo.sdk.internal.storage.SqliteEventStore
import io.kixo.sdk.internal.transport.HttpClientFactory
import io.kixo.sdk.internal.transport.Transport
import java.time.Instant
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

/**
 * Builds the live [EventQueue] from real peer-agent types and exposes
 * a public-facade-facing wrapper [KixoEventQueueRef].
 *
 * **Wave 6 refactor (May 2026):** earlier revisions wrapped every peer
 * type (`storage.EventStore`, `transport.Transport`, `model.KixoEvent`,
 * `model.BatchPayload`, `context.DeviceInfo`, `model.EnrichedContext`)
 * in a queue-side adapter so the queue could declare narrow
 * "parallel-universe" stub interfaces. The adapters added ~280 LOC
 * with no behavioural value once Agent 5's parallel-build phase ended.
 *
 * This file now wires the queue against the real types directly.
 * [KixoEventQueueRef] is the only remaining wrapper, and only because
 * the public facade's `EventQueueRef` interface in `Kixo.kt` is
 * `private` — we can't satisfy it directly from a non-nested type.
 *
 * Per AGENT_BRIEFING.md §6 file-ownership: this file lives in
 * `internal/queue/` (Agent 5's folder) because the wiring is a queue
 * concern. We READ peer types but never modify them.
 */
/**
 * Functional handle the public facade uses to wrap into the
 * `Kixo.PushTransportBridge` private interface. SAM-style so the
 * facade's anonymous-object adapter is a one-liner.
 */
internal fun interface PushTransportInvoke {
    operator fun invoke(token: String, provider: io.kixo.sdk.PushProvider)
}

internal object QueueWiring {

    /**
     * Build the live `EventQueue` + return an [KixoEventQueueRef]
     * suitable for the public facade's `Wiring.queueRef` slot.
     *
     * Side effects (in order):
     *  1. Construct the real `SqliteEventStore` at `<filesDir>/kixo/events.db`
     *     and run `recoverInFlight()` once to re-claim crashed in-flight rows.
     *  2. Construct the shared `OkHttpClient` (debug-build logging on).
     *  3. Construct the real `Transport` against the configured base URL.
     *  4. Seed `ConfigHolder` from the [KixoConfiguration] snapshot.
     *  5. Construct the queue-internal `BatchPayloadAssembler` with
     *     the real `DeviceInfo`.
     *  6. Construct the queue with the real store + transport +
     *     assembler + a SupervisorJob-rooted scope. No adapters.
     *  7. Optimistically transition lifecycle to `Running` so events
     *     ship right away. If creds are wrong, backend's 401 →
     *     `PausedByServer("http_401")` flips state via the existing
     *     apply-response path.
     *  8. Return [KixoEventQueueRef] for the public facade.
     */
    /**
     * Aggregate of everything `QueueWiring.build` constructs that the
     * facade needs to wire up. Lets us hand back the queue ref AND the
     * push-transport bridge AND the underlying `Transport` (so future
     * subsystems — replay uploader, etc — can share the same OkHttp
     * client + creds without rebuilding).
     */
    internal data class Built(
        val queueRef: KixoEventQueueRef,
        val pushTransport: PushTransportInvoke,
        val transport: Transport,
        val httpClient: okhttp3.OkHttpClient,
        val scope: CoroutineScope,
    )

    fun build(
        context: Context,
        config: KixoConfiguration,
        identity: IdentityManager,
        deviceInfo: DeviceInfo,
        releaseId: String? = null,
    ): Built {
        // 1. Real store + recover in-flight. The Helper builds the
        //    SupportSQLiteOpenHelper (lazy file create at /filesDir/kixo/),
        //    SqliteEventStore wraps it.
        val store = SqliteEventStore(EventStorageHelper(context).create())
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch { store.recoverInFlight() }

        // 2. + 3. HTTP client + transport. Logging on in debug.
        val httpClient = HttpClientFactory.create(enableLogging = config.debug)
        val json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = false
        }
        val transport = Transport(
            httpClient = httpClient,
            baseUrl = config.apiHost,
            json = json,
        )

        // 4. Seed ConfigHolder from the user's KixoConfiguration so
        //    BatchPayloadAssembler.assemble() reads the right env / creds.
        ConfigHolder.set(
            ConfigHolder.Snapshot(
                projectId = config.projectId,
                apiKey = config.apiKey,
                environment = config.environment,
                apiHost = config.apiHost,
                appVersion = appVersion(context),
                bundleId = context.packageName,
                releaseId = releaseId.orEmpty(),
                maxBufferSize = 200,
                flushAt = 20,
                flushIntervalMs = 30_000L,
                debug = config.debug,
            ),
        )

        // 5. Assembler now takes the real DeviceInfo — no adapter.
        val assembler = BatchPayloadAssembler(deviceInfo = deviceInfo)

        // 6. Queue itself. Real types throughout — no adapters.
        val queue = EventQueue(
            store = store,
            transport = transport,
            payloadAssembler = assembler,
            scope = scope,
            flushAt = 20,
            flushIntervalMs = 30_000L,
            maxBufferSize = 200,
        )

        // 7. Optimistic Running so events ship immediately. The async
        // init below will downgrade to PausedByServer on a `paused`
        // response (kill-switch) — but the periodic flush won't have
        // sent anything in the ~50-200 ms init takes anyway. If init
        // fails (network blip), we stay Running and the backend's
        // auto-app-discovery path on /api/sdk/batch fills in
        // `release_id` server-side — no events lost.
        queue.setLifecycleState(LifecycleState.Running)

        // 8. Wave 6: real /api/sdk/init wiring. Fires async on the
        // SDK scope so cold-launch isn't blocked. On success we
        // stamp the resolved `release_id` into ConfigHolder so
        // subsequent batches embed it (vs the empty-string fallback
        // that triggers backend auto-discovery on every batch).
        // On `paused: true` (server kill-switch) we transition the
        // lifecycle to PausedByServer — events stop shipping.
        scope.launch {
            try {
                val req = InitRequest(
                    projectId = config.projectId,
                    apiKey = config.apiKey,
                    bundleId = context.packageName,
                    appVersion = appVersion(context),
                    build = appBuild(context),
                    environment = config.environment,
                    sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
                )
                val resp = transport.postInit(req)
                if (resp == null) {
                    // Transient/permanent failure — leave queue Running.
                    // The next /api/sdk/batch will trigger backend auto-
                    // discovery; release_id stays empty until then.
                    if (config.debug) {
                        android.util.Log.d(
                            "Kixo",
                            "/api/sdk/init returned null (network or 5xx); staying in optimistic Running",
                        )
                    }
                    return@launch
                }
                if (resp.paused) {
                    // Kill-switch from server (e.g. SDK version disabled).
                    queue.setLifecycleState(
                        LifecycleState.PausedByServer(resp.pausedReason ?: "init_paused"),
                    )
                    if (config.debug) {
                        android.util.Log.w(
                            "Kixo",
                            "/api/sdk/init returned paused=true reason=${resp.pausedReason}; SDK halted",
                        )
                    }
                    return@launch
                }
                ConfigHolder.setReleaseId(resp.releaseId)
                if (config.debug) {
                    android.util.Log.d(
                        "Kixo",
                        "init ok: release_id=${resp.releaseId} app=${resp.appName} max_batch=${resp.maxBatchSize ?: "default"}",
                    )
                }
            } catch (t: Throwable) {
                // R6 — never crash the host. Worst case: release_id
                // stays empty, backend auto-discovers per batch.
                if (config.debug) {
                    android.util.Log.w("Kixo", "/api/sdk/init threw — degrading to optimistic mode", t)
                }
            }
        }

        // 9. Public-facade-facing wrapper + push bridge using the same
        //    transport + scope.
        val queueRef = KixoEventQueueRef(queue, identity, deviceInfo)
        val pushBridge = buildPushTransportBridge(transport, identity, scope)
        return Built(queueRef, pushBridge, transport, httpClient, scope)
    }

    /**
     * Real implementation of `Kixo.PushTransportBridge` — sends a
     * plaintext push token to `/api/sdk/push/register`. Wave 7 fix:
     * before this, `Kixo.setPushToken(...)` routed through a no-op
     * bridge so the token never actually reached the backend.
     *
     * Token plaintext crosses the wire here ONLY (per AGENT_BRIEFING.md
     * R10). Every other event-stream reference uses SHA-256.
     */
    fun buildPushTransportBridge(
        transport: Transport,
        identity: IdentityManager,
        scope: CoroutineScope,
    ): PushTransportInvoke = PushTransportInvoke { token, provider ->
        // Snapshot creds once. ConfigHolder is process-stable after
        // configure(); we never mid-flight rotate creds at runtime.
        val cfg = ConfigHolder.snapshot()
        if (cfg.projectId.isEmpty() || cfg.apiKey.isEmpty()) {
            // Pre-configure call (would have buffered into the
            // facade's pre-init ring — should never reach here, but
            // belt-and-braces).
            return@PushTransportInvoke
        }
        val req = io.kixo.sdk.internal.model.PushRegisterRequest(
            projectId = cfg.projectId,
            apiKey = cfg.apiKey,
            deviceId = identity.deviceId(),
            userId = identity.userId(),
            token = token,
            // platform default = "android"
        )
        scope.launch {
            try {
                val ok = transport.postPushRegister(req)
                if (!ok && cfg.debug) {
                    android.util.Log.w(
                        "Kixo.Push",
                        "registerPushToken failed (transient or 4xx); the next setPushToken() call retries",
                    )
                }
            } catch (t: Throwable) {
                // R6 — never crash the host.
                if (cfg.debug) android.util.Log.w("Kixo.Push", "registerPushToken threw", t)
            }
        }
    }

    private fun appBuild(context: Context): String =
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            // longVersionCode is API 28+; SDK minSdk is 24 so guard.
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                info.longVersionCode.toString()
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toString()
            }
        } catch (_: Throwable) {
            "0"
        }

    private fun appVersion(context: Context): String =
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
        } catch (_: Throwable) {
            "0.0.0"
        }
}

// ─── EventQueueRef adapter (public-facade-facing) ─────────────────

/**
 * Wraps the real [EventQueue] for the public facade. The facade's
 * own `EventQueueRef` interface is `private` inside `object Kixo`,
 * so we expose the queue through this internal type and let
 * `Kixo.configure(...)` build a private anonymous adapter that
 * forwards to it.
 *
 * `enqueueCustom(eventType, eventName, properties)` builds a complete
 * real [KixoEvent] (UUID event_id + live identity stamps + map →
 * JsonObject conversion) and routes through `EventQueue.enqueue()`
 * via a launch on the SDK's process-global scope (the public API is
 * non-suspend).
 */
internal class KixoEventQueueRef(
    private val queue: EventQueue,
    private val identity: IdentityManager,
    private val deviceInfo: DeviceInfo,
) {
    fun enqueueCustom(eventType: String, eventName: String, properties: Map<String, Any?>) {
        val realEvent = KixoEvent(
            eventId = UUID.randomUUID().toString(),
            deviceId = identity.deviceId(),
            anonymousId = identity.anonymousId(),
            userId = identity.userId(),
            sessionId = currentSessionId(),
            fingerprint = currentFingerprint(),
            eventType = wireToEnum(eventType),
            eventName = eventName,
            properties = properties.toJsonElement(),
            timestamp = Instant.now(),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(realEvent)
    }

    /**
     * Wave 8 — accept a fully-built [KixoEvent] from a caller that has
     * already minted the event id, identity stamps, and fingerprint
     * itself. Used by [io.kixo.sdk.internal.interaction.TouchInterceptor]
     * which needs control over the gesture-time fingerprint snapshot
     * (so the screen_id stamped on a tap matches the screen the user
     * was looking at when the touch landed, NOT the screen they may
     * have transitioned to by the time the queue's enqueue coroutine
     * is dispatched).
     *
     * Callers that pass an `EventContext` placeholder (e.g.
     * [io.kixo.sdk.internal.interaction.TouchInterceptor]'s
     * `EMPTY_EVENT_CONTEXT`) get it overwritten here with the real
     * per-event context from [deviceInfo] so the wire payload always
     * carries enriched device info.
     */
    fun enqueueEvent(event: KixoEvent) {
        val enriched = event.copy(context = deviceInfo.perEventContext())
        queue.enqueueAsync(enriched)
    }

    fun flush() = queue.flush()
    fun flushBlocking(timeoutMs: Long): Boolean = queue.flushBlocking(timeoutMs)
    fun stop(reason: String) = queue.stop(reason)

    private fun currentSessionId(): String =
        io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap.currentSessionId()
            ?: "boot-${UUID.randomUUID()}"

    private fun currentFingerprint(): String =
        io.kixo.sdk.internal.screen.ScreenIdentity.current().screenId

    private fun wireToEnum(eventType: String): KixoEventType {
        // Defensive: backend rejects unknown event_types as permanent
        // failures, so mapping to .Custom is the safe sink for
        // unrecognised tokens (mirrors iOS). Match against @SerialName
        // wire value (snake_case), not enum constant name (PascalCase).
        return KixoEventType.values().firstOrNull { enumWireValue(it) == eventType }
            ?: KixoEventType.Custom
    }

    private fun enumWireValue(t: KixoEventType): String {
        // Cheap mapping — kotlinx.serialization @SerialName is what we
        // need but its lookup requires reflection; the enum's `name`
        // field is reachable from the constant's declaration order.
        // This mirrors `Json.encodeToString(serializer, t).removeSurrounding("\"")`
        // without paying serialization cost per enqueue.
        return when (t) {
            KixoEventType.ScreenView -> "screen_view"
            KixoEventType.Tap -> "tap"
            KixoEventType.Scroll -> "scroll"
            KixoEventType.Network -> "network"
            KixoEventType.Crash -> "crash"
            KixoEventType.Custom -> "custom"
            KixoEventType.SessionStart -> "session_start"
            KixoEventType.SessionEnd -> "session_end"
            KixoEventType.Identify -> "identify"
            KixoEventType.Group -> "group"
            KixoEventType.Lifecycle -> "lifecycle"
            KixoEventType.Navigation -> "navigation"
            KixoEventType.Gesture -> "gesture"
            KixoEventType.PushOpen -> "push_open"
            KixoEventType.PushReceived -> "push_received"
            KixoEventType.PushDismissed -> "push_dismissed"
            KixoEventType.PushSilent -> "push_silent"
            KixoEventType.PushAction -> "push_action"
            KixoEventType.PushPermission -> "push_permission"
            KixoEventType.PushTokenInvalidated -> "push_token_invalidated"
            KixoEventType.DeepLink -> "deep_link"
            KixoEventType.Iap -> "iap"
            KixoEventType.UserProperty -> "user_property"
            KixoEventType.ScreenVisit -> "screen_visit"
            KixoEventType.Goal -> "goal"
        }
    }
}

/**
 * Helper to launch a suspend `enqueue` from the non-suspend public API
 * surface. Lives on a process-global SDK scope rooted in SupervisorJob
 * so a single failed enqueue doesn't tear peers down.
 */
private fun EventQueue.enqueueAsync(event: KixoEvent) {
    SdkScope.launch { enqueue(event) }
}

private object SdkScope : CoroutineScope by CoroutineScope(SupervisorJob() + Dispatchers.Default)
