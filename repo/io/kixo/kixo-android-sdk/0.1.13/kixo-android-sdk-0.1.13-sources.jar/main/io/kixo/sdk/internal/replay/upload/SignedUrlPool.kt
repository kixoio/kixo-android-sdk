package io.kixo.sdk.internal.replay.upload

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.time.Instant
import java.time.format.DateTimeParseException
import io.kixo.sdk.internal.replay.upload.SignedUrlClient.SignedUrl

/**
 * Concurrency-safe pool of signed URLs handed out by
 * `/api/sdk/replay/{session/start, frames/sign}`. Mirrors the
 * iOS pattern (BackgroundUploader stages frames, SignedURLClient
 * keeps the lease pool topped up).
 *
 * **Why a pool, not per-frame signing:**
 *  - Each `/api/sdk/replay/frames/sign` round-trip is ~150-300 ms
 *    on a healthy connection. If we signed per-frame, the user
 *    interaction → frame-on-server latency would balloon by that
 *    amount. The pool lets us amortise the round-trip across N
 *    frames — `signMore(count=10)` returns 40 URLs (10 seqs × 4
 *    kinds), so we sign roughly once every 5 user interactions.
 *  - The backend signs URLs with a 10-min expiry — well within the
 *    typical session length.
 *
 * **Refill threshold:** when the pool drops below
 * [DEFAULT_REFILL_THRESHOLD] URLs (across all kinds, all seqs), we
 * fire an async [SignedUrlClient.signMore] request. The trigger
 * runs in a fire-and-forget coroutine on the SDK scope so the
 * caller's [take] returns immediately. If the refill is in flight,
 * a second under-threshold trigger short-circuits — see
 * [refillInFlight].
 *
 * **Expiry handling:** URLs older than `expires_at` are silently
 * dropped on `take`. This matters when the SDK was suspended for
 * 10+ min between captures (e.g. a flaky network kept the pool
 * full but the URLs aged out before any uploads happened).
 *
 * **Concurrency model:** all mutating ops are gated behind a single
 * [Mutex]. The mutex is suspending (Kotlin coroutines), so there
 * is NO thread-blocking — coroutines park cleanly. We don't use a
 * `ConcurrentHashMap` because the pool needs the conditional
 * "take + maybe-trigger-refill" to be one critical section; a
 * lock-free map would force us to retry the take in a loop on
 * refill races.
 */
internal class SignedUrlPool(
    private val client: SignedUrlClient,
    private val sessionId: String,
    /**
     * F13 (KIX-UNI-01) — true when this pool serves a RESUMED stint
     * with a non-zero watermark (`session/start` sent `next_seq > 0`).
     * A resumed pool must never fall back to a positional any-URL
     * take: if the backend ignored `next_seq` (pre-Wave-1 server)
     * the pool holds lower-seq URLs whose GCS objects belong to an
     * EARLIER stint of the same session — handing one out would
     * overwrite that stint's frame. [take] drops to metadata-only
     * (null) instead. Fresh-session behavior is identical.
     */
    private val resumedStint: Boolean = false,
    private val refillThreshold: Int = DEFAULT_REFILL_THRESHOLD,
    private val refillBatchSize: Int = DEFAULT_REFILL_BATCH_SIZE,
    /**
     * Per-consumed-kind low-water mark (see [consumedKinds]). The
     * primary refill trigger: fire when ANY kind the SDK actually
     * takes drops below this, independent of how many URLs of other
     * (unconsumed) kinds still sit in the pool.
     */
    private val perKindRefillThreshold: Int = DEFAULT_PER_KIND_REFILL_THRESHOLD,
    /**
     * Coroutine scope on which refill triggers run. Default is a
     * SupervisorJob + Dispatchers.IO so a single failing refill
     * doesn't tear down peers AND we don't block the main thread.
     * Tests can pass a [kotlinx.coroutines.test.TestScope] to drive
     * timing deterministically.
     */
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) {

    /** Per-kind queue of available signed URLs, indexed by [FrameKind]. */
    private val urls: MutableMap<FrameKind, ArrayDeque<SignedUrl>> = mutableMapOf()

    /** Tracks the highest seq we've ever seen — drives [signMore]'s `fromSeq`. */
    private var highestSeqIssued: Long = -1L

    private val mutex = Mutex()

    /**
     * True while a `signMore` HTTP call is in flight. Blocks
     * duplicate triggers from piling up — without this, every
     * [take] under threshold would launch a fresh refill, hammering
     * the backend during a quiet network condition.
     */
    private var refillInFlight: Boolean = false

    /**
     * Kinds the SDK has ACTUALLY requested via [take]. The refill
     * trigger keys off these, NOT the total across all kinds. Reason:
     * when structural/OCR are disabled (compiled default 2026-07-05) —
     * or when PRE carry-forward is off — the SDK consumes only a subset
     * of the 4 signed kinds. The unconsumed kinds' URLs would otherwise
     * keep [totalUrlsLocked] permanently above [refillThreshold] while
     * the consumed kind (e.g. POST) drained to empty, so refill never
     * fired and every frame past the initial pool dropped `pool_empty`.
     * Caught by the on-device smoke on 2026-07-05.
     */
    private val consumedKinds: MutableSet<FrameKind> = mutableSetOf()

    /**
     * Seed the pool with the URLs returned by [SignedUrlClient.startSession].
     * Called exactly once per session by [ReplayUploader] right
     * after `/api/sdk/replay/session/start` returns.
     */
    suspend fun seed(initial: List<SignedUrl>) {
        mutex.withLock {
            for (url in initial) {
                addUrlLocked(url)
            }
            recomputeHighestSeqLocked()
        }
    }

    /**
     * Take a signed URL for the requested `(seq, kind)` pair, OR
     * return any URL of the right [kind] if no exact-seq match is
     * available. The latter case is rare in steady state — pre/post
     * are signed in pairs — but does happen when the pool ran dry
     * mid-session and a fresh batch arrived starting at a higher
     * seq.
     *
     * Returns `null` when the pool is empty for [kind] AND the
     * caller would have to wait for a refill — caller decides
     * whether to drop the frame OR persist it for a future retry
     * (UploadWorker handles the latter).
     *
     * On EVERY take, expired URLs are pruned from the front of the
     * queue. If the pool drops below [refillThreshold] after the
     * take, an async refill is fired (no-op if one is already in
     * flight).
     */
    suspend fun take(seq: Long, kind: FrameKind): SignedUrl? {
        val taken: SignedUrl?
        var shouldRefill = false
        mutex.withLock {
            val queue = urls[kind] ?: ArrayDeque<SignedUrl>().also { urls[kind] = it }
            consumedKinds.add(kind)
            pruneExpiredLocked(queue)
            // Prefer an exact-seq match — keeps the player-side
            // pre/post pairing intact. The backend signs both kinds
            // for every seq in `signMore`, so this is the common path.
            val exactIndex = queue.indexOfFirst { it.seq == seq }
            taken = if (exactIndex >= 0) {
                queue.removeAt(exactIndex)
            } else if (resumedStint) {
                // F13 — no positional fallback on a resumed stint:
                // a mismatched URL here is likely a lower-seq one
                // (backend that didn't honor `next_seq`) and PUTting
                // to it would overwrite an EARLIER stint's GCS frame.
                // Drop to metadata-only instead; the URL stays queued
                // for its own seq should it ever be requested.
                null
            } else {
                queue.removeFirstOrNull()
            }
            // Primary trigger: any actually-consumed kind is low.
            // Secondary floor: the legacy total-across-all-kinds check
            // (kept so a broadly-drained pool still tops up).
            if (!refillInFlight && refillThreshold > 0 &&
                (shouldRefillLocked() || totalUrlsLocked() < refillThreshold)) {
                refillInFlight = true
                shouldRefill = true
            }
        }
        if (shouldRefill) {
            scope.launch { triggerRefill() }
        }
        return taken
    }

    /**
     * Snapshot count of remaining URLs across all kinds. Tests +
     * [io.kixo.sdk.KixoDiagnostics] consume this.
     */
    suspend fun remaining(): Int = mutex.withLock { totalUrlsLocked() }

    /**
     * Force a refill even when above threshold. Used by
     * [ReplaySessionLifecycle] after a long suspend — the bulk of
     * the pool may have aged out and we want fresh URLs immediately.
     */
    suspend fun forceRefill() {
        var go = false
        mutex.withLock {
            if (!refillInFlight) {
                refillInFlight = true
                go = true
            }
        }
        if (go) triggerRefill()
    }

    /** Drop every URL — called when the session ends or replay opt-out fires. */
    suspend fun clear() {
        mutex.withLock {
            urls.clear()
            highestSeqIssued = -1L
        }
    }

    // ─── Internals (locked) ───────────────────────────────────

    private fun addUrlLocked(url: SignedUrl) {
        val kind = FrameKind.fromWire(url.kind)
        if (kind == null) {
            // Unknown kind from server — drop silently rather than
            // crash. A future "video" kind would land here until we
            // ship support.
            Log.d(TAG, "Dropping signed URL with unknown kind=${url.kind}")
            return
        }
        urls.getOrPut(kind) { ArrayDeque() }.addLast(url)
    }

    private fun recomputeHighestSeqLocked() {
        var max = highestSeqIssued
        for (queue in urls.values) {
            for (u in queue) if (u.seq > max) max = u.seq
        }
        highestSeqIssued = max
    }

    private fun totalUrlsLocked(): Int = urls.values.sumOf { it.size }

    /**
     * True when ANY kind the SDK has actually consumed is below the
     * per-kind low-water mark. This is the exhaustion signal that the
     * old total-across-all-kinds check missed once consumption became
     * uneven (structural/OCR disabled → only POST drains).
     */
    private fun shouldRefillLocked(): Boolean {
        if (consumedKinds.isEmpty()) return false
        return consumedKinds.any { (urls[it]?.size ?: 0) < perKindRefillThreshold }
    }

    /**
     * Drop URLs whose `expires_at` is already in the past. Walks
     * from the front of the queue (oldest first) and stops at the
     * first non-expired entry — backend issues URLs in monotonic
     * `expires_at` order.
     *
     * Defensive: a malformed `expires_at` (server bug) is treated
     * as non-expired so the URL still gets a chance. The backend
     * would 403 on the actual PUT and [UploadWorker] would handle
     * it.
     */
    private fun pruneExpiredLocked(queue: ArrayDeque<SignedUrl>) {
        val now = Instant.now()
        while (queue.isNotEmpty()) {
            val front = queue.first()
            val expires = parseInstantOrNull(front.expiresAt)
            if (expires != null && expires.isBefore(now)) {
                queue.removeFirst()
            } else {
                break
            }
        }
    }

    private fun parseInstantOrNull(iso: String): Instant? = try {
        Instant.parse(iso)
    } catch (e: DateTimeParseException) {
        null
    } catch (t: Throwable) {
        null
    }

    /**
     * The actual refill HTTP call. Always clears [refillInFlight]
     * in the finally block — leaking it would leave the pool stuck
     * forever once a refill failed.
     */
    private suspend fun triggerRefill() {
        try {
            val fromSeq = mutex.withLock { highestSeqIssued + 1 }
            val resp = client.signMore(sessionId, fromSeq, refillBatchSize)
            if (resp == null || resp.signedUrls.isEmpty()) {
                // Backend hiccup. The next [take] under threshold will
                // try again — refillInFlight clears below.
                return
            }
            mutex.withLock {
                for (u in resp.signedUrls) {
                    addUrlLocked(u)
                }
                recomputeHighestSeqLocked()
                // Bound accumulation of kinds we never take (e.g. PRE /
                // structural / OCR when disabled): their queues are never
                // pruned by [take], so sweep expired URLs across ALL
                // queues here, once per refill.
                for (q in urls.values) pruneExpiredLocked(q)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Refill threw — pool will retry on next under-threshold take", t)
        } finally {
            mutex.withLock { refillInFlight = false }
        }
    }

    companion object {
        /**
         * Default refill threshold (across all kinds). 12 = ~3 seqs
         * worth of URLs (4 kinds × 3 seqs). Below this, we eagerly
         * top up so the pool doesn't drain to zero between captures.
         * Tuned to match the iOS lease pool behaviour.
         */
        const val DEFAULT_REFILL_THRESHOLD: Int = 12

        /**
         * Per-consumed-kind low-water mark. 3 ≈ 3 seqs of headroom for
         * a single kind — enough to cover the ~150-300 ms sign RTT at
         * the capture cadence floor. The PRIMARY refill trigger.
         */
        const val DEFAULT_PER_KIND_REFILL_THRESHOLD: Int = 3

        /**
         * Default batch size for [SignedUrlClient.signMore]. The
         * backend issues 4 kinds per seq, so 10 = 40 URLs per RTT
         * — covers ~10 captures before another sign call.
         */
        const val DEFAULT_REFILL_BATCH_SIZE: Int = 10

        private const val TAG = "Kixo.SignedUrlPool"
    }
}
