package io.kixo.sdk.internal.replay

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.Window

/**
 * Renders a window into a `Bitmap` for the replay upload pipeline.
 * Mirrors iOS [FrameSnapshotter.swift] semantics adapted to Android's
 * capture primitives.
 *
 * **AND-CAP-01 (2026-07-05) — PixelCopy is now the DEFAULT.**
 *
 *  1. **`PixelCopy.request(Window, Bitmap, callback, handler)`** —
 *     async, GPU-backed, reads the actual composited pixels off the
 *     UI thread. Captures SurfaceView / TextureView / GLSurfaceView /
 *     video / Compose pixels that `View.draw(Canvas)` renders BLACK.
 *     Sentry Android defaults to this ("slightly lower overhead than
 *     Canvas"). The destination bitmap is allocated at a downscaled
 *     size in `RGB_565` (half the memory of ARGB_8888; the frame is
 *     JPEG'd to 20 KB anyway). API 24+ — our minSdk — so it's always
 *     present, but we still fall back on failure.
 *
 *  2. **`View.draw(Canvas)`** — synchronous, main-thread — is the
 *     FALLBACK: no valid/attached window, PixelCopy returning a non-
 *     SUCCESS status, or PixelCopy throwing. `View.draw()` does NOT
 *     redact anything on its own — a WebView / `kxRedact`-tagged view /
 *     email+phone `EditText` all render their plaintext into the Canvas.
 *     So the fallback MUST composite the same window-space
 *     [StructuralSnapshotter.collectRedactionRects] the PixelCopy SUCCESS
 *     branch uses (here at scale = 1.0 — the Canvas bitmap is full window
 *     size). The caller drops the frame entirely when it couldn't resolve
 *     those rects (over-mask by dropping).
 *
 * **Masking under PixelCopy.** PixelCopy captures raw window pixels
 * with NO per-view redaction. The caller supplies WINDOW-space
 * redaction rects (from [StructuralSnapshotter.collectRedactionRects],
 * the same view-tree pass we already run) and we composite opaque
 * black rects over them OFF the main thread, on the PixelCopy callback
 * handler, BEFORE the callback returns the masked bitmap. If a rect
 * can't be resolved the caller over-masks / falls back to Canvas.
 *
 * **captured_at contract.** The PixelCopy callback fires at the REAL
 * capture wall-clock moment (a few ms after the request). The caller
 * stamps `captured_at_post` from that moment, not the request time —
 * so the player shows the tap on the pre-tap frame (AND-CAP-05).
 *
 * **Thread.** Reading window/view geometry + issuing the PixelCopy
 * REQUEST happens on the main thread. The GPU copy + the mask
 * composite run on the [callbackThread] we own (one reused
 * HandlerThread, not one per capture). The Canvas fallback runs
 * synchronously on main.
 */
internal object FrameSnapshotter {

    private const val TAG = "Kixo"

    /**
     * Single reused background thread for PixelCopy callbacks + mask
     * compositing. Lazily started; never one-per-capture. Kept alive
     * for the SDK lifetime (cheap idle thread) — [ReplayController]
     * has no per-session teardown for it and re-acquire is free.
     */
    private val callbackHandler: Handler by lazy {
        val thread = HandlerThread("kixo-pixelcopy").apply { start() }
        Handler(thread.looper)
    }

    private val maskPaint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
    }

    /**
     * Async window snapshot. Default path is PixelCopy; the [callback]
     * fires on the PixelCopy callback thread with the (masked) bitmap,
     * or `null` on failure. The bitmap is RGB_565 at [captureScale] of
     * the window size. Ownership transfers to the callback — it must
     * recycle or hand off.
     *
     * @param window the target window (`activity.window`).
     * @param captureScale downscale factor (0,1]; the destination
     *   bitmap is allocated at this fraction of the window size.
     * @param redactionRects WINDOW-space rects to paint opaque over,
     *   scaled by [captureScale] before compositing. Empty = no PII.
     * @param onFrame invoked with the captured+masked bitmap (or null).
     */
    fun snapshotViaPixelCopy(
        window: Window,
        captureScale: Float,
        redactionRects: List<Rect>,
        onFrame: (Bitmap?) -> Unit,
    ) {
        val decor = window.decorView
        val width = decor.width
        val height = decor.height
        if (width <= 0 || height <= 0) {
            onFrame(null)
            return
        }
        val scale = captureScale.coerceIn(0.1f, 1f)
        val dstW = (width * scale).toInt().coerceAtLeast(1)
        val dstH = (height * scale).toInt().coerceAtLeast(1)

        val bitmap: Bitmap = try {
            // RGB_565 halves the memory vs ARGB_8888 — window frames
            // are opaque so we lose no visible fidelity, and the JPEG
            // encode discards alpha anyway.
            Bitmap.createBitmap(dstW, dstH, Bitmap.Config.RGB_565)
        } catch (oom: OutOfMemoryError) {
            Log.w(TAG, "PixelCopy bitmap alloc OOM (${dstW}x${dstH})")
            onFrame(null)
            return
        }
        try {
            PixelCopy.request(
                window,
                bitmap,
                { result ->
                    if (result == PixelCopy.SUCCESS) {
                        // Composite the mask rects OFF main (we're on
                        // the PixelCopy callback thread here).
                        try {
                            compositeMask(bitmap, redactionRects, scale)
                        } catch (t: Throwable) {
                            // A masking failure MUST NOT ship an
                            // unredacted frame — drop it (over-mask by
                            // dropping). R6: never crash the host.
                            Log.w(TAG, "mask composite failed — dropping frame", t)
                            recycleQuiet(bitmap)
                            onFrame(null)
                            return@request
                        }
                        onFrame(bitmap)
                    } else {
                        Log.w(TAG, "PixelCopy result=$result — caller should fall back")
                        recycleQuiet(bitmap)
                        onFrame(null)
                    }
                },
                callbackHandler,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "PixelCopy.request failed — caller should fall back", t)
            recycleQuiet(bitmap)
            onFrame(null)
        }
    }

    /**
     * Paint opaque rects over [redactionRects] (given in unscaled
     * WINDOW space) on [bitmap] (already downscaled by [scale]). Runs
     * on the PixelCopy callback thread.
     */
    private fun compositeMask(bitmap: Bitmap, redactionRects: List<Rect>, scale: Float) {
        if (redactionRects.isEmpty()) return
        val canvas = Canvas(bitmap)
        for (r in redactionRects) {
            val l = (r.left * scale)
            val t = (r.top * scale)
            val rr = (r.right * scale)
            val b = (r.bottom * scale)
            canvas.drawRect(l, t, rr, b, maskPaint)
        }
    }

    /**
     * Synchronous Canvas fallback. Renders [view] into a pooled
     * ARGB_8888 bitmap on the main thread (~3-5 ms). Used when PixelCopy
     * is unavailable / failed. **`View.draw()` does NOT redact anything**
     * — a WebView / `kxRedact`-tagged view / email+phone `EditText`
     * renders its plaintext straight into the Canvas — so this path
     * composites the same window-space [redactionRects] the PixelCopy
     * SUCCESS branch masks (from [StructuralSnapshotter.collectRedactionRects]).
     * The bitmap is full window size, so the rects apply at scale = 1.0.
     * Returns `null` on zero-bounds / OOM / draw failure, or when the
     * mask composite fails (over-mask by dropping, never ship unmasked).
     *
     * The caller must pass the SAME rects it would have composited on the
     * PixelCopy path; when it couldn't resolve them (rect walk threw) it
     * drops the frame instead of calling this.
     *
     * **MUST be called on the main thread.**
     */
    fun snapshotViaCanvas(view: View, redactionRects: List<Rect>): Bitmap? {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            Log.w(TAG, "snapshotViaCanvas called off-main; refusing")
            return null
        }
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) return null

        val bitmap = BitmapPool.acquireOrAlloc(width, height)
            ?: run {
                Log.w(TAG, "bitmap alloc OOM (${width}x${height})")
                return null
            }
        bitmap.eraseColor(0)
        return try {
            view.draw(Canvas(bitmap))
            // The Canvas bitmap is full window size (no captureScale), so
            // the WINDOW-space rects composite 1:1. A masking failure MUST
            // NOT ship an unredacted frame — drop it (over-mask by
            // dropping), mirroring the PixelCopy SUCCESS branch.
            compositeMask(bitmap, redactionRects, scale = 1.0f)
            bitmap
        } catch (t: Throwable) {
            Log.w(TAG, "view.draw / mask composite failed", t)
            BitmapPool.release(bitmap)
            null
        }
    }

    /**
     * Return a no-longer-needed bitmap to the pool (Canvas path) or
     * recycle it (PixelCopy path allocates fresh RGB_565 outside the
     * pool). The pool refuses non-mutable / wrong-config bitmaps and
     * recycles them, so this is safe for both origins.
     */
    fun release(bitmap: Bitmap?) {
        BitmapPool.release(bitmap)
    }

    private fun recycleQuiet(bitmap: Bitmap?) {
        if (bitmap == null || bitmap.isRecycled) return
        try {
            bitmap.recycle()
        } catch (_: Throwable) { /* swallow */ }
    }

    /**
     * Whether the supplied View hierarchy contains any view that
     * historically forced PixelCopy (SurfaceView / TextureView /
     * GLSurfaceView). Retained for diagnostics — PixelCopy is now the
     * default for ALL hierarchies, so this is no longer a branch on
     * the capture path.
     */
    fun containsSurfaceView(root: View): Boolean {
        if (isSurfaceLike(root)) return true
        if (root is android.view.ViewGroup) {
            for (i in 0 until root.childCount) {
                val child = root.getChildAt(i) ?: continue
                if (containsSurfaceView(child)) return true
            }
        }
        return false
    }

    // FIX 3 (2026-07-05) — `containsVisibleSurface` (M2 surface-heartbeat
    // probe) removed with the surface-heartbeat: masked surfaces produce no
    // visual change, so nothing needs to detect a *visible* surface to force
    // a periodic capture any more. [isSurfaceLike] (type-based) remains the
    // shared capture/redaction predicate; [containsSurfaceView] remains for
    // diagnostics.

    /**
     * FIX 2 (2026-07-05, single-owner surface predicate) — THE canonical
     * "is this a surface-composited view?" test, shared by BOTH the
     * capture-side detection ([containsSurfaceView]) AND the redaction
     * walk ([StructuralSnapshotter.defaultShouldRedactSubtree]) so the two
     * can't drift. Matched by TYPE, not simple-name, so a custom subclass
     * (`class MyVideoView : SurfaceView`, `class Foo : TextureView`) is
     * caught too — a subclass is captured by PixelCopy but was previously
     * NOT given a redaction rect, shipping its pixels UNMASKED (camera
     * preview / video privacy leak). [GLSurfaceView] extends [SurfaceView]
     * so the base-type check covers it; ExoPlayer's default `SurfaceView`-
     * backed video is likewise covered.
     */
    fun isSurfaceLike(view: View): Boolean =
        view is SurfaceView || view is TextureView

    /**
     * Class-name predicate retained for JVM unit tests that assert the
     * surface families without a live [View]. The runtime path uses the
     * TYPE-based [isSurfaceLike] (which also catches subclasses); this is
     * the exact-name subset those tests pin.
     */
    fun isSurfaceLikeClassName(simpleName: String): Boolean =
        simpleName == "SurfaceView" ||
            simpleName == "TextureView" ||
            simpleName == "GLSurfaceView"
}
