package io.kixo.sdk.internal.replay

import android.util.Log
import android.view.View
import android.view.ViewTreeObserver
import java.lang.ref.WeakReference

/**
 * **AND-CAP-02 (2026-07-05 dirty-driven cadence) — the dirty-signal
 * layer of the Mixpanel/PostHog-style dirty-driven capture model.**
 *
 * Android has NO swizzling need (the iOS advantage inverted): instead
 * of patching `UIViewController.viewDidAppear` / `UIView.layoutSubviews`
 * IMPs, we attach a [ViewTreeObserver.OnDrawListener] +
 * [ViewTreeObserver.OnGlobalLayoutListener] to the current window's
 * decor view. Every draw / layout pass MARKS THE SCREEN DIRTY; a
 * capture proceeds only when the flag is set, bounded by a settle
 * delay + a cadence floor. Static screen ⇒ no marks ⇒ zero capture
 * work. Companion to iOS `DirtyTracker.swift`.
 *
 * This type is ONLY the trigger side. It owns:
 *   - the two [ViewTreeObserver] listeners, attached ONCE per decor
 *     view and only while [setEnabled] is true — a sampled-out /
 *     replay-off process never attaches a listener;
 *   - the atomic dirty flag + per-lane dispatch coalescing.
 *
 * The DECISION side — settle scheduling, the 5 s heartbeat, and the
 * render-vs-skip verdict — lives in [ReplayController]. This tracker
 * never renders, never scans, never allocates on the hot path.
 *
 * **Hot-path budget** (`onDraw` fires per frame, `onGlobalLayout` per
 * layout pass): one `synchronized` acquire + a branch + at most one
 * bool store. A new-window-of-a-lane mark also fires exactly one
 * [onDirty] callback whose only job is to post one delayed settle.
 *
 * **Lanes** — two independent coalescing lanes so a screen ENTRY can
 * never be swallowed by generic layout churn (first-frame guarantee):
 *   - [Lane.GENERIC] — draw / layout / scroll marks.
 *   - [Lane.SCREEN_ENTRY] — screen-visit marks (from Agent 9's screen
 *     tracker). Coalesced only against itself, so every screen change
 *     schedules its own settle even when a generic attempt is pending.
 *   - [Source.INTERACTION] marks are flag-only (no dispatch): the tap
 *     pipeline schedules its own settle. The mark still keeps the
 *     heartbeat honest about "something changed since last consume".
 *
 * **Threading.** All marks arrive on the main thread (draw / layout /
 * lifecycle callbacks). The state is guarded by [lock] anyway so a
 * future off-main mark is safe.
 */
internal object DirtyTracker {

    private const val TAG = "Kixo.DirtyTracker"

    /**
     * What produced a dirty mark. Drives the coalescing lane and the
     * `tap_kind` trigger string the eventual capture ships with
     * (`screen_change` / `dirty` / `heartbeat`).
     */
    enum class Source {
        /** A screen visit was recorded (Agent 9's ScreenTracker). */
        SCREEN_ENTRY,
        /** `onDraw` fired — pixel content churned. */
        DRAW,
        /** `onGlobalLayout` fired — layout churned. */
        LAYOUT,
        /** A scroll gesture ended (`ScrollEndDetector`). Same lane as DRAW. */
        SCROLL,
        /** A tap reached the interceptor. Mark-only — the tap pipeline owns its settle. */
        INTERACTION;

        /** Coalescing lane, or `null` for a mark-only source. */
        val lane: Lane?
            get() = when (this) {
                SCREEN_ENTRY -> Lane.SCREEN_ENTRY
                DRAW, LAYOUT, SCROLL -> Lane.GENERIC
                INTERACTION -> null
            }
    }

    /** Dispatch-coalescing lane — one pending settle attempt per lane. */
    enum class Lane { GENERIC, SCREEN_ENTRY }

    /** Outcome of one [markDirty] call — computed by the pure [markDecision]. */
    data class MarkDecision(val marksDirty: Boolean, val dispatches: Boolean)

    /**
     * The complete mark policy as a pure function (unit-testable, no
     * state / Android):
     *   - disabled → no-op;
     *   - INTERACTION → mark, never dispatch;
     *   - SCREEN_ENTRY → mark; dispatch unless a screen-entry attempt
     *     is already pending (generic pending does NOT suppress it —
     *     first-frame guarantee);
     *   - DRAW / LAYOUT / SCROLL → mark; dispatch only when NO attempt
     *     is pending on either lane.
     */
    fun markDecision(
        source: Source,
        enabled: Boolean,
        genericPending: Boolean,
        screenEntryPending: Boolean,
    ): MarkDecision {
        if (!enabled) return MarkDecision(marksDirty = false, dispatches = false)
        return when (source) {
            Source.INTERACTION -> MarkDecision(marksDirty = true, dispatches = false)
            Source.SCREEN_ENTRY ->
                MarkDecision(marksDirty = true, dispatches = !screenEntryPending)
            Source.DRAW, Source.LAYOUT, Source.SCROLL ->
                MarkDecision(
                    marksDirty = true,
                    dispatches = !genericPending && !screenEntryPending,
                )
        }
    }

    // ─── State (all behind one lock) ───────────────────────────────

    private val lock = Any()
    private var enabled = false
    private var dirty = false
    private var genericPending = false
    private var screenEntryPending = false

    /**
     * **AND-CAP-02 skip-unchanged bypass.** `true` when at least one
     * [Source.DRAW] (`onDraw` fired ⇒ pixels demonstrably changed) has
     * marked the screen dirty since the last [consumeDirty]. Threaded to
     * the ship site so pure PIXEL churn inside an identical structure +
     * bounds + text (a playing video, an in-place `setImageBitmap` with
     * the same layout) is NOT dedup-skipped by the structural signature
     * — which is blind to pixels. A LAYOUT / settle / screen-entry
     * source leaves this false, so a true structural no-op can still be
     * skipped. Bounded by the controller's cadence floor, so a
     * constantly-animating screen produces at most one frame per floor
     * interval, not a storm.
     */
    private var drawSinceConsume = false

    /**
     * Trigger-engine sink. CONTRACT: assign BEFORE [setEnabled] `true`
     * and don't reassign while enabled. Called synchronously on the
     * marking thread (main), at most once per settle window per lane.
     */
    @Volatile
    var onDirty: ((Source) -> Unit)? = null

    // ─── Listener attach state ─────────────────────────────────────

    private var attachedRef: WeakReference<View>? = null
    private val drawListener = ViewTreeObserver.OnDrawListener { markDirty(Source.DRAW) }
    private val layoutListener = ViewTreeObserver.OnGlobalLayoutListener { markDirty(Source.LAYOUT) }

    // ─── Marking (hot path) ────────────────────────────────────────

    /** Record that the screen (may have) changed. See the type doc. */
    fun markDirty(source: Source) {
        val decision = synchronized(lock) {
            val d = markDecision(source, enabled, genericPending, screenEntryPending)
            if (d.marksDirty) {
                dirty = true
                // Remember a DRAW-sourced mark so the ship site can
                // bypass the structure-only signature dedup for pure
                // pixel churn (video / in-place bitmap). Any non-DRAW
                // source leaves the flag as-is (a prior DRAW in the same
                // window still counts).
                if (source == Source.DRAW) drawSinceConsume = true
            }
            if (d.dispatches) {
                when (source.lane) {
                    Lane.GENERIC -> genericPending = true
                    Lane.SCREEN_ENTRY -> screenEntryPending = true
                    null -> {}
                }
            }
            d
        }
        if (decision.dispatches) {
            try {
                onDirty?.invoke(source)
            } catch (t: Throwable) {
                Log.w(TAG, "onDirty sink threw", t)
            }
        }
    }

    // ─── Trigger-engine bookkeeping ────────────────────────────────

    /** Peek — used by the heartbeat's cheap "anything at all?" check. */
    fun isDirty(): Boolean = synchronized(lock) { dirty }

    /**
     * Whether a [Source.DRAW] mark has landed since the last
     * [consumeDirty]. The ship site reads this to decide whether to
     * bypass the structure-only signature dedup for pure pixel churn.
     * See [drawSinceConsume]. Must be read BEFORE [consumeDirty] clears
     * it (or captured as [consumeDirty]'s return-adjacent state).
     */
    fun wasDrawSourced(): Boolean = synchronized(lock) { drawSinceConsume }

    /**
     * Clear the dirty flag at CAPTURE-ATTEMPT START (the attempt is
     * about to assess the current state, so everything marked so far
     * is covered; changes DURING the capture re-mark). Also clears the
     * [drawSinceConsume] flag — the capture that follows covers every
     * DRAW so far. Returns prior dirty state.
     */
    fun consumeDirty(): Boolean = synchronized(lock) {
        val was = dirty
        dirty = false
        drawSinceConsume = false
        was
    }

    /**
     * Release a lane's pending flag — the scheduled settle attempt is
     * running (or was abandoned), so the NEXT mark on the lane may
     * dispatch again.
     */
    fun clearPending(lane: Lane) = synchronized(lock) {
        when (lane) {
            Lane.GENERIC -> genericPending = false
            Lane.SCREEN_ENTRY -> screenEntryPending = false
        }
    }

    /**
     * Re-arm after a `throttled` gate verdict: the change is still
     * unshipped, so restore the dirty flag and retake the lane's
     * pending slot. Returns `true` when the caller owns the re-
     * schedule; `false` when another mark already dispatched a fresh
     * attempt (nothing to do — that attempt covers us).
     */
    fun rearmAfterThrottle(lane: Lane): Boolean = synchronized(lock) {
        dirty = true
        when (lane) {
            Lane.GENERIC -> {
                if (genericPending) return@synchronized false
                genericPending = true
            }
            Lane.SCREEN_ENTRY -> {
                if (screenEntryPending) return@synchronized false
                screenEntryPending = true
            }
        }
        true
    }

    /**
     * Master switch, flipped by [ReplayController]: `true` on replay
     * start + foreground resume; `false` on background / stop / optOut.
     * Disabling clears all flags so a resumed stint starts clean, and
     * detaches the [ViewTreeObserver] listeners.
     */
    fun setEnabled(on: Boolean) {
        synchronized(lock) {
            enabled = on
            if (!on) {
                dirty = false
                genericPending = false
                screenEntryPending = false
                drawSinceConsume = false
            }
        }
        if (!on) detach()
    }

    // ─── Listener attach / detach ──────────────────────────────────

    /**
     * Attach the draw + layout listeners to [decorView]'s
     * ViewTreeObserver. Idempotent per decor view — re-attaching to
     * the SAME view is a no-op; attaching to a NEW view detaches the
     * old one first (Activity switch / recreation). Main thread only.
     */
    fun attachTo(decorView: View) {
        val current = attachedRef?.get()
        if (current === decorView) return
        detach()
        val vto = try {
            decorView.viewTreeObserver
        } catch (t: Throwable) {
            Log.w(TAG, "viewTreeObserver unavailable", t)
            return
        }
        if (!vto.isAlive) return
        try {
            vto.addOnDrawListener(drawListener)
            vto.addOnGlobalLayoutListener(layoutListener)
            attachedRef = WeakReference(decorView)
        } catch (t: Throwable) {
            // Some observers refuse listeners mid-dispatch; harmless.
            Log.w(TAG, "listener attach failed", t)
        }
    }

    /** Detach the current listeners, if any. Main thread only. */
    fun detach() {
        val view = attachedRef?.get()
        attachedRef = null
        if (view == null) return
        try {
            val vto = view.viewTreeObserver
            if (vto.isAlive) {
                vto.removeOnDrawListener(drawListener)
                vto.removeOnGlobalLayoutListener(layoutListener)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "listener detach failed", t)
        }
    }

    // ─── Test hooks ────────────────────────────────────────────────

    @androidx.annotation.VisibleForTesting
    internal fun stateForTesting(): State =
        synchronized(lock) {
            State(enabled, dirty, genericPending, screenEntryPending, drawSinceConsume)
        }

    @androidx.annotation.VisibleForTesting
    internal data class State(
        val enabled: Boolean,
        val dirty: Boolean,
        val genericPending: Boolean,
        val screenEntryPending: Boolean,
        val drawSinceConsume: Boolean = false,
    )

    @androidx.annotation.VisibleForTesting
    internal fun resetForTesting() {
        synchronized(lock) {
            enabled = false
            dirty = false
            genericPending = false
            screenEntryPending = false
            drawSinceConsume = false
        }
        onDirty = null
        attachedRef = null
    }
}

/**
 * **AND-CAP-02 — pure trigger-engine decisions, split out of
 * [ReplayController] so the scheduler truth table is unit-testable
 * without a window / handler.** Mirrors iOS `DirtyTrigger`.
 */
internal object DirtyTrigger {

    /** Heartbeat gate: fire only when dirty AND no attempt in the last interval. */
    fun heartbeatShouldFire(
        isDirty: Boolean,
        msSinceLastGateEval: Long,
        intervalMs: Long,
    ): Boolean = isDirty && msSinceLastGateEval >= intervalMs

    // FIX 3 (2026-07-05) — `heartbeatShouldConsider` (M2 surface-driven
    // entry gate) removed. The surface-heartbeat is gone (masked surfaces
    // never visually change), so the heartbeat's entry condition is simply
    // `isDirty()` again — see ReplayController.heartbeatFired.

    /**
     * M3 (2026-07-05) — pure cadence-FLOOR decision. `true` when a capture
     * must be THROTTLED because the last capture ATTEMPT (not success —
     * the caller now advances the timestamp on dispatch, so a screen whose
     * captures keep failing is still throttled) is within [floorMs].
     *
     *   - `floorMs <= 0` → no throttle (feature off);
     *   - `lastAttemptElapsedMs == 0` → never attempted this stint, don't
     *     throttle the first frame;
     *   - else throttle iff `nowElapsedMs - lastAttemptElapsedMs < floorMs`.
     *
     * Split out of [ReplayController] so the "≤ 1 attempt per floor even
     * when captures keep failing" guarantee is unit-testable without a
     * live handler / window.
     */
    fun shouldThrottleCapture(
        nowElapsedMs: Long,
        lastAttemptElapsedMs: Long,
        floorMs: Long,
    ): Boolean =
        floorMs > 0L &&
            lastAttemptElapsedMs != 0L &&
            (nowElapsedMs - lastAttemptElapsedMs) < floorMs
}

/**
 * **AND-CAP-04 — server-knob clamps for the cadence + compression
 * engine.** Pure so the bounds are pinnable in unit tests. `null` =
 * the server value is absent or nonsense (non-finite / non-positive)
 * → keep the compiled default; out-of-band finite values clamp into
 * range (an operator typo shouldn't wedge the pipeline). Mirrors iOS
 * `DirtyCadenceClamp` + `ReplayCompressionClamp`.
 */
internal object DirtyCadenceClamp {

    /** `replay.postTapSettleMs` → 100…5000 ms. */
    fun settleMs(value: Double?): Long? {
        if (value == null || !value.isFinite() || value <= 0.0) return null
        return value.coerceIn(100.0, 5000.0).toLong()
    }

    /** `replay.dirtyHeartbeatSec` (SECONDS on the wire) → 1…60 s, returned as MS. */
    fun heartbeatMs(seconds: Double?): Long? {
        if (seconds == null || !seconds.isFinite() || seconds <= 0.0) return null
        return (seconds.coerceIn(1.0, 60.0) * 1000.0).toLong()
    }

    /** `replay.captureMinIntervalMs` → 0…10000 ms (0 = no throttle). */
    fun captureMinIntervalMs(value: Double?): Long? {
        if (value == null || !value.isFinite() || value < 0.0) return null
        return value.coerceIn(0.0, 10_000.0).toLong()
    }

    /**
     * `replay.heicQuality` (0-1 fraction on the wire, cross-platform)
     * → Android `jpegQuality` 1…100. iOS ships HEIC 0.05…0.5; we scale
     * to a JPEG int and clamp to a useful 5…95 band.
     */
    fun jpegQualityFromHeic(fraction: Double?): Int? {
        if (fraction == null || !fraction.isFinite() || fraction <= 0.0) return null
        return (fraction * 100.0).coerceIn(5.0, 95.0).toInt()
    }

    /** `replay.captureScale` → 0.3…1.0. */
    fun captureScale(value: Double?): Float? {
        if (value == null || !value.isFinite() || value <= 0.0) return null
        return value.coerceIn(0.3, 1.0).toFloat()
    }
}
