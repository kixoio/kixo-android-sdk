package io.kixo.sdk.internal.queue

import android.content.Context
import io.kixo.sdk.KixoConfiguration
import io.kixo.sdk.internal.context.DeviceInfo
import io.kixo.sdk.internal.identity.IdentityManager
import io.kixo.sdk.internal.model.InitRequest
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.model.toJsonElement
import io.kixo.sdk.internal.privacy.PiiFilter
import io.kixo.sdk.internal.storage.EventStorageHelper
import io.kixo.sdk.internal.storage.SqliteEventStore
import io.kixo.sdk.internal.transport.HttpClientFactory
import io.kixo.sdk.internal.transport.Transport
import java.time.Instant
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlin.random.Random

/**
 * Builds the live [EventQueue] from real peer-agent types and exposes
 * a public-facade-facing wrapper [KixoEventQueueRef].
 *
 * **Wave 6 refactor (May 2026):** earlier revisions wrapped every peer
 * type (`storage.EventStore`, `transport.Transport`, `model.KixoEvent`,
 * `model.BatchPayload`, `context.DeviceInfo`, `model.EnrichedContext`)
 * in a queue-side adapter so the queue could declare narrow
 * "parallel-universe" stub interfaces. The adapters added ~280 LOC
 * with no behavioural value once Agent 5's parallel-build phase ended.
 *
 * This file now wires the queue against the real types directly.
 * [KixoEventQueueRef] is the only remaining wrapper, and only because
 * the public facade's `EventQueueRef` interface in `Kixo.kt` is
 * `private` — we can't satisfy it directly from a non-nested type.
 *
 * Per AGENT_BRIEFING.md §6 file-ownership: this file lives in
 * `internal/queue/` (Agent 5's folder) because the wiring is a queue
 * concern. We READ peer types but never modify them.
 */
/**
 * Functional handle the public facade uses to wrap into the
 * `Kixo.PushTransportBridge` private interface. SAM-style so the
 * facade's anonymous-object adapter is a one-liner.
 */
internal fun interface PushTransportInvoke {
    operator fun invoke(token: String, provider: io.kixo.sdk.PushProvider)
}

internal object QueueWiring {

    /**
     * Build the live `EventQueue` + return an [KixoEventQueueRef]
     * suitable for the public facade's `Wiring.queueRef` slot.
     *
     * Side effects (in order):
     *  1. Construct the real `SqliteEventStore` at `<filesDir>/kixo/events.db`
     *     and run `recoverInFlight()` once to re-claim crashed in-flight rows.
     *  2. Construct the shared `OkHttpClient` (debug-build logging on).
     *  3. Construct the real `Transport` against the configured base URL.
     *  4. Seed `ConfigHolder` from the [KixoConfiguration] snapshot.
     *  5. Construct the queue-internal `BatchPayloadAssembler` with
     *     the real `DeviceInfo`.
     *  6. Construct the queue with the real store + transport +
     *     assembler + a SupervisorJob-rooted scope. No adapters.
     *  7. Optimistically transition lifecycle to `Running` so events
     *     ship right away. If creds are wrong, backend's 401 →
     *     `PausedByServer("http_401")` flips state via the existing
     *     apply-response path.
     *  8. Return [KixoEventQueueRef] for the public facade.
     */
    /**
     * Aggregate of everything `QueueWiring.build` constructs that the
     * facade needs to wire up. Lets us hand back the queue ref AND the
     * push-transport bridge AND the underlying `Transport` (so future
     * subsystems — replay uploader, etc — can share the same OkHttp
     * client + creds without rebuilding).
     */
    internal data class Built(
        val queueRef: KixoEventQueueRef,
        val pushTransport: PushTransportInvoke,
        val transport: Transport,
        val httpClient: okhttp3.OkHttpClient,
        val scope: CoroutineScope,
    )

    fun build(
        context: Context,
        config: KixoConfiguration,
        identity: IdentityManager,
        deviceInfo: DeviceInfo,
        releaseId: String? = null,
    ): Built {
        // 1. Real store + recover in-flight. The Helper builds the
        //    SupportSQLiteOpenHelper (lazy file create at /filesDir/kixo/),
        //    SqliteEventStore wraps it.
        val store = SqliteEventStore(EventStorageHelper(context).create())
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
        scope.launch { store.recoverInFlight() }

        // 2. + 3. HTTP client + transport. Logging on in debug.
        val httpClient = HttpClientFactory.create(enableLogging = config.debug)
        val json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = false
        }
        val transport = Transport(
            httpClient = httpClient,
            baseUrl = config.apiHost,
            json = json,
        )

        // 4. Seed ConfigHolder from the user's KixoConfiguration so
        //    BatchPayloadAssembler.assemble() reads the right env / creds.
        ConfigHolder.set(
            ConfigHolder.Snapshot(
                projectId = config.projectId,
                apiKey = config.apiKey,
                environment = config.environment,
                apiHost = config.apiHost,
                appVersion = appVersion(context),
                bundleId = context.packageName,
                releaseId = releaseId.orEmpty(),
                maxBufferSize = 200,
                flushAt = 20,
                flushIntervalMs = 30_000L,
                debug = config.debug,
            ),
        )

        // 5. Assembler now takes the real DeviceInfo — no adapter.
        val assembler = BatchPayloadAssembler(deviceInfo = deviceInfo)

        // 6. Queue itself. Real types throughout — no adapters.
        val queue = EventQueue(
            store = store,
            transport = transport,
            payloadAssembler = assembler,
            scope = scope,
            flushAt = 20,
            flushIntervalMs = 30_000L,
            maxBufferSize = 200,
        )

        // 7. Optimistic Running so events ship immediately. The async
        // init below will downgrade to PausedByServer on a `paused`
        // response (kill-switch) — but the periodic flush won't have
        // sent anything in the ~50-200 ms init takes anyway. If init
        // fails (network blip), we stay Running and the backend's
        // auto-app-discovery path on /api/sdk/batch fills in
        // `release_id` server-side — no events lost.
        queue.setLifecycleState(LifecycleState.Running)

        // 8. Wave 6: real /api/sdk/init wiring. Fires async on the
        // SDK scope so cold-launch isn't blocked. On success we
        // stamp the resolved `release_id` into ConfigHolder so
        // subsequent batches embed it (vs the empty-string fallback
        // that triggers backend auto-discovery on every batch).
        // On `paused: true` (server kill-switch) we transition the
        // lifecycle to PausedByServer — events stop shipping.
        //
        // Wave 9 — retry on transient failure (network blip, 5xx)
        // with capped exponential backoff + ±25% jitter so a million
        // installs recovering from a backend outage don't all retry
        // in lockstep. We don't retry forever: 6 attempts (5s/10s/
        // 20s/40s/80s/160s with jitter, total ~5 min) is enough to
        // cover the typical reconnect window. After that the queue
        // stays in optimistic Running and `/api/sdk/batch`'s server-
        // side auto-discovery fills in `release_id` per batch.
        scope.launch { runInitWithRetry(config, context, transport, queue) }

        // 9. Public-facade-facing wrapper + push bridge using the same
        //    transport + scope.
        val queueRef = KixoEventQueueRef(queue, identity, deviceInfo)
        val pushBridge = buildPushTransportBridge(transport, identity, scope)
        return Built(queueRef, pushBridge, transport, httpClient, scope)
    }

    /**
     * Real implementation of `Kixo.PushTransportBridge` — sends a
     * plaintext push token to `/api/sdk/push/register`. Wave 7 fix:
     * before this, `Kixo.setPushToken(...)` routed through a no-op
     * bridge so the token never actually reached the backend.
     *
     * Token plaintext crosses the wire here ONLY (per AGENT_BRIEFING.md
     * R10). Every other event-stream reference uses SHA-256.
     */
    fun buildPushTransportBridge(
        transport: Transport,
        identity: IdentityManager,
        scope: CoroutineScope,
    ): PushTransportInvoke = PushTransportInvoke { token, provider ->
        // Snapshot creds once. ConfigHolder is process-stable after
        // configure(); we never mid-flight rotate creds at runtime.
        val cfg = ConfigHolder.snapshot()
        if (cfg.projectId.isEmpty() || cfg.apiKey.isEmpty()) {
            // Pre-configure call (would have buffered into the
            // facade's pre-init ring — should never reach here, but
            // belt-and-braces).
            return@PushTransportInvoke
        }
        val req = io.kixo.sdk.internal.model.PushRegisterRequest(
            projectId = cfg.projectId,
            apiKey = cfg.apiKey,
            deviceId = identity.deviceId(),
            userId = identity.userId(),
            token = token,
            // platform default = "android"
            // App-approval gate identity (2026-06-28): the backend
            // pauses push/register for an unrecognised app, so ship the
            // resolved release_id + the app bundle so the gate resolves
            // (or self-registers) an approved app. Mirrors iOS b31c7a1.
            // releaseId is "" until /api/sdk/init lands — the backend
            // treats that as falsy and uses the bundle_id envelope.
            releaseId = cfg.releaseId,
            bundleId = cfg.bundleId,
            environment = cfg.environment,
            sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
        )
        scope.launch {
            try {
                val ok = transport.postPushRegister(req)
                if (!ok && cfg.debug) {
                    android.util.Log.w(
                        "Kixo.Push",
                        "registerPushToken failed (transient or 4xx); the next setPushToken() call retries",
                    )
                }
            } catch (t: Throwable) {
                // R6 — never crash the host.
                if (cfg.debug) android.util.Log.w("Kixo.Push", "registerPushToken threw", t)
            }
        }
    }

    /**
     * Wave 9 — `/api/sdk/init` with capped exponential backoff +
     * ±25% jitter. Stops on:
     *   - First successful response (stamps release_id, returns)
     *   - `paused: true` (server kill-switch — flips queue to
     *     `PausedByServer` and stops retrying)
     *   - [INIT_RETRY_ATTEMPTS] consecutive failures (gives up;
     *     queue stays in optimistic Running and per-batch auto-
     *     discovery fills release_id)
     *
     * Retry schedule (median, before jitter): 5 / 10 / 20 / 40 / 80
     * / 160 sec — covers ~5 minutes of reconnection. Total wall-
     * clock cost in the failure-then-recovery case is bounded;
     * pure-failure cost is ~5 minutes of background coroutine.
     *
     * Briefing R6: every error path swallows. A network exception
     * mid-init is logged in debug and counts as a retry; a JSON
     * parse failure inside `transport.postInit` returns null and
     * counts as a retry too.
     */
    private suspend fun runInitWithRetry(
        config: KixoConfiguration,
        context: Context,
        transport: Transport,
        queue: EventQueue,
    ) {
        val req = InitRequest(
            projectId = config.projectId,
            apiKey = config.apiKey,
            bundleId = context.packageName,
            appVersion = appVersion(context),
            build = appBuild(context),
            environment = config.environment,
            sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
        )
        var attempt = 0
        while (attempt < INIT_RETRY_ATTEMPTS) {
            try {
                val resp = transport.postInit(req)
                if (resp != null) {
                    // Always publish data_collection FIRST so subsequent
                    // pause / unpause work picks up the latest snapshot.
                    // Coverage fix (May 2026): the typed DataCollection
                    // model flows out through DataCollectionHolder.snapshot()
                    // into every emit-time tracker check.
                    DataCollectionHolder.set(resp.dataCollection)
                    applyDataCollectionSideEffects(resp.dataCollection, config.debug)

                    // Top-level `paused`: server can flip via either
                    //  (a) InitResponse.paused (kill-switch / version disabled)
                    //  (b) data_collection.paused (operator dashboard toggle)
                    // Either one routes us into PausedByServer so the queue
                    // stops persisting.
                    val effectivePaused = resp.paused || (resp.dataCollection?.paused == true)
                    if (effectivePaused) {
                        val reason = resp.pausedReason
                            ?: if (resp.dataCollection?.paused == true) "data_collection_paused"
                            else "init_paused"
                        queue.setLifecycleState(LifecycleState.PausedByServer(reason))
                        if (config.debug) {
                            android.util.Log.w(
                                "Kixo",
                                "/api/sdk/init paused; reason=$reason; SDK halted",
                            )
                        }
                        return
                    }
                    ConfigHolder.setReleaseId(resp.releaseId)

                    // P1 (Codex, 2026-07-03) — fire the DEFERRED replay
                    // start now that the RESOLVED server policy is known.
                    // `Kixo.configure(...)` only ARMED a start thunk (local
                    // opt-in); it deliberately did NOT start, so the first
                    // session can't sample on the LOCAL rate nor open
                    // /session/start for a replay-disabled project before
                    // this policy lands. Start ONLY when the server
                    // explicitly enabled replay with a positive rate — we've
                    // already returned above on any paused state, and
                    // `applyDataCollectionSideEffects` above threaded the
                    // server sampleRate into the deterministic verdict (and
                    // discarded the arm on the off path). release_id is
                    // stamped first because the /session/start body needs it.
                    // Mirrors iOS `maybeStartReplayFromResolvedConfig`
                    // (config is the single start authority; if /init never
                    // succeeds, replay never starts).
                    val replay = resp.dataCollection?.replay
                    val serverRate = replay?.sampleRate
                    val replayPolicyOn = replay?.enabled == true &&
                        (serverRate == null || serverRate > 0.0)
                    if (replayPolicyOn) {
                        try {
                            io.kixo.sdk.internal.replay.ReplayController.startPendingIfArmed()
                        } catch (t: Throwable) {
                            if (config.debug) {
                                android.util.Log.w("Kixo", "replay startPendingIfArmed threw", t)
                            }
                        }
                    }

                    if (config.debug) {
                        val tag = if (attempt == 0) "init ok" else "init ok after ${attempt + 1} attempts"
                        android.util.Log.d(
                            "Kixo",
                            "$tag: release_id=${resp.releaseId} app=${resp.appName} max_batch=${resp.maxBatchSize ?: "default"} replay_policy_on=$replayPolicyOn",
                        )
                    }
                    return
                }
            } catch (t: Throwable) {
                if (config.debug) {
                    android.util.Log.w("Kixo", "/api/sdk/init attempt ${attempt + 1} threw", t)
                }
            }
            attempt++
            if (attempt >= INIT_RETRY_ATTEMPTS) break
            // Capped exponential: 5s, 10s, 20s, 40s, 80s, 160s.
            // Capped at INIT_RETRY_MAX_DELAY_MS so a future bump
            // to attempt count doesn't accidentally extend us into
            // multi-minute waits.
            val baseMs = (INIT_RETRY_BASE_DELAY_MS shl (attempt - 1))
                .coerceAtMost(INIT_RETRY_MAX_DELAY_MS)
            val jitterMs = (baseMs * 0.5 * (Random.nextDouble() - 0.5)).toLong()
            val sleepMs = (baseMs + jitterMs).coerceAtLeast(1_000L)
            delay(sleepMs)
        }
        if (config.debug) {
            android.util.Log.w(
                "Kixo",
                "/api/sdk/init gave up after $INIT_RETRY_ATTEMPTS attempts; release_id stays empty " +
                    "(backend auto-discovers per batch)",
            )
        }
    }

    /**
     * Apply the side-effecting half of the data_collection contract:
     *  - push.contentMode / titlePreviewChars / bodyPreviewChars →
     *    rebuild PushTracker's [PushPayloadSanitizer] so subsequent
     *    `logPushReceived/Opened/etc.` honour the new policy.
     *  - paused → also notify ReplayController so frame capture
     *    halts in addition to the queue's PausedByServer flip.
     *
     * Pure value-routing — no Android system services touched here,
     * safe to invoke from the init coroutine. All error paths swallow
     * per AGENT_BRIEFING R6.
     */
    private fun applyDataCollectionSideEffects(
        dc: io.kixo.sdk.internal.model.DataCollection?,
        debug: Boolean,
    ) {
        dc ?: return

        // Push content-mode wiring. Pre-fix `updateContentMode` had
        // zero callers — operator dashboard's push redaction toggle was
        // 100% no-op on Android. Now flows through here on every /init.
        val pushCfg = dc.push
        if (pushCfg != null) {
            try {
                val mode = io.kixo.sdk.internal.push.ContentMode.fromServerString(pushCfg.contentMode)
                io.kixo.sdk.internal.push.PushTracker.updateContentMode(
                    mode = mode,
                    titleLimit = pushCfg.titlePreviewChars
                        ?: io.kixo.sdk.internal.push.PushPayloadSanitizer.TITLE_PREVIEW_CHARS,
                    bodyLimit = pushCfg.bodyPreviewChars
                        ?: io.kixo.sdk.internal.push.PushPayloadSanitizer.BODY_PREVIEW_CHARS,
                )
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection push update threw", t)
            }
        }

        // Replay fan-out to ReplayController. Mirrors iOS
        // `applyRemoteConfig` (Kixo.swift:1942-1960).
        //
        // Two operator signals seal the in-flight session + tear down
        // the cost-heavy thermal/memory observers (queue lifecycle
        // handles the analytics-event side via setLifecycleState
        // upstream; frame capture is the side that needs an explicit
        // stop):
        //   - global `paused` (kill-switch)
        //   - S4: `replay.enabled == false` OR a server rate <= 0 —
        //     an operator runtime-disable of replay specifically. Emit
        //     was already suppressed at tap time, but the phantom
        //     "live · 0" backend session + observers stayed resident;
        //     stop() (idempotent) seals them.
        //
        // Otherwise, when replay stays enabled and the server ships a
        // sample rate, thread it into the deterministic verdict via
        // `updateSampleRate` (S3 / KIX-UNI-22 parity). The wire rate is
        // 0-100 percent; convert to a 0-1 fraction. The override is
        // applied on the NEXT start()/session-open — matching iOS, we
        // don't re-roll a live verdict.
        val replay = dc.replay
        val serverRate = replay?.sampleRate
        val replayOff = dc.paused == true ||
            replay?.enabled == false ||
            (serverRate != null && serverRate <= 0.0)
        if (replayOff) {
            try {
                // P1 (Codex, 2026-07-03) — the server said replay is off, so
                // drop the armed deferred-start BEFORE sealing any live
                // session. Without this a stale arm could be fired by a
                // later trigger even though the resolved policy is disabled.
                // Mirrors iOS clearing `replayBootstrapPending` on the
                // config-disable arm.
                io.kixo.sdk.internal.replay.ReplayController.discardPendingStart()
                io.kixo.sdk.internal.replay.ReplayController.stop()
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection replay stop threw", t)
            }
        } else if (serverRate != null) {
            try {
                io.kixo.sdk.internal.replay.ReplayController.updateSampleRate(
                    (serverRate / 100.0).coerceIn(0.0, 1.0),
                )
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection replay sampleRate update threw", t)
            }
        }

        // AND-CAP-04 — thread the server-resolved perf knobs into the
        // live ReplayConfig (structural/ocr re-enable, cadence,
        // compression). Only when replay is NOT being torn down above.
        // Enterprise gating is enforced server-side (replay-plan-gate),
        // so we faithfully apply whatever the server sends. Each value
        // is clamped by DirtyCadenceClamp; null (server said nothing)
        // leaves the compiled default. `heicQuality` (0-1 wire) maps to
        // our jpegQuality; `dirtyHeartbeatSec` (seconds) → ms.
        if (!replayOff && replay != null) {
            try {
                io.kixo.sdk.internal.replay.ReplayController.applyRemoteReplayKnobs(
                    io.kixo.sdk.internal.replay.ReplayKnobs(
                        frameCaptureEnabled = replay.frameCaptureEnabled,
                        structuralEnabled = replay.structuralEnabled,
                        ocrEnabled = replay.ocrEnabled,
                        captureMinIntervalMs =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .captureMinIntervalMs(replay.captureMinIntervalMs),
                        scrollEndCaptureEnabled = replay.scrollEndCaptureEnabled,
                        scrollEndMinIntervalSec = replay.scrollEndMinIntervalSec
                            ?.takeIf { it.isFinite() && it >= 0.0 },
                        postTapSettleMs =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .settleMs(replay.postTapSettleMs),
                        dirtyHeartbeatMs =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .heartbeatMs(replay.dirtyHeartbeatSec),
                        jpegQuality =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .jpegQualityFromHeic(replay.heicQuality),
                        captureScale =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .captureScale(replay.captureScale),
                    ),
                )
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection replay knobs update threw", t)
            }
        }
    }

    /**
     * Test seam — drive the real [applyDataCollectionSideEffects]
     * replay/push routing (S3/S4 wiring) from a unit test without a
     * live /init round-trip. Mirrors the `resetForTesting` /
     * `nextSeqForTesting` seam convention elsewhere in the SDK.
     */
    @androidx.annotation.VisibleForTesting
    internal fun applyDataCollectionSideEffectsForTesting(
        dc: io.kixo.sdk.internal.model.DataCollection?,
        debug: Boolean = false,
    ) = applyDataCollectionSideEffects(dc, debug)

    private const val INIT_RETRY_ATTEMPTS: Int = 6
    private const val INIT_RETRY_BASE_DELAY_MS: Long = 5_000L
    private const val INIT_RETRY_MAX_DELAY_MS: Long = 160_000L

    private fun appBuild(context: Context): String =
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            // longVersionCode is API 28+; SDK minSdk is 24 so guard.
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                info.longVersionCode.toString()
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toString()
            }
        } catch (_: Throwable) {
            "0"
        }

    private fun appVersion(context: Context): String =
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
        } catch (_: Throwable) {
            "0.0.0"
        }
}

// ─── EventQueueRef adapter (public-facade-facing) ─────────────────

/**
 * Wraps the real [EventQueue] for the public facade. The facade's
 * own `EventQueueRef` interface is `private` inside `object Kixo`,
 * so we expose the queue through this internal type and let
 * `Kixo.configure(...)` build a private anonymous adapter that
 * forwards to it.
 *
 * `enqueueCustom(eventType, eventName, properties)` builds a complete
 * real [KixoEvent] (UUID event_id + live identity stamps + map →
 * JsonObject conversion) and routes through `EventQueue.enqueue()`
 * via a launch on the SDK's process-global scope (the public API is
 * non-suspend).
 */
internal class KixoEventQueueRef(
    private val queue: EventQueue,
    private val identity: IdentityManager,
    private val deviceInfo: DeviceInfo,
) {
    fun enqueueCustom(eventType: String, eventName: String, properties: Map<String, Any?>) {
        val realEvent = KixoEvent(
            eventId = UUID.randomUUID().toString(),
            deviceId = identity.deviceId(),
            anonymousId = identity.anonymousId(),
            userId = identity.userId(),
            sessionId = currentSessionId(),
            fingerprint = currentFingerprint(),
            eventType = wireToEnum(eventType),
            eventName = eventName,
            // Critic BLOCKER Android-B1 (May 2026) — every `properties`
            // map shipped via Kixo.track / identify / screen /
            // setUserProperty / markGoal flows through here. Without
            // sanitization, raw customer-supplied free-text values
            // ship to the wire — including any embedded emails / cards
            // / phone numbers / tokens. iOS PiiFilter was wired only
            // to the Replay subsystem; the analytics enqueue path was
            // an unguarded hole. Sanitize STRING leaves AND KEYS
            // (a `{ "user@x.com": "…" }` map otherwise leaks the
            // address in the key position).
            // Sanitise first (PII redaction on customer free-text), THEN
            // stamp the attribution window — the `attribution_*` ids are
            // routing keys, not PII, so they must bypass the redactor (a
            // UUID/CUID brushing a regex must never be mangled). This is the
            // SINGLE chokepoint that closes AC-5 / §3.3 end-to-end: every
            // tracked event inside the 30-min window inherits the resolved
            // link/click/campaign.
            properties = decorateAttribution(
                sanitizePropertiesForWire(properties).toJsonElement(),
            ),
            timestamp = Instant.now(),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(realEvent)
    }

    /**
     * Wave 8 — accept a fully-built [KixoEvent] from a caller that has
     * already minted the event id, identity stamps, and fingerprint
     * itself. Used by [io.kixo.sdk.internal.interaction.TouchInterceptor]
     * which needs control over the gesture-time fingerprint snapshot
     * (so the screen_id stamped on a tap matches the screen the user
     * was looking at when the touch landed, NOT the screen they may
     * have transitioned to by the time the queue's enqueue coroutine
     * is dispatched).
     *
     * Callers that pass an `EventContext` placeholder (e.g.
     * [io.kixo.sdk.internal.interaction.TouchInterceptor]'s
     * `EMPTY_EVENT_CONTEXT`) get it overwritten here with the real
     * per-event context from [deviceInfo] so the wire payload always
     * carries enriched device info.
     *
     * **Critic Round 3 BLOCKER Android-B1 (May 2026)** — every property
     * `JsonObject` is routed through [sanitizePropertiesForWire] so
     * `TouchInterceptor`'s raw `target_text` (EditText contents — emails,
     * phones, card numbers typed by the end-user) never reaches the
     * wire. Pre-fix only [enqueueCustom] sanitised; this method bypassed
     * the chokepoint and shipped raw text to ClickHouse `tap.target_text`.
     * The sanitiser handles `JsonObject` walks directly (see
     * `sanitizeJsonObject` in this file), so we re-wrap the result.
     */
    fun enqueueEvent(event: KixoEvent) {
        val sanitizedProperties = sanitizeJsonObjectForWire(event.properties)
        // Attribution window inheritance also applies to pre-built events
        // (taps / screen-visits). Same post-sanitise ordering as enqueueCustom.
        val decorated = decorateAttribution(sanitizedProperties)
        val enriched = event.copy(
            properties = decorated,
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(enriched)
    }

    fun flush() = queue.flush()
    fun flushBlocking(timeoutMs: Long): Boolean = queue.flushBlocking(timeoutMs)
    fun stop(reason: String) = queue.stop(reason)

    /**
     * Forward live queue health to the facade-side diagnostics
     * surface. Cheap; non-blocking. See [EventQueue.diagnostics].
     */
    fun diagnostics(): QueueDiagnostics = queue.diagnostics()

    private fun currentSessionId(): String =
        io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap.currentSessionId()
            ?: "boot-${UUID.randomUUID()}"

    private fun currentFingerprint(): String =
        io.kixo.sdk.internal.screen.ScreenIdentity.current().screenId

    private fun wireToEnum(eventType: String): KixoEventType {
        // Defensive: backend rejects unknown event_types as permanent
        // failures, so mapping to .Custom is the safe sink for
        // unrecognised tokens (mirrors iOS). Match against @SerialName
        // wire value (snake_case), not enum constant name (PascalCase).
        return KixoEventType.values().firstOrNull { enumWireValue(it) == eventType }
            ?: KixoEventType.Custom
    }

    private fun enumWireValue(t: KixoEventType): String {
        // Cheap mapping — kotlinx.serialization @SerialName is what we
        // need but its lookup requires reflection; the enum's `name`
        // field is reachable from the constant's declaration order.
        // This mirrors `Json.encodeToString(serializer, t).removeSurrounding("\"")`
        // without paying serialization cost per enqueue.
        return when (t) {
            KixoEventType.ScreenView -> "screen_view"
            KixoEventType.Tap -> "tap"
            KixoEventType.Scroll -> "scroll"
            KixoEventType.Network -> "network"
            KixoEventType.Crash -> "crash"
            KixoEventType.Custom -> "custom"
            KixoEventType.SessionStart -> "session_start"
            KixoEventType.SessionEnd -> "session_end"
            KixoEventType.Identify -> "identify"
            KixoEventType.Group -> "group"
            KixoEventType.Lifecycle -> "lifecycle"
            KixoEventType.Navigation -> "navigation"
            KixoEventType.Gesture -> "gesture"
            KixoEventType.PushOpen -> "push_open"
            KixoEventType.PushReceived -> "push_received"
            KixoEventType.PushDismissed -> "push_dismissed"
            KixoEventType.PushSilent -> "push_silent"
            KixoEventType.PushAction -> "push_action"
            KixoEventType.PushPermission -> "push_permission"
            KixoEventType.PushTokenInvalidated -> "push_token_invalidated"
            KixoEventType.DeepLink -> "deep_link"
            KixoEventType.Iap -> "iap"
            KixoEventType.UserProperty -> "user_property"
            // §0 §2 / §2-cont — the install-discovery + referrer-enrichment
            // wire values. wireToEnum("install"/"attribution") now round-trips
            // to the right enum (was falling through to Custom → "custom",
            // BLOCKER A / B).
            KixoEventType.Install -> "install"
            KixoEventType.Attribution -> "attribution"
            KixoEventType.ScreenVisit -> "screen_visit"
            KixoEventType.Goal -> "goal"
        }
    }
}

/**
 * Helper to launch a suspend `enqueue` from the non-suspend public API
 * surface. Lives on a process-global SDK scope rooted in SupervisorJob
 * so a single failed enqueue doesn't tear peers down.
 */
private fun EventQueue.enqueueAsync(event: KixoEvent) {
    SdkScope.launch { enqueue(event) }
}

private object SdkScope : CoroutineScope by CoroutineScope(SupervisorJob() + Dispatchers.Default)

// ─── PII sanitizer for the enqueue path ───────────────────────────
//
// Critic BLOCKER Android-B1 (May 2026). Every customer-supplied
// `properties` map ships through here on its way to the wire. We
// walk the structure recursively, routing every `String` value AND
// every `String` key through [PiiFilter.DEFAULT.redact] so the wire
// payload never carries a raw email / phone / card / SSN / JWT / IBAN.
//
// Depth bound = [MAX_SANITIZE_DEPTH]. Past that we drop the value
// silently (rather than throwing) — host apps occasionally hand us
// cycle-bearing or pathologically-deep maps and crashing is a worse
// outcome than truncating the payload (AGENT_BRIEFING.md R6).
//
// The filter is [PiiFilter.DEFAULT] (no NER) for cost reasons — this
// path runs on every `track()` call from the host's hot UI thread,
// so we keep allocations bounded to the regex set and skip ML Kit.
// Replay-side captures (where richer NER coverage matters) keep
// their own NER-enabled filter wired separately in `Kixo.kt`.

// ─── Attribution-window decorate (the enqueue chokepoint) ──────────
//
// AC-5 / §3.3 fix (June 2026). `InstallAttributionStore.recordOpen` (deferred
// referrer + warm App-Link via `Kixo.handleDeepLink`) and
// `PushAttributionStore.recordOpen` (push_open) open a 30-min window; this is
// the SINGLE place every outbound event reads that window so it inherits
// `attribution_*`. Pre-fix both stores' `decorate(...)` had NO production
// caller — only their own unit tests — so the window opened but no event ever
// inherited it (the install-store half was the P0-spine equivalent of the
// already-unwired push-store pattern; this wires BOTH).
//
// Push decorates FIRST, then the install store's first-write-wins fills any
// remaining keys (they use disjoint key sets — `attribution_campaign_id` vs
// `attribution_campaign` — so they never fight; the only shared key is the
// diagnostic `attribution_age_ms`, where whichever window opened more recently
// — i.e. push, decorated first — wins, which is the correct last-touch age).
// Runs POST-sanitise so the routing ids bypass PII redaction. Both stores
// return the SAME reference on the closed-window no-op fast path, so an event
// outside any window pays only two cheap lock-guarded timestamp comparisons.
internal fun decorateAttribution(properties: JsonObject): JsonObject {
    val afterPush = io.kixo.sdk.internal.push.PushAttributionStore.decorate(properties)
    return io.kixo.sdk.internal.attribution.InstallAttributionStore.decorate(afterPush)
}

internal const val MAX_SANITIZE_DEPTH: Int = 6

/**
 * Top-level entry — sanitize an already-built `JsonObject` from a
 * pre-fingerprinted caller (TouchInterceptor / ScreenVisitRecorder /
 * etc) before it lands in [EventQueue.enqueueAsync]. Mirrors
 * [sanitizePropertiesForWire] but skips the `Map` → `JsonObject`
 * round-trip the public-API path needs. Critic Round 3 BLOCKER
 * Android-B1 (May 2026): without this the `enqueueEvent` chokepoint
 * stays a PII hole for `tap.target_text` and any other
 * pre-serialised pre-fingerprinted event.
 */
internal fun sanitizeJsonObjectForWire(properties: JsonObject): JsonObject {
    if (properties.isEmpty()) return properties
    return sanitizeJsonObject(properties, depth = 0)
}

/**
 * Top-level entry — sanitize the public-API property map. Always
 * returns a fresh `Map<String, Any?>` (never mutates the caller's
 * map; mutation would be observable from a `markGoal(...)`-style
 * caller that retains the props for re-use).
 */
internal fun sanitizePropertiesForWire(properties: Map<String, Any?>): Map<String, Any?> {
    // Critic R2-H-N2 (May 2026): never return the caller's reference
    // even on the empty fast-path. `emptyMap()` is the Kotlin stdlib
    // singleton immutable map — safe to share, no allocation cost,
    // and ensures the sanitizer's contract ("always returns a fresh
    // map" — see KDoc above) holds uniformly.
    if (properties.isEmpty()) return emptyMap()
    return sanitizeMap(properties, depth = 0)
}

private fun sanitizeMap(map: Map<*, *>, depth: Int): Map<String, Any?> {
    if (depth >= MAX_SANITIZE_DEPTH) return emptyMap()
    val out = LinkedHashMap<String, Any?>(map.size)
    for ((k, v) in map) {
        val rawKey = k?.toString() ?: continue
        val cleanKey = PiiFilter.DEFAULT.redact(rawKey)
        out[cleanKey] = sanitizeAny(v, depth + 1)
    }
    return out
}

private fun sanitizeAny(value: Any?, depth: Int): Any? {
    if (depth >= MAX_SANITIZE_DEPTH) return null
    return when (value) {
        null -> null
        is String -> PiiFilter.DEFAULT.redact(value)
        // Critic R2-H-N1 (May 2026): when a caller hands us an already-
        // JSON-converted property map (e.g. `GoalMarker.mark` →
        // `Kixo.kt:GoalSink.enqueueGoal` passes a `JsonObject` whose
        // values are `JsonPrimitive` / `JsonObject` / `JsonArray`),
        // the raw `else -> value` branch let JsonPrimitive strings
        // through unsanitized. Walk the JsonElement tree explicitly:
        is JsonPrimitive -> sanitizeJsonPrimitive(value)
        is JsonObject -> sanitizeJsonObject(value, depth)
        is JsonArray -> sanitizeJsonArray(value, depth)
        is Map<*, *> -> sanitizeMap(value, depth)
        is List<*> -> value.map { sanitizeAny(it, depth + 1) }
        is Array<*> -> value.map { sanitizeAny(it, depth + 1) }
        // Numbers / Booleans / etc. PiiFilter doesn't apply — they're
        // not free-text customer input. Pass through unchanged.
        else -> value
    }
}

/**
 * Redact the textual `content` of a JSON string primitive. Numeric /
 * boolean / null primitives are returned as-is — they aren't
 * free-text customer input that could carry an email / phone /
 * card. We preserve the wrapping `JsonPrimitive` type so downstream
 * `JsonObject`/`JsonArray` reconstruction stays type-safe (the
 * enqueue path eventually re-serializes via `toJsonElement()`).
 */
private fun sanitizeJsonPrimitive(value: JsonPrimitive): JsonPrimitive {
    if (!value.isString) return value
    val content = value.contentOrNull ?: return value
    if (content.isEmpty()) return value
    val redacted = PiiFilter.DEFAULT.redact(content)
    return if (redacted == content) value else JsonPrimitive(redacted)
}

private fun sanitizeJsonObject(obj: JsonObject, depth: Int): JsonObject {
    if (depth >= MAX_SANITIZE_DEPTH) return JsonObject(emptyMap())
    val out = LinkedHashMap<String, JsonElement>(obj.size)
    for ((k, v) in obj) {
        val cleanKey = PiiFilter.DEFAULT.redact(k)
        out[cleanKey] = sanitizeJsonElement(v, depth + 1)
    }
    return JsonObject(out)
}

private fun sanitizeJsonArray(arr: JsonArray, depth: Int): JsonArray {
    if (depth >= MAX_SANITIZE_DEPTH) return JsonArray(emptyList())
    return JsonArray(arr.map { sanitizeJsonElement(it, depth + 1) })
}

private fun sanitizeJsonElement(value: JsonElement, depth: Int): JsonElement {
    if (depth >= MAX_SANITIZE_DEPTH) return JsonNull
    return when (value) {
        is JsonPrimitive -> sanitizeJsonPrimitive(value)
        is JsonObject -> sanitizeJsonObject(value, depth)
        is JsonArray -> sanitizeJsonArray(value, depth)
    }
}
