package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import io.kixo.sdk.internal.replay.upload.JpegEncoder.writeToFile
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * Main entry point that Agent 13's ReplayController calls per
 * captured frame. Mirrors the iOS pipeline (capture → encode →
 * stage → schedule background upload) but uses WorkManager
 * instead of `URLSession.background` for the post-staging
 * persistence.
 *
 * **Pipeline:**
 *   1. Caller hands us the Bitmap (or structural JSON / OCR text)
 *      + the target seq + kind + per-tap event metadata.
 *   2. We pull a signed URL from [SignedUrlPool] for that
 *      `(seq, kind)`. If the pool is empty (refill in flight,
 *      sustained network outage), we drop the frame — rationale
 *      below.
 *   3. We encode the payload (JPEG / structural JSON / OCR UTF-8)
 *      and write it atomically to a per-session cache file.
 *   4. We enqueue a [UploadWorker] with the network-type +
 *      cellular constraints from [io.kixo.sdk.KixoConfiguration].
 *   5. The event metadata (tap coords, kind, screen hash, etc.)
 *      is forwarded to [ReplayEventBatcher] which POSTs in
 *      bundles of up to 100 every ~5 s.
 *
 * **Why we DROP rather than buffer-then-retry on empty pool:**
 *  - Buffering raw Bitmaps in memory is the #1 OOM vector on
 *    Android — a 1080×2400 ARGB_8888 bitmap is ~10 MB. iOS
 *    documented the same problem in Replay C.3v3 (`scrollEnd
 *    hard-disabled (was OOM source on iPhone 11/12)`).
 *  - The pool only goes empty during a sustained sign-API outage.
 *    That same outage is also blocking event POSTs to /replay/events.
 *    A re-tried frame whose metadata never lands is orphaned anyway.
 *  - Replay is best-effort — losing 5% of frames on a 4G dropout
 *    is fine; locking up the host app is not.
 *
 * **metadata_only mode:** When the backend's
 * `/api/sdk/replay/session/start` returned `metadata_only=true`
 * (daily quota / plan disabled / project paused), we set
 * [metadataOnly] to true and SKIP all frame encoding + upload —
 * only the [ReplayEventBatcher] keeps shipping per-tap JSON. The
 * dashboard renders these sessions in metadata-only mode.
 */
internal class ReplayUploader(
    private val context: Context,
    private val pool: SignedUrlPool,
    private val eventBatcher: ReplayEventBatcher,
    private val sessionId: String,
    /**
     * From [io.kixo.sdk.KixoConfiguration.replayCaptureOnCellular].
     * False (default) → uploads gated to `NetworkType.UNMETERED`.
     * True → `NetworkType.CONNECTED`. Frames stage to disk in both
     * cases — we only gate the network egress.
     */
    private val captureOnCellular: Boolean = false,
    /**
     * Flipped to true by [ReplaySessionLifecycle] when the backend
     * returned `metadata_only=true` from session/start. While true,
     * frame uploads are skipped entirely and only events flow.
     */
    @Volatile var metadataOnly: Boolean = false,
) {

    /**
     * Per-session staging directory under `cacheDir/kixo-replay/`.
     * Lazily created on first frame so an unused replay session
     * never touches the FS. Files in here have the shape
     * `<seq>_<kind>.<ext>` (e.g. `42_pre.jpg`, `42_structural.json`).
     */
    private val sessionDir: File by lazy {
        File(context.cacheDir, "kixo-replay/$sessionId").also {
            if (!it.exists()) it.mkdirs()
        }
    }

    /**
     * Track total bytes uploaded for the session — passed back to
     * `/api/sdk/replay/session/end` for ops accounting. Updated
     * inside the encode step (we count what we STAGED, not what
     * landed; backend has its own GCS-side accounting for the
     * billing-of-record).
     */
    @Volatile private var totalStagedBytes: Long = 0L
    @Volatile private var stagedFrameCount: Int = 0

    /**
     * Wave 14 #6 — frame-drop telemetry. Per-session counters,
     * surfaced on session/end so the backend can attribute drops
     * per-customer. Three orthogonal drop reasons (the SDK's
     * three drop sites in [scheduleUpload]):
     *
     *   - **encode_failed** — [JpegEncoder.encodeJpeg] returned
     *     null (q=20 + 0.4× downscale still busts the 20 KB cap;
     *     OOM during `Bitmap.compress`; or `bitmap == null`).
     *     This is the high-entropy outlier signal we want to
     *     surface in the admin dashboard so we can tune per-app.
     *   - **pool_empty** — sign-API outage / refill in flight.
     *     Signals network health + pool sizing, not encoder
     *     pressure.
     *   - **staging_failed** — disk full / cache eviction race.
     *     Should be near-zero in healthy fleets.
     *
     * Counters are `Volatile Int` rather than `AtomicInteger`
     * because [scheduleUpload] is the single writer (called from
     * the replay scheduler's serial dispatcher) and the read in
     * [framesDroppedByReason] only happens at session-end after
     * all writes are done.
     */
    @Volatile private var dropEncodeFailed: Int = 0
    @Volatile private var dropPoolEmpty: Int = 0
    @Volatile private var dropStagingFailed: Int = 0

    fun totalStagedBytes(): Long = totalStagedBytes
    fun stagedFrameCount(): Int = stagedFrameCount

    /** Total frames dropped this session (sum of all reasons). */
    fun framesDropped(): Int = dropEncodeFailed + dropPoolEmpty + dropStagingFailed

    /**
     * Per-reason breakdown for `/api/sdk/replay/session/end`.
     * Returns null when no drops occurred so the wire payload
     * stays slim on healthy sessions.
     */
    fun framesDroppedByReason(): Map<String, Int>? {
        val total = framesDropped()
        if (total == 0) return null
        val map = LinkedHashMap<String, Int>(3)
        if (dropEncodeFailed > 0) map["encode_failed"] = dropEncodeFailed
        if (dropPoolEmpty > 0) map["pool_empty"] = dropPoolEmpty
        if (dropStagingFailed > 0) map["staging_failed"] = dropStagingFailed
        return map
    }

    /**
     * Schedule upload of one frame slot.
     *
     * @param seq the per-session monotonic sequence number assigned
     *            by Agent 13's ReplayController.
     * @param kind which of the 4 frame kinds this payload represents.
     * @param bitmap pre/post-tap Bitmap (only when kind in {PRE, POST}).
     * @param structuralJson serialised structural snapshot (only when
     *            kind == STRUCTURAL).
     * @param ocrText canonical OCR text (only when kind == OCR).
     * @param eventMeta the per-tap metadata dict — forwarded to
     *            [ReplayEventBatcher] verbatim. May be empty for
     *            non-tap kinds (structural / OCR are correlated to
     *            the tap by seq, not by their own event row).
     */
    suspend fun uploadFrame(
        seq: Long,
        kind: FrameKind,
        bitmap: Bitmap? = null,
        structuralJson: String? = null,
        ocrText: String? = null,
        eventMeta: Map<String, Any?> = emptyMap(),
        /**
         * AND-CAP-06 — starting JPEG quality (from
         * [io.kixo.sdk.internal.replay.ReplayConfig.jpegQuality]).
         */
        jpegQuality: Int = 60,
        /**
         * AND-CAP-06 — extra encode downscale. PixelCopy frames are
         * pre-downscaled by `captureScale` so pass 1.0; Canvas-fallback
         * frames pass the legacy 0.4.
         */
        encodeDownscale: Float = 1.0f,
    ) {
        // metadata_only: server told us NOT to ship frames. Only
        // forward the event metadata. (Per-frame branches below
        // would no-op if we reached them, but short-circuiting saves
        // the encode + WorkManager INSERT round trip.)
        if (metadataOnly) {
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // 1. Pull a signed URL. If empty, drop AND still ship the
        //    event metadata — partial replay (events without frames)
        //    is more useful than nothing.
        val signedUrl = pool.take(seq, kind)
        if (signedUrl == null) {
            Log.d(TAG, "Pool empty for seq=$seq kind=$kind — dropping frame, keeping event")
            // Wave 14 #6 — telemetry counter. Only count PRE/POST
            // pixel drops; structural/OCR pool exhaustion is more
            // about timing than encoder pressure and would dilute
            // the "high-entropy outlier" signal admins care about.
            if (kind == FrameKind.PRE || kind == FrameKind.POST) dropPoolEmpty++
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // 2. Encode the payload according to kind.
        val encoded: ByteArray? = when (kind) {
            FrameKind.PRE, FrameKind.POST -> bitmap?.let {
                JpegEncoder.encodeJpeg(
                    it,
                    downscale = encodeDownscale,
                    startQuality = jpegQuality,
                )
            }
            FrameKind.STRUCTURAL -> structuralJson?.let { StructuralEncoder.encodeJson(it) }
            FrameKind.OCR -> ocrText?.let { StructuralEncoder.encodeOcr(it) }
        }
        if (encoded == null) {
            // Encode failure (bitmap was null, OOM, etc.) — drop the
            // frame. The signed URL we just took is now wasted; the
            // backend's signing budget absorbs it.
            Log.d(TAG, "Encode returned null for seq=$seq kind=$kind — dropping")
            // Wave 14 #6 — telemetry counter. Same scope rationale
            // as pool_empty above.
            if (kind == FrameKind.PRE || kind == FrameKind.POST) dropEncodeFailed++
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // 3. Stage to disk. Atomic rename inside writeToFile so a
        //    crash mid-write never leaves a partial file for the
        //    worker to PUT.
        val stagingFile = File(sessionDir, "${seq}_${kind.wire}.${kind.fileExtension}")
        if (!encoded.writeToFile(stagingFile)) {
            Log.d(TAG, "Failed to stage seq=$seq kind=$kind — dropping")
            // Wave 14 #6 — telemetry counter. Same scope rationale.
            if (kind == FrameKind.PRE || kind == FrameKind.POST) dropStagingFailed++
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }
        totalStagedBytes += encoded.size.toLong()
        stagedFrameCount++

        // 4. Schedule the WorkManager upload. Wave 9 — prefer the
        //    server-supplied content-type / max-bytes echoed back
        //    by the sign route. Falls back to the FrameKind enum
        //    default when an older backend is on the other end (no
        //    `content_type` / `max_bytes` in response). Both must
        //    match what the V4 signature was issued for, byte-for-
        //    byte, or GCS returns 4xx.
        val effectiveContentType = signedUrl.contentType ?: kind.contentType
        val effectiveMaxBytes = signedUrl.maxBytes ?: DEFAULT_MAX_BYTES
        scheduleUpload(stagingFile, signedUrl.url, effectiveContentType, effectiveMaxBytes)

        // 5. Enrich event meta with the gcs_path so the backend
        //    can join the metadata to the frame on the player side
        //    (player needs to know "this tap's pre-frame is at
        //    replays/p/<projectId>/d/<date>/s/<sessionId>/000_pre.jpg").
        if (eventMeta.isNotEmpty()) {
            val enriched = HashMap<String, Any?>(eventMeta.size + 1).apply {
                putAll(eventMeta)
                put(when (kind) {
                    FrameKind.PRE -> "pre_frame_path"
                    FrameKind.POST -> "post_frame_path"
                    FrameKind.STRUCTURAL -> "structural_path"
                    FrameKind.OCR -> "ocr_path"
                }, signedUrl.gcsPath)
            }
            eventBatcher.enqueue(seq, enriched)
        }
    }

    private fun scheduleUpload(file: File, signedUrl: String, contentType: String, maxBytes: Long) {
        val constraints = Constraints.Builder()
            // Cellular gating: false (default) → wait for unmetered
            // wifi. True → ship on any connection. Frames stage
            // regardless; we only delay the egress.
            .setRequiredNetworkType(
                if (captureOnCellular) NetworkType.CONNECTED else NetworkType.UNMETERED
            )
            // Don't fire the upload during low-battery — replay is
            // never urgent enough to drain the device. Doze respects
            // this automatically.
            .setRequiresBatteryNotLow(true)
            .build()

        val inputData = Data.Builder()
            .putString(UploadWorker.KEY_SIGNED_URL, signedUrl)
            .putString(UploadWorker.KEY_LOCAL_FILE_PATH, file.absolutePath)
            .putString(UploadWorker.KEY_CONTENT_TYPE, contentType)
            // Wave 9 — per-call max_bytes (echoed back from the
            // sign route). Must match the value the backend signed
            // with byte-for-byte; mismatch → V4 signature failure.
            .putLong(UploadWorker.KEY_MAX_BYTES, maxBytes)
            .build()

        val request = OneTimeWorkRequestBuilder<UploadWorker>()
            .setConstraints(constraints)
            .setInputData(inputData)
            // Exponential backoff with WorkManager's 10 s minimum.
            // Combined with our own (signed-URL has 10 min validity)
            // this gives us ~6 retry attempts before the URL expires
            // in the worst case (10s, 20s, 40s, 80s, 160s, 320s). After
            // that the worker returns Result.failure on 403 and the
            // staging file goes to failed/.
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 10, TimeUnit.SECONDS)
            // Tag with session_id so a session-end can cancel any
            // dangling uploads (e.g. operator opt-out mid-session).
            .addTag("kixo-replay")
            .addTag("kixo-replay-session-$sessionId")
            .build()

        // Unique by absolute path: re-scheduling the same staging
        // file (e.g. due to a crash recovery) replaces the prior
        // request rather than queuing two identical PUTs.
        val workName = "kixo-replay-upload-${file.name}-$sessionId"
        try {
            WorkManager.getInstance(context).enqueueUniqueWork(
                workName,
                ExistingWorkPolicy.REPLACE,
                request,
            )
        } catch (t: Throwable) {
            // WorkManager initialization can throw if the host app
            // disabled the default initialiser without registering
            // their own. Fall back to deleting the staging file and
            // logging — replay degrades to metadata-only.
            Log.w(TAG, "WorkManager unavailable; dropping staged frame", t)
            file.delete()
        }
    }

    /**
     * Cancel any outstanding upload work for this session. Called
     * by [ReplaySessionLifecycle] on opt-out or session-end so the
     * worker queue doesn't keep hammering signed URLs whose session
     * is already sealed.
     */
    fun cancelPendingUploads() {
        try {
            WorkManager.getInstance(context)
                .cancelAllWorkByTag("kixo-replay-session-$sessionId")
        } catch (t: Throwable) {
            // Idempotent failure — we tried.
            Log.d(TAG, "cancelAllWorkByTag failed", t)
        }
    }

    companion object {
        private const val TAG = "Kixo.ReplayUploader"

        /**
         * Fallback frame-byte cap when an older backend doesn't echo
         * `max_bytes` in the sign response. 20 KB is the canonical
         * replay-frame cap across all platforms (iOS, Android, web)
         * — agreed ceiling that bounds per-tap egress; hit-View
         * captures + JPEG q=85 typically land ~5-15 KB so this is
         * rarely the binding constraint.
         *
         * Wave 9+ backends ship the value per call so this only
         * fires against pre-Wave-9 servers (none in production any
         * more, but defensive anyway).
         */
        private const val DEFAULT_MAX_BYTES: Long = 20_000L
    }
}
