package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import androidx.work.Data
import androidx.work.NetworkType
import androidx.work.WorkManager
import io.kixo.sdk.internal.replay.upload.JpegEncoder.writeToFile
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Main entry point that Agent 13's ReplayController calls per
 * captured frame. Mirrors the iOS pipeline (capture → encode →
 * stage → schedule background upload) but uses WorkManager
 * instead of `URLSession.background` for the post-staging
 * persistence.
 *
 * **Pipeline:**
 *   1. Caller hands us the Bitmap (or structural JSON / OCR text)
 *      + the target seq + kind + per-tap event metadata.
 *   2. We pull a signed URL from [SignedUrlPool] for that
 *      `(seq, kind)`. If the pool is empty (refill in flight,
 *      sustained network outage), we drop the frame — rationale
 *      below.
 *   3. We encode the payload (JPEG / structural JSON / OCR UTF-8)
 *      and write it atomically to a per-session cache file.
 *   4. We enqueue an [UploadWorker] with the network-type + cellular
 *      constraints from the live project [ReplayRuntimePolicy].
 *   5. The event metadata (tap coords, kind, screen hash, etc.)
 *      is forwarded to [ReplayEventBatcher] which POSTs in
 *      bundles of up to 100 every ~5 s.
 *
 * **Why we DROP rather than buffer-then-retry on empty pool:**
 *  - Buffering raw Bitmaps in memory is the #1 OOM vector on
 *    Android — a 1080×2400 ARGB_8888 bitmap is ~10 MB. iOS
 *    documented the same problem in Replay C.3v3 (`scrollEnd
 *    hard-disabled (was OOM source on iPhone 11/12)`).
 *  - The pool only goes empty during a sustained sign-API outage.
 *    That same outage is also blocking event POSTs to /replay/events.
 *    A re-tried frame whose metadata never lands is orphaned anyway.
 *  - Replay is best-effort — losing 5% of frames on a 4G dropout
 *    is fine; locking up the host app is not.
 *
 * **metadata_only mode:** When the backend's
 * `/api/sdk/replay/session/start` returned `metadata_only=true`
 * (daily quota / plan disabled / project paused), we set
 * [metadataOnly] to true and SKIP all frame encoding + upload —
 * only the [ReplayEventBatcher] keeps shipping per-tap JSON. The
 * dashboard renders these sessions in metadata-only mode.
 */
internal class ReplayUploader(
    private val context: Context,
    private val pool: SignedUrlPool,
    private val eventBatcher: ReplayEventBatcher,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val sessionId: String,
    private val installationId: String,
    /**
     * Project-scoped live policy from `/api/sdk/config`. The worker token
     * includes an identity generation, so queued work cannot cross reset.
     */
    private val runtimePolicy: ReplayRuntimePolicy,
    /** Immutable generation captured when this replay stint opened. */
    private val policyToken: String,
    /**
     * Flipped to true by [ReplaySessionLifecycle] when the backend
     * returned `metadata_only=true` from session/start. While true,
     * frame uploads are skipped entirely and only events flow.
     */
    @Volatile var metadataOnly: Boolean = false,
    private val workScheduler: ReplayWorkScheduler = WorkManagerReplayWorkScheduler,
    private val onPendingUploadsDrained: () -> Unit = {},
    private val onStagedTotalsChanged: (Int, Long, Long?) -> Unit = { _, _, _ -> },
) {

    /**
     * Per-session staging directory under `cacheDir/kixo-replay/`.
     * Lazily created on first frame so an unused replay session
     * never touches the FS. Files in here have the shape
     * `<seq>_<kind>.<ext>` (e.g. `42_pre.jpg`, `42_structural.json`).
     */
    private val sessionDir: File by lazy {
        File(context.cacheDir, "kixo-replay/$sessionId")
    }

    /**
     * Track total bytes uploaded for the session — passed back to
     * `/api/sdk/replay/session/end` for ops accounting. Updated
     * inside the encode step (we count what we STAGED, not what
     * landed; backend has its own GCS-side accounting for the
     * billing-of-record).
     */
    @Volatile private var totalStagedBytes: Long = 0L
    @Volatile private var stagedFrameCount: Int = 0

    /**
     * Wave 14 #6 — frame-drop telemetry. Per-session counters,
     * surfaced on session/end so the backend can attribute drops
     * per-customer. Three orthogonal drop reasons (the SDK's
     * three drop sites in [scheduleUpload]):
     *
     *   - **encode_failed** — [JpegEncoder.encodeJpeg] returned
     *     null (q=20 + 0.4× downscale still busts the 20 KB cap;
     *     OOM during `Bitmap.compress`; or `bitmap == null`).
     *     This is the high-entropy outlier signal we want to
     *     surface in the admin dashboard so we can tune per-app.
     *   - **pool_empty** — sign-API outage / refill in flight.
     *     Signals network health + pool sizing, not encoder
     *     pressure.
     *   - **staging_failed** — disk full / cache eviction race.
     *     Should be near-zero in healthy fleets.
     *
     * Counters are `Volatile Int` rather than `AtomicInteger`
     * because [scheduleUpload] is the single writer (called from
     * the replay scheduler's serial dispatcher) and the read in
     * [framesDroppedByReason] only happens at session-end after
     * all writes are done.
     */
    @Volatile private var dropEncodeFailed: Int = 0
    @Volatile private var dropPoolEmpty: Int = 0
    @Volatile private var dropStagingFailed: Int = 0
    @Volatile private var lastStagedFrameSeq: Long? = null
    private val discarded = AtomicBoolean(false)
    private val hardTerminated = AtomicBoolean(false)
    /** Orders WorkManager enqueue against privacy cancellation. */
    private val workLock = Any()
    private data class PendingUpload(
        val file: File,
        val workName: String,
        val inputData: Data,
    )
    private val pendingUploads = ConcurrentHashMap<String, PendingUpload>()
    private val cellularListenerRemoved = AtomicBoolean(false)
    private val drainNotified = AtomicBoolean(false)
    private val removeCellularLooseningListener = runtimePolicy.addCellularLooseningListener {
        reschedulePendingForCellular()
    }

    fun totalStagedBytes(): Long = totalStagedBytes
    fun stagedFrameCount(): Int = stagedFrameCount
    fun lastStagedFrameSeq(): Long? = lastStagedFrameSeq
    fun hasPendingUploads(): Boolean = synchronized(workLock) { pendingUploads.isNotEmpty() }

    /** Total frames dropped this session (sum of all reasons). */
    fun framesDropped(): Int = dropEncodeFailed + dropPoolEmpty + dropStagingFailed

    /**
     * Per-reason breakdown for `/api/sdk/replay/session/end`.
     * Returns null when no drops occurred so the wire payload
     * stays slim on healthy sessions.
     */
    fun framesDroppedByReason(): Map<String, Int>? {
        val total = framesDropped()
        if (total == 0) return null
        val map = LinkedHashMap<String, Int>(3)
        if (dropEncodeFailed > 0) map["encode_failed"] = dropEncodeFailed
        if (dropPoolEmpty > 0) map["pool_empty"] = dropPoolEmpty
        if (dropStagingFailed > 0) map["staging_failed"] = dropStagingFailed
        return map
    }

    /**
     * Schedule upload of one frame slot.
     *
     * @param seq the per-session monotonic sequence number assigned
     *            by Agent 13's ReplayController.
     * @param kind which of the 4 frame kinds this payload represents.
     * @param bitmap pre/post-tap Bitmap (only when kind in {PRE, POST}).
     * @param structuralJson serialised structural snapshot (only when
     *            kind == STRUCTURAL).
     * @param ocrText canonical OCR text (only when kind == OCR).
     * @param eventMeta the per-tap metadata dict — forwarded to
     *            [ReplayEventBatcher] verbatim. May be empty for
     *            non-tap kinds (structural / OCR are correlated to
     *            the tap by seq, not by their own event row).
     */
    suspend fun uploadFrame(
        seq: Long,
        kind: FrameKind,
        bitmap: Bitmap? = null,
        structuralJson: String? = null,
        ocrText: String? = null,
        eventMeta: Map<String, Any?> = emptyMap(),
        /**
         * AND-CAP-06 — starting JPEG quality (from
         * [io.kixo.sdk.internal.replay.ReplayConfig.jpegQuality]).
         */
        jpegQuality: Int = 15,
        /**
         * AND-CAP-06 — extra encode downscale. PixelCopy frames are
         * pre-downscaled by `captureScale` so pass 1.0; Canvas-fallback
         * frames pass the effective project captureScale.
         */
        encodeDownscale: Float = 1.0f,
    ) {
        if (discarded.get()) return
        // metadata_only: server told us NOT to ship frames. Only
        // forward the event metadata. (Per-frame branches below
        // would no-op if we reached them, but short-circuiting saves
        // the encode + WorkManager INSERT round trip.)
        if (metadataOnly) {
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // 1. Pull a signed URL. If empty, drop AND still ship the
        //    event metadata — partial replay (events without frames)
        //    is more useful than nothing.
        val signedUrl = pool.take(seq, kind)
        if (discarded.get()) return
        if (signedUrl == null) {
            Log.d(TAG, "Pool empty for seq=$seq kind=$kind — dropping frame, keeping event")
            // Wave 14 #6 — telemetry counter. Only count PRE/POST
            // pixel drops; structural/OCR pool exhaustion is more
            // about timing than encoder pressure and would dilute
            // the "high-entropy outlier" signal admins care about.
            if (kind == FrameKind.PRE || kind == FrameKind.POST) dropPoolEmpty++
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // The signing response is the authority for the encoder cap. Today the
        // backend returns 20 KB, but binding the fit-to-cap pass to this exact
        // value prevents a future lower limit from producing a locally-valid
        // JPEG that UploadWorker must then discard. Content type is resolved
        // from the worker's fresh lease immediately before upload.
        val effectiveMaxBytes = signedUrl.maxBytes ?: DEFAULT_MAX_BYTES
        val encodeMaxBytes = boundedEncoderMaxBytes(effectiveMaxBytes)

        // 2. Encode the payload according to kind.
        val encoded: ByteArray? = when (kind) {
            FrameKind.PRE, FrameKind.POST -> bitmap?.let {
                JpegEncoder.encodeJpeg(
                    it,
                    maxBytes = encodeMaxBytes,
                    downscale = encodeDownscale,
                    startQuality = jpegQuality,
                )
            }
            FrameKind.STRUCTURAL -> structuralJson?.let { StructuralEncoder.encodeJson(it) }
            FrameKind.OCR -> ocrText?.let { StructuralEncoder.encodeOcr(it) }
        }
        if (discarded.get()) return
        if (encoded == null) {
            // Encode failure (bitmap was null, OOM, etc.) — drop the
            // frame. The signed URL we just took is now wasted; the
            // backend's signing budget absorbs it.
            Log.d(TAG, "Encode returned null for seq=$seq kind=$kind — dropping")
            // Wave 14 #6 — telemetry counter. Same scope rationale
            // as pool_empty above.
            if (kind == FrameKind.PRE || kind == FrameKind.POST) dropEncodeFailed++
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // 3. Stage to disk. Atomic rename inside writeToFile so a
        //    crash mid-write never leaves a partial file for the
        //    worker to PUT.
        val stagingFile = File(sessionDir, "${seq}_${kind.wire}.${kind.fileExtension}")
        var writeAttempted = false
        var staged = false
        val stageAuthorised = runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.DATA,
        ) {
            if (!discarded.get()) {
                writeAttempted = true
                staged = encoded.writeToFile(stagingFile)
                if (staged && discarded.get()) {
                    stagingFile.delete()
                    staged = false
                }
                if (staged) {
                    totalStagedBytes += encoded.size.toLong()
                    stagedFrameCount++
                    lastStagedFrameSeq = lastStagedFrameSeq
                        ?.let { maxOf(it, signedUrl.seq) }
                        ?: signedUrl.seq
                }
            }
        }
        if (!stageAuthorised || !staged) {
            stagingFile.delete()
            if (!stageAuthorised) return
            Log.d(TAG, "Failed to stage seq=$seq kind=$kind — dropping")
            // Wave 14 #6 — telemetry counter. Same scope rationale.
            if (writeAttempted && (kind == FrameKind.PRE || kind == FrameKind.POST)) {
                dropStagingFailed++
            }
            if (eventMeta.isNotEmpty()) eventBatcher.enqueue(seq, eventMeta)
            return
        }

        // 4. Schedule the WorkManager upload with durable signing metadata,
        //    not the ten-minute URL currently in the pool. The worker may sit
        //    behind a Wi-Fi constraint for hours, so it obtains a fresh exact
        //    `(session, seq, kind)` lease immediately before its GCS PUT.
        if (!scheduleUpload(stagingFile, signedUrl.seq, kind, signedUrl.gcsPath)) {
            return
        }

        // 5. Enrich event meta with the gcs_path so the backend
        //    can join the metadata to the frame on the player side
        //    (player needs to know "this tap's pre-frame is at
        //    replays/p/<projectId>/d/<date>/s/<sessionId>/000_pre.jpg").
        if (eventMeta.isNotEmpty() && !discarded.get()) {
            val enriched = HashMap<String, Any?>(eventMeta.size + 1).apply {
                putAll(eventMeta)
                put(when (kind) {
                    FrameKind.PRE -> "pre_frame_path"
                    FrameKind.POST -> "post_frame_path"
                    FrameKind.STRUCTURAL -> "structural_path"
                    FrameKind.OCR -> "ocr_path"
                }, signedUrl.gcsPath)
            }
            eventBatcher.enqueue(seq, enriched)
        }
    }

    private fun scheduleUpload(
        file: File,
        seq: Long,
        kind: FrameKind,
        expectedGcsPath: String,
    ): Boolean {
        val inputData = Data.Builder()
            .putString(UploadWorker.KEY_LOCAL_FILE_PATH, file.absolutePath)
            .putString(UploadWorker.KEY_REPLAY_POLICY_TOKEN, policyToken)
            .putString(UploadWorker.KEY_API_BASE_URL, baseUrl)
            .putString(UploadWorker.KEY_PROJECT_ID, projectId)
            .putString(UploadWorker.KEY_API_KEY, apiKey)
            .putString(UploadWorker.KEY_SESSION_ID, sessionId)
            .putString(UploadWorker.KEY_INSTALLATION_ID, installationId)
            .putLong(UploadWorker.KEY_FRAME_SEQ, seq)
            .putString(UploadWorker.KEY_FRAME_KIND, kind.wire)
            .putString(UploadWorker.KEY_EXPECTED_GCS_PATH, expectedGcsPath)
            .build()
        // Unique by absolute path: re-scheduling the same staging
        // file (e.g. due to a crash recovery) replaces the prior
        // request rather than queuing two identical PUTs.
        val workName = "kixo-replay-upload-${file.name}-$sessionId"
        val pending = PendingUpload(file, workName, inputData)
        var scheduled = false
        val enqueueAuthorised = runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.DATA,
        ) {
            synchronized(workLock) {
                if (!discarded.get()) {
                    pendingUploads[workName] = pending
                    val descriptorPersisted = ReplayPendingUploadStore.persist(
                        rawFile = file,
                        workName = workName,
                        inputData = inputData,
                    )
                    if (descriptorPersisted) {
                        registerCompletionLocked(pending)
                        scheduled = enqueuePendingLocked(
                            pending = pending,
                            captureOnCellular = runtimePolicy.snapshot().captureOnCellular,
                        )
                    }
                    if (!scheduled) {
                        pendingUploads.remove(workName, pending)
                        ReplayUploadCompletionRegistry.unregister(file.absolutePath)
                        ReplayPendingUploadStore.delete(file)
                    } else {
                        runCatching {
                            onStagedTotalsChanged(
                                stagedFrameCount,
                                totalStagedBytes,
                                lastStagedFrameSeq,
                            )
                        }
                    }
                }
            }
        }
        if (!enqueueAuthorised || !scheduled) {
            UploadWorker.discardPermanentlyRejectedFile(file)
            ReplayPendingUploadStore.delete(file)
        }
        return enqueueAuthorised && scheduled
    }

    /**
     * WorkManager constraints are immutable. When a dashboard config refresh
     * changes Wi-Fi-only to cellular-allowed, replace every still-staged
     * request so it becomes eligible immediately instead of waiting for Wi-Fi.
     */
    private fun reschedulePendingForCellular() {
        runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.DATA,
        ) {
            synchronized(workLock) {
                if (hardTerminated.get()) return@synchronized
                pendingUploads.values.toList().forEach { pending ->
                    if (!pending.file.exists() || pending.file.length() == 0L) {
                        onPendingUploadTerminalLocked(pending)
                    } else {
                        registerCompletionLocked(pending)
                        enqueuePendingLocked(pending, captureOnCellular = true)
                    }
                }
            }
        }
    }

    /** Caller holds [workLock] and the live replay policy monitor. */
    private fun enqueuePendingLocked(
        pending: PendingUpload,
        captureOnCellular: Boolean,
    ): Boolean = workScheduler.enqueue(
        context = context,
        workName = pending.workName,
        inputData = pending.inputData,
        captureOnCellular = captureOnCellular,
        sessionId = sessionId,
    )

    private fun registerCompletionLocked(pending: PendingUpload) {
        ReplayUploadCompletionRegistry.register(pending.file.absolutePath) {
            synchronized(workLock) {
                onPendingUploadTerminalLocked(pending)
            }
        }
    }

    private fun onPendingUploadTerminalLocked(pending: PendingUpload) {
        pendingUploads.remove(pending.workName, pending)
        ReplayUploadCompletionRegistry.unregister(pending.file.absolutePath)
        releaseCellularListenerIfIdleLocked()
    }

    private fun releaseCellularListenerIfIdleLocked() {
        if (discarded.get() && pendingUploads.isEmpty() &&
            cellularListenerRemoved.compareAndSet(false, true)
        ) {
            removeCellularLooseningListener()
        }
        if (discarded.get() && pendingUploads.isEmpty() &&
            drainNotified.compareAndSet(false, true)
        ) {
            onPendingUploadsDrained()
        }
    }

    /**
     * Stop accepting captures while leaving durable uploads alive. A normal
     * background/timeout close is not a privacy boundary: frames staged under
     * Wi-Fi-only policy must still be able to upload when Wi-Fi arrives, or be
     * replaced with CONNECTED work if the dashboard later allows cellular.
     */
    fun closeCaptureKeepingPendingUploads() {
        synchronized(workLock) {
            discarded.set(true)
            releaseCellularListenerIfIdleLocked()
        }
    }

    /**
     * Cancel any outstanding upload work for this session. This is only for a
     * hard privacy/identity/policy boundary; ordinary session seal keeps its
     * bounded delayed-upload work alive.
     */
    fun cancelPendingUploads() {
        synchronized(workLock) {
            // Normal close is terminal too: it must not race a final capture or
            // leave a cellular-loosening listener able to resurrect cancelled
            // unique work.
            discarded.set(true)
            hardTerminated.set(true)
            if (cellularListenerRemoved.compareAndSet(false, true)) {
                removeCellularLooseningListener()
            }
            pendingUploads.values.forEach { pending ->
                ReplayUploadCompletionRegistry.unregister(pending.file.absolutePath)
            }
            pendingUploads.clear()
            try {
                WorkManager.getInstance(context)
                    .cancelAllWorkByTag("kixo-replay-session-$sessionId")
            } catch (t: Throwable) {
                // Idempotent failure — we tried.
                Log.d(TAG, "cancelAllWorkByTag failed", t)
            }
            purgeSessionFilesLocked()
        }
    }

    /**
     * Hard privacy teardown. The lock closes the enqueue-after-cancel race:
     * either a request is enqueued first and this method cancels it, or the
     * discarded flag wins first and [scheduleUpload] refuses the enqueue.
     */
    fun discardPendingUploads() {
        synchronized(workLock) {
            discarded.set(true)
            cancelPendingUploads()
        }
    }

    /** Caller holds [workLock]. Never retain cancelled raw frame bytes. */
    private fun purgeSessionFilesLocked() {
        val cachePath = runCatching { context.cacheDir.absolutePath }
            .getOrNull()
            ?.takeIf { it.isNotBlank() }
            ?: return
        val directory = File(cachePath, "kixo-replay/$sessionId")
        try {
            if (directory.deleteRecursively()) return
            directory.walkBottomUp().forEach { entry ->
                if (entry.isFile) {
                    UploadWorker.discardPermanentlyRejectedFile(entry)
                } else {
                    entry.delete()
                }
            }
        } catch (t: Throwable) {
            Log.d(TAG, "purge staged replay files failed", t)
        }
    }

    companion object {
        private const val TAG = "Kixo.ReplayUploader"

        /**
         * Fallback frame-byte cap when an older backend doesn't echo
         * `max_bytes` in the sign response. 20 KB is the canonical
         * replay-frame cap across all platforms (iOS, Android, web)
         * — agreed ceiling that bounds per-tap egress; hit-View
         * captures + JPEG q=85 typically land ~5-15 KB so this is
         * rarely the binding constraint.
         *
         * Wave 9+ backends ship the value per call so this only
         * fires against pre-Wave-9 servers (none in production any
         * more, but defensive anyway).
         */
        private const val DEFAULT_MAX_BYTES: Long = 20_000L

        @JvmStatic
        internal fun requiredNetworkType(captureOnCellular: Boolean): NetworkType =
            if (captureOnCellular) NetworkType.CONNECTED else NetworkType.UNMETERED

        @JvmStatic
        @androidx.annotation.VisibleForTesting
        internal fun boundedEncoderMaxBytes(serverMaxBytes: Long): Int = when {
            serverMaxBytes <= 0L -> 0
            serverMaxBytes > Int.MAX_VALUE.toLong() -> Int.MAX_VALUE
            else -> serverMaxBytes.toInt()
        }
    }
}
