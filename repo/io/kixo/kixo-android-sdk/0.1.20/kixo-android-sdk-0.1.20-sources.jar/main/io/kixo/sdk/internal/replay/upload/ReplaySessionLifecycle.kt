package io.kixo.sdk.internal.replay.upload

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import io.kixo.sdk.internal.replay.ReplayResumeState
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.replay.ReplayController
import io.kixo.sdk.internal.replay.ReplaySessionOpenResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Owns the lifecycle of a single replay session: open → seal.
 * Wraps:
 *   - [SignedUrlClient] for the start/end RPCs
 *   - [SignedUrlPool] for the per-frame URL leases
 *   - [ReplayEventBatcher] for the per-tap metadata stream
 *   - [ReplayUploader] for the orchestration
 *
 * Called by Agent 13's ReplayController. The controller decides
 * WHEN a session opens (sample-rate hit, rage-click trigger,
 * crash trigger); this class executes the open/close mechanics.
 *
 * **Crash defence:** writes session metadata to SharedPreferences
 * the moment a session opens. On the NEXT launch, [recoverFromCrash]
 * checks for any orphaned sessions (process killed before
 * session/end fired) and posts a session/end with reason
 * `app_terminated` so the backend doesn't sit with a "live · 0"
 * row. The backend ALSO has a 30-min idle-sweep cron as a
 * defence-in-depth fallback (see iOS C.4 phantom-session fix
 * lesson) — both layers help.
 *
 * **Why SharedPreferences not SQLite:** session metadata is small
 * (one row, < 200 bytes) and we need it durable past a force-kill.
 * SharedPreferences's commit semantics fit perfectly; spinning up
 * a SQLite db just for one row is overkill and adds a dependency
 * on Agent 3's storage helper.
 */
@SuppressLint("ApplySharedPref") // commit() deliberately closes process-death windows.
internal class ReplaySessionLifecycle(
    private val context: Context,
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val runtimePolicy: ReplayRuntimePolicy,
    private val endWorkScheduler: ReplayEndWorkScheduler = WorkManagerReplayEndWorkScheduler,
) {

    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }
    private val pendingEndStore: ReplayPendingEndStore by lazy {
        ReplayPendingEndStore(prefs)
    }

    @Volatile private var current: Active? = null
    /** Serializes open/close/discard so a stale close cannot clear a new stint. */
    private val lifecycleMutex = Mutex()
    private val lifecycleGeneration = AtomicLong(0L)
    private val remotePauseLatched = AtomicBoolean(false)
    /** Closed stints whose durable frame work is still pending. */
    private val retainedUploaders = ConcurrentHashMap.newKeySet<ReplayUploader>()
    /** Prevent identical recovery retries from replacing WorkManager backoff. */
    private val scheduledEnds = ConcurrentHashMap<String, ScheduledEnd>()
    private val persistenceLock = Any()

    /** Guarded by [persistenceLock]. See [InMemoryOpeningBudget]. */
    private var inMemoryOpeningBudget: InMemoryOpeningBudget? = null

    /**
     * Active session bundle exposed to [ReplayUploader] via
     * [activeUploader]. Null when no session is open.
     */
    private data class Active(
        val sessionId: String,
        /**
         * The session id the ADAPTER requested (the analytics session
         * id) — [ReplayResumeState] is keyed by it, while [sessionId]
         * is whatever the server echoed back. In practice they match;
         * keying the resume carry off the client-side id keeps the
         * state machine consistent with the adapter/controller seams.
         */
        val clientSessionId: String,
        val installationId: String,
        val policyToken: String,
        val stintId: String,
        val stintEpoch: Long,
        val startedAt: Instant,
        val client: SignedUrlClient,
        val pool: SignedUrlPool,
        val batcher: ReplayEventBatcher,
        val uploader: ReplayUploader,
        val metadataOnly: Boolean,
        val metadataOnlyReason: String?,
        /**
         * F11 — `/session/end` counters carried in from PREVIOUS
         * stints of the same session id (0 on fresh opens). The end
         * report is `carried + staged-this-stint` because the backend
         * absolute-overwrites: reporting stint-local values would
         * clobber the session's totals down to the last stint's.
         */
        val carriedFrameCount: Int,
        val carriedTotalBytes: Long,
        val carriedLastFrameSeq: Long?,
    )

    /** The currently-active uploader, or null when no session is open. */
    fun activeUploader(): ReplayUploader? = current?.uploader

    /** True when the active session is in metadata-only mode (server quota). */
    fun metadataOnly(): Boolean = current?.metadataOnly == true

    /** Optional reason string the backend returned with metadata_only. */
    fun metadataOnlyReason(): String? = current?.metadataOnlyReason

    /**
     * Open a new replay session. Returns true on success (the
     * uploader is now ready for [ReplayUploader.uploadFrame] calls);
     * false on failure (network or server error — caller backs off).
     *
     * **Idempotency:** opening a second session while one is live
     * seals the first with reason `superseded` then opens the new
     * one. Caller should normally not do this — but a misbehaving
     * controller shouldn't strand state.
     */
    suspend fun openSession(
        sessionId: String,
        installationId: String,
        userId: String?,
        releaseId: String,
        triggers: List<String>,
        region: String,
        flags: Map<String, Boolean>? = null,
        /**
         * KIX-UNI-01 resume contract (v2, F6) — seq the backend
         * should pre-sign URLs from. `null` = fresh open (the
         * `next_seq` key is omitted from the wire body); non-null —
         * INCLUDING 0 — = this stint RESUMES a previous stint of the
         * SAME analytics session (see
         * [io.kixo.sdk.internal.replay.ReplayResumeState]) and the
         * watermark is always serialized so the backend reopens the
         * SEALED row.
         */
        nextSeq: Long? = null,
    ): ReplaySessionOpenResult {
        // Capture before waiting for another lifecycle operation. An identity
        // reset that wins the mutex rotates this token, so the old opening can
        // neither reconcile nor persist under the successor generation.
        val policyToken = runtimePolicy.workerToken()
        return lifecycleMutex.withLock {
            val policyCurrent = runtimePolicy.runIfCallAllowed(
                token = policyToken,
                authority = ReplayRuntimePolicy.CallAuthority.DATA,
                block = {},
            )
            if (!policyCurrent) {
                return@withLock ReplaySessionOpenResult.PolicyPaused
            }
            val bundleId = runCatching { context.packageName }
                .getOrNull()
                ?.trim()
                .orEmpty()
            if (bundleId.isBlank()) {
                Log.d(TAG, "openSession: host package name is unavailable")
                return@withLock ReplaySessionOpenResult.Terminal
            }
            if (releaseId.isBlank()) {
                // The replay backend binds every session to the exact approved
                // release established by /init. Never fall back to a package-only
                // or newest-release lookup while control-plane identity is absent.
                Log.d(TAG, "openSession: release id is unavailable")
                return@withLock ReplaySessionOpenResult.Retryable
            }
            // Crash recovery is launched independently during SDK bootstrap.
            // A fast fresh start must not win this mutex first and overwrite
            // the previous process's open-session breadcrumb. Reconcile it
            // synchronously before any new opening/start state is persisted.
            when (recoverFromCrashLocked(policyToken, installationId).status) {
                CrashRecoveryStatus.READY -> Unit
                CrashRecoveryStatus.RETRYABLE ->
                    return@withLock ReplaySessionOpenResult.Retryable
                CrashRecoveryStatus.POLICY_PAUSED ->
                    return@withLock ReplaySessionOpenResult.PolicyPaused
            }
            when (reconcileSupersededOpening(
                sessionId = sessionId,
                installationId = installationId,
                policyToken = policyToken,
            )) {
                OpeningReconcile.Done -> Unit
                OpeningReconcile.Retryable ->
                    return@withLock ReplaySessionOpenResult.Retryable
            }
            // Seal any leftover live session before opening a new one.
            if (current != null) {
                closeSessionLocked(EndReason.SUPERSEDED)
            }
            val openGeneration = lifecycleGeneration.incrementAndGet()
            remotePauseLatched.set(false)
            // Every object in this stint keeps the token captured BEFORE the
            // start RPC. It must never borrow a later identity/policy generation.
            // A start response may be lost after the server has opened the stint.
            // Persist the client id BEFORE the socket and reuse it for retries of
            // this exact analytics session + installation pair.
            val stintId = getOrCreateOpeningStintId(sessionId, installationId)
                ?: return@withLock ReplaySessionOpenResult.Retryable

            val startedAt = Instant.now()
            val client = SignedUrlClient(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            installationId = installationId,
            runtimePolicy = runtimePolicy,
            policyToken = policyToken,
        )

        val startOutcome = client.startSession(
            sessionId = sessionId,
            installationId = installationId,
            stintId = stintId,
            userId = userId,
            releaseId = releaseId,
            bundleId = bundleId,
            startedAtIso = ISO.format(startedAt),
            triggers = triggers,
            region = region,
            initialUrlCount = 8,
            flags = flags,
            nextSeq = nextSeq,
        )
        val response = when (startOutcome) {
            is SignedUrlClient.StartOutcome.Opened -> startOutcome.response
            SignedUrlClient.StartOutcome.Retryable -> {
                Log.d(TAG, "openSession: retryable server start failure for $sessionId")
                return@withLock ReplaySessionOpenResult.Retryable
            }
            SignedUrlClient.StartOutcome.Terminal -> {
                runtimePolicy.denyUntilFreshRemotePolicy()
                return@withLock ReplaySessionOpenResult.Terminal
            }
        }
        if (response.paused) {
            clearOpeningStintIfMatches(sessionId, installationId, stintId)
            handleRemotePaused(
                expectedGeneration = openGeneration,
                expectedSessionId = null,
                reason = response.pausedReason,
            )
            return@withLock ReplaySessionOpenResult.PolicyPaused
        }
        if (!response.ok || response.sessionId.isBlank() ||
            response.stintEpoch !in 1L..MAX_STINT_EPOCH
        ) {
            clearOpeningStintIfMatches(sessionId, installationId, stintId)
            Log.d(TAG, "openSession: invalid server response for $sessionId")
            runtimePolicy.denyUntilFreshRemotePolicy()
            return@withLock ReplaySessionOpenResult.Terminal
        }

        val carried = if (nextSeq != null) {
            ReplayResumeState.carriedTotalsFor(sessionId)
        } else {
            ReplayResumeState.StintTotals(0, 0L, null)
        }
        val pool = SignedUrlPool(
            client = client,
            sessionId = response.sessionId,
            onRemotePaused = { reason ->
                handleRemotePaused(openGeneration, response.sessionId, reason)
            },
        )
        // Mutex-only local preparation may suspend; final publication below
        // re-checks the immutable token under the policy monitor.
        pool.seed(response.signedUrls)

        var published = false
        val committed = runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.DATA,
        ) {
            // Persist and publish under the same monitor as policy/reset boundaries.
            // A response that completed just before a boundary cannot create a
            // fresh local session after that boundary has returned.
            // Once the server has opened a new epoch, a durable end from the
            // prior stint is stale; remove its local retry record. An already
            // in-flight request is still stopped by the server epoch compare.
            if (!persistSession(
                originalId = sessionId,
                returnedId = response.sessionId,
                installationId = installationId,
                stintId = stintId,
                startedAt = startedAt,
                frameCount = carried.frameCount,
                totalBytes = carried.totalBytes,
                lastFrameSeq = carried.lastFrameSeq,
                stintEpoch = response.stintEpoch,
            )) return@runIfCallAllowed
            pendingEndStore.removeForSession(response.sessionId, installationId)

            val batcher = ReplayEventBatcher(
                context = context,
                httpClient = httpClient,
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                sessionId = response.sessionId,
                installationId = installationId,
                runtimePolicy = runtimePolicy,
                policyToken = policyToken,
                onRemotePaused = { reason ->
                    handleRemotePaused(openGeneration, response.sessionId, reason)
                },
            ).apply { start() }

            lateinit var uploader: ReplayUploader
            uploader = ReplayUploader(
                context = context,
                pool = pool,
                eventBatcher = batcher,
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                sessionId = response.sessionId,
                installationId = installationId,
                runtimePolicy = runtimePolicy,
                policyToken = policyToken,
                metadataOnly = response.metadataOnly,
                onPendingUploadsDrained = { retainedUploaders.remove(uploader) },
                onStagedTotalsChanged = { frameCount, totalBytes, lastFrameSeq ->
                    runtimePolicy.runIfCallAllowed(
                        token = policyToken,
                        authority = ReplayRuntimePolicy.CallAuthority.DATA,
                    ) {
                        persistOpenTotals(
                            expectedSessionId = response.sessionId,
                            frameCount = carried.frameCount + frameCount,
                            totalBytes = carried.totalBytes + totalBytes,
                            lastFrameSeq = listOfNotNull(
                                carried.lastFrameSeq,
                                lastFrameSeq,
                            ).maxOrNull(),
                        )
                    }
                },
            )

            current = Active(
                sessionId = response.sessionId,
                clientSessionId = sessionId,
                installationId = installationId,
                policyToken = policyToken,
                stintId = stintId,
                stintEpoch = response.stintEpoch,
                startedAt = startedAt,
                client = client,
                pool = pool,
                batcher = batcher,
                uploader = uploader,
                metadataOnly = response.metadataOnly,
                metadataOnlyReason = response.metadataOnlyReason,
                carriedFrameCount = carried.frameCount,
                carriedTotalBytes = carried.totalBytes,
                carriedLastFrameSeq = carried.lastFrameSeq,
            )
            published = true
        }
        if (!committed || !published) {
            Log.d(TAG, "openSession: policy changed or breadcrumb was not durable before publish")
            return@withLock ReplaySessionOpenResult.PolicyPaused
        }
        ReplaySessionOpenResult.Opened(sessionId)
        }
    }

    /**
     * A `/session/start` request can reach the backend even when its response
     * is lost. Before a different analytics session overwrites that durable
     * opening breadcrumb, replay the old idempotency key, learn its exact
     * stint epoch, and seal it. The exact old nonce is retried only briefly:
     * an offline predecessor must not park replay for a successor identity
     * indefinitely.
     *
     * Two outcomes, and the difference matters:
     *  - **Identity CONFIRMED** — reconcile answered `open` and returned the
     *    predecessor's exact stint epoch. That seal is never discarded: it is
     *    handed to [pendingEndStore] (see [reconcileSupersededOpeningOnce]) so
     *    the predecessor's specific server session is sealed exactly, even if
     *    the wire call fails or the process dies first.
     *  - **Genuinely AMBIGUOUS** — the budget ran out before any answer, so no
     *    server session is known to exist. Only that breadcrumb is retired,
     *    and the backend idle sweeper owns any row whose start response was
     *    lost.
     *
     * The budget itself measures time actually spent ATTEMPTING plus the
     * number of failed attempts; it is never a wall clock that can run down
     * while the app is backgrounded and nobody is attempting anything.
     */
    private suspend fun reconcileSupersededOpening(
        sessionId: String,
        installationId: String,
        policyToken: String,
    ): OpeningReconcile {
        val opening = readOpeningAttempt() ?: return OpeningReconcile.Done
        if (opening.sessionId == sessionId &&
            opening.installationId == installationId
        ) {
            return OpeningReconcile.Done
        }
        if (opening.installationId != installationId) {
            // Identity reset owns the old installation boundary. Its server
            // row, if any, is intentionally left to the idle sweeper rather
            // than sending old-identity cleanup under new credentials.
            clearOpeningStintIfMatches(
                opening.sessionId,
                opening.installationId,
                opening.stintId,
            )
            return OpeningReconcile.Done
        }

        val budget = beginOpeningReconcileBudget(opening)
            ?: return OpeningReconcile.Done
        val remainingMs = ReplaySupersededOpeningRetryPolicy.remainingMs(budget.spentMs)
        if (remainingMs <= 0L ||
            !ReplaySupersededOpeningRetryPolicy.shouldRetry(budget.failures, budget.spentMs)
        ) {
            retireSupersededOpening(
                opening,
                "budget spent before this attempt: " +
                    "failures=${budget.failures} spent_ms=${budget.spentMs}",
            )
            return OpeningReconcile.Done
        }

        // Use the real IO dispatcher for the in-flight deadline. This also
        // keeps kotlinx-coroutines-test virtual time from expiring a live
        // MockWebServer request before its IO callback can run.
        val attemptStartedAtMs = System.currentTimeMillis()
        val outcome = withContext(Dispatchers.IO) {
            withTimeoutOrNull(remainingMs) {
                reconcileSupersededOpeningOnce(opening, policyToken)
            }
        } ?: OpeningReconcile.Retryable
        // Only time inside the attempt is charged to the budget. A background
        // gap between attempt series bounds nothing, so it must not be able to
        // retire a predecessor that was never once asked about.
        val attemptSpentMs = (System.currentTimeMillis() - attemptStartedAtMs)
            .coerceAtLeast(0L)
        return when (outcome) {
            OpeningReconcile.Retryable ->
                recordOpeningReconcileFailure(opening, budget, attemptSpentMs)
            OpeningReconcile.Done -> outcome
        }
    }

    private suspend fun reconcileSupersededOpeningOnce(
        opening: OpeningAttempt,
        policyToken: String,
    ): OpeningReconcile {
        val client = SignedUrlClient(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            installationId = opening.installationId,
            runtimePolicy = runtimePolicy,
            policyToken = policyToken,
        )
        val stintEpoch = when (val outcome = client.reconcileSession(
            sessionId = opening.sessionId,
            stintId = opening.stintId,
        )) {
            SignedUrlClient.ReconcileOutcome.Retryable ->
                return OpeningReconcile.Retryable
            SignedUrlClient.ReconcileOutcome.Terminal -> {
                // A permanent answer from the read-only reconcile route says
                // nothing about whether replay is allowed — an older backend
                // revision that has not deployed the route answers 404. iOS
                // retires the opening and keeps recording; Android used to
                // call denyUntilFreshRemotePolicy() and kill replay for the
                // whole project scope, so the backend saw the two platforms
                // disagree about the same 404. Aligned to iOS: retire the
                // ambiguous opening, keep capturing.
                retireSupersededOpening(opening, "reconcile answered permanently")
                return OpeningReconcile.Done
            }
            SignedUrlClient.ReconcileOutcome.Absent,
            SignedUrlClient.ReconcileOutcome.Closed,
            SignedUrlClient.ReconcileOutcome.Superseded -> {
                clearOpeningStintIfMatches(
                    opening.sessionId,
                    opening.installationId,
                    opening.stintId,
                )
                return OpeningReconcile.Done
            }
            is SignedUrlClient.ReconcileOutcome.Open -> outcome.stintEpoch
        }

        // The predecessor's identity is now CONFIRMED: the backend answered
        // `open` and handed back its exact stint epoch. From here the seal is
        // owed unconditionally, so it goes to the durable pending-end store
        // BEFORE the wire attempt — the same mechanism that already made
        // "network acknowledgement is no longer a prerequisite for opening a
        // new session" true for the crash breadcrumb (see
        // [migrateCrashBreadcrumb]). Discarding a CONFIRMED predecessor would
        // leave its row open until the backend's 30-minute idle sweeper closed
        // it as `idle_timeout` instead of the exact seal we already know how to
        // send — and for a RESUMED, frame-bearing session that row is not empty.
        //
        // F11 — report the session-cumulative counters, not stint-local zeros:
        // the end route absolute-overwrites, so a resumed session sealed with
        // 0/0 would permanently zero totals the earlier stints already staged.
        val carried = ReplayResumeState.carriedTotalsFor(opening.sessionId)
        val pendingEnd = ReplayPendingEndStore.Record(
            sessionId = opening.sessionId,
            installationId = opening.installationId,
            stintId = opening.stintId,
            stintEpoch = stintEpoch,
            endedAtIso = ISO.format(Instant.now()),
            frameCount = carried.frameCount,
            totalBytes = carried.totalBytes,
            lastFrameSeq = carried.lastFrameSeq,
            endReason = EndReason.SUPERSEDED.wire,
        )
        val durablyQueued = pendingEndStore.upsert(pendingEnd)
        if (durablyQueued) schedulePendingEnd(pendingEnd, policyToken)

        val endOutcome = sendPendingEnd(client, pendingEnd)
        if (endOutcome != SignedUrlClient.EndOutcome.Retry) {
            // Acknowledged, or permanently rejected (wrong stint / newer
            // epoch): either way this exact record has no future.
            pendingEndStore.removeIfUnchanged(pendingEnd)
        } else if (!durablyQueued) {
            // Neither the wire nor the disk accepted the exact seal. Keep the
            // breadcrumb so a later attempt can retry under the same budget
            // rather than losing the confirmed identity.
            return OpeningReconcile.Retryable
        }
        clearOpeningStintIfMatches(
            opening.sessionId,
            opening.installationId,
            opening.stintId,
        )
        return OpeningReconcile.Done
    }

    /**
     * Read the budget already spent on [opening]. The persisted counters give
     * cross-process durability; the in-memory floor guarantees the loop is
     * still bounded when `commit()` reports a failed disk write (a full data
     * partition used to leave the failure counter frozen at its old value, so
     * the original indefinite block survived unchanged). Whichever source is
     * further along wins.
     */
    private fun beginOpeningReconcileBudget(opening: OpeningAttempt): ReconcileBudget? =
        synchronized(persistenceLock) {
            if (!openingAttemptMatches(opening)) return@synchronized null
            val memory = inMemoryOpeningBudget?.takeIf { it.key == opening.budgetKey }
            val failures = maxOf(
                prefs.getInt(KEY_OPENING_RECONCILE_FAILURES, 0).coerceAtLeast(0),
                memory?.failures ?: 0,
            )
            val spentMs = maxOf(
                prefs.getLong(KEY_OPENING_RECONCILE_SPENT_MS, 0L).coerceAtLeast(0L),
                memory?.spentMs ?: 0L,
            )
            rememberOpeningReconcileBudget(opening, failures, spentMs)
            ReconcileBudget(failures = failures, spentMs = spentMs)
        }

    private fun recordOpeningReconcileFailure(
        opening: OpeningAttempt,
        budget: ReconcileBudget,
        attemptSpentMs: Long,
    ): OpeningReconcile =
        synchronized(persistenceLock) {
            if (!openingAttemptMatches(opening)) return@synchronized OpeningReconcile.Done
            val failureCount = budget.failures + 1
            val spentMs = budget.spentMs + attemptSpentMs.coerceAtLeast(0L)
            // Advance the in-memory floor FIRST: progress must not depend on a
            // successful disk write.
            rememberOpeningReconcileBudget(opening, failureCount, spentMs)
            runCatching {
                prefs.edit()
                    .putInt(KEY_OPENING_RECONCILE_FAILURES, failureCount)
                    .putLong(KEY_OPENING_RECONCILE_SPENT_MS, spentMs)
                    .commit()
            }.onFailure { Log.d(TAG, "persist opening reconcile failure threw", it) }
            if (!ReplaySupersededOpeningRetryPolicy.shouldRetry(failureCount, spentMs)) {
                clearOpeningStintIfMatches(
                    opening.sessionId,
                    opening.installationId,
                    opening.stintId,
                )
                Log.d(
                    TAG,
                    "superseded opening retired after bounded reconciliation: " +
                        "failures=$failureCount spent_ms=$spentMs",
                )
                return@synchronized OpeningReconcile.Done
            }
            OpeningReconcile.Retryable
        }

    private fun rememberOpeningReconcileBudget(
        opening: OpeningAttempt,
        failures: Int,
        spentMs: Long,
    ) {
        inMemoryOpeningBudget = InMemoryOpeningBudget(
            key = opening.budgetKey,
            failures = failures,
            spentMs = spentMs,
        )
    }

    private fun retireSupersededOpening(opening: OpeningAttempt, reason: String) {
        clearOpeningStintIfMatches(
            opening.sessionId,
            opening.installationId,
            opening.stintId,
        )
        Log.d(TAG, "superseded opening retired: $reason")
    }

    /**
     * A replay data-plane 200/paused response is authoritative immediately;
     * do not wait for the thirty-minute config poll. Generation/session checks
     * prevent a late callback from an old stint from stopping its successor.
     */
    private fun handleRemotePaused(
        expectedGeneration: Long,
        expectedSessionId: String?,
        reason: String?,
    ) {
        if (lifecycleGeneration.get() != expectedGeneration) return
        if (expectedSessionId != null && current?.sessionId != expectedSessionId) return
        if (!remotePauseLatched.compareAndSet(false, true)) return
        Log.d(TAG, "Replay remotely paused${reason?.let { ": $it" } ?: ""}")
        runtimePolicy.denyUntilFreshRemotePolicy()
        ReplayController.stopForRemotePolicy()
    }

    /**
     * Seal the currently-open session. Freezes new capture, drains the event
     * batcher, posts session/end, preserves already-staged background uploads,
     * and removes the SharedPreferences entry. No-op if no session is open.
     */
    suspend fun closeSession(reason: EndReason) = lifecycleMutex.withLock {
        closeSessionLocked(reason)
    }

    private suspend fun closeSessionLocked(reason: EndReason) {
        val active = current ?: return
        current = null

        // 1. Freeze capture before snapshotting the server retry bound. Work
        //    already staged stays durable; anything that lost this race sees
        //    capture-closed and cannot create an unreported seq afterwards.
        retainedUploaders += active.uploader
        active.uploader.closeCaptureKeepingPendingUploads()

        // 2. Drain durable event metadata first. When offline, leave the end
        // record to WorkManager: sealing synchronously before the event worker
        // would create an avoidable ordering race after process death.
        val eventsDrained = try {
            active.batcher.stop()
        } catch (t: Throwable) {
            Log.d(TAG, "batcher.stop threw", t)
            false
        }

        // 3. Tell the backend the session is sealed. Best-effort —
        //    the 30-min idle-sweep cron will catch us if the call
        //    fails AND the next launch's crash recovery doesn't
        //    pick it up.
        //
        // F11 — report CUMULATIVE totals for the session id (carried
        // from previous stints + staged this stint): the end route
        // absolute-overwrites, so a resumed session reporting only
        // its last stint would permanently undercount. The carry is
        // saved BEFORE the RPC so a network throw can't lose it.
        val cumulativeFrameCount = active.carriedFrameCount + active.uploader.stagedFrameCount()
        val cumulativeTotalBytes = active.carriedTotalBytes + active.uploader.totalStagedBytes()
        val cumulativeLastFrameSeq = listOfNotNull(
            active.carriedLastFrameSeq,
            active.uploader.lastStagedFrameSeq(),
        ).maxOrNull()
        ReplayResumeState.onStintTotals(
            sessionId = active.clientSessionId,
            frameCount = cumulativeFrameCount,
            totalBytes = cumulativeTotalBytes,
            lastFrameSeq = cumulativeLastFrameSeq,
        )
        val endedAt = Instant.now()
        val pendingEnd = ReplayPendingEndStore.Record(
            sessionId = active.sessionId,
            installationId = active.installationId,
            stintId = active.stintId,
            stintEpoch = active.stintEpoch,
            endedAtIso = ISO.format(endedAt),
            frameCount = cumulativeFrameCount,
            totalBytes = cumulativeTotalBytes,
            lastFrameSeq = cumulativeLastFrameSeq,
            endReason = reason.wire,
            framesDropped = active.uploader.framesDropped(),
            dropReasons = active.uploader.framesDroppedByReason(),
        )
        var durablyQueued = false
        val cleanupAllowed = runtimePolicy.runIfCallAllowed(
            token = active.policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.CLEANUP,
        ) {
            durablyQueued = pendingEndStore.upsert(pendingEnd)
            if (durablyQueued) {
                schedulePendingEnd(pendingEnd, active.policyToken)
                clearPersistedOpenSession(active.sessionId)
            }
        }
        if (cleanupAllowed && eventsDrained) {
            val outcome = sendPendingEnd(active.client, pendingEnd)
            if (outcome != SignedUrlClient.EndOutcome.Retry) {
                pendingEndStore.removeIfUnchanged(pendingEnd)
                clearPersistedOpenSession(active.sessionId)
            }
        }

        // 4. The sealed-retry sign contract permits only exact,
        //    already-staged frames bounded by last_frame_seq + retention.
        if (!active.uploader.hasPendingUploads()) {
            retainedUploaders.remove(active.uploader)
        }

        // 5. Drop signed URLs we never used.
        try { active.pool.clear() } catch (t: Throwable) { Log.d(TAG, "pool.clear threw", t) }

        // 6. The open breadcrumb was moved atomically to the pending-end store
        //    above. On transient failure that durable record survives launch.
    }

    /**
     * Hard identity/policy close. No final event flush and no session/end RPC:
     * cancel everything that can wake later, delete staged bytes, and remove
     * the crash-recovery breadcrumb. Serialized with [openSession], so an
     * in-flight session/start cannot publish a fresh [current] after discard.
     */
    suspend fun discardSession() = lifecycleMutex.withLock {
        val active = current
        current = null
        if (active != null) {
            try { active.batcher.discard() } catch (t: Throwable) {
                Log.d(TAG, "batcher.discard threw", t)
            }
            try { active.uploader.discardPendingUploads() } catch (t: Throwable) {
                Log.d(TAG, "uploader discard threw", t)
            }
            try { active.pool.clear() } catch (t: Throwable) {
                Log.d(TAG, "pool.clear threw", t)
            }
        }
        val closedUploaders = retainedUploaders.toList()
        retainedUploaders.clear()
        closedUploaders.forEach { uploader ->
            try { uploader.discardPendingUploads() } catch (t: Throwable) {
                Log.d(TAG, "retained uploader discard threw", t)
            }
        }
        clearAllPersistedState()
        Unit
    }

    /**
     * On launch, check for a session that was open when the process
     * died and ship a session/end so the dashboard doesn't see a
     * "live · 0" row sitting forever. Mirrors the iOS C.4 phantom-
     * session fix.
     *
     * Returns the `session_id` we recovered (for diagnostics) or
     * null if there was nothing to recover.
     */
    suspend fun recoverFromCrash(expectedInstallationId: String? = null): String? {
        val policyToken = runtimePolicy.workerToken()
        return lifecycleMutex.withLock {
            recoverFromCrashLocked(policyToken, expectedInstallationId).recoveredSessionId
        }
    }

    private suspend fun recoverFromCrashLocked(
        policyToken: String,
        expectedInstallationId: String?,
    ): CrashRecoveryResult {
        val migration = migrateCrashBreadcrumb(policyToken, expectedInstallationId)
        if (migration.status != CrashRecoveryStatus.READY) return migration

        val currentSessionId = current?.sessionId
        val pending = buildList {
            pendingEndStore.snapshot().forEach { record ->
                if (expectedInstallationId != null &&
                    record.installationId != expectedInstallationId
                ) {
                    // Identity reset owns this boundary. Never grant a retired
                    // installation's cleanup record the successor generation.
                    pendingEndStore.removeIfUnchanged(record)
                } else if (record.sessionId != currentSessionId) {
                    add(record)
                }
            }
        }
        pending.forEach { record ->
            schedulePendingEnd(record, policyToken)
            val client = SignedUrlClient(
                httpClient = httpClient,
                baseUrl = baseUrl,
                projectId = projectId,
                apiKey = apiKey,
                installationId = record.installationId,
                runtimePolicy = runtimePolicy,
                policyToken = policyToken,
            )
            val outcome = sendPendingEnd(client, record)
            if (outcome != SignedUrlClient.EndOutcome.Retry) {
                pendingEndStore.removeIfUnchanged(record)
            }
        }
        return migration.copy(
            recoveredSessionId = migration.recoveredSessionId
                ?: pending.firstOrNull()?.sessionId,
        )
    }

    /**
     * Move the process-death breadcrumb to the durable pending-end store under
     * the caller's policy generation. Once that write commits, network
     * acknowledgement is no longer a prerequisite for opening a new session.
     */
    private fun migrateCrashBreadcrumb(
        policyToken: String,
        expectedInstallationId: String?,
    ): CrashRecoveryResult {
        if (current != null) return CrashRecoveryResult(CrashRecoveryStatus.READY)
        val crashedSessionId = prefs.getString(KEY_OPEN_SESSION_ID, null)
            ?: return CrashRecoveryResult(CrashRecoveryStatus.READY)
        val installationId = prefs.getString(KEY_INSTALLATION_ID, null)
        val stintId = prefs.getString(KEY_STINT_ID, null)

        var result = CrashRecoveryResult(
            CrashRecoveryStatus.RETRYABLE,
            crashedSessionId,
        )
        val admitted = runtimePolicy.runIfCallAllowed(
            token = policyToken,
            authority = ReplayRuntimePolicy.CallAuthority.CLEANUP,
        ) {
            // A reset publishes its new generation before the synchronous
            // purge reaches these preferences. Re-read under the policy lock
            // so a successor generation can never adopt the old breadcrumb.
            if (prefs.getString(KEY_OPEN_SESSION_ID, null) != crashedSessionId) {
                result = CrashRecoveryResult(CrashRecoveryStatus.READY)
                return@runIfCallAllowed
            }
            if (installationId.isNullOrBlank() || stintId.isNullOrBlank() ||
                (expectedInstallationId != null && installationId != expectedInstallationId)
            ) {
                result = CrashRecoveryResult(
                    status = if (clearPersistedOpenSession(crashedSessionId)) {
                        CrashRecoveryStatus.READY
                    } else {
                        CrashRecoveryStatus.RETRYABLE
                    },
                    recoveredSessionId = crashedSessionId,
                )
                return@runIfCallAllowed
            }

            Log.d(TAG, "Recovering crashed session $crashedSessionId")
            val disk = ReplayPendingUploadStore.pendingStats(
                context = context,
                sessionId = crashedSessionId,
                installationId = installationId,
            )
            val persistedLastSeq = if (prefs.contains(KEY_LAST_FRAME_SEQ)) {
                prefs.getLong(KEY_LAST_FRAME_SEQ, -1L).takeIf { it >= 0L }
            } else {
                null
            }
            val record = ReplayPendingEndStore.Record(
                sessionId = crashedSessionId,
                installationId = installationId,
                stintId = stintId,
                stintEpoch = prefs.getLong(KEY_STINT_EPOCH, 1L).coerceAtLeast(1L),
                endedAtIso = ISO.format(Instant.now()),
                frameCount = maxOf(prefs.getInt(KEY_FRAME_COUNT, 0), disk.frameCount),
                totalBytes = maxOf(prefs.getLong(KEY_TOTAL_BYTES, 0L), disk.totalBytes),
                lastFrameSeq = listOfNotNull(
                    persistedLastSeq,
                    disk.lastFrameSeq,
                ).maxOrNull(),
                endReason = EndReason.APP_TERMINATED.wire,
            )
            if (!pendingEndStore.upsert(record)) {
                result = CrashRecoveryResult(
                    CrashRecoveryStatus.RETRYABLE,
                    crashedSessionId,
                )
                return@runIfCallAllowed
            }

            // pendingEndStore is now the source of truth. A failed clear is
            // harmless: a later fresh persist may overwrite the breadcrumb,
            // while the old close remains durable and independently retryable.
            clearPersistedOpenSession(crashedSessionId)
            result = CrashRecoveryResult(
                CrashRecoveryStatus.READY,
                crashedSessionId,
            )
        }
        return if (admitted) {
            result
        } else {
            CrashRecoveryResult(
                CrashRecoveryStatus.POLICY_PAUSED,
                crashedSessionId,
            )
        }
    }

    private fun schedulePendingEnd(
        record: ReplayPendingEndStore.Record,
        policyToken: String,
    ): Boolean {
        val scheduled = ScheduledEnd(policyToken, record)
        if (scheduledEnds[record.key] == scheduled) return true
        val enqueued = endWorkScheduler.enqueue(
            context = context,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            policyToken = policyToken,
            record = record,
        )
        if (enqueued) scheduledEnds[record.key] = scheduled
        return enqueued
    }

    /**
     * Wire crash recovery to production only after a fresh project response.
     * Session/end is cleanup-exempt, so replay itself may remain disabled;
     * only resolved policy is required.
     */
    suspend fun recoverFromCrashAfterFreshPolicy(
        installationIdProvider: () -> String,
    ) {
        // StateFlow suspension is allocation-free while policy remains
        // unresolved; the old 250 ms loop woke forever without fresh policy.
        repeat(MAX_END_RECOVERY_ATTEMPTS) { attempt ->
            if (!currentCoroutineContext().isActive) return
            runtimePolicy.awaitFreshPolicy()
            val policyToken = runtimePolicy.workerToken()
            val recovery = lifecycleMutex.withLock {
                recoverFromCrashLocked(
                    policyToken = policyToken,
                    expectedInstallationId = installationIdProvider(),
                )
            }
            val activeId = current?.sessionId
            val hasRetryable = pendingEndStore.snapshot().any { it.sessionId != activeId }
            if (recovery.status == CrashRecoveryStatus.READY && !hasRetryable) return
            delay(END_RECOVERY_BASE_DELAY_MS shl attempt)
        }
    }

    private suspend fun sendPendingEnd(
        client: SignedUrlClient,
        record: ReplayPendingEndStore.Record,
    ): SignedUrlClient.EndOutcome = try {
        client.endSession(
            sessionId = record.sessionId,
            stintId = record.stintId,
            endedAtIso = record.endedAtIso,
            frameCount = record.frameCount,
            totalBytes = record.totalBytes,
            endReason = record.endReason,
            lastFrameSeq = record.lastFrameSeq,
            stintEpoch = record.stintEpoch,
            framesDropped = record.framesDropped,
            dropReasons = record.dropReasons,
        )
    } catch (cancelled: CancellationException) {
        throw cancelled
    } catch (t: Throwable) {
        Log.d(TAG, "endSession threw", t)
        SignedUrlClient.EndOutcome.Retry
    }

    private fun persistSession(
        originalId: String,
        returnedId: String,
        installationId: String,
        stintId: String,
        startedAt: Instant,
        frameCount: Int,
        totalBytes: Long,
        lastFrameSeq: Long?,
        stintEpoch: Long,
    ): Boolean = synchronized(persistenceLock) {
        val committed = runCatching {
            prefs.edit()
                .putString(KEY_OPEN_SESSION_ID, returnedId)
                .putString(KEY_ORIGINAL_SESSION_ID, originalId)
                .putString(KEY_INSTALLATION_ID, installationId)
                .putString(KEY_STINT_ID, stintId)
                .putString(KEY_STARTED_AT, ISO.format(startedAt))
                .putInt(KEY_FRAME_COUNT, frameCount)
                .putLong(KEY_TOTAL_BYTES, totalBytes)
                .putLong(KEY_STINT_EPOCH, stintEpoch)
                .apply {
                    if (lastFrameSeq == null) remove(KEY_LAST_FRAME_SEQ)
                    else putLong(KEY_LAST_FRAME_SEQ, lastFrameSeq)
                }
                .commit()
        }.onFailure { Log.d(TAG, "persistSession threw", it) }
            .getOrDefault(false)
        // Keep the opening id until the open breadcrumb itself is durable. If
        // commit() reports a disk failure, an in-process retry must still use
        // the id the server may already have accepted.
        if (committed) clearOpeningStintIfMatches(originalId, installationId, stintId)
        committed
    }

    private fun getOrCreateOpeningStintId(
        sessionId: String,
        installationId: String,
    ): String? = synchronized(persistenceLock) {
        val existing = prefs.getString(KEY_OPENING_STINT_ID, null)
        val sameAttempt = !existing.isNullOrBlank() &&
            prefs.getString(KEY_OPENING_SESSION_ID, null) == sessionId &&
            prefs.getString(KEY_OPENING_INSTALLATION_ID, null) == installationId
        if (sameAttempt) {
            // commit() can update the in-memory map yet report that its disk
            // write failed. Recommit before trusting a restored/in-memory id;
            // no start request is allowed until one synchronous write succeeds.
            val durable = runCatching {
                prefs.edit()
                    .putString(KEY_OPENING_STINT_ID, existing)
                    .putString(KEY_OPENING_SESSION_ID, sessionId)
                    .putString(KEY_OPENING_INSTALLATION_ID, installationId)
                    .remove(KEY_OPENING_RECONCILE_SPENT_MS)
                    .remove(KEY_OPENING_RECONCILE_FAILURES)
                    .commit()
            }.onFailure { Log.d(TAG, "re-persist opening stint id threw", it) }
                .getOrDefault(false)
            return@synchronized existing.takeIf { durable }
        }

        val fresh = UUID.randomUUID().toString()
        val committed = runCatching {
            prefs.edit()
                .putString(KEY_OPENING_STINT_ID, fresh)
                .putString(KEY_OPENING_SESSION_ID, sessionId)
                .putString(KEY_OPENING_INSTALLATION_ID, installationId)
                .remove(KEY_OPENING_RECONCILE_SPENT_MS)
                .remove(KEY_OPENING_RECONCILE_FAILURES)
                .commit()
        }.onFailure { Log.d(TAG, "persist opening stint id threw", it) }
            .getOrDefault(false)
        fresh.takeIf { committed }
    }

    private fun readOpeningAttempt(): OpeningAttempt? = synchronized(persistenceLock) {
        val stintId = prefs.getString(KEY_OPENING_STINT_ID, null)
            ?.takeIf { it.isNotBlank() }
            ?: return@synchronized null
        val sessionId = prefs.getString(KEY_OPENING_SESSION_ID, null)
            ?.takeIf { it.isNotBlank() }
            ?: return@synchronized null
        val installationId = prefs.getString(KEY_OPENING_INSTALLATION_ID, null)
            ?.takeIf { it.isNotBlank() }
            ?: return@synchronized null
        OpeningAttempt(
            sessionId = sessionId,
            installationId = installationId,
            stintId = stintId,
        )
    }

    private fun openingAttemptMatches(opening: OpeningAttempt): Boolean =
        prefs.getString(KEY_OPENING_STINT_ID, null) == opening.stintId &&
            prefs.getString(KEY_OPENING_SESSION_ID, null) == opening.sessionId &&
            prefs.getString(KEY_OPENING_INSTALLATION_ID, null) == opening.installationId

    private fun clearOpeningStintIfMatches(
        sessionId: String,
        installationId: String,
        stintId: String,
    ) = synchronized(persistenceLock) {
        val matches = prefs.getString(KEY_OPENING_STINT_ID, null) == stintId &&
            prefs.getString(KEY_OPENING_SESSION_ID, null) == sessionId &&
            prefs.getString(KEY_OPENING_INSTALLATION_ID, null) == installationId
        if (matches) {
            runCatching {
                prefs.edit()
                    .remove(KEY_OPENING_STINT_ID)
                    .remove(KEY_OPENING_SESSION_ID)
                    .remove(KEY_OPENING_INSTALLATION_ID)
                    .remove(KEY_OPENING_RECONCILE_SPENT_MS)
                    .remove(KEY_OPENING_RECONCILE_FAILURES)
                    .commit()
            }.onFailure { Log.d(TAG, "clear opening stint id threw", it) }
        }
        Unit
    }

    private fun persistOpenTotals(
        expectedSessionId: String,
        frameCount: Int,
        totalBytes: Long,
        lastFrameSeq: Long?,
    ) = synchronized(persistenceLock) {
        if (prefs.getString(KEY_OPEN_SESSION_ID, null) != expectedSessionId) return@synchronized
        runCatching {
            prefs.edit()
                .putInt(KEY_FRAME_COUNT, frameCount)
                .putLong(KEY_TOTAL_BYTES, totalBytes)
                .apply {
                    if (lastFrameSeq == null) remove(KEY_LAST_FRAME_SEQ)
                    else putLong(KEY_LAST_FRAME_SEQ, lastFrameSeq)
                }
                .commit()
        }
    }

    private fun clearPersistedOpenSession(
        expectedSessionId: String? = null,
    ): Boolean = synchronized(persistenceLock) {
            if (expectedSessionId != null &&
                prefs.getString(KEY_OPEN_SESSION_ID, null) != expectedSessionId
            ) {
                return@synchronized true
            }
            runCatching {
                prefs.edit()
                .remove(KEY_OPEN_SESSION_ID)
                .remove(KEY_ORIGINAL_SESSION_ID)
                .remove(KEY_INSTALLATION_ID)
                .remove(KEY_STINT_ID)
                .remove(KEY_STARTED_AT)
                .remove(KEY_FRAME_COUNT)
                .remove(KEY_TOTAL_BYTES)
                .remove(KEY_LAST_FRAME_SEQ)
                .remove(KEY_STINT_EPOCH)
                .remove(KEY_OPENING_STINT_ID)
                .remove(KEY_OPENING_SESSION_ID)
                .remove(KEY_OPENING_INSTALLATION_ID)
                .remove(KEY_OPENING_RECONCILE_SPENT_MS)
                .remove(KEY_OPENING_RECONCILE_FAILURES)
                .commit()
            }.onFailure { Log.d(TAG, "clearPersistedOpenSession threw", it) }
                .getOrDefault(false)
        }

    private fun clearAllPersistedState() {
        synchronized(persistenceLock) {
            runCatching { prefs.edit().clear().commit() }
                .onFailure { Log.d(TAG, "clearAllPersistedState threw", it) }
        }
    }

    /**
     * Reasons we send to `/api/sdk/replay/session/end` — mirror
     * the iOS catalog. Backend dashboards group sessions by reason
     * for ops insight.
     */
    enum class EndReason(val wire: String) {
        FOREGROUND_TO_BACKGROUND("foreground_to_background"),
        APP_TERMINATED("app_terminated"),
        TIMEOUT("timeout"),
        LOW_MEMORY("low_memory"),
        SUPERSEDED("superseded"),
        IDENTITY_RESET("identity_reset"),
    }

    private data class OpeningAttempt(
        val sessionId: String,
        val installationId: String,
        val stintId: String,
    ) {
        val budgetKey: String
            get() = "$sessionId$installationId$stintId"
    }

    /** Budget already spent reconciling one opening, before this attempt. */
    private data class ReconcileBudget(
        val failures: Int,
        val spentMs: Long,
    )

    /**
     * Process-local floor for [ReconcileBudget]. Persistence supplies the
     * cross-process bound; this supplies the bound that survives a failed
     * `commit()`.
     */
    private data class InMemoryOpeningBudget(
        val key: String,
        val failures: Int,
        val spentMs: Long,
    )

    /**
     * A reconcile pass never pauses replay policy: the read-only reconcile
     * route's answer is about ONE ambiguous opening, not about whether this
     * project may record (see the Terminal branch of
     * [reconcileSupersededOpeningOnce]).
     */
    private enum class OpeningReconcile {
        Done,
        Retryable,
    }

    private enum class CrashRecoveryStatus {
        READY,
        RETRYABLE,
        POLICY_PAUSED,
    }

    private data class CrashRecoveryResult(
        val status: CrashRecoveryStatus,
        val recoveredSessionId: String? = null,
    )

    private data class ScheduledEnd(
        val policyToken: String,
        val record: ReplayPendingEndStore.Record,
    )

    companion object {
        private const val PREFS_NAME = ReplayPendingEndStore.PREFS_NAME
        private const val KEY_OPEN_SESSION_ID = "open_session_id"
        private const val KEY_ORIGINAL_SESSION_ID = "original_session_id"
        private const val KEY_INSTALLATION_ID = "installation_id"
        private const val KEY_STINT_ID = "stint_id"
        private const val KEY_STARTED_AT = "started_at"
        private const val KEY_FRAME_COUNT = "frame_count"
        private const val KEY_TOTAL_BYTES = "total_bytes"
        private const val KEY_LAST_FRAME_SEQ = "last_frame_seq"
        private const val KEY_STINT_EPOCH = "stint_epoch"
        private const val KEY_OPENING_STINT_ID = "opening_stint_id"
        private const val KEY_OPENING_SESSION_ID = "opening_session_id"
        private const val KEY_OPENING_INSTALLATION_ID = "opening_installation_id"
        private const val KEY_OPENING_RECONCILE_SPENT_MS = "opening_reconcile_spent_ms"
        private const val KEY_OPENING_RECONCILE_FAILURES = "opening_reconcile_failures"

        private const val MAX_END_RECOVERY_ATTEMPTS = 5
        private const val END_RECOVERY_BASE_DELAY_MS = 1_000L
        private const val MAX_STINT_EPOCH = 2_147_483_647L

        private val ISO: DateTimeFormatter = DateTimeFormatter.ISO_INSTANT

        private const val TAG = "Kixo.ReplaySessionLifecycle"

        /**
         * A project-policy purge removes open/start breadcrumbs but preserves
         * non-content pending session/end records.
         */
        internal fun purgePolicyBoundaryBreadcrumbs(context: Context) {
            runCatching {
                context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .remove(KEY_OPEN_SESSION_ID)
                    .remove(KEY_ORIGINAL_SESSION_ID)
                    .remove(KEY_INSTALLATION_ID)
                    .remove(KEY_STINT_ID)
                    .remove(KEY_STARTED_AT)
                    .remove(KEY_FRAME_COUNT)
                    .remove(KEY_TOTAL_BYTES)
                    .remove(KEY_LAST_FRAME_SEQ)
                    .remove(KEY_STINT_EPOCH)
                    .remove(KEY_OPENING_STINT_ID)
                    .remove(KEY_OPENING_SESSION_ID)
                    .remove(KEY_OPENING_INSTALLATION_ID)
                    .remove(KEY_OPENING_RECONCILE_SPENT_MS)
                    .remove(KEY_OPENING_RECONCILE_FAILURES)
                    .commit()
            }.onFailure { Log.d(TAG, "policy-boundary breadcrumb purge threw", it) }
        }
    }
}

/**
 * Bound for an ambiguous opening that a later analytics/identity session must
 * supersede. Mirrors iOS: preserve the exact old nonce briefly, then favor
 * successor capture while the backend idle sweeper cleans any orphaned row.
 */
internal object ReplaySupersededOpeningRetryPolicy {
    /** Attempts, not attempt series: three failures retire the opening. */
    const val MAX_FAILURES = 3

    /**
     * Total wall time the SDK may spend INSIDE reconcile attempts. It is not a
     * deadline that starts ticking at the first attempt and keeps running
     * while the app is backgrounded: an unattempted gap must never be able to
     * retire a predecessor with zero attempts.
     */
    const val MAX_ATTEMPT_MS = 15_000L

    fun shouldRetry(failureCount: Int, spentMs: Long): Boolean =
        failureCount < MAX_FAILURES && spentMs < MAX_ATTEMPT_MS

    /** Deadline for the NEXT single attempt: whatever is left of the budget. */
    fun remainingMs(spentMs: Long): Long = MAX_ATTEMPT_MS - spentMs.coerceAtLeast(0L)
}
