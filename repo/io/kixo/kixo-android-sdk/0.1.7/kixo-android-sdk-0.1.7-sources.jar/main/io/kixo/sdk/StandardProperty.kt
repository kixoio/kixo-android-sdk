package io.kixo.sdk

/**
 * Standard user properties recognised by the Kixo backend and
 * promoted to the dedicated profile columns shown in the audience
 * explorer (`profile.email`, `profile.phone`, `profile.plan`, …).
 *
 * Reserved names carry a `$` prefix to namespace them away from
 * customer-defined custom traits. This matches Mixpanel / Amplitude
 * / Segment conventions and means a customer can use a bare key like
 * `email` for an unrelated app-specific property (e.g. "email
 * notification frequency") without colliding with the Kixo `$email`
 * reserved column.
 *
 * Pass `Kixo.setUserProperty(StandardProperty.EMAIL.key, "…")` or the
 * raw string `"$email"` — both write `property_name = "$email"` on
 * the wire. Any other (non-`$`) key is stored as a custom trait,
 * queryable from segments and chat but NOT promoted to a `profile.*`
 * column.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Identity/UserProperties.swift`
 * and `kixo-web-sdk/src/core/standard-properties.ts` byte-for-byte.
 * When iOS adds a new case, mirror it here in the same PR.
 */
public enum class StandardProperty(public val key: String) {
    EMAIL("\$email"),
    PHONE("\$phone"),
    NAME("\$name"),
    FIRST_NAME("\$first_name"),
    LAST_NAME("\$last_name"),
    AVATAR_URL("\$avatar_url"),
    CREATED("\$created"),        // signup date (ISO8601)
    CITY("\$city"),
    COUNTRY("\$country"),
    REGION("\$region"),
    LANGUAGE("\$language"),
    TIMEZONE("\$timezone"),
    GENDER("\$gender"),
    BIRTH_YEAR("\$birth_year"),
    PLAN("\$plan"),              // subscription tier
    REVENUE("\$revenue"),        // total revenue
}
