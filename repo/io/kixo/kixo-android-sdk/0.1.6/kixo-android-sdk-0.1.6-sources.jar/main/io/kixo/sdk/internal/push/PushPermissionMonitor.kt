package io.kixo.sdk.internal.push

import android.content.Context
import android.util.Log
import androidx.core.app.NotificationManagerCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Watches the host app's notification-permission state and emits a
 * `push_permission` event whenever it changes. Closes audit gap **B4**
 * (the Android side previously never fired any permission events, so
 * the dashboard's push funnel `permission_granted_rate` was NaN for
 * Android projects).
 *
 * **Sampling strategy.** Android — unlike iOS — has no system
 * notification that fires when the user toggles the "Allow
 * notifications" switch in Settings. The cheapest reliable signal is to
 * re-read the state on every foreground transition (the user has to
 * leave the app to reach Settings, then come back, and a foreground
 * happens then). We therefore install a [DefaultLifecycleObserver] on
 * [ProcessLifecycleOwner] and poll [NotificationManagerCompat.areNotificationsEnabled]
 * on each `ON_START`. The first sample fires unconditionally
 * (`previous = null`); subsequent samples fire ONLY when the boolean
 * flipped — a stable state does NOT spam the queue.
 *
 * Why `areNotificationsEnabled` and not the raw API-33
 * `POST_NOTIFICATIONS` permission check? Because the user can disable
 * notifications via either path:
 *   1. The runtime permission dialog introduced in API 33 (Tiramisu).
 *   2. The per-channel block toggle (since API 26 / O).
 *   3. The app-wide block toggle in system Settings (any API level).
 * `NotificationManagerCompat.areNotificationsEnabled` returns `false` if
 * ANY of those is blocking — exactly the boolean the funnel cares about.
 *
 * **iOS parity:** mirrors `Sources/Kixo/Push/PushPermissionMonitor.swift`.
 * iOS observes `UIApplication.didBecomeActiveNotification`; on Android
 * `ProcessLifecycleOwner.ON_START` is the equivalent process-wide signal.
 *
 * **R6 (never crash the host):** every call into platform APIs
 * (NotificationManagerCompat, ProcessLifecycleOwner) is wrapped in
 * `try/catch` — a misbehaving OEM ROM that throws `SecurityException`
 * out of a NotificationManager call will be logged + swallowed, not
 * propagated.
 *
 * **Install-before-configure safety:** the observer is registered on
 * the main thread (matched against `ProcessLifecycleOwner`'s `@MainThread`
 * contract) and state capture happens lazily on first foreground after
 * bind. Pre-configure invocations of [install] still wire the observer;
 * if the supplied emit lambda is a no-op until the queue is wired, the
 * first real emit is the next foreground after configure lands.
 *
 * **Idempotency:** [install] is guarded by an [AtomicBoolean] — a second
 * call is a WARN-logged no-op. Matches the discipline `Kixo.configure`
 * itself uses.
 */
internal object PushPermissionMonitor {

    private const val TAG = "Kixo"

    /**
     * Wire `event_type` and `event_name` for the emitted event. Both
     * use the same `"push_permission"` token — the type matches
     * [io.kixo.sdk.internal.model.KixoEventType.PushPermission]'s
     * `@SerialName`; the event name is unconstrained and we pick the
     * same string for symmetry with how `goal` events stamp the goal
     * id into both type and name.
     */
    private const val EVENT_TYPE = "push_permission"
    private const val EVENT_NAME = "push_permission"

    /**
     * Source label stamped on every event so the backend can
     * distinguish foreground-poll snapshots from any future
     * synchronous-on-permission-callback emits (e.g. if Android ever
     * gains a system-broadcast for the toggle).
     */
    private const val SOURCE_FOREGROUND_POLL = "foreground_poll"

    /**
     * Whether [install] has run successfully. Subsequent calls are
     * no-ops with a WARN — matches `Kixo.configure`'s discipline.
     */
    private val installed = AtomicBoolean(false)

    /**
     * Last sampled permission state. `null` means we have never
     * sampled (i.e. the monitor was just installed and no foreground
     * has happened yet). On the first sample we emit with
     * `previous = null` and remember the boolean; subsequent emits
     * only fire when the boolean flips.
     *
     * `@Volatile` because reads happen on the main thread (lifecycle
     * callbacks) but the [currentState] accessor may be called from
     * arbitrary threads.
     */
    @Volatile
    private var lastKnownState: Boolean? = null

    /**
     * Application context retained for lazy [NotificationManagerCompat]
     * lookups. Stored as `applicationContext` so we never hold an
     * activity reference. Null between [install] and [uninstall].
     */
    @Volatile
    private var appContext: Context? = null

    /**
     * Emit sink — set by [install], cleared by [uninstall]. Receives
     * `(event_type, event_name, properties)` and is expected to
     * route into `EventQueue.enqueueCustom`. Held as a `@Volatile`
     * reference so a concurrent [uninstall] is observed promptly
     * by an in-flight foreground tick.
     */
    @Volatile
    private var emit: ((String, String, Map<String, Any?>) -> Unit)? = null

    /**
     * Observer reference — kept so [uninstall] can detach it. We
     * could re-derive `ProcessLifecycleOwner.get()` on uninstall but
     * holding the registered instance is the safer pattern.
     */
    @Volatile
    private var observer: DefaultLifecycleObserver? = null

    /**
     * Install the monitor. Idempotent — a second call is a WARN no-op.
     *
     * @param context any context (`applicationContext` is retained).
     * @param emit lambda that forwards `(event_type, event_name, props)`
     *   to the EventQueue. Typically `queueAdapter?.enqueueCustom(...)`
     *   from `Kixo.configure`. May be a no-op until the queue is wired
     *   — the first real emit then lands on the next foreground.
     */
    fun install(context: Context, emit: (String, String, Map<String, Any?>) -> Unit) {
        if (!installed.compareAndSet(false, true)) {
            Log.w(TAG, "PushPermissionMonitor.install called twice; ignoring.")
            return
        }
        this.appContext = context.applicationContext
        this.emit = emit

        val obs = object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                sampleAndEmit()
            }
        }
        observer = obs

        // ProcessLifecycleOwner.addObserver requires the main thread.
        // configure() is documented as safe-from-any-thread but the
        // typical call site is Application.onCreate (main). We still
        // try/catch in case a host calls configure() from a worker
        // thread on an old Lifecycle version that throws.
        try {
            ProcessLifecycleOwner.get().lifecycle.addObserver(obs)
        } catch (t: Throwable) {
            Log.w(TAG, "PushPermissionMonitor: addObserver failed", t)
            // Roll back — if registration failed, future install() calls
            // should be allowed to retry rather than be wedged.
            installed.set(false)
            this.appContext = null
            this.emit = null
            this.observer = null
        }
    }

    /**
     * Detach the observer + clear retained state. Safe to call from
     * any thread; the underlying `Lifecycle.removeObserver` is also
     * `@MainThread` so we try/catch + log on a mismatch.
     *
     * Primarily for tests + [io.kixo.sdk.Kixo.reset]. A normal
     * configure → process-death cycle never calls this.
     */
    fun uninstall() {
        if (!installed.compareAndSet(true, false)) {
            return
        }
        val obs = observer
        if (obs != null) {
            try {
                ProcessLifecycleOwner.get().lifecycle.removeObserver(obs)
            } catch (t: Throwable) {
                Log.w(TAG, "PushPermissionMonitor: removeObserver failed", t)
            }
        }
        observer = null
        appContext = null
        emit = null
        lastKnownState = null
    }

    /**
     * Read the current notification-permission state directly, without
     * waiting for the next foreground tick. Used by tests + as a
     * convenience for callers that want a one-shot read.
     *
     * Returns `null` if the monitor is not installed OR the platform
     * call threw — callers MUST treat null as "unknown" rather than
     * "permission denied".
     */
    fun currentState(context: Context): Boolean? {
        return try {
            NotificationManagerCompat.from(context.applicationContext).areNotificationsEnabled()
        } catch (t: Throwable) {
            Log.w(TAG, "PushPermissionMonitor: areNotificationsEnabled() threw", t)
            null
        }
    }

    /**
     * Main-thread sample-and-emit, called from the lifecycle observer.
     * Reads the live boolean, compares against [lastKnownState], emits
     * exactly when it changes (or on the first sample after install).
     */
    private fun sampleAndEmit() {
        val ctx = appContext ?: return
        val sink = emit ?: return

        val current: Boolean = try {
            NotificationManagerCompat.from(ctx).areNotificationsEnabled()
        } catch (t: Throwable) {
            // Swallow + log per R6. Do NOT update lastKnownState — a
            // transient platform error shouldn't poison the next valid
            // sample.
            Log.w(TAG, "PushPermissionMonitor: areNotificationsEnabled() threw", t)
            return
        }

        val previous = lastKnownState
        // Skip emit when the value hasn't changed (and isn't the first
        // sample). Stable state doesn't spam the queue.
        if (previous != null && previous == current) {
            return
        }
        lastKnownState = current

        val props: Map<String, Any?> = mapOf(
            "enabled" to current,
            "previous" to previous,
            "source" to SOURCE_FOREGROUND_POLL,
        )

        try {
            sink(EVENT_TYPE, EVENT_NAME, props)
        } catch (t: Throwable) {
            // The sink itself is `EventQueue.enqueueCustom` which is
            // best-effort and already swallows internally — but be
            // paranoid in case a future adapter throws.
            Log.w(TAG, "PushPermissionMonitor: emit failed", t)
        }
    }
}
