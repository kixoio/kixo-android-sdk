package io.kixo.sdk.internal.interaction

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Pure, stateless classifier that maps a finished gesture (one or
 * more pointer trajectories) to an [InteractionMeta.Kind].
 *
 * **PORTED FROM iOS — including the bug post-mortem.**
 *
 * The iOS `WindowEventInterceptor` had a 3-day perf regression
 * (April 28 2026) traced to comparing `touch.previousLocation`
 * (frame-to-frame, ≈0 px on a decelerating scroll plateau) instead
 * of `.began → .ended` total movement. Result: scroll-end touches
 * were misclassified as taps and the tap pipeline (snapshot, OCR,
 * upload) fired N times per active scroll.
 *
 * See `~/.claude/projects/-Users-kukitz-WWDA-src-kuicktech-godanalytics
 *      /memory/feedback_perf_diagnosis.md` for the full lesson.
 *
 * **The Android version avoids the trap by design.** [TouchTracker]
 * captures the `ACTION_DOWN` location once, never overwrites it on
 * `ACTION_MOVE`, and feeds [TouchTrack] objects into [classify]
 * whose `startX/Y` field is the down-location and `endX/Y` is the
 * up-location. Classification is then total displacement, full stop.
 *
 * **Inputs are device pixels** (raw `MotionEvent.getX/Y` returns
 * pixels relative to the receiving view; we observe them at the
 * window-callback level which is window-pixel coordinates). The
 * 100-px tap threshold is squared as `100*100 = 10_000` to avoid
 * `sqrt` calls in the hot path.
 *
 * **All threshold tunables are `internal const`** so parallel-built
 * unit tests can reference the exact values rather than re-encoding
 * magic numbers.
 *
 * **Threshold rationale (matches AGENT_BRIEFING §3 R7 verbatim):**
 *   - Tap: `totalDistanceSq < 100*100`, `durationMs < 500`
 *   - Long press: same distance, `durationMs >= 500`
 *   - Swipe: `totalDistanceSq >= 100*100`, single pointer, dominant axis
 *   - Multi-tap: `pointerCount >= 2`, sum-of-distances small
 *   - Pinch: `pointerCount >= 2`, inter-pointer distance changed
 *   - Scroll: anything else with movement (we don't usually see this
 *     classification path because scroll-end is detected separately
 *     via [ScrollEndDetector]; this branch exists for completeness)
 */
internal object GestureClassifier {

    /** Squared threshold for "did the pointer barely move". 100 px. */
    internal const val TAP_DISTANCE_THRESHOLD_PX = 100f
    internal const val TAP_DISTANCE_SQ_THRESHOLD: Float =
        TAP_DISTANCE_THRESHOLD_PX * TAP_DISTANCE_THRESHOLD_PX

    /**
     * Boundary between tap and long-press. Matches Android's own
     * `ViewConfiguration.getLongPressTimeout()` default (500 ms).
     * Hard-coded rather than queried from the platform so JVM unit
     * tests work without a Robolectric shadow.
     */
    internal const val LONG_PRESS_DURATION_MS = 500L

    /**
     * Minimum change in inter-pointer distance for a 2-pointer
     * gesture to qualify as a pinch (rather than a multi-tap that
     * happened to have very slight pointer drift). 50 px chosen to
     * sit comfortably above the noise floor of accidental pointer
     * jitter while remaining sensitive to deliberate pinches.
     */
    internal const val PINCH_DISTANCE_DELTA_PX = 50f

    /**
     * Minimum measurable swipe length in dominant axis to be tagged
     * as a swipe rather than a generic scroll. Identical to the tap
     * threshold; kept as a separate name to make the classification
     * decision tree readable.
     */
    internal const val SWIPE_MIN_AXIS_PX = TAP_DISTANCE_THRESHOLD_PX

    /**
     * Maximum per-finger drift for a 2+ pointer gesture to qualify
     * as a multi-tap. Tighter than [TAP_DISTANCE_THRESHOLD_PX]
     * (single-finger tap) by design: a multi-tap is defined by ALL
     * fingers being approximately stationary at touch-down, while
     * a 2-finger pan typically sees each finger drift 30+ px even
     * over a brief swipe. With this threshold a deliberate
     * 2-finger tap (jitter < 25 px per finger) classifies as
     * MULTI_TAP, while a 2-finger pan (each finger drifts > 25 px,
     * inter-pointer distance unchanged) falls through to
     * SCROLL_END. Sized at one-quarter of the tap threshold so the
     * full tap-vs-not-tap envelope still has 4× headroom on either
     * side of an actual multi-tap centre.
     */
    internal const val MULTI_TAP_PER_FINGER_DRIFT_PX = 25f
    internal const val MULTI_TAP_PER_FINGER_DRIFT_SQ: Float =
        MULTI_TAP_PER_FINGER_DRIFT_PX * MULTI_TAP_PER_FINGER_DRIFT_PX

    /**
     * One pointer's lifetime: down location, up location, and
     * timestamps. Pure data — no behaviour. Keep the field count
     * small; this is allocated once per finger per gesture and we
     * want the GC pressure under control.
     *
     * Coordinates are in window-pixel space (matches the iOS
     * `UIWindow.location(in: window)` semantics). Timestamps are
     * `MotionEvent.getEventTime()` — boot-relative monotonic millis,
     * safe to subtract for `durationMs` computation.
     */
    internal data class TouchTrack(
        val pointerId: Int,
        val startX: Float,
        val startY: Float,
        val endX: Float,
        val endY: Float,
        val downAtMs: Long,
        val upAtMs: Long,
    ) {
        /** Squared total displacement from down → up. */
        val totalDistanceSq: Float
            get() {
                val dx = endX - startX
                val dy = endY - startY
                return dx * dx + dy * dy
            }

        /** Wall-clock duration in millis. Always non-negative. */
        val durationMs: Long
            get() = (upAtMs - downAtMs).coerceAtLeast(0L)
    }

    /**
     * One full gesture's worth of finger trajectories. The
     * `pointerCount` here is the PEAK observed pointer count, not the
     * current snapshot — multi-touch gestures may have pointers come
     * and go, and the classifier's distance-sum heuristics need to
     * see every track that participated.
     *
     * Pre-condition: [tracks] is non-empty when fed to [classify].
     * The caller ([TouchTracker]) should never assemble an empty
     * batch — it only fires when the LAST pointer goes up.
     */
    internal data class GestureBatch(val tracks: List<TouchTrack>)

    /**
     * Classify a finished gesture. Returns the best-fit
     * [InteractionMeta.Kind] plus normalised end coordinates +
     * normalised start coordinates (when meaningful) + duration +
     * touch-count. Caller stamps frame normalisation by passing in
     * [windowWidthPx] / [windowHeightPx] (window dimensions in
     * pixels — matches the iOS player's normalisation contract).
     *
     * Coordinate normalisation is clamped to `0..1` defensively;
     * `MotionEvent` coordinates can briefly drift outside view
     * bounds during rubber-band scroll bounces.
     */
    fun classify(
        batch: GestureBatch,
        windowWidthPx: Int,
        windowHeightPx: Int,
    ): InteractionMeta {
        require(batch.tracks.isNotEmpty()) {
            "GestureBatch.tracks must not be empty"
        }

        val pointerCount = batch.tracks.size
        val singleTouch = pointerCount == 1

        // Use the trajectory with the LARGEST displacement as the
        // representative "primary" track. For single-touch gestures
        // there's only one. For multi-touch we still need an
        // (x, y, durationMs) pair to put on the wire, and the
        // longest-distance track is the most informative.
        val primary = batch.tracks.maxByOrNull { it.totalDistanceSq }!!

        // Span from earliest down to latest up across ALL pointers
        // — peak duration of the gesture as a whole, not just the
        // primary finger.
        val gestureStartMs = batch.tracks.minOf { it.downAtMs }
        val gestureEndMs = batch.tracks.maxOf { it.upAtMs }
        val durationMs = (gestureEndMs - gestureStartMs).coerceAtLeast(0L)

        val kind: InteractionMeta.Kind = if (singleTouch) {
            classifySingle(primary, durationMs)
        } else {
            classifyMulti(batch.tracks)
        }

        val (xNorm, yNorm) = normalise(primary.endX, primary.endY, windowWidthPx, windowHeightPx)
        // Start coordinates are only useful when start ≠ end (swipe,
        // long-press-with-drift, drag). For plain taps we omit them
        // to keep the wire payload identical to iOS plain taps.
        val (startNormX, startNormY) = if (kind == InteractionMeta.Kind.TAP || kind == InteractionMeta.Kind.MULTI_TAP) {
            null to null
        } else {
            val (sx, sy) = normalise(primary.startX, primary.startY, windowWidthPx, windowHeightPx)
            sx to sy
        }

        return InteractionMeta(
            tapKind = kind,
            tapXNorm = xNorm,
            tapYNorm = yNorm,
            tapStartXNorm = startNormX,
            tapStartYNorm = startNormY,
            gestureDurationMs = durationMs,
            touchCount = pointerCount,
        )
    }

    // ─── Internal classification ────────────────────────────────

    /**
     * One-finger gestures. Decision tree:
     *   1. Movement < 100 px && duration < 500 ms → tap
     *   2. Movement < 100 px && duration ≥ 500 ms → long_press
     *   3. Movement ≥ 100 px → swipe in dominant axis
     */
    private fun classifySingle(
        track: TouchTrack,
        durationMs: Long,
    ): InteractionMeta.Kind {
        val movedFar = track.totalDistanceSq >= TAP_DISTANCE_SQ_THRESHOLD
        if (!movedFar) {
            return if (durationMs >= LONG_PRESS_DURATION_MS) {
                InteractionMeta.Kind.LONG_PRESS
            } else {
                InteractionMeta.Kind.TAP
            }
        }
        // Swipe direction by dominant axis (mirrors web SDK
        // `auto/interaction-taxonomy.ts` swipe direction logic +
        // iOS `UISwipeGestureRecognizer.Direction` semantics).
        val dx = track.endX - track.startX
        val dy = track.endY - track.startY
        return if (abs(dx) >= abs(dy)) {
            if (dx >= 0) InteractionMeta.Kind.SWIPE_RIGHT else InteractionMeta.Kind.SWIPE_LEFT
        } else {
            // Y axis: positive Y in MotionEvent space points DOWN
            // the screen (Android convention). Swipe-down means the
            // finger moved toward larger y.
            if (dy >= 0) InteractionMeta.Kind.SWIPE_DOWN else InteractionMeta.Kind.SWIPE_UP
        }
    }

    /**
     * Two-or-more-finger gestures. Decision tree:
     *   1. Inter-pointer distance changed by ≥50 px between start
     *      and end → pinch (in if shrunk, out if grew).
     *   2. Sum of all tracks' distance < N × 100 px² → multi_tap.
     *   3. Otherwise → scroll_end (multi-touch drag/two-finger pan).
     *
     * The pinch test wins over the multi-tap test because two
     * fingers tapping in the SAME spot also have low movement; the
     * inter-pointer distance change is the actual discriminator.
     */
    private fun classifyMulti(tracks: List<TouchTrack>): InteractionMeta.Kind {
        // Need at least the first two pointers to compute pinch
        // distance change. If any one track has zero-second timing
        // we still proceed — we're using spatial info, not temporal.
        val a = tracks[0]
        val b = tracks[1]
        val initialDist = hypot((b.startX - a.startX).toDouble(), (b.startY - a.startY).toDouble()).toFloat()
        val finalDist = hypot((b.endX - a.endX).toDouble(), (b.endY - a.endY).toDouble()).toFloat()
        val deltaDist = finalDist - initialDist
        if (abs(deltaDist) >= PINCH_DISTANCE_DELTA_PX) {
            return if (deltaDist < 0) InteractionMeta.Kind.PINCH_IN
            else InteractionMeta.Kind.PINCH_OUT
        }

        // Multi-tap: EVERY pointer must individually be near-
        // stationary (< 25 px drift). The previous heuristic was
        // sum-based (`sumSq < TAP_DISTANCE_SQ_THRESHOLD * tracks.size`)
        // which let a 2-finger 30px-each parallel pan slip through
        // as multi-tap (sum 1800 px² < 20 000 px² × 2). The per-
        // finger check correctly rejects two-finger pans where
        // both fingers drifted but the inter-pointer delta stayed
        // below the pinch threshold. Real-world multi-taps are
        // very stationary — finger-down jitter is typically
        // 5-10 px so 25 px tolerance per finger is comfortable.
        val allFingersStatic = tracks.all { it.totalDistanceSq < MULTI_TAP_PER_FINGER_DRIFT_SQ }
        if (allFingersStatic) {
            return InteractionMeta.Kind.MULTI_TAP
        }

        // Two-or-more-finger drag/pan with no inter-pointer
        // distance change → looks like content scrolling. Use
        // scroll_end so the dashboard player draws no tap dot.
        return InteractionMeta.Kind.SCROLL_END
    }

    /** Clamp to `0..1` and divide by window dimension. Defensive. */
    private fun normalise(x: Float, y: Float, w: Int, h: Int): Pair<Float, Float> {
        val xn = if (w > 0) (x / w).coerceIn(0f, 1f) else 0f
        val yn = if (h > 0) (y / h).coerceIn(0f, 1f) else 0f
        return xn to yn
    }
}
