package io.kixo.sdk.internal.queue

import android.util.Log
import io.kixo.sdk.PushProvider
import io.kixo.sdk.internal.model.BatchPayload
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.storage.EventStore
import io.kixo.sdk.internal.transport.BatchOutcome
import io.kixo.sdk.internal.transport.TransportContract
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonPrimitive

/**
 * Ships events from the SDK to `/api/sdk/batch` with batching, jitter,
 * a bounded buffer and the cooldown pivot to recovery.
 *
 * Faithful Kotlin port of `kixo-ios-sdk/Sources/Kixo/EventQueue.swift`
 * with two adaptations for the platform:
 *   1. **Coroutines, not GCD.** `workQueue.async { … }` becomes
 *      `scope.launch { … }`. The serialising "lock" becomes a
 *      coroutine [Mutex] so we don't block a thread while waiting
 *      for it. Same suspend/resume semantics as iOS's NSLock-around-
 *      DispatchQueue but cheaper to compose.
 *   2. **StateFlow for lifecycle.** The Kixo facade subscribes to
 *      [lifecycleState] to mirror our internal phase into its public
 *      `KixoDiagnostics`. iOS uses a `var` + a callback closure
 *      (`onCooldownEntered`); StateFlow gives us the same one-way
 *      signal with built-in latest-value semantics.
 *
 * **Five invariants (verbatim from iOS):**
 *
 *   1. **Host app NEVER crashes.** Every error path swallows; the
 *      worst case is dropped analytics, never a crash. AGENT_BRIEFING
 *      R6.
 *
 *   2. **We retry on the same schedule as the web SDK.** The first
 *      10 failed sends fire on a fast schedule (5 / 10 / 20 / 30 /
 *      60s × 6). Failures 11-29 retry every 60s. Failures 30+
 *      enter a 30-min cooldown. See [RetryScheduler].
 *
 *   3. **Buffer is bounded.** `maxBufferSize` (default 200) caps
 *      both the in-memory batch and the on-disk store. When a new
 *      event would push the queue over the cap, the OLDEST is
 *      dropped (FIFO) — handled inside [EventStore.append] (Agent 3).
 *
 *   4. **Jitter prevents thundering herd.** Every retry delay gets
 *      a random ±25% wobble. When the backend recovers from an
 *      outage a million clients don't hit `/api/sdk/batch`
 *      simultaneously.
 *
 *   5. **First success resets state.** One good 2xx with at least
 *      one accepted event clears `consecutiveFailures` and snaps
 *      us back to the normal cadence. There's no slow decay —
 *      recovery is immediate.
 *
 * **Lifecycle interplay:**
 *  - `Initialising` / `Recovering`: events buffer, no flush.
 *  - `Running`: normal flush cadence.
 *  - `PausedByServer`: events DROPPED at enqueue time + the durable
 *    buffer is drained on entry. The server told us to stop;
 *    persisting more would just delay recovery.
 *
 * **Threading model:** all internal mutations + flushes run on the
 * `scope` parameter (a `CoroutineScope` rooted in `SupervisorJob +
 * Dispatchers.Default`). Public methods are safe to call from any
 * thread. Public methods that need to interact with internal state
 * either marshal through the scope or use `synchronized`.
 */
internal class EventQueue(
    private val store: EventStore,
    private val transport: TransportContract,
    private val payloadAssembler: BatchPayloadAssembler,
    private val scope: CoroutineScope,
    /**
     * Number of buffered events that triggers an immediate flush.
     * Mirrors iOS's `Configuration.flushAt` default 20. Pass a
     * smaller value in tests to avoid having to enqueue 20 events.
     */
    private val flushAt: Int = 20,
    /**
     * Periodic flush cadence. Default 30s — same as iOS + the web SDK.
     */
    private val flushIntervalMs: Long = 30_000L,
    /**
     * FIFO cap on the on-disk + in-memory buffer. The store enforces
     * this when [append][EventStore.append] is called; the queue
     * just passes it through for diagnostics.
     */
    private val maxBufferSize: Int = 200,
    /** Verbose logcat output (debug builds only). */
    private val debug: Boolean = false,
    /**
     * Wave 13 — opt-out for the periodic-flush timer started in
     * `init { startPeriodicFlush() }`. Production always wants it
     * (default `true`); tests under `runTest` + virtual time pass
     * `false` so the scheduler doesn't get spammed with N years
     * worth of timer ticks every time `advanceTimeBy(...)` is
     * called inside a retry loop. Without this, `runTest`'s
     * "drain everything before completing" semantic ends up
     * cleaning up dozens of orphaned mutex-acquirer coroutines
     * from the periodic-flush ticker, which can take real-time
     * minutes when the virtual-time advance crossed many flush
     * intervals.
     */
    private val enablePeriodicFlush: Boolean = true,
    /**
     * Wave 14 — opt-out for the auto-retry path inside
     * [scheduleRetry]. Production wants it (`true`): a
     * NetworkError / transient HttpError ticks the failure counter
     * and a retry is launched on a backoff schedule. Tests under
     * `runTest` + virtual time pass `false` so each `flush()`
     * call corresponds to EXACTLY ONE `postBatch` call, with no
     * background retries firing during the next
     * `advanceTimeBy(...)` window.
     *
     * The cooldown-pivot logic (transition to
     * [LifecycleState.Recovering] when [consecutiveFailures]
     * crosses [RetryScheduler.COOLDOWN_THRESHOLD]) STILL fires
     * regardless of this flag — it's a state-machine transition,
     * not a retry — so the cooldown unit test re-uses the same
     * queue + a 30-iteration `repeat { q.flush() }` to exercise
     * the lifecycle change without any parked coroutines.
     *
     * Without this opt-out, `advanceUntilIdle()` after a
     * NetworkError walks the retry chain all the way to cooldown
     * (every parked `delay(N)` wakes up and chains another retry),
     * which broke the original [`transient failure...`] +
     * [`success after failures...`] tests in Wave 13. See trace
     * in [project_android_sdk.md] Wave 14 #1 for the analysis.
     */
    private val enableAutoRetry: Boolean = true,
) {

    // ─── State ────────────────────────────────────────────────────

    /** Coroutine mutex around all state-mutating sections. */
    private val mutex: Mutex = Mutex()

    /**
     * Number of consecutive failed flushes since the last partial-
     * or-full success. Resets to 0 on success.
     *
     * Modified under [mutex]. Read by [diagnostics] (snapshot under
     * the same mutex) and by the retry loop after each flush attempt.
     */
    private var consecutiveFailures: Int = 0

    /**
     * Set while a flush is in-flight so two concurrent flushes don't
     * race and re-send the same events twice.
     *
     * Modified under [mutex]. iOS uses a bool guarded by NSLock for
     * the same purpose.
     */
    private var isFlushing: Boolean = false

    /**
     * Lifecycle phase as a [StateFlow] — emit on every transition so
     * the Kixo facade can mirror it into its public `KixoDiagnostics`
     * without polling.
     *
     * Default starting state is [LifecycleState.Initialising]. The
     * Kixo facade transitions us to [LifecycleState.Running] (or
     * [LifecycleState.PausedByServer]) once `/api/sdk/init` resolves.
     */
    private val _lifecycleState: MutableStateFlow<LifecycleState> =
        MutableStateFlow(LifecycleState.Initialising)

    /**
     * The dedup pass for identify/user_property/push_token events.
     * Held by the queue (rather than a separate singleton) because
     * the lifecycle of dedup state matches the queue's lifecycle —
     * both reset on `Kixo.reset()`.
     */
    private val identityDedup: IdentityDedup = IdentityDedup()

    /**
     * Once-per-cooldown-episode flag for the `Recovering` transition.
     * Without it, every retry while the failure counter sits at 30+
     * would re-emit the lifecycle transition. Reset when the failure
     * counter drops back below threshold (i.e., on success).
     *
     * Modified under [mutex].
     */
    private var hasNotifiedCooldown: Boolean = false

    /**
     * Handle to the periodic flush coroutine so [stop] can cancel
     * it cleanly. Started lazily on the first [enqueue] / [flush]
     * call (which is also when `scope` is guaranteed to be alive).
     */
    private var periodicFlushJob: Job? = null

    /**
     * Best-effort cached pending count from the last successful
     * [store.pendingCount] read (taken inside the flush path or after
     * an enqueue). Updated under no lock so [diagnostics] can read it
     * without suspending. Critic 7 fix: replaces the prior
     * [runBlocking] inside [diagnostics] which could ANR if a host
     * called diagnostics() from the main thread at a UI moment. The
     * slight staleness is documented in [QueueDiagnostics] —
     * diagnostics is best-effort by contract.
     */
    @Volatile
    private var lastKnownPendingCount: Int = 0

    init {
        if (enablePeriodicFlush) startPeriodicFlush()
    }

    // ─── Public API ──────────────────────────────────────────────

    /**
     * Reactive view of the lifecycle phase. Subscribe from the Kixo
     * facade to surface the same value through `Kixo.diagnostics()`.
     * Cold-collected — no background work is started just because
     * someone subscribes.
     */
    fun lifecycleState(): StateFlow<LifecycleState> = _lifecycleState.asStateFlow()

    /**
     * Append an event to the queue. Persisted via [EventStore.append]
     * BEFORE returning so a crash before the next flush still
     * preserves it. Triggers an immediate flush if the threshold is
     * met AND we're in [LifecycleState.Running].
     *
     * **Identity dedup:** events with `eventType` in the dedup set
     * (`identify` / `user_property` / `push_token`) are gated through
     * [IdentityDedup] BEFORE persistence. A duplicate identify call
     * with the same traits never touches disk. See iOS comment in
     * `Kixo.swift`: "Observed on LikePost: 41 `identify`, 37
     * `user_property`, 10 `push_token` per device in a 2h window".
     *
     * **Paused state:** events are dropped silently. The server told
     * us to stop. Persisting them would just delay recovery when
     * the server resumes us.
     */
    suspend fun enqueue(event: KixoEvent) {
        // Drop early when paused — never write to disk.
        val state = _lifecycleState.value
        if (state is LifecycleState.PausedByServer) {
            if (debug) Log.d(TAG, "Drop event ${event.eventId}: SDK paused (${state.reason ?: "unspecified"})")
            return
        }

        // Identity dedup (the iOS hot-path optimisation). The dedup
        // decision is made BEFORE the persistence call so a no-op
        // identify never touches disk.
        if (!shouldEmitForDedup(event)) {
            if (debug) Log.v(TAG, "Drop event ${event.eventId}: identity dedup matched prior call")
            return
        }

        // Persist. The store enforces the FIFO cap (`maxBufferSize`)
        // by dropping the oldest row if needed — that's an internal
        // detail of EventStore.append, the queue doesn't need to
        // double-check.
        runCatching { store.append(event) }
            .onFailure { t ->
                // R6: never throw out of enqueue. A persistence
                // failure (disk full, encoding bug, sqlite locked)
                // means we drop the event — but not the host app.
                if (debug) Log.w(TAG, "Persist failed for ${event.eventId}", t)
            }

        // Threshold trigger. Re-check `Running` AND `!isFlushing`
        // inside the mutex at fire time — the state we read above
        // could be stale by now (a parallel flush failed and ticked
        // us into `Recovering` between the dedup check and here).
        val pending = runCatching { store.pendingCount() }.getOrDefault(Int.MAX_VALUE)
        // Refresh the diagnostics cache (Critic 7 fix). Skip on the
        // Int.MAX_VALUE sentinel which means the count call failed —
        // we don't want to lie about an unbounded queue.
        if (pending != Int.MAX_VALUE) lastKnownPendingCount = pending
        if (pending >= flushAt) {
            scope.launch { tryFlush() }
        }
    }

    /**
     * Best-effort drain. Idempotent; safe to call from any thread.
     * Returns immediately — the actual send happens async on
     * [scope].
     *
     * No-op if the queue is suspended (anything but
     * [LifecycleState.Running]) or already flushing — the in-flight
     * batch will still resolve on its own.
     */
    fun flush() {
        scope.launch { tryFlush() }
    }

    /**
     * Synchronous drain for tests + manual triggers. Blocks the
     * calling thread until the flush completes or the timeout
     * elapses.
     *
     * **MUST NOT be called from the main thread** — uses
     * `runBlocking` internally which would ANR a real Android app.
     * The contract (also in the briefing) is "test-only / manual
     * teardown only". Provided so tests don't have to plumb
     * `runTest` everywhere.
     *
     * @return `true` if a flush completed within the timeout
     *         (success OR no-op-with-empty-buffer counts), `false`
     *         on timeout.
     */
    fun flushBlocking(timeoutMs: Long): Boolean {
        // Marshal to the queue's scope/dispatcher so we honour the
        // serialisation guarantee. `runBlocking` parks the caller's
        // thread; the actual flush still runs on `scope`'s
        // dispatcher (Default by convention) so we don't deadlock
        // on a single-thread executor.
        return runBlocking(Dispatchers.Default) {
            withTimeoutOrNull(timeoutMs) {
                tryFlush()
                true
            } ?: false
        }
    }

    /**
     * Transition the lifecycle phase. Called by the Kixo facade
     * (Agent 1) from `/api/sdk/init` outcomes and from its
     * recovery-loop. Side effects:
     *   - On entering `Running`: kicks an immediate flush so
     *     events buffered during the suspend window land
     *     promptly instead of waiting for the next periodic tick.
     *   - On entering `PausedByServer`: drains the durable buffer.
     *     The server told us to stop; events sitting in the queue
     *     waiting to be sent are wasted disk.
     *   - On entering `Recovering` from `Running`: resets the
     *     failure counter so the next attempt starts from rapid-
     *     tier rather than cooldown. (The iOS path does the same
     *     via `resetFailureCounter()`.)
     *
     * Idempotent: setting the same state twice is a cheap no-op.
     */
    fun setLifecycleState(state: LifecycleState) {
        val prev = _lifecycleState.value
        if (prev == state) return
        _lifecycleState.value = state

        if (debug) Log.d(TAG, "Lifecycle ${prev.name} → ${state.name}")

        when (state) {
            is LifecycleState.Running -> {
                // Reset failure counter + clear cooldown notification
                // flag so the next failure starts the rapid tier
                // again from #1.
                scope.launch {
                    mutex.withLock {
                        consecutiveFailures = 0
                        hasNotifiedCooldown = false
                    }
                    // Kick a flush so buffered events ship right away.
                    tryFlush()
                }
            }
            is LifecycleState.PausedByServer -> {
                // Drain on-disk buffer. The server told us to stop;
                // events queued waiting to ship are now dead weight.
                scope.launch {
                    runCatching { store.clear() }
                        .onFailure { t ->
                            if (debug) Log.w(TAG, "Drain on pause failed", t)
                        }
                }
            }
            else -> {
                // Initialising / Recovering: no immediate side effect
                // beyond suspending the flush path (the periodic flush
                // checks state before each attempt).
            }
        }
    }

    /**
     * Wipe identity dedup caches. Called from `Kixo.reset()` after
     * a logout so a re-identify with the same payload still fires
     * once.
     *
     * Does NOT touch the durable event store — the host can
     * separately call `clear()` through Agent 3's API if they
     * want a full reset.
     */
    fun resetIdentityDedup() {
        identityDedup.reset()
    }

    /**
     * Snapshot of queue health for `Kixo.diagnostics()`.
     *
     * **Best-effort, never blocks (Critic 7 fix).** An earlier
     * revision called `store.pendingCount()` + acquired the coroutine
     * [mutex] inside a `runBlocking(Dispatchers.Default)`. Even on
     * Default, `runBlocking` parks the calling thread until the work
     * completes — if a host calls `Kixo.diagnostics()` from the main
     * thread during a UI moment AND the SQLite count query takes
     * longer than the ANR window (e.g. checkpoint stall on a
     * write-heavy app), the host ANRs. The fix:
     *  - Read the cached [lastKnownPendingCount] (Volatile, lock-
     *    free) instead of touching SQLite. The cache is refreshed
     *    after every [enqueue] threshold check + after every
     *    successful flush — so it lags the truth by at most one
     *    flush interval (~30s) under normal load. Documented on
     *    [QueueDiagnostics].
     *  - Read [consecutiveFailures] / [isFlushing] / lifecycle as
     *    plain field reads. They're all simple primitives /
     *    references; no torn-read risk for the diagnostic use
     *    case (the worst case is a 1-microsecond inconsistency
     *    between failures and isFlushing, irrelevant for a human-
     *    readable diagnostic).
     *
     * The trade-off (slight cache staleness vs no ANR risk) is the
     * right one for a diagnostics surface that the briefing already
     * calls "best-effort."
     */
    fun diagnostics(): QueueDiagnostics {
        val lifecycle = _lifecycleState.value
        val pausedReason = (lifecycle as? LifecycleState.PausedByServer)?.reason
        val failures = consecutiveFailures
        return QueueDiagnostics(
            bufferedEventCount = lastKnownPendingCount,
            bufferCap = maxBufferSize,
            consecutiveFailures = failures,
            isFlushing = isFlushing,
            retryTier = RetryScheduler.tierName(failures),
            lifecycleState = lifecycle.name,
            pausedReason = pausedReason,
        )
    }

    // ─── Internals ───────────────────────────────────────────────

    /**
     * Identity dedup gate. Returns true if the event should be
     * emitted, false if it duplicates the last one of its kind.
     *
     * Non-dedup event types fall through unconditionally.
     *
     * The dedup hashes live in `properties` for the wire-format
     * versions of these events. We extract the relevant fields
     * defensively — wrong-shape properties (theoretically a host
     * bug) emit the event rather than silently dropping it. R6:
     * never crash; here, prefer one duplicate over zero events.
     */
    private fun shouldEmitForDedup(event: KixoEvent): Boolean {
        return when (event.eventType) {
            KixoEventType.Identify -> {
                val (userId, traits) = identifyExtractor(event)
                identityDedup.shouldEmitIdentify(userId, traits)
            }
            KixoEventType.UserProperty -> {
                val (key, value) = userPropertyExtractor(event)
                if (key == null) {
                    // Malformed user_property event — let it through.
                    true
                } else {
                    identityDedup.shouldEmitUserProperty(key, value)
                }
            }
            // The prior queue used `event.eventType == "push_token"` for
            // dedup. The real wire token is `push_token_invalidated`
            // (the only push-token-related event_type the SDK emits).
            // Use the enum form so the wire string is single-sourced
            // through @SerialName on the enum definition.
            KixoEventType.PushTokenInvalidated -> {
                val (token, provider) = pushTokenExtractor(event)
                if (token == null) {
                    true
                } else {
                    identityDedup.shouldEmitPushToken(token, provider)
                }
            }
            else -> true
        }
    }

    /**
     * Best-effort extractor for an `identify` event's payload. Reads
     * `user_id` + the rest of `properties` as traits.
     *
     * Reads directly from the real [KixoEvent] (`userId` field +
     * `properties: JsonObject`). The JsonObject is converted to
     * `Map<String, Any?>` so [IdentityDedup.shouldEmitIdentify] can
     * hash it the same way the iOS path does. Conversion cost is
     * proportional to property-bag size (small, single-digit kb in
     * practice).
     */
    private fun identifyExtractor(event: KixoEvent): Pair<String?, Map<String, Any?>> {
        return Pair(event.userId, jsonObjectToMap(event.properties))
    }

    /**
     * Extract `(key, value)` for a `user_property` event. The wire
     * shape is `{ "key": "<string>", "value": <any> }`, mirroring
     * iOS. We pull the key as a string primitive and pass the value
     * through as a kotlin-typed scalar (Boolean / Long / Double /
     * String / null) for the dedup hasher.
     */
    private fun userPropertyExtractor(event: KixoEvent): Pair<String?, Any?> {
        val props = event.properties
        val key = props["key"]?.jsonPrimitive?.contentOrNull
        val value = jsonElementToAny(props["value"])
        return Pair(key, value)
    }

    /**
     * Extract `(token, provider)` for a `push_token_invalidated`
     * event. Wire shape: `{ "push_token": "<sha256>", "push_provider": "fcm|hms|apns" }`.
     */
    private fun pushTokenExtractor(event: KixoEvent): Pair<String?, PushProvider> {
        val props = event.properties
        val token = props["push_token"]?.jsonPrimitive?.contentOrNull
        val providerStr = props["push_provider"]?.jsonPrimitive?.contentOrNull
        val provider = PushProvider.fromWireValue(providerStr) ?: PushProvider.FCM
        return Pair(token, provider)
    }

    /**
     * Convert a [JsonObject] to a `Map<String, Any?>` with kotlin-
     * typed scalars. Used by the dedup pass which needs a stable
     * non-Json representation for its SHA-256 keying (the same shape
     * iOS hashes).
     *
     * Lossy by design — the dedup only needs primitive equality, not
     * fidelity round-trips through JSON. Nested JsonObject /
     * JsonArray values recurse so multi-level traits hash
     * deterministically.
     */
    private fun jsonObjectToMap(obj: JsonObject): Map<String, Any?> =
        obj.entries.associate { (k, v) -> k to jsonElementToAny(v) }

    private fun jsonElementToAny(el: JsonElement?): Any? {
        if (el == null) return null
        return when (el) {
            is JsonNull -> null
            is JsonPrimitive -> when {
                el.isString -> el.content
                el.content == "true" -> true
                el.content == "false" -> false
                el.content.toLongOrNull() != null -> el.content.toLong()
                el.content.toDoubleOrNull() != null -> el.content.toDouble()
                else -> el.content
            }
            is JsonObject -> el.entries.associate { (k, v) -> k to jsonElementToAny(v) }
            is JsonArray -> el.map { jsonElementToAny(it) }
        }
    }

    /**
     * Single-flight flush. Honours the suspend gate (any state but
     * [LifecycleState.Running] is a no-op) and the in-flight gate
     * (a parallel flush already running is a no-op).
     *
     * Marked `private` even though [flush] / [flushBlocking] both
     * route through it — the public surface always goes through
     * the scope.
     */
    private suspend fun tryFlush() {
        // Re-check lifecycle + in-flight gate INSIDE the mutex so
        // a transition during the launch dispatch doesn't let two
        // flushes race.
        val proceed = mutex.withLock {
            val state = _lifecycleState.value
            if (state !is LifecycleState.Running) return@withLock false
            if (isFlushing) return@withLock false
            isFlushing = true
            true
        }
        if (!proceed) return

        // Claim the batch. The store flips claimed rows to in-flight
        // (Mixpanel MPDB pattern) so a parallel claim wouldn't see
        // them. No buffer here — the queue is a thin orchestrator
        // over the durable store.
        val batch: List<KixoEvent> = try {
            store.checkout(MAX_BATCH_SIZE)
        } catch (t: Throwable) {
            if (debug) Log.w(TAG, "checkout failed", t)
            mutex.withLock { isFlushing = false }
            return
        }

        if (batch.isEmpty()) {
            mutex.withLock { isFlushing = false }
            return
        }

        // Build the payload. Pulls the live config snapshot + the
        // device context. Cheap (data-class instantiation).
        val payload: BatchPayload = try {
            payloadAssembler.assemble(batch)
        } catch (t: Throwable) {
            // R6: assembly failure is a permanent bug, not a network
            // problem. Release the in-flight rows so they retry
            // (defensive — the bug is in our code, retry won't help,
            // but dropping silently is worse).
            if (debug) Log.w(TAG, "payload assembly failed", t)
            runCatching { store.release(batch.map { it.eventId }) }
            mutex.withLock { isFlushing = false }
            return
        }

        // Make the network call. Transport never throws — outcomes
        // are wrapped in [BatchOutcome]. R6 boundary: Transport's
        // contract owns the "never throw" guarantee for HTTP errors.
        // Convert outcome → queue's internal [BatchResponse] model so
        // the rest of the apply path stays platform-neutral (this
        // mapping used to live in `TransportAdapter` in QueueWiring;
        // post-Wave 6 refactor it lives inline as a private helper).
        val outcome: BatchOutcome = try {
            transport.postBatch(payload)
        } catch (t: Throwable) {
            // Defensive — Transport SHOULDN'T throw, but if a future
            // refactor regresses we still don't crash. Treat as
            // transient so events retry.
            if (debug) Log.w(TAG, "transport.postBatch threw (treating as transient)", t)
            BatchOutcome.NetworkError(t)
        }

        applyResponse(batch, outcome.toQueueResponse())
    }

    /**
     * Convert the real [BatchOutcome] (Agent 4's transport return type)
     * into the queue's internal [BatchResponse] model.
     *
     *  - [BatchOutcome.Success] partitions IDs into `accepted /
     *    transient / permanent`. Queue's [BatchResponse.Success]
     *    expects `acceptedEventIds` + a single `errors` list of
     *    [EventError] with `permanent` flags set per bucket. We fold
     *    permanent + transient back into one list, tagging each with
     *    the right flag.
     *  - [BatchOutcome.HttpError] flips `transient` to `permanent`
     *    via negation (queue's model expresses the inverse polarity).
     *  - [BatchOutcome.NetworkError] is always transient → discard
     *    the cause (the queue only acts on the typed outcome; the
     *    underlying exception is logged at the transport boundary).
     *  - [BatchOutcome.SerializationError] means our own payload
     *    was malformed — drop the batch as a permanent 400 so we
     *    don't loop forever on a bad shape.
     */
    private fun BatchOutcome.toQueueResponse(): BatchResponse = when (this) {
        is BatchOutcome.Success -> BatchResponse.Success(
            acceptedEventIds = acceptedIds,
            errors = permanentIds.map {
                EventError(eventId = it, message = "permanent", permanent = true)
            } + transientIds.map {
                EventError(eventId = it, message = "transient", permanent = false)
            },
            paused = paused,
            pausedReason = pausedReason,
        )
        is BatchOutcome.HttpError -> BatchResponse.HttpError(
            statusCode = code,
            permanent = !transient,
        )
        is BatchOutcome.NetworkError -> BatchResponse.NetworkError
        BatchOutcome.SerializationError -> BatchResponse.HttpError(
            statusCode = 400,
            permanent = true,
        )
    }

    /**
     * Apply the per-event acks from a [BatchResponse], reconciling
     * the durable store and updating retry / lifecycle state.
     *
     * Possible outcomes:
     *   - `Success` with at least one accepted/permanent event →
     *     reset failure counter, schedule another flush if more
     *     events arrived during the in-flight send.
     *   - `Success` with all-transient or `NetworkError` /
     *     `HttpError(transient)` → tick failure counter, schedule
     *     a retry with backoff.
     *   - `HttpError(permanent)` (e.g. 401) → drop the events,
     *     transition to `PausedByServer`. The host's API key is
     *     wrong; retrying makes nothing better.
     *   - `Success(paused=true)` → server has flipped our SDK
     *     to off; transition to `PausedByServer` carrying the
     *     server's reason code.
     */
    private suspend fun applyResponse(batch: List<KixoEvent>, response: BatchResponse) {
        when (response) {
            is BatchResponse.Success -> {
                // Per-event ack contract (briefing R5):
                //   - in `acceptedEventIds` → DELETE
                //   - in `errors` with permanent=true → DELETE
                //   - in `errors` with permanent=false → release (flag=0, retry)
                //   - missing from BOTH → defensive: treat as accepted
                val acceptedIds = response.acceptedEventIds.toMutableSet()
                val transientIds = mutableSetOf<String>()
                val permanentIds = mutableSetOf<String>()
                for (err in response.errors) {
                    if (err.permanent) permanentIds += err.eventId
                    else transientIds += err.eventId
                }

                // Defensive: an event that appears in BOTH the
                // accepted list AND the errors list would be
                // ambiguous. Trust the explicit error over the
                // accepted (matches iOS Transport.swift's resolved-
                // ids semantics — error wins).
                for (id in transientIds) acceptedIds.remove(id)
                for (id in permanentIds) acceptedIds.remove(id)

                // Defensive: any batched event NOT mentioned in
                // either array — treat as accepted (legacy backend
                // semantics). The iOS Transport's response parser
                // uses `transient` as the fallback; we use
                // `accepted` here because Agent 4's Android
                // Transport will already apply the same defensive
                // conversion before returning to us. Either way,
                // the apply path is correct.
                val mentioned = acceptedIds + transientIds + permanentIds
                for (e in batch) {
                    if (e.eventId !in mentioned) acceptedIds += e.eventId
                }

                // Settle: accepted + permanent are dropped from the
                // store; transient are released for the next claim.
                runCatching {
                    store.confirm((acceptedIds + permanentIds).toList())
                }.onFailure { if (debug) Log.w(TAG, "confirm failed", it) }

                runCatching {
                    if (transientIds.isNotEmpty()) {
                        store.release(transientIds.toList())
                    }
                }.onFailure { if (debug) Log.w(TAG, "release failed", it) }

                // Counter logic — "made progress" means accepted OR
                // permanent (both indicate the backend is reachable
                // and processing).
                val madeProgress = acceptedIds.isNotEmpty() || permanentIds.isNotEmpty()
                val anyTransient = transientIds.isNotEmpty()
                val (failures, hadFailures) = mutex.withLock {
                    val prev = consecutiveFailures
                    if (madeProgress) {
                        consecutiveFailures = 0
                        hasNotifiedCooldown = false
                    } else if (anyTransient) {
                        consecutiveFailures += 1
                    }
                    isFlushing = false
                    Pair(consecutiveFailures, prev > 0)
                }

                if (madeProgress && hadFailures && debug) {
                    Log.i(TAG, "Recovered after failures — back to normal cadence")
                }

                // Handle server-paused signal. The Success carries
                // `paused=true` when the project was killed mid-batch
                // — we honour that by transitioning lifecycle even
                // though the events themselves landed.
                if (response.paused) {
                    setLifecycleState(LifecycleState.PausedByServer(response.pausedReason))
                    return
                }

                // Retry path for all-transient outcomes (no progress).
                if (!madeProgress && anyTransient) {
                    scheduleRetry(failures)
                }

                // Made progress AND there's still data to ship?
                // Don't wait for the periodic timer.
                if (madeProgress) {
                    val pending = runCatching { store.pendingCount() }.getOrDefault(0)
                    // Refresh diagnostics cache (Critic 7 fix).
                    lastKnownPendingCount = pending
                    if (pending > 0) scope.launch { tryFlush() }
                }
            }

            is BatchResponse.HttpError -> {
                if (response.permanent) {
                    // 4xx (except 429): permanent. The events are
                    // bad / the host is misconfigured. Drop them so
                    // we don't loop forever, and pivot to
                    // PausedByServer carrying a synthetic reason so
                    // the host's diagnostics surface the cause.
                    runCatching { store.confirm(batch.map { it.eventId }) }
                    mutex.withLock {
                        consecutiveFailures = 0
                        hasNotifiedCooldown = false
                        isFlushing = false
                    }
                    val reason = "http_${response.statusCode}"
                    if (debug) Log.w(TAG, "Permanent batch failure ($reason) — pausing SDK")
                    setLifecycleState(LifecycleState.PausedByServer(reason))
                } else {
                    // Transient HTTP — re-release rows + tick counter.
                    runCatching { store.release(batch.map { it.eventId }) }
                    val failures = mutex.withLock {
                        consecutiveFailures += 1
                        isFlushing = false
                        consecutiveFailures
                    }
                    scheduleRetry(failures)
                }
            }

            is BatchResponse.NetworkError -> {
                // Network-level failure — release rows, tick counter,
                // schedule retry with backoff.
                runCatching { store.release(batch.map { it.eventId }) }
                val failures = mutex.withLock {
                    consecutiveFailures += 1
                    isFlushing = false
                    consecutiveFailures
                }
                scheduleRetry(failures)
            }
        }
    }

    /**
     * Schedule a retry at the current tier's delay. If the failure
     * count crosses [RetryScheduler.COOLDOWN_THRESHOLD], also
     * transition to [LifecycleState.Recovering] — the lifecycle
     * controller (Kixo facade) listens for that and pivots to
     * `/api/sdk/init` re-fetch instead of continuing to hammer
     * `/api/sdk/batch`.
     *
     * Once-per-cooldown-episode notification: [hasNotifiedCooldown]
     * gates the transition so a retry-loop sitting at 35 failures
     * doesn't re-emit the lifecycle change every attempt. The flag
     * resets when the failure counter resets.
     */
    private suspend fun scheduleRetry(failures: Int) {
        // Cooldown pivot — fire once per episode. Runs regardless of
        // [enableAutoRetry] because it's a state-machine transition,
        // not a retry. The cooldown unit test relies on this so it
        // can drive 30 manual `flush()` calls and observe the
        // Running → Recovering transition without parking any
        // background coroutines.
        if (failures >= RetryScheduler.COOLDOWN_THRESHOLD) {
            val shouldPivot = mutex.withLock {
                if (hasNotifiedCooldown) false
                else {
                    hasNotifiedCooldown = true
                    true
                }
            }
            if (shouldPivot) {
                // Transition to Recovering. The Kixo facade subscribes
                // to lifecycleState() and will start its config-refetch
                // loop on this signal. We DON'T schedule the retry
                // delay below — recovery is the controller's job from
                // here.
                setLifecycleState(LifecycleState.Recovering)
                return
            }
        }

        // Wave 14 — opt-out for tests. Production keeps it on so
        // a NetworkError chains a backoff retry instead of waiting
        // for the next periodic flush. Tests pass `false` so each
        // `flush()` corresponds to exactly one `postBatch` (no
        // parked retries firing during `advanceTimeBy(...)`).
        if (!enableAutoRetry) return

        val delayMs = RetryScheduler.nextDelayMs(failures)
        if (debug) Log.d(TAG, "Flush failed (#$failures) — retry in ${delayMs}ms (${RetryScheduler.tierName(failures)})")

        // Normal retry: launch a delayed flush attempt. The launch
        // is fire-and-forget on `scope` — if a parallel periodic
        // tick or another scheduled retry beats us to it, the
        // single-flight gate inside [tryFlush] makes ours a no-op.
        scope.launch {
            delay(delayMs)
            // Re-check lifecycle: if we transitioned to PausedByServer
            // / Recovering during the delay, skip.
            if (_lifecycleState.value is LifecycleState.Running) {
                tryFlush()
            }
        }
    }

    /**
     * Periodic flush coroutine. Ticks every [flushIntervalMs] and
     * fires a flush when [LifecycleState.Running]. The single-flight
     * gate inside [tryFlush] handles overlapping with retry-driven
     * flushes safely.
     *
     * Cancelled when the parent `scope` is cancelled (typically only
     * at SDK teardown — production code never tears down the SDK,
     * but tests do).
     */
    private fun startPeriodicFlush() {
        periodicFlushJob?.cancel()
        periodicFlushJob = scope.launch {
            while (isActive) {
                delay(flushIntervalMs)
                if (_lifecycleState.value is LifecycleState.Running) {
                    tryFlush()
                }
            }
        }
    }

    /**
     * Test-only: bring the queue to a clean stop. Cancels the
     * periodic flush and clears in-flight state so a subsequent
     * test instance starts fresh. Production code never calls this.
     */
    internal fun stopForTest() {
        periodicFlushJob?.cancel()
        periodicFlushJob = null
        // We can't safely runBlocking inside a test teardown without
        // risking ANR on emulator-backed tests; just null out the
        // flag from any thread (atomic Boolean would be cleaner;
        // for now this is best-effort).
    }

    /**
     * Production stop hook (Critic 3 BLOCKER).
     *
     * Cancels the periodic flush coroutine started in [init] and
     * pivots lifecycle into [LifecycleState.PausedByServer] with a
     * caller-supplied [reason]. The "PausedByServer" state name is
     * a slight misnomer here — the immediate caller is `Kixo.optOut`
     * / `Kixo.reset`, not the server — but the semantics are what
     * we want: enqueue() drops events silently and the durable
     * buffer drains. (The state-name was set in stone before the
     * client-driven pause path; renaming it is a separate refactor.)
     *
     * Wiring contract: Agent 1 (the public facade) calls this from
     * `Kixo.optOut()` and `Kixo.reset()` with reasons "opted_out"
     * and "reset" respectively. Without this hook, the periodic
     * flush coroutine kept ticking forever after opt-out and would
     * sometimes catch a re-armed Running state during reset, double-
     * shipping events that the user explicitly walked away from.
     *
     * Idempotent: calling twice is harmless (cancel on a null Job is
     * a no-op).
     */
    fun stop(reason: String = "stopped") {
        periodicFlushJob?.cancel()
        periodicFlushJob = null
        // Drain + drop. Runs through setLifecycleState so the
        // PausedByServer branch wipes the durable store and any
        // observers see the transition.
        setLifecycleState(LifecycleState.PausedByServer(reason))
    }

    private companion object {
        const val TAG: String = "Kixo.EventQueue"

        /**
         * Cap on a single batch claim. Matches iOS's default
         * `loadPendingEvents(limit: 500)` — large enough to drain a
         * heavy backlog in one round trip, small enough to keep the
         * batch payload under the backend's per-request size cap.
         */
        const val MAX_BATCH_SIZE: Int = 500
    }
}

// ─────────────────────────────────────────────────────────────────────
// Internal apply-response model.
//
// [BatchResponse] + [EventError] are the queue's own per-event-ack
// reconciliation types. They were previously parallel-universe
// duplicates of the real [BatchOutcome] from Agent 4's transport;
// the Wave 6 refactor (May 2026) imports the real BatchOutcome,
// converts it to BatchResponse via [toQueueResponse] above, and uses
// these locally for the `applyResponse` partition logic.
//
// Keeping them as a queue-internal model (not an Agent-4 concern) is
// deliberate: the partition step branches on permanent / transient /
// accepted / paused with queue-specific lifecycle side-effects. Tying
// it to the transport's wire-side outcome shape would couple the
// queue's recovery state machine to the transport's encoding choices.
// ─────────────────────────────────────────────────────────────────────

/**
 * Per-event ack response classified for the queue's apply path.
 * Built from [BatchOutcome] inside [EventQueue.toQueueResponse].
 */
internal sealed class BatchResponse {
    /**
     * 2xx response from the batch endpoint. Carries per-event acks
     * + the optional server-paused signal.
     *
     * @property acceptedEventIds   IDs of events the backend stored.
     * @property errors             Per-event failures (with their
     *           `permanent` flag set).
     * @property paused             True when the server has flipped
     *           our SDK to off mid-batch (kill-switch). Triggers a
     *           transition to [LifecycleState.PausedByServer] even
     *           though THIS batch landed.
     * @property pausedReason       Server-supplied code (`"sdk_version_disabled"`,
     *           etc.) when [paused]. Surfaced through diagnostics.
     */
    data class Success(
        val acceptedEventIds: List<String>,
        val errors: List<EventError>,
        val paused: Boolean = false,
        val pausedReason: String? = null,
    ) : BatchResponse()

    /**
     * Non-2xx HTTP response. `permanent=true` means a 4xx (other
     * than 429); the events are bad and we drop them. `permanent=false`
     * means 5xx / 429; the events stay queued for retry.
     */
    data class HttpError(val statusCode: Int, val permanent: Boolean) : BatchResponse()

    /**
     * Network-level failure (no response, DNS error, TLS handshake
     * timeout). Always transient.
     */
    object NetworkError : BatchResponse()
}

/**
 * Single per-event error built into [BatchResponse.Success.errors]
 * during the [BatchOutcome] → [BatchResponse] conversion.
 */
internal data class EventError(
    val eventId: String,
    val message: String,
    /**
     * True when retrying won't help (validation failure, kill-
     * switched event_type, schema rejection). The queue drops
     * these from the durable store. False for rate-limit / timeout
     * / 5xx — those release for retry.
     */
    val permanent: Boolean,
)
