package io.kixo.sdk.internal.transport

/**
 * Centralised endpoint paths so a wire-format change is a one-file
 * edit, not a grep-and-pray sweep across replay/upload/identity. Paths
 * mirror the backend's api/sdk/... routes exactly.
 *
 * Hosts are intentionally NOT here — environment selection lives in
 * configuration (`KixoConfiguration.environment`) so the same URL set
 * works in dev / staging / prod without recompiling.
 */
internal object Endpoints {
    // ─── Core ingest ──────────────────────────────────────────
    /** Once on launch — fetches `release_id`, `data_collection`, `paused`. */
    const val INIT = "/api/sdk/init"

    /** Periodic event flush (every 30 s OR every 20 events). */
    const val BATCH = "/api/sdk/batch"

    /** Side-channel identify (most events use /batch instead). */
    const val IDENTIFY = "/api/sdk/identify"

    // ─── Push ─────────────────────────────────────────────────
    /** Once per token change — only place a plaintext push token leaves the device. */
    const val PUSH_REGISTER = "/api/sdk/push/register"

    // ─── Replay ───────────────────────────────────────────────
    /** On replay session open. */
    const val REPLAY_SESSION_START = "/api/sdk/replay/session/start"

    /** Per-tap replay metadata (interaction taxonomy + tap coords). */
    const val REPLAY_EVENTS = "/api/sdk/replay/events"

    /** When the signed-URL pool runs low. */
    const val REPLAY_FRAMES_SIGN = "/api/sdk/replay/frames/sign"

    /** Tile-style frame signing (per-leaf HEIC tiles, iOS C.3 v1+v2). */
    const val REPLAY_FRAMES_SIGN_TILES = "/api/sdk/replay/frames/sign-tiles"

    /** On replay session seal. */
    const val REPLAY_SESSION_END = "/api/sdk/replay/session/end"

    /**
     * Build a fully-qualified URL for the given base + path.
     *
     * **Wave 5: HTTPS assert.** A misconfigured operator pointing at
     * `http://sdk.dev.kixo.io` would silently ship every event
     * payload — push tokens, user_ids, full event properties — in
     * cleartext. We refuse and fall back to PROD HTTPS rather than
     * risk plaintext egress. Production-side network_security_config
     * blocks cleartext too on Android 28+, but the SDK's defensive
     * check fires earlier and produces a more readable log line.
     *
     * **Wave 14: loopback exception.** `http://localhost`,
     * `http://127.0.0.1`, `http://0.0.0.0`, `http://[::1]` pass through
     * untouched — local-dev only, no PII risk because traffic never
     * leaves the host. This is what unit tests use (OkHttp
     * `MockWebServer` always binds HTTP-only on localhost) and what
     * developers running a backend on `./gradlew run` use.
     */
    fun url(baseUrl: String, path: String): String {
        val isHttps = baseUrl.startsWith("https://")
        val isLocalHttp = baseUrl.startsWith("http://localhost") ||
            baseUrl.startsWith("http://127.0.0.1") ||
            baseUrl.startsWith("http://0.0.0.0") ||
            baseUrl.startsWith("http://[::1]")
        val safeBase = if (!isHttps && !isLocalHttp) {
            android.util.Log.w(
                "Kixo.Endpoints",
                "Refusing non-HTTPS non-loopback baseUrl '$baseUrl' — falling back to ${io.kixo.sdk.internal.KixoEndpoints.PROD}. " +
                    "Set KixoConfiguration.Builder.apiHost(\"https://...\") explicitly if you need a custom host.",
            )
            io.kixo.sdk.internal.KixoEndpoints.PROD
        } else {
            baseUrl
        }
        // Strip a trailing slash on `safeBase` so we don't end up with
        // `https://sdk.dev.kixo.io//api/sdk/batch`. Cheap to do here
        // once vs. expecting every caller to remember.
        val trimmed = if (safeBase.endsWith('/')) safeBase.dropLast(1) else safeBase
        return trimmed + path
    }
}
