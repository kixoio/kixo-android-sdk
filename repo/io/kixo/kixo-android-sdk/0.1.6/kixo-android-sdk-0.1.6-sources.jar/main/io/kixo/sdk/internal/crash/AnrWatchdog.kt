package io.kixo.sdk.internal.crash

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Main-thread heartbeat watchdog that detects App Not Responding
 * (ANR) conditions — where the UI thread has been blocked long
 * enough that Android's own ANR dialog would trigger (~5s).
 *
 * # Why a separate watchdog from [CrashTracker]
 *
 * [CrashTracker] installs a `Thread.UncaughtExceptionHandler`, which
 * fires on JVM exceptions but NEVER on ANRs — an ANR is a blocked
 * main-thread, not a throw. The OS will kill the process after 5+
 * seconds of unresponsiveness with no Kotlin code path involved, so
 * we'd lose the signal entirely without a dedicated watcher.
 *
 * iOS has the same gap and fills it with signal handlers
 * (`SIGABRT` / `SIGSEGV` on the watchdog tick); Android's idiomatic
 * answer is a Looper heartbeat: post a `Runnable` to the main thread
 * from a background thread and verify it ran within a deadline. If
 * the main `Handler` doesn't service the runnable for N consecutive
 * samples, the main thread is wedged and we capture its stack
 * **from the watchdog thread** (`Thread.stackTrace` is safe to read
 * cross-thread and works even when the target is blocked).
 *
 * # Why a plain [Thread] (not a coroutine)
 *
 * Coroutines run on a [java.util.concurrent.ExecutorService] that we
 * don't fully control; the SDK's `Dispatchers.IO` is shared with the
 * queue + transport + crash drain, and a watchdog whose health
 * depends on the same pool it's monitoring is structurally unable to
 * detect saturation of THAT pool. A `Thread(isDaemon = true)` runs
 * on its own native thread, has predictable scheduling, and exits
 * automatically when the JVM shuts down — exactly the lifetime we
 * want.
 *
 * Daemon = true is load-bearing: a non-daemon watchdog thread
 * outlives the host's main thread and prevents the process from
 * exiting cleanly during a graceful shutdown (e.g. in instrumentation
 * tests).
 *
 * # ApplicationExitInfo post-mortem
 *
 * The live heartbeat catches ANRs that happen WHILE we're running.
 * For ANRs that happened in a previous process (host got killed
 * before we could enqueue), Android 11+ exposes
 * [ActivityManager.getHistoricalProcessExitReasons], which returns a
 * list of recent terminations with reason codes including
 * [ApplicationExitInfo.REASON_ANR]. On install we read that list,
 * find entries newer than the last-seen pid (persisted in
 * SharedPreferences `kixo_anr_last_pid`), and enqueue them as crash
 * events with `anr=true` metadata. Dedup by `pid` so a relaunch
 * doesn't double-fire.
 *
 * # Anti-crash discipline (briefing R6)
 *
 * Every step is wrapped in try/catch and reports failures only to
 * logcat. The watchdog must NEVER crash the host — if our thread
 * died with an uncaught throwable, the dead watchdog would itself
 * cause the OS to ANR-kill the process if main was blocked. Every
 * loop iteration is independent.
 *
 * # No LLM / network from this path (briefing R2)
 *
 * The watchdog reads [Thread.stackTrace] and calls into a single
 * provided `enqueueCrash` lambda. The lambda is the SDK's normal
 * queue path; no HTTP, no model inference, no anything else.
 *
 * # API shape (mirrors [io.kixo.sdk.internal.lifecycle.MemoryWarningObserver])
 *
 * - [install] is idempotent. Second invocation is a no-op.
 * - [uninstall] is cancel-safe: it interrupts the watchdog thread
 *   and clears state. Designed for tests + `Kixo.reset()` paths.
 */
internal object AnrWatchdog {

    private const val TAG = "Kixo"

    /** Subdirectory / prefs prefix matching the storage convention. */
    private const val PREFS_NAME = "kixo_anr"
    private const val KEY_LAST_PID = "last_seen_pid"

    /** Heartbeat tick interval. */
    private const val HEARTBEAT_INTERVAL_MS = 1_000L

    /**
     * Consecutive missed ticks before firing an ANR event. Five
     * misses at a one-second cadence ≈ 5 seconds main-thread
     * wedged, which matches the Android ANR dialog threshold.
     */
    private const val ANR_THRESHOLD_MISSES = 5

    /** Idempotent install guard. */
    private val installed = AtomicBoolean(false)

    /**
     * Heartbeat counter incremented by the runnable that runs on the
     * main thread. The watchdog compares the current value against
     * the snapshot taken at the last tick — if it didn't move, the
     * main thread didn't service its queue.
     *
     * `AtomicLong` because the increment runs on main but the read
     * runs on the watchdog thread; we need a visibility guarantee
     * without paying for a synchronized block on every tick.
     */
    private val heartbeatCounter = AtomicLong(0L)

    /**
     * Reference to the watchdog thread so [uninstall] can interrupt
     * it. `Volatile` because the install + uninstall calls might
     * arrive on different threads.
     */
    @Volatile
    private var watchdogThread: Thread? = null

    /**
     * The enqueue callback supplied by [CrashTracker]. The caller
     * routes the payload to the EventQueue as a `crash` event with
     * `event_name = "anr"`. `Volatile` for the same cross-thread
     * reason as [watchdogThread].
     */
    @Volatile
    private var enqueueCrashRef: ((Map<String, Any?>) -> Unit)? = null

    /**
     * Install the watchdog. Spawns a daemon thread that posts a
     * heartbeat runnable to the main looper every
     * [HEARTBEAT_INTERVAL_MS]. After [ANR_THRESHOLD_MISSES]
     * consecutive missed ticks, fires an ANR event via [enqueueCrash]
     * and resets the miss counter (so a single ANR fires exactly
     * one event, not one per tick).
     *
     * Also drains historical `REASON_ANR` exits from prior processes
     * (API 30+) and enqueues each as a crash event with
     * `anr=true` + `historical=true` metadata.
     *
     * @param context Any [Context]; we promote to application
     *   context via [Context.getApplicationContext] to avoid leaking
     *   an Activity reference.
     * @param enqueueCrash Lambda that routes the assembled property
     *   map to the EventQueue as `event_type=crash, event_name=anr`.
     *   Called from the watchdog thread (NOT main). Must be
     *   thread-safe — the SDK's `enqueueCustom` adapter already is.
     */
    fun install(context: Context, enqueueCrash: (Map<String, Any?>) -> Unit) {
        if (!installed.compareAndSet(false, true)) return
        try {
            val appContext = context.applicationContext ?: context
            enqueueCrashRef = enqueueCrash

            // Drain ApplicationExitInfo BEFORE starting the live
            // watchdog so we never race a fresh-ANR enqueue against a
            // historical-ANR enqueue for the same pid.
            try {
                drainHistoricalAnrs(appContext, enqueueCrash)
            } catch (t: Throwable) {
                Log.w(TAG, "AnrWatchdog historical drain failed", t)
            }

            val mainHandler = Handler(Looper.getMainLooper())
            val thread = Thread({
                runWatchdogLoop(mainHandler, enqueueCrash)
            }, "kixo-anr-watchdog").apply {
                isDaemon = true
                // Slightly above default so we still get scheduled
                // when the host is busy — but well below the main
                // thread's default + replay threads to avoid
                // starving foreground work.
                priority = Thread.NORM_PRIORITY
            }
            watchdogThread = thread
            thread.start()
        } catch (t: Throwable) {
            // R6: never crash the host on install failure.
            Log.w(TAG, "AnrWatchdog install failed; ANR detection disabled", t)
            installed.set(false)
            watchdogThread = null
            enqueueCrashRef = null
        }
    }

    /**
     * Stop the watchdog. Idempotent. Interrupts the thread (so the
     * next `sleep` returns with [InterruptedException]) and clears
     * state. Test-only / `Kixo.reset()` path — production code
     * doesn't call this.
     */
    fun uninstall() {
        if (!installed.compareAndSet(true, false)) return
        try {
            val t = watchdogThread
            watchdogThread = null
            enqueueCrashRef = null
            t?.interrupt()
        } catch (t: Throwable) {
            Log.w(TAG, "AnrWatchdog uninstall failed", t)
        }
    }

    /**
     * The watchdog loop. Runs on the dedicated daemon thread until
     * [uninstall] interrupts it. Anti-crash: every iteration is
     * independent — a throwable in one tick doesn't kill the loop.
     */
    private fun runWatchdogLoop(
        mainHandler: Handler,
        enqueueCrash: (Map<String, Any?>) -> Unit,
    ) {
        var lastObservedCounter = heartbeatCounter.get()
        var consecutiveMisses = 0

        while (!Thread.currentThread().isInterrupted && installed.get()) {
            try {
                // Post a heartbeat runnable to main. If main is
                // alive and servicing its queue, this runnable will
                // run before we wake up next tick and the counter
                // moves. If main is wedged, it'll sit in the queue
                // and the counter will be stuck.
                mainHandler.post {
                    heartbeatCounter.incrementAndGet()
                }

                Thread.sleep(HEARTBEAT_INTERVAL_MS)

                val current = heartbeatCounter.get()
                if (current == lastObservedCounter) {
                    consecutiveMisses += 1
                    if (consecutiveMisses >= ANR_THRESHOLD_MISSES) {
                        fireAnrEvent(consecutiveMisses, enqueueCrash)
                        // Reset miss counter so a single sustained ANR
                        // fires exactly one event. The counter
                        // snapshot is also rolled forward to the
                        // CURRENT value so we don't immediately
                        // re-fire if main is still wedged on the next
                        // tick — we wait for ANOTHER full threshold
                        // of misses before firing again.
                        consecutiveMisses = 0
                        lastObservedCounter = current
                    }
                } else {
                    // Main thread serviced its queue between the
                    // last sample and this one. Reset the miss
                    // counter and snapshot the new value.
                    consecutiveMisses = 0
                    lastObservedCounter = current
                }
            } catch (_: InterruptedException) {
                // Expected from uninstall(). Exit the loop cleanly.
                Thread.currentThread().interrupt()
                return
            } catch (t: Throwable) {
                // R6: any other throwable is logged and we continue.
                // A dead watchdog is worse than a flaky one.
                try {
                    Log.w(TAG, "AnrWatchdog loop iteration failed", t)
                } catch (_: Throwable) { /* logger itself failed */ }
            }
        }
    }

    /**
     * Capture the main thread's stack trace + device context and
     * forward to [enqueueCrash]. Runs on the watchdog thread — main
     * is, by definition, blocked when this fires, so we MUST NOT
     * touch any API that posts back to main (e.g. broadcasts).
     *
     * [Thread.getStackTrace] is safe to call cross-thread on a
     * blocked target: the JVM walks the target's frame stack
     * directly, no cooperation from the target needed.
     */
    private fun fireAnrEvent(
        missedTicks: Int,
        enqueueCrash: (Map<String, Any?>) -> Unit,
    ) {
        try {
            val mainThread = Looper.getMainLooper().thread
            val stackFrames = try {
                mainThread.stackTrace
            } catch (_: Throwable) {
                emptyArray<StackTraceElement>()
            }
            val stackTrace = buildString {
                append(mainThread.name ?: "main")
                append(" (")
                append(mainThread.state.name)
                append(")\n")
                var capped = false
                for (frame in stackFrames) {
                    append("  at ").append(frame.toString()).append('\n')
                    // Bound the payload — Android's main stack on a
                    // wedged JNI call can be 100+ frames deep.
                    if (length > 16_384) {
                        append("  ... (truncated)\n")
                        capped = true
                        break
                    }
                }
                if (!capped && stackFrames.isEmpty()) {
                    append("  (stack unavailable)\n")
                }
            }

            val props: Map<String, Any?> = linkedMapOf(
                "thread_name" to (mainThread.name ?: "main"),
                "stack_trace" to stackTrace,
                "frozen_ms" to (missedTicks.toLong() * HEARTBEAT_INTERVAL_MS),
                "api_level" to Build.VERSION.SDK_INT,
                "device_model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                "os_version" to (Build.VERSION.RELEASE ?: "unknown"),
                "anr" to true,
                "historical" to false,
            )
            enqueueCrash(props)
        } catch (t: Throwable) {
            try {
                Log.w(TAG, "AnrWatchdog fireAnrEvent failed", t)
            } catch (_: Throwable) { /* swallow */ }
        }
    }

    /**
     * Read recent [ApplicationExitInfo] entries (API 30+) and
     * enqueue any [ApplicationExitInfo.REASON_ANR] exits we haven't
     * seen before. Dedup by `pid` via SharedPreferences so a
     * relaunch doesn't re-fire the same one.
     *
     * Bounded to the most-recent 5 exits — covers the common case
     * (single ANR → fast relaunch) without inflating cold-start.
     */
    private fun drainHistoricalAnrs(
        appContext: Context,
        enqueueCrash: (Map<String, Any?>) -> Unit,
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return

        val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE)
            as? ActivityManager ?: return

        val prefs = try {
            appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        } catch (_: Throwable) {
            null
        }
        val lastSeenPid = prefs?.getInt(KEY_LAST_PID, -1) ?: -1

        val packageName = try {
            appContext.packageName
        } catch (_: Throwable) {
            null
        } ?: return

        val exits: List<ApplicationExitInfo> = try {
            activityManager.getHistoricalProcessExitReasons(packageName, 0, 5) ?: emptyList()
        } catch (_: Throwable) {
            emptyList()
        }

        var newestPid = lastSeenPid
        for (exit in exits) {
            try {
                if (exit.reason != ApplicationExitInfo.REASON_ANR) continue
                val pid = exit.pid
                // Track newest pid across ALL ANR entries so the
                // next launch's high-water mark is correct.
                if (pid > newestPid) newestPid = pid
                // Skip pids we've already drained.
                if (pid <= lastSeenPid) continue

                val stackTrace = readStackTrace(exit)
                val props: Map<String, Any?> = linkedMapOf(
                    "thread_name" to "main",
                    "stack_trace" to stackTrace,
                    "frozen_ms" to (ANR_THRESHOLD_MISSES.toLong() * HEARTBEAT_INTERVAL_MS),
                    "api_level" to Build.VERSION.SDK_INT,
                    "device_model" to "${Build.MANUFACTURER} ${Build.MODEL}",
                    "os_version" to (Build.VERSION.RELEASE ?: "unknown"),
                    "anr" to true,
                    "historical" to true,
                    "historical_pid" to pid,
                    "historical_timestamp_ms" to exit.timestamp,
                    "historical_description" to (exit.description ?: ""),
                    "historical_importance" to exit.importance,
                )
                enqueueCrash(props)
            } catch (t: Throwable) {
                Log.w(TAG, "AnrWatchdog historical entry skipped", t)
            }
        }

        // Persist the new high-water mark even if we drained zero
        // entries — keeps the dedup correct on subsequent launches.
        if (newestPid != lastSeenPid && prefs != null) {
            try {
                prefs.edit().putInt(KEY_LAST_PID, newestPid).apply()
            } catch (t: Throwable) {
                Log.w(TAG, "AnrWatchdog prefs persist failed", t)
            }
        }
    }

    /**
     * Best-effort read of the ANR trace blob embedded in an
     * [ApplicationExitInfo]. Bounded to 16 KiB so a multi-MB
     * stack-dump doesn't bloat the wire payload.
     */
    private fun readStackTrace(exit: ApplicationExitInfo): String {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return ""
        return try {
            exit.traceInputStream?.use { stream ->
                val bytes = ByteArray(16_384)
                val read = stream.read(bytes)
                if (read <= 0) "" else String(bytes, 0, read, Charsets.UTF_8)
            } ?: ""
        } catch (_: Throwable) {
            ""
        }
    }

    /**
     * Test-only — reset install state so a fresh [install] re-wires
     * the watchdog. Production code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        uninstall()
        heartbeatCounter.set(0L)
    }
}
