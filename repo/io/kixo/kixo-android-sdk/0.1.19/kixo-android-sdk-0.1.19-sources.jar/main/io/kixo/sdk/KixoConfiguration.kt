package io.kixo.sdk

import android.content.Context
import android.content.pm.ApplicationInfo

/**
 * Configuration for the Kixo SDK. Constructed via [Builder] (Kotlin
 * DSL or Java fluent), then handed to [Kixo.configure].
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Configuration.swift`
 * (`ConfigurationOptions` / `Configuration` pair). On iOS the two are
 * separate — `ConfigurationOptions` is public, `Configuration` is
 * internal. On Android we collapse to one public class and slot the
 * `projectId` / `apiKey` parsing into the same place. Runtime replay
 * policy is resolved from the project in the Kixo dashboard; the
 * legacy replay builder fields remain only for source compatibility.
 *
 * **Why a Builder, not a `data class` with default arguments?** The
 * config has 18+ fields, most with reasonable defaults. A Kotlin
 * data-class call site like:
 * ```
 * KixoConfiguration("kx_proj_…", "kx_key_…", autoTrackTaps = true,
 *     maxBufferSize = 200, …)
 * ```
 * doesn't read well past 5-6 named arguments and is hostile to Java
 * callers (who'd need to thread defaults manually since named
 * arguments aren't a Java feature). The Builder pattern stays
 * idiomatic for both languages and gives Java a clean fluent API.
 *
 * **Idempotency contract:** [Kixo.configure] is idempotent — passing
 * a different [KixoConfiguration] on a second call from the same
 * process is a WARN-logged no-op. So the values frozen here on the
 * FIRST call are the ones that govern the SDK lifetime.
 *
 * **Internal-only:** this class is **not** `@Serializable` — it
 * never crosses the wire. All wire-format DTOs live under
 * `io.kixo.sdk.internal.model` (Agent 2 owns).
 */
public class KixoConfiguration private constructor(
    /**
     * Project identifier (`kx_proj_…`). Issued in the dashboard
     * "SDK keys" panel. Required; the Builder rejects empty values.
     */
    public val projectId: String,

    /**
     * API key (`kx_key_…`). Public-by-design ingest credential —
     * paired to [projectId] on the backend.
     *
     * **Not secret.** The customer's mobile app ships this in their
     * compiled APK; anyone unzipping the APK can read it. The
     * backend's anomaly detection layer protects against abuse —
     * this is the same model as Segment's `writeKey` and Mixpanel's
     * project token. See briefing R10 — this is why we never rotate
     * "leaked" SDK keys.
     */
    public val apiKey: String,

    /**
     * Resolved environment string — `"development"` / `"production"`.
     * Drives `defaultApiHost` selection.
     * See [Builder.environment] for the explicit override and production default.
     */
    public val environment: String,

    /**
     * Resolved ingest host (e.g. `"https://sdk.dev.kixo.io"`). All
     * SDK endpoints are built as `"$apiHost/api/sdk/<path>"`.
     */
    public val apiHost: String,

    /**
     * If true, the SDK logs verbose diagnostic messages via
     * `android.util.Log` (`Log.d("Kixo", …)`). Auto-detected from
     * the host app's `applicationInfo.flags & FLAG_DEBUGGABLE` —
     * release builds default to `false`.
     */
    public val debug: Boolean,

    // ─── Auto-tracking flags ────────────────────────────────────

    /**
     * Auto-emit `screen_view` events on every Activity/Fragment
     * resume + Compose nav-graph destination change. Default `true`.
     */
    public val autoTrackScreens: Boolean,

    /**
     * Auto-classify [MotionEvent]s into the gesture taxonomy
     * (tap/long_press/swipe/multi_tap/pinch/scroll_end) per
     * briefing R7 and emit `tap` / `long_press` / etc events.
     * Default `true`.
     */
    public val autoTrackTaps: Boolean,

    /**
     * **Deprecated — no-op since alpha14.** Network auto-tracking via
     * an SDK-shipped `OkHttpInterceptor` is on the roadmap but not in
     * this release. Setting this flag has no effect; no `network`
     * events are emitted from Android. The flag stays on the public
     * API for source-compatibility with hosts that already wired it,
     * but will be removed in a future major version. For HTTP
     * observability today, instrument your own `Interceptor` and call
     * `Kixo.track("network", mapOf("url" to ..., "status" to ...))`.
     */
    @Deprecated(
        message = "Network auto-tracking is not implemented on Android. " +
            "Setting this flag has no effect. Will be removed in a future major release.",
        level = DeprecationLevel.WARNING,
    )
    public val autoTrackNetwork: Boolean,

    /** Install crash + ANR handlers and emit `crash` events. */
    public val autoTrackCrashes: Boolean,

    /**
     * Maintain a session boundary based on [sessionTimeoutMillis] of
     * background-time and emit `session_start` / `session_end` events.
     */
    public val autoTrackSessions: Boolean,

    /**
     * Wrap FCM `MessagingService` and `Activity.onCreate` notification
     * intent extraction; emit `push_received` / `push_open` /
     * `push_dismissed`. Safe no-op when the host app doesn't use
     * push at all. Default `true`.
     */
    public val autoTrackPush: Boolean,

    /**
     * Seconds (in ms) after a `push_open` during which subsequent
     * events inherit push attribution properties (`kixo_campaign_id`,
     * `kixo_delivery_id`). Default 30 minutes — matches iOS.
     */
    public val pushAttributionWindowMillis: Long,

    /**
     * Background-time threshold (ms) after which the next foreground
     * starts a new `session_id`. Default 30 seconds — matches iOS.
     */
    public val sessionTimeoutMillis: Long,

    // ─── Deep-linking / attribution (deterministic flagship) ────

    /**
     * Master switch for the Play Install Referrer read (the deterministic
     * deferred-attribution flagship — matches AppsFlyer/Branch per-device).
     * Read EXACTLY ONCE on first run, async, off the main thread; emitted as a
     * synthetic `install_referrer` event into `/api/sdk/batch` + resolved at
     * `/api/sdk/link/resolve`. Default `true` — the referrer is
     * analytics-policy-clean (no advertising ID, no fingerprint, no clipboard)
     * and is the headline acquisition signal.
     *
     * The referrer is immutable for 90 days; [Kixo.fetchInstallReferrer] can
     * explicitly retry a failed or deferred platform read.
     */
    public val installReferrerEnabled: Boolean,

    /**
     * Deterministic install-receipt validation (KIX-MMP-FRAUD-01). When `true`
     * (the default), the SDK acquires a Play Integrity token on first run and
     * POSTs it to `/api/sdk/install/validate` so the backend can prove the
     * install is a genuine Play download running on a recognized device
     * (anti-replay / anti-spoof). NON-BLOCKING — it never delays or blocks event
     * ingest, and gracefully no-ops when the Play Integrity API is unavailable
     * (e.g. the app didn't include the `com.google.android.play:integrity`
     * dependency). Set `false` to disable entirely.
     */
    public val installReceiptValidationEnabled: Boolean,

    /**
     * Auto-extract the COLD-START launch-intent deep link
     * (`Intent.ACTION_VIEW` + `intent.data`), emit a `deep_link` event, and
     * open the attribution window. Default `true`.
     *
     * **Warm `onNewIntent` is NOT auto-handled** — it is delivered to
     * `Activity.onNewIntent` only, which the SDK's lifecycle layer cannot
     * observe. The host MUST forward warm taps via [Kixo.handleDeepLink]
     * (App Links also require a host-app `autoVerify` manifest intent-filter
     * the SDK cannot inject).
     */
    public val autoHandleAppLinks: Boolean,

    /**
     * Optional allow-list of deep-link hosts (e.g. `my.kixo.cc`, `myapp.com`).
     * Empty (default) = accept any `http(s)` VIEW intent (only ones carrying a
     * `kixo_link_id` are actually attributed).
     */
    public val deepLinkHosts: Set<String>,

    /**
     * Android Privacy Sandbox **Attribution Reporting API (ARA)** registration
     * (KIX-MMP-ARA-01). When `true` (the default — "detect-and-on"), the SDK
     * registers an ARA SOURCE on a Kixo deep-link click and a TRIGGER on
     * install/first-open, running in PARALLEL to the deterministic Install
     * Referrer path (it's a privacy-preserving fallback for the cookieless
     * future, not a replacement).
     *
     * Gracefully NO-OPS when the AdServices runtime is absent (older devices /
     * no Privacy-Sandbox SDK extension) — it never crashes `configure()` on a
     * minSdk=24 device. Non-blocking and controlled by project collection policy.
     * Set `false` to disable.
     *
     * **Honesty ceiling:** real on-device ARA delivery additionally requires
     * Privacy-Sandbox ENROLLMENT (an operator step); until then registration is a
     * harmless no-op even where the runtime exists.
     */
    public val araEnabled: Boolean,

    // ─── Queue tunables ─────────────────────────────────────────

    /**
     * Periodic flush cadence (ms). The queue flushes whenever
     * [flushAt] events accumulate OR this many ms elapse, whichever
     * fires first. Default 30 seconds — matches iOS.
     */
    public val flushIntervalMillis: Long,

    /**
     * Event-count threshold that triggers an immediate flush (without
     * waiting for [flushIntervalMillis]). Default 20 — matches iOS.
     */
    public val flushAt: Int,

    /**
     * Maximum number of events the in-memory + SQLite queue will
     * hold before it starts dropping the OLDEST event (FIFO). Caps
     * memory growth during extended backend outages.
     *
     * 200 is a deliberate conservative default per iOS — typical
     * mobile users generate 10-50 events per session, so 200 covers
     * ~5-7 full sessions of buffered backlog. Hosts that need to
     * preserve more on long outages bump this; hosts paranoid
     * about memory pull it down.
     *
     * **Trade-off:** thundering-herd protection (when our servers
     * recover) does NOT come from this cap — it comes from the
     * jittered retry schedule in the queue. A larger cap doesn't
     * hurt the backend any more than a smaller one; it just buys
     * more loss tolerance per client.
     */
    public val maxBufferSize: Int,

    // ─── Replay ─────────────────────────────────────────────────

    /**
     * Compatibility-only snapshot, always `false`. Replay enablement is owned
     * by the project's dashboard policy (`dataCollection.replay.enabled`).
     */
    @Deprecated(
        message = "Configure replay in the Kixo dashboard; this local value is ignored.",
        level = DeprecationLevel.WARNING,
    )
    public val replayEnabled: Boolean,

    /** Compatibility-only snapshot, always `0.0`; dashboard policy wins. */
    @Deprecated(
        message = "Configure replay sampling in the Kixo dashboard; this local value is ignored.",
        level = DeprecationLevel.WARNING,
    )
    public val replaySampleRate: Double,

    /** Compatibility-only snapshot, always `false`; dashboard policy wins. */
    @Deprecated(
        message = "Configure cellular replay upload in the Kixo dashboard; this local value is ignored.",
        level = DeprecationLevel.WARNING,
    )
    public val replayCaptureOnCellular: Boolean,

    /** Compatibility-only snapshot, always false; text pipelines and their
     * soft-failing NER redaction are owned by project OCR/structural policy. */
    @Deprecated(
        message = "Replay text processing is configured in the Kixo dashboard; this value is ignored.",
        level = DeprecationLevel.WARNING,
    )
    public val piiNerEnabled: Boolean,
) {

    /**
     * Builder for [KixoConfiguration]. Required: [projectId] and
     * [apiKey] (passed to the Builder constructor — they have no
     * meaningful default). Everything else has a default.
     *
     * Kotlin idiom — `apply` block:
     * ```
     * val config = KixoConfiguration.Builder("kx_proj_…", "kx_key_…")
     *     .autoTrackScreens(true)
     *     .build()
     * ```
     *
     * Java idiom — fluent calls:
     * ```
     * KixoConfiguration config = new KixoConfiguration.Builder("kx_proj_…", "kx_key_…")
     *     .autoTrackScreens(true)
     *     .build();
     * ```
     */
    public class Builder(
        private val projectId: String,
        private val apiKey: String,
    ) {
        // ─── Defaults — match iOS ConfigurationOptions ──────────
        private var environment: String? = null
        private var apiHost: String? = null
        private var debug: Boolean? = null

        private var autoTrackScreens: Boolean = true
        private var autoTrackTaps: Boolean = true
        private var autoTrackNetwork: Boolean = true
        private var autoTrackCrashes: Boolean = true
        private var autoTrackSessions: Boolean = true
        private var autoTrackPush: Boolean = true
        private var pushAttributionWindowMillis: Long = 30L * 60 * 1000  // 30 min
        private var sessionTimeoutMillis: Long = 30L * 1000              // 30 s

        private var installReferrerEnabled: Boolean = true
        private var installReceiptValidationEnabled: Boolean = true
        private var autoHandleAppLinks: Boolean = true
        private var deepLinkHosts: Set<String> = emptySet()
        private var araEnabled: Boolean = true

        private var flushIntervalMillis: Long = 30L * 1000               // 30 s
        private var flushAt: Int = 20
        private var maxBufferSize: Int = 200

        /**
         * Override the environment. Supported values are
         * `"development"` / `"production"`. `"staging"` is rejected
         * because Kixo has no provisioned staging cluster. When not set,
         * [build] always uses production. Custom backends remain supported
         * through [apiHost] with either supported wire environment.
         */
        public fun environment(environment: String): Builder = apply {
            this.environment = environment
        }

        /**
         * Override the resolved ingest host. By default [build] picks
         * from environment:
         *   - `"development"` → `https://sdk.dev.kixo.io`
         *   - `"production"`  → `https://sdk.kixo.io`
         *
         * Hosts that need a custom backend (self-hosted Kixo, on-prem)
         * pass an explicit URL here. Trailing `/` is stripped to keep
         * URL concatenation `"$apiHost/api/sdk/init"` clean.
         */
        public fun apiHost(apiHost: String): Builder = apply {
            this.apiHost = apiHost.trimEnd('/')
        }

        /**
         * Override the auto-detected debug flag. By default [build]
         * derives from `Context.applicationInfo.flags & FLAG_DEBUGGABLE` —
         * release builds (Play Store / App Bundles) get `false`,
         * debuggable builds get `true`.
         *
         * Setting this to `true` in a release build floods Logcat with
         * SDK diagnostic output — useful only when reproducing customer
         * issues with their permission.
         */
        public fun debug(debug: Boolean): Builder = apply { this.debug = debug }

        public fun autoTrackScreens(enabled: Boolean): Builder = apply {
            this.autoTrackScreens = enabled
        }

        public fun autoTrackTaps(enabled: Boolean): Builder = apply {
            this.autoTrackTaps = enabled
        }

        /**
         * **Deprecated — no-op since alpha14.** See
         * [KixoConfiguration.autoTrackNetwork]. Kept on the Builder
         * for source-compatibility; will be removed in a future
         * major release.
         */
        @Deprecated(
            message = "Network auto-tracking is not implemented on Android. " +
                "This setter has no effect. Will be removed in a future major release.",
            level = DeprecationLevel.WARNING,
        )
        public fun autoTrackNetwork(enabled: Boolean): Builder = apply {
            this.autoTrackNetwork = enabled
        }

        public fun autoTrackCrashes(enabled: Boolean): Builder = apply {
            this.autoTrackCrashes = enabled
        }

        public fun autoTrackSessions(enabled: Boolean): Builder = apply {
            this.autoTrackSessions = enabled
        }

        public fun autoTrackPush(enabled: Boolean): Builder = apply {
            this.autoTrackPush = enabled
        }

        /** @param millis Push attribution window length, in ms. */
        public fun pushAttributionWindowMillis(millis: Long): Builder = apply {
            require(millis >= 0) { "pushAttributionWindowMillis must be >= 0" }
            this.pushAttributionWindowMillis = millis
        }

        /** @param millis Background-time before a new session starts. */
        public fun sessionTimeoutMillis(millis: Long): Builder = apply {
            require(millis >= 0) { "sessionTimeoutMillis must be >= 0" }
            this.sessionTimeoutMillis = millis
        }

        /** Enable/disable the Play Install Referrer read. See
         *  [KixoConfiguration.installReferrerEnabled]. */
        public fun installReferrerEnabled(enabled: Boolean): Builder = apply {
            this.installReferrerEnabled = enabled
        }

        /** Enable/disable deterministic install-receipt validation (Play
         *  Integrity). See [KixoConfiguration.installReceiptValidationEnabled]. */
        public fun installReceiptValidationEnabled(enabled: Boolean): Builder = apply {
            this.installReceiptValidationEnabled = enabled
        }

        /** Enable/disable cold-start App-Link auto-handling. See
         *  [KixoConfiguration.autoHandleAppLinks]. */
        public fun autoHandleAppLinks(enabled: Boolean): Builder = apply {
            this.autoHandleAppLinks = enabled
        }

        /** Restrict auto-handled deep links to these hosts. Empty = any. See
         *  [KixoConfiguration.deepLinkHosts]. */
        public fun deepLinkHosts(hosts: Set<String>): Builder = apply {
            this.deepLinkHosts = hosts.toSet()
        }

        /** Toggle Android Privacy Sandbox ARA registration (KIX-MMP-ARA-01). See
         *  [KixoConfiguration.araEnabled]. Default `true` (detect-and-on). */
        public fun araEnabled(enabled: Boolean): Builder = apply {
            this.araEnabled = enabled
        }

        /** @param millis Periodic flush cadence (ms). */
        public fun flushIntervalMillis(millis: Long): Builder = apply {
            require(millis > 0) { "flushIntervalMillis must be > 0" }
            this.flushIntervalMillis = millis
        }

        /** @param count Event-count threshold to flush immediately. */
        public fun flushAt(count: Int): Builder = apply {
            require(count > 0) { "flushAt must be > 0" }
            this.flushAt = count
        }

        /**
         * @param size Max queue size before FIFO drops kick in. We
         * honour the host's value as-is; we considered clamping
         * upward to [flushAt] (so a batch could always assemble
         * before drops kick in) but that hid surprises — a host
         * setting `maxBufferSize: 10` deserves to see those drops
         * immediately rather than the SDK silently overriding.
         * Same rationale as iOS.
         */
        public fun maxBufferSize(size: Int): Builder = apply {
            require(size > 0) { "maxBufferSize must be > 0" }
            this.maxBufferSize = size
        }

        @Deprecated(
            message = "Configure replay in the Kixo dashboard; this setter is ignored at runtime.",
            level = DeprecationLevel.WARNING,
        )
        public fun replayEnabled(@Suppress("UNUSED_PARAMETER") enabled: Boolean): Builder = this

        /** Compatibility-only no-op. Replay sampling comes from the project. */
        @Deprecated(
            message = "Configure replay sampling in the Kixo dashboard; this setter is ignored at runtime.",
            level = DeprecationLevel.WARNING,
        )
        public fun replaySampleRate(@Suppress("UNUSED_PARAMETER") rate: Double): Builder = this

        @Deprecated(
            message = "Configure cellular replay upload in the Kixo dashboard; this setter is ignored at runtime.",
            level = DeprecationLevel.WARNING,
        )
        public fun replayCaptureOnCellular(
            @Suppress("UNUSED_PARAMETER") allowed: Boolean,
        ): Builder = this

        @Deprecated(
            message = "Replay text processing is configured in the Kixo dashboard; this setter is ignored.",
            level = DeprecationLevel.WARNING,
        )
        public fun piiNerEnabled(@Suppress("UNUSED_PARAMETER") enabled: Boolean): Builder = this

        /**
         * Materialise the [KixoConfiguration]. Auto-detection runs
         * here so a Builder constructed before `Application.onCreate`
         * still picks up the right environment when [Kixo.configure]
         * lands.
         *
         * @param context Application context — used solely for debug
         *   auto-detection. Environment defaults to production. NOT held by the
         *   resulting [KixoConfiguration]. Pass `applicationContext`
         *   to avoid Activity leaks.
         */
        public fun build(context: Context): KixoConfiguration {
            require(projectId.isNotBlank()) { "projectId must not be blank" }
            require(apiKey.isNotBlank()) { "apiKey must not be blank" }

            val internalDevForced =
                // SDK self-test routing flag, internal use only.
                System.getProperty("kixo.internal.dev") == "1" ||
                    System.getenv("KIXO_INTERNAL_DEV") == "1"
            val requestedEnvironment = environment?.trim()?.lowercase()
            if (!internalDevForced) {
                require(
                    requestedEnvironment == null ||
                        requestedEnvironment == "production" ||
                        requestedEnvironment == "development",
                ) {
                    "Unsupported Kixo environment '$environment'. Use 'production' or " +
                        "'development', and Builder.apiHost(...) for a custom endpoint."
                }
            }

            var resolvedEnvironment = if (internalDevForced) {
                "development"
            } else {
                requestedEnvironment ?: detectEnvironment(context)
            }
            var resolvedApiHost = apiHost ?: defaultApiHost(resolvedEnvironment)
            val resolvedDebug = debug ?: detectDebug(context)

            // SDK self-test routing flag, internal use only.
            if (internalDevForced) {
                resolvedApiHost = io.kixo.sdk.internal.KixoEndpoints.forEnvironment("development")
                resolvedEnvironment = "development"
            }

            return KixoConfiguration(
                projectId = projectId,
                apiKey = apiKey,
                environment = resolvedEnvironment,
                apiHost = resolvedApiHost,
                debug = resolvedDebug,
                autoTrackScreens = autoTrackScreens,
                autoTrackTaps = autoTrackTaps,
                autoTrackNetwork = autoTrackNetwork,
                autoTrackCrashes = autoTrackCrashes,
                autoTrackSessions = autoTrackSessions,
                autoTrackPush = autoTrackPush,
                pushAttributionWindowMillis = pushAttributionWindowMillis,
                sessionTimeoutMillis = sessionTimeoutMillis,
                installReferrerEnabled = installReferrerEnabled,
                installReceiptValidationEnabled = installReceiptValidationEnabled,
                autoHandleAppLinks = autoHandleAppLinks,
                deepLinkHosts = deepLinkHosts,
                araEnabled = araEnabled,
                flushIntervalMillis = flushIntervalMillis,
                flushAt = flushAt,
                maxBufferSize = maxBufferSize,
                // Deprecated source-compatibility snapshots. Runtime replay
                // authority comes only from the project control plane.
                replayEnabled = false,
                replaySampleRate = 0.0,
                replayCaptureOnCellular = false,
                piiNerEnabled = false,
            )
        }
    }

    public companion object {
        /**
         * Default ingest host per environment. Hosts wanting a
         * custom backend pass `apiHost` explicitly via [Builder.apiHost].
         * Unsupported environments fail explicitly.
         */
        @JvmStatic
        public fun defaultApiHost(environment: String): String =
            io.kixo.sdk.internal.KixoEndpoints.forEnvironment(environment)

        /**
         * Returns the default environment string.
         *
         * **v0.1.2: always `"production"`.** Previously this auto-promoted
         * debuggable builds to `"development"` via `FLAG_DEBUGGABLE`,
         * which leaked any customer's debug-build events to Kixo's
         * internal dev backend instead of their own Kixo project on
         * prod. The fix is intentionally global — debug AND release
         * builds default to prod. Internal-team SDK development
         * routes to dev only via an explicit
         * `KixoConfiguration.Builder(...).environment("development")`.
         *
         * The `context` parameter is unused since v0.1.2 but retained
         * on the signature for binary compatibility with hosts that
         * already wired it.
         */
        @JvmStatic
        @Suppress("UNUSED_PARAMETER")
        public fun detectEnvironment(context: Context): String = "production"

        /**
         * Default `debug` value. Unlike environment selection, debug logging
         * still follows the host build type: debuggable builds get verbose logging, release builds stay
         * quiet so an end-user's Logcat isn't flooded.
         */
        @JvmStatic
        public fun detectDebug(context: Context): Boolean = isDebuggable(context)

        private fun isDebuggable(context: Context): Boolean {
            return try {
                (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            } catch (t: Throwable) {
                // Defensive — never crash the host on a malformed
                // applicationInfo. Treat unknown as production
                // (safer default — release behaviour).
                false
            }
        }
    }
}
