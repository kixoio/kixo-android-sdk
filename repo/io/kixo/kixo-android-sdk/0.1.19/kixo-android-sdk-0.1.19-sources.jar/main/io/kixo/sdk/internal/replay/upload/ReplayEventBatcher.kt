package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.util.Log
import androidx.work.WorkManager
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.Call
import okhttp3.OkHttpClient
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Disk-first replay metadata queue.
 *
 * Admission is durable before this method returns: one atomic sidecar owns a
 * `(session_id, seq)` slot and carries its immutable `event_id` + payload
 * across process death, offline periods, and ambiguous HTTP responses. Both
 * the foreground periodic loop and WorkManager drain those same sidecars, so
 * every retry serializes the exact original record.
 */
internal class ReplayEventBatcher(
    private val context: Context,
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val sessionId: String,
    private val installationId: String,
    private val runtimePolicy: ReplayRuntimePolicy,
    /** Immutable generation captured at session open. */
    private val policyToken: String,
    /** Test seam; production mints one queue-owned UUID per first admission. */
    private val eventIdFactory: () -> String = { UUID.randomUUID().toString() },
    private val flushIntervalMs: Long = 5_000L,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
    private val store: ReplayPendingEventStore = ReplayPendingEventStore(context),
    private val workScheduler: ReplayEventWorkScheduler = WorkManagerReplayEventWorkScheduler,
    private val networkState: () -> Pair<Boolean, Boolean> = {
        ReplayPendingEventDrain.currentNetwork(context)
    },
    private val onRemotePaused: (String?) -> Unit = {},
) {
    private val lifecycleMutex = Mutex()
    private var periodicJob: Job? = null
    private val discarded = AtomicBoolean(false)
    private val activeCalls = ConcurrentHashMap.newKeySet<Call>()

    /**
     * Persist one per-tap payload. The first valid writer for a sequence wins;
     * duplicate callbacks cannot replace its UUID or JSON while it is pending
     * or in flight.
     */
    suspend fun enqueue(seq: Long, payload: Map<String, Any?>) {
        if (discarded.get()) return
        val payloadJson = runCatching { toJsonElement(payload) as JsonObject }
            .getOrNull() ?: return
        val candidate = ReplayPendingEventStore.Record(
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            sessionId = sessionId,
            installationId = installationId,
            policyToken = policyToken,
            eventId = eventIdFactory().lowercase(),
            seq = seq,
            payload = payloadJson,
        )

        val shouldFlushNow = lifecycleMutex.withLock {
            if (discarded.get()) return
            val admitted = store.firstWrite(candidate) ?: return
            // Keep scheduling inside the same lock as durable admission. A
            // concurrent discard therefore either cancels this WorkSpec, or
            // wins first and prevents both the file and WorkSpec.
            workScheduler.enqueue(context, admitted)
            store.count(baseUrl, projectId, apiKey, sessionId, installationId) >=
                MAX_BATCH_SIZE
        }

        if (shouldFlushNow) {
            scope.launch { flush() }
        }
    }

    /** Start the foreground low-latency drain. WorkManager remains the durable backup. */
    fun start() {
        if (discarded.get() || periodicJob != null) return
        periodicJob = scope.launch {
            // Recover rows left by a killed process without waiting five seconds.
            flush()
            while (isActive) {
                delay(flushIntervalMs)
                try {
                    flush()
                } catch (t: Throwable) {
                    Log.w(TAG, "Periodic durable replay-event drain threw", t)
                }
            }
        }
    }

    /**
     * Stop new periodic work and drain every durable row. `false` means the
     * caller must leave session/end to WorkManager so metadata is delivered
     * before the session is sealed.
     */
    suspend fun stop(): Boolean {
        periodicJob?.cancel()
        periodicJob = null
        return flush()
    }

    /**
     * Identity/policy teardown. No final network flush is attempted. Active
     * calls are cancelled, sidecars are synchronously deleted, and the
     * session-tagged WorkSpecs are cancelled before this returns.
     */
    suspend fun discard() {
        discarded.set(true)
        periodicJob?.cancel()
        periodicJob = null
        activeCalls.toList().forEach { runCatching { it.cancel() } }
        lifecycleMutex.withLock {
            ReplayPendingEventDrain.discardSession(
                store = store,
                baseUrl = baseUrl,
                projectId = projectId,
                sessionId = sessionId,
                installationId = installationId,
            )
        }
        runCatching {
            WorkManager.getInstance(context)
                .cancelAllWorkByTag("kixo-replay-session-$sessionId")
        }
    }

    /** Drain all records currently on disk. */
    suspend fun flush(): Boolean {
        if (discarded.get()) return true
        val outcome = ReplayPendingEventDrain.drainSession(
            context = context,
            httpClient = httpClient,
            store = store,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            sessionId = sessionId,
            installationId = installationId,
            networkState = networkState,
            onCallStarted = { activeCalls += it },
            onCallFinished = { activeCalls -= it },
            onRemotePaused = onRemotePaused,
        )
        return outcome == ReplayPendingEventDrain.Outcome.DRAINED
    }

    private fun toJsonElement(value: Any?): JsonElement = when (value) {
        null -> JsonNull
        is JsonElement -> value
        is Boolean -> JsonPrimitive(value)
        is Number -> JsonPrimitive(value)
        is String -> JsonPrimitive(value)
        is Map<*, *> -> JsonObject(value.entries.associate { (key, child) ->
            key.toString() to toJsonElement(child)
        })
        is Iterable<*> -> JsonArray(value.map(::toJsonElement))
        else -> JsonPrimitive(value.toString())
    }

    companion object {
        /** Kept as a public-internal compatibility name for existing tests. */
        const val MAX_QUEUE: Int = ReplayPendingEventStore.MAX_EVENTS_PER_SESSION
        private const val MAX_BATCH_SIZE = 100
        private const val TAG = "Kixo.ReplayEventBatcher"
    }
}
