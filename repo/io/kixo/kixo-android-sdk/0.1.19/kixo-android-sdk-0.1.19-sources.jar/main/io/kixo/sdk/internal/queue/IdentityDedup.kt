package io.kixo.sdk.internal.queue

import io.kixo.sdk.PushProvider
import java.security.MessageDigest
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Suppress duplicate identify / user_property / push_token events.
 *
 * Mirrors the iOS dedup pass in `kixo-ios-sdk/Sources/Kixo/Kixo.swift`
 * (`lastIdentifyHash`, `lastUserPropertyHash`, `lastPushTokenHash`).
 * From the iOS comment: "Observed on LikePost: 41 `identify`, 37
 * `user_property`, 10 `push_token` per device in a 2h window — because
 * the host app calls these on every app_foreground / screen change
 * even when nothing has changed."
 *
 * **Why hash, not deep-equals:** an SDK that holds the user's full
 * trait map in memory keys a multi-MB property bag in long-lived
 * state. SHA-256 of the canonical-JSON form is 32 bytes. We don't
 * need cryptographic strength — collision-resistance to silently-
 * drop a real change is the only safety property required, and a 256-
 * bit hash gives us that with absurd headroom (2^-128 false-negative
 * rate). MD5 / FNV would suffice; SHA-256 is the platform default and
 * needs no third-party dep.
 *
 * **Threading:** all mutations + reads are guarded by `synchronized`
 * blocks against `this`. The dedup is called from the public
 * `Kixo.identify(...)` / `setUserProperty(...)` / `setPushToken(...)`
 * surface, which fans in from arbitrary host threads. A coroutine
 * mutex would be tidier but requires the call site to be `suspend`,
 * and we don't want to force the public API surface to be suspend.
 *
 * **Reserve / commit protocol:** a caller that must persist the event
 * before it may treat the declaration as delivered — `EventQueue.enqueue`
 * — takes a [Reservation] instead of using the `shouldEmit*` shorthand.
 * The cache is only ever written by [Reservation.commit]; taking a
 * reservation publishes nothing. What that commit implies depends on the
 * caller: `EventQueue.enqueue` commits after a durable append, so the value
 * reached the store, while the `shouldEmit*` shorthand has no persistence
 * step and commits inline, so its values were never persisted.
 * Consequences:
 *   - A rolled-back attempt leaves the cache exactly as it found it;
 *     there is no displaced value to replay in the wrong order.
 *   - Two attempts racing on one key cannot see each other's pending
 *     hash, so a failing attempt can never suppress a concurrent one.
 *     The cost is that two simultaneous *identical* declarations can
 *     both be emitted; that is deliberate. A duplicate identify is a
 *     backend upsert on the same identity row (documented below),
 *     whereas suppressing a declaration that never landed loses it
 *     until the value changes to something else.
 *   - Commits can still arrive out of order, and that skew is not
 *     harmless in both directions. `EventQueue.enqueue` appends under
 *     its persistence mutex but calls [Reservation.commit] after
 *     releasing it, so two threads writing different values for one key
 *     can append in one order and commit in the reverse order: A appends
 *     `plan=pro` and is descheduled before its commit, B appends
 *     `plan=pro-annual` and commits, then A commits. The cache now holds
 *     `pro` while the store's latest is `pro-annual`, so a later genuine
 *     `plan=pro` declaration is suppressed as a duplicate — a dropped
 *     change, not a redundant emit. The window is only the gap between
 *     releasing the persistence mutex and committing, and it needs two
 *     threads racing on the same key with different values; the previous
 *     publish-at-reserve-time design had the same skew class over a
 *     wider window, so this is a narrowed residual rather than a
 *     regression. Closing it entirely would mean committing inside the
 *     persistence mutex.
 *
 * **What goes through dedup vs not:**
 *   - `identify`        → dedupes on `(userId, traits)` tuple hash
 *   - `user_property`   → dedupes per-key on `(value)` hash. Multi-
 *     property calls go through one key at a time.
 *   - `push_token`      → dedupes on `(token, provider)` hash. Token
 *     rotation produces a new hash; reporting the same token twice
 *     in a session is the primary noise we suppress.
 *
 * **What doesn't dedupe (and why):**
 *   - `track`, `screen`, `markGoal`, push lifecycle events — these
 *     are observations of what the user DID, not declarations of
 *     who they are. Dropping a duplicate `track("button_clicked")`
 *     would lose real signal. Dropping a duplicate `identify` with
 *     the same traits costs nothing because the backend's identity
 *     row is upsert-keyed on user_id.
 *
 * **Reset semantics:** [reset] clears all three caches and retires
 * every outstanding reservation. Called from `Kixo.reset()` after a
 * logout so that a re-identify with the same (user_id, traits) tuple
 * after a logout fires once — otherwise the post-logout user's first
 * identify would be silently dropped.
 */
internal class IdentityDedup {

    /**
     * One queue append attempt's claim on a dedup slot.
     *
     * A reservation publishes NOTHING when it is taken — the cache keeps
     * whatever the last commit left there. [commit] publishes the reserved
     * hash: after a durable append when the caller is `EventQueue.enqueue`,
     * immediately for the `shouldEmit*` shorthand, and under the
     * commit-order skew described on the class the published value need
     * not stay the newest one. [rollback] abandons the claim, and since
     * this attempt never overwrote anything it has nothing to restore.
     *
     * That asymmetry is the point. The previous design published the
     * hash at reserve time and made rollback *replay* the value it had
     * displaced. With two concurrent attempts on one key that replay ran
     * in forward order, so the loser's rollback re-published a value
     * whose event had never been persisted, and every later declaration
     * of that value was then suppressed as a duplicate. Nothing to
     * replay means nothing to replay wrongly.
     */
    internal class Reservation(
        private val commitAction: () -> Unit,
    ) {
        private val active = AtomicBoolean(true)

        /** Publish the reserved hash. Idempotent; a no-op after [rollback]. */
        fun commit() {
            if (active.compareAndSet(true, false)) commitAction()
        }

        /**
         * Abandon the attempt. Only bars a later [commit] — this attempt
         * never wrote to the cache, so it has nothing to restore.
         */
        fun rollback() {
            active.set(false)
        }
    }

    /**
     * Last COMMITTED hash of the (`user_id`, `traits`) pair from
     * [shouldEmitIdentify]. `null` until the first identify call commits —
     * after a durable append via `EventQueue.enqueue`, or immediately when
     * it came through the [shouldEmitIdentify] shorthand.
     */
    private var lastIdentifyHash: ByteArray? = null

    /**
     * Per-key hash map for [shouldEmitUserProperty]. Each property
     * dedupes independently — `setUserProperty("plan", "pro")` and
     * `setUserProperty("country", "US")` keep separate slots.
     *
     * `LinkedHashMap` keeps insertion order so debug logs / future
     * dump-state diagnostics are reproducible.
     */
    private val lastUserPropertyHash: LinkedHashMap<String, ByteArray> = LinkedHashMap()

    /**
     * Last committed hash of the (`token`, `provider`) pair from
     * [shouldEmitPushToken]. `null` until the first push-token call
     * commits — after a durable append via `EventQueue.enqueue`, or
     * immediately when it came through the [shouldEmitPushToken] shorthand.
     */
    private var lastPushTokenHash: ByteArray? = null

    /**
     * Bumped by [reset]. A reservation taken before a reset carries the
     * old epoch and its [Reservation.commit] is dropped, so a logout can
     * never be re-poisoned by an append that was already in flight when
     * the caches were wiped.
     */
    private var resetEpoch: Long = 0L

    /**
     * Decide whether an `identify` event should be emitted to the
     * queue. Returns `true` if (userId, traits) has changed since the
     * last call (or this is the first call), `false` if it's a no-op.
     *
     * Updates the cached hash on `true` so the NEXT call with the
     * same payload is suppressed.
     *
     * **Note on null userId:** the iOS code merges `["user_id":
     * userId]` into the traits before hashing. We do the same so that
     * `identify(userId="alice", traits=...)` and a separate later
     * `identify(userId="bob", traits=...)` with identical traits both
     * fire — they describe different users.
     */
    fun shouldEmitIdentify(userId: String?, traits: Map<String, Any?>): Boolean =
        // Reserve and commit under one monitor acquisition (Java monitors
        // are reentrant) so callers with no persistence step keep the
        // original single-shot semantics.
        synchronized(this) {
            val reservation = reserveIdentify(userId, traits) ?: return@synchronized false
            reservation.commit()
            true
        }

    fun reserveIdentify(userId: String?, traits: Map<String, Any?>): Reservation? {
        // Build a canonical map: traits + user_id under a reserved key.
        // The reserved key uses a colon so it can't collide with a
        // legitimate trait name (trait keys are validated to alpha-
        // numeric + underscore upstream).
        val payload: MutableMap<String, Any?> = LinkedHashMap(traits.size + 1)
        payload.putAll(traits)
        payload["__user_id__"] = userId
        val hash = sha256OfMap(payload)
        return synchronized(this) {
            if (lastIdentifyHash != null && lastIdentifyHash!!.contentEquals(hash)) {
                null
            } else {
                val epoch = resetEpoch
                Reservation {
                    synchronized(this) {
                        if (resetEpoch == epoch) lastIdentifyHash = hash
                    }
                }
            }
        }
    }

    /**
     * Decide whether a single `user_property` change should be
     * emitted. Each (key, value) is tracked independently — a
     * `setUserProperties({a:1, b:2})` call invokes this twice and may
     * suppress one but not the other.
     *
     * Returns `true` if the value differs from the last cached value
     * for this key (or it's a new key), `false` if it's the same.
     */
    fun shouldEmitUserProperty(key: String, value: Any?): Boolean =
        synchronized(this) {
            val reservation = reserveUserProperty(key, value) ?: return@synchronized false
            reservation.commit()
            true
        }

    fun reserveUserProperty(key: String, value: Any?): Reservation? {
        val hash = sha256OfValue(value)
        return synchronized(this) {
            val existing = lastUserPropertyHash[key]
            if (existing != null && existing.contentEquals(hash)) {
                null
            } else {
                val epoch = resetEpoch
                Reservation {
                    synchronized(this) {
                        if (resetEpoch == epoch) lastUserPropertyHash[key] = hash
                    }
                }
            }
        }
    }

    /**
     * Decide whether a `push_token` event should be emitted. Token
     * rotation (provider issues a new value) produces a new hash;
     * reporting the same token twice is the primary noise.
     *
     * The (token, provider) tuple is hashed because the same token
     * string under a different provider would mean a different
     * registration to the backend (theoretically — in practice
     * provider strings rarely change for a given install).
     */
    fun shouldEmitPushToken(token: String, provider: PushProvider): Boolean =
        synchronized(this) {
            val reservation = reservePushToken(token, provider) ?: return@synchronized false
            reservation.commit()
            true
        }

    fun reservePushToken(token: String, provider: PushProvider): Reservation? {
        // Compose `provider:token` so a token-prefix collision across
        // providers is impossible. Provider's wireValue is a stable
        // ASCII string ("fcm" / "hms" / "apns").
        val composed = "${provider.wireValue}:$token"
        val hash = sha256OfBytes(composed.encodeToByteArray())
        return synchronized(this) {
            if (lastPushTokenHash != null && lastPushTokenHash!!.contentEquals(hash)) {
                null
            } else {
                val epoch = resetEpoch
                Reservation {
                    synchronized(this) {
                        if (resetEpoch == epoch) lastPushTokenHash = hash
                    }
                }
            }
        }
    }

    /**
     * Wipe all three caches. Called from `Kixo.reset()` after a
     * logout so a re-identify with the prior user's traits still
     * emits once. Cheap (three pointer assignments).
     */
    fun reset() {
        synchronized(this) {
            lastIdentifyHash = null
            lastUserPropertyHash.clear()
            lastPushTokenHash = null
            // Retire every reservation taken before this wipe: a commit
            // that lands after a logout must not restore the prior
            // identity's hash into the fresh caches.
            resetEpoch++
        }
    }

    // ─── Hash helpers ────────────────────────────────────────────────

    /**
     * Stable SHA-256 of a `Map<String, Any?>`. Keys are sorted
     * lexicographically so reorderings between calls hash the same
     * (the iOS counterpart uses `JSONSerialization` with
     * `.sortedKeys`; we mirror that).
     *
     * Values are coerced via `toString()` — collision-resistance to
     * silently-drop a real change is what matters; absolute key-
     * universe coverage is not. The fallback in iOS is identical
     * (`String(describing:)`).
     */
    private fun sha256OfMap(map: Map<String, Any?>): ByteArray {
        val sb = StringBuilder(64)
        val sortedKeys = map.keys.sorted()
        for (key in sortedKeys) {
            sb.append(key)
            sb.append('=')
            sb.append(serializeValue(map[key]))
            sb.append('\u001E') // record separator — unprintable, can't
            // collide with a real character in a trait key/value
        }
        return sha256OfBytes(sb.toString().encodeToByteArray())
    }

    /** Stable SHA-256 of an arbitrary value. Mirrors `sha256OfMap` for scalars. */
    private fun sha256OfValue(value: Any?): ByteArray {
        return sha256OfBytes(serializeValue(value).encodeToByteArray())
    }

    /**
     * Coerce an arbitrary value to its dedup-stable string form.
     * Recurses into lists/maps so nested traits hash deterministically.
     *
     * - `null`        → `"null"` (a literal token, distinguishable
     *                    from the string `"null"` because the latter
     *                    would be wrapped in quotes by the caller)
     * - `Boolean`     → `"true"` / `"false"`
     * - `Number`      → bare digits via `toString`
     * - `String`      → wrapped in single quotes so `"true"` !=
     *                    `true` !=  the string `"true"`
     * - `Map<*, *>`   → recursive, sorted by key
     * - `Iterable<*>` → recursive, order preserved (lists are ordered
     *                    semantically; reordering a tag list IS a
     *                    real change)
     * - other         → `toString` (best-effort; same as iOS fallback)
     */
    private fun serializeValue(value: Any?): String {
        if (value == null) return "null"
        return when (value) {
            is Boolean -> value.toString()
            is Number -> value.toString()
            is String -> "'$value'"
            is Map<*, *> -> {
                val sb = StringBuilder(32)
                sb.append('{')
                val keys = value.keys.mapNotNull { it?.toString() }.sorted()
                for ((idx, k) in keys.withIndex()) {
                    if (idx > 0) sb.append(',')
                    sb.append(k).append(':').append(serializeValue(value[k]))
                }
                sb.append('}')
                sb.toString()
            }
            is Iterable<*> -> {
                val sb = StringBuilder(32)
                sb.append('[')
                var first = true
                for (e in value) {
                    if (!first) sb.append(',')
                    first = false
                    sb.append(serializeValue(e))
                }
                sb.append(']')
                sb.toString()
            }
            else -> value.toString()
        }
    }

    /** Single SHA-256 evaluation. Cached MessageDigest is not safe for
     *  concurrent use, so a fresh instance per call is the simplest correct
     *  thing — the cost of `MessageDigest.getInstance("SHA-256")` is dominated
     *  by the hash computation itself, this is not a hot path. */
    private fun sha256OfBytes(bytes: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(bytes)
    }
}
