package io.kixo.sdk.internal.lifecycle

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.IOException
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

/**
 * Prevents work admitted under a retired identity or server policy from
 * crossing that collection boundary. This is lifecycle coordination only: it
 * does not store or infer collection eligibility and never decides what the
 * host may collect.
 */
internal class CollectionBoundaryGate {
    private val lock = Any()
    private var epoch: Long = 0L
    private val jobs = LinkedHashSet<Job>()
    private val calls = LinkedHashSet<Call>()

    internal class Lease internal constructor(
        val epoch: Long,
        private val releaseOnce: () -> Unit,
    ) {
        private val closed = AtomicBoolean(false)

        fun close() {
            if (closed.compareAndSet(false, true)) releaseOnce()
        }
    }

    internal class StaleBoundaryException : IOException(
        "retired collection boundary rejected network call",
    )

    fun launchTask(
        scope: CoroutineScope,
        block: suspend (Long) -> Unit,
    ): Job = synchronized(lock) {
        val admittedEpoch = epoch
        lateinit var job: Job
        job = scope.launch(start = CoroutineStart.LAZY) {
            if (synchronized(lock) { admittedEpoch != epoch }) return@launch
            block(admittedEpoch)
        }
        jobs += job
        job.invokeOnCompletion {
            synchronized(lock) { jobs.remove(job) }
        }
        job.start()
        job
    }

    fun registerTask(job: Job): Lease = synchronized(lock) {
        val admittedEpoch = epoch
        jobs += job
        val lease = Lease(admittedEpoch) {
            synchronized(lock) { jobs.remove(job) }
        }
        job.invokeOnCompletion { lease.close() }
        lease
    }

    fun <T> commit(block: () -> T): T = synchronized(lock) { block() }

    suspend fun executeCall(
        admittedEpoch: Long,
        call: Call,
    ): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { runCatching { call.cancel() } }
        val admitted = try {
            synchronized(lock) {
                if (admittedEpoch != epoch) return@synchronized false
                calls += call
                try {
                    call.enqueue(object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                            unregister(call)
                            if (continuation.isActive) {
                                continuation.resumeWith(Result.failure(e))
                            }
                        }

                        override fun onResponse(call: Call, response: Response) {
                            unregister(call)
                            if (continuation.isActive) {
                                continuation.resume(response)
                            } else {
                                response.close()
                            }
                        }
                    })
                } catch (t: Throwable) {
                    calls.remove(call)
                    throw t
                }
                true
            }
        } catch (t: Throwable) {
            if (continuation.isActive) continuation.resumeWith(Result.failure(t))
            true
        }
        if (!admitted && continuation.isActive) {
            runCatching { call.cancel() }
            continuation.resumeWith(Result.failure(StaleBoundaryException()))
        }
    }

    fun rotate() {
        synchronized(lock) {
            epoch += 1L
            val activeJobs = jobs.toList()
            jobs.clear()
            activeJobs.forEach { it.cancel() }
            val activeCalls = calls.toList()
            calls.clear()
            activeCalls.forEach { runCatching { it.cancel() } }
        }
    }

    private fun unregister(call: Call) {
        synchronized(lock) { calls.remove(call) }
    }
}
