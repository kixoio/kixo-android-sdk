package io.kixo.sdk.internal.crash

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.util.Log

/**
 * Post-mortem drain of native (C/C++) crash exits from prior
 * processes. Mirrors [AnrWatchdog.drainHistoricalAnrs] but targets
 * [ApplicationExitInfo.REASON_CRASH_NATIVE] (signal-driven kills:
 * SIGSEGV / SIGABRT / SIGBUS / SIGFPE / SIGILL / SIGTRAP).
 *
 * # Why a separate drain (not part of [CrashTracker])
 *
 * [CrashTracker] installs a [Thread.UncaughtExceptionHandler], which
 * fires on JVM throwables but NEVER on native signals. When a C/C++
 * library — Google Maps, libwebp, video codecs, JNI bindings —
 * dereferences a bad pointer, the kernel raises SIGSEGV directly
 * against the process; the OS kills the process before any JVM frame
 * gets a chance to run. To catch those LIVE we would need a JNI
 * signal handler (sigaction(2)) installed from C, which is a separate
 * NDK workstream we're not doing yet.
 *
 * On API 30+ Android, the platform records every recent termination
 * (including native crashes) in [ApplicationExitInfo] and exposes them
 * via [ActivityManager.getHistoricalProcessExitReasons]. We can't
 * recover the crashing stack from C-land, but we DO get:
 *
 *  - the signal description (e.g. `"SIGSEGV (Segmentation fault)"`)
 *  - the pid + timestamp of the killed process
 *  - rough memory state at death (pss / rss)
 *  - the foreground / background importance bucket
 *
 * That's ~85% of the customer-value payload from a live handler with
 * none of the NDK complexity. On the NEXT cold launch this drain
 * reads the list, filters to native-crash entries we haven't seen
 * before, and enqueues each as a `crash` event with `native=true` and
 * `historical=true` tags.
 *
 * # Why a separate SharedPreferences key from ANR
 *
 * The drains use the same pid-based dedup pattern but MUST keep their
 * high-water marks separate. A process termination has exactly one
 * `reason` code — a single pid is either an ANR exit or a native
 * crash, never both — so the two pid counters track independent
 * subsequences of the exit log. Sharing the key would conflate them
 * and corrupt the dedup (the ANR drain bumps the mark past a native
 * crash pid → the native drain then skips that pid permanently, or
 * vice versa).
 *
 * # Why a separate object (not a method on [AnrWatchdog])
 *
 * ANR detection has two halves — a LIVE main-thread heartbeat and a
 * historical drain. Native crash detection currently has only a
 * historical drain (no live signal handler yet). Co-locating the
 * native drain inside [AnrWatchdog] would put it next to code that
 * spins up a daemon thread it has no business depending on, and would
 * blur the responsibility boundary when the live JNI handler lands.
 * Keeping it in a sibling file makes the v1 → v2 upgrade path clean:
 * a future `NativeCrashHandler.install` will sit next to this drain
 * and mirror the AnrWatchdog two-half shape.
 *
 * # Anti-crash discipline (briefing R6)
 *
 * Every step is wrapped in try/catch and reports failures only to
 * logcat. A bug in the drain MUST NOT crash the host on cold launch
 * — the whole point of the drain is to make crashes visible to
 * operators, so taking the host down with us is the worst possible
 * regression.
 *
 * # No LLM / network from this path (briefing R2)
 *
 * The drain reads [ApplicationExitInfo] via [ActivityManager] and
 * calls into a single provided `enqueueCrash` lambda. The lambda is
 * the SDK's normal queue path; no HTTP, no model inference.
 *
 * # API shape
 *
 * - [drainHistoricalNativeCrashes] is intended to run ONCE at install
 *   on API 30+. Caller is [CrashTracker.install]. On lower API
 *   levels it no-ops gracefully — [ApplicationExitInfo] is unavailable
 *   below API 30, and reflecting around that would only add bytes to
 *   no benefit.
 */
internal object NativeCrashDrain {

    private const val TAG = "Kixo"

    /**
     * Distinct SharedPreferences subdirectory from
     * [AnrWatchdog]'s `kixo_anr` — see object KDoc for why the two
     * dedupes must not collide.
     */
    private const val PREFS_NAME = "kixo_native_crash"
    private const val KEY_LAST_PID = "last_seen_pid"

    /**
     * Maximum number of recent exit entries to inspect. Same bound
     * AnrWatchdog uses — covers the common case (single crash → fast
     * relaunch) without inflating cold-start.
     */
    private const val MAX_EXIT_ENTRIES = 5

    /**
     * Regex that matches the conventional Unix signal name embedded
     * in the [ApplicationExitInfo.description] string. The platform
     * formats descriptions like `"SIGSEGV (Segmentation fault)"` or
     * `"signal 6 (SIGABRT)"` depending on the kernel version, so we
     * grab the first `SIG[A-Z]+` token rather than relying on a fixed
     * position.
     */
    private val SIGNAL_REGEX = Regex("SIG[A-Z]+")

    /**
     * Read recent [ApplicationExitInfo] entries (API 30+) and enqueue
     * any [ApplicationExitInfo.REASON_CRASH_NATIVE] exits we haven't
     * seen before. Dedup by `pid` via SharedPreferences so a relaunch
     * doesn't re-fire the same one.
     *
     * Bounded to the most-recent [MAX_EXIT_ENTRIES] exits — covers
     * the common case (single crash → fast relaunch) without
     * inflating cold-start.
     *
     * @param context Any [Context]; promoted to application context
     *   to avoid leaking an Activity reference.
     * @param enqueueCrash Lambda that routes the assembled property
     *   map to the EventQueue as `event_type=crash,
     *   event_name=native_crash`. Called from whatever thread invoked
     *   this method — the caller is typically the SDK configure path,
     *   which is the main thread, so the lambda must be thread-safe
     *   (the SDK's `enqueueCustom` adapter already is).
     */
    fun drainHistoricalNativeCrashes(
        context: Context,
        enqueueCrash: (Map<String, Any?>) -> Unit,
    ) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return

        // Critic Round 3 HIGH (Phase 11.B coverage gap, May 2026) — the
        // operator switch `data_collection.core.errors = false` halts
        // every error-channel emission. The JVM uncaught handler in
        // CrashTracker already honours this; the native crash drain
        // did not. Both must be silent for a project that disabled
        // of error tracking. Default-allow on pre-init / missing field.
        if (!io.kixo.sdk.internal.queue.DataCollectionHolder
                .isAllowed { it.core?.errors }) {
            return
        }

        try {
            val appContext = context.applicationContext ?: context

            val activityManager = appContext.getSystemService(Context.ACTIVITY_SERVICE)
                as? ActivityManager ?: return

            val prefs = try {
                appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            } catch (_: Throwable) {
                null
            }
            val lastSeenPid = prefs?.getInt(KEY_LAST_PID, -1) ?: -1

            val packageName = try {
                appContext.packageName
            } catch (_: Throwable) {
                null
            } ?: return

            val exits: List<ApplicationExitInfo> = try {
                activityManager.getHistoricalProcessExitReasons(packageName, 0, MAX_EXIT_ENTRIES)
                    ?: emptyList()
            } catch (_: Throwable) {
                emptyList()
            }

            var newestPid = lastSeenPid
            for (exit in exits) {
                try {
                    if (exit.reason != ApplicationExitInfo.REASON_CRASH_NATIVE) continue
                    val pid = exit.pid
                    // Track newest pid across ALL native-crash entries
                    // so the next launch's high-water mark is correct.
                    if (pid > newestPid) newestPid = pid
                    // Skip pids we've already drained.
                    if (pid <= lastSeenPid) continue

                    val description = exit.description
                    val props: Map<String, Any?> = linkedMapOf(
                        // ApplicationExitInfo doesn't tell us which
                        // thread received the signal — most native
                        // crashes happen on main (UI-driven JNI calls)
                        // but the platform doesn't expose it. Best
                        // guess + native=true keeps the event shape
                        // consistent with the live ANR + JVM events.
                        "thread_name" to "main",
                        "signal_name" to extractSignalName(description),
                        "signal_description" to (description ?: ""),
                        "native" to true,
                        "historical" to true,
                        "historical_pid" to pid.toLong(),
                        "historical_timestamp_ms" to exit.timestamp,
                        // Memory state at death — useful for ruling out
                        // OOM-adjacent native crashes from genuine
                        // pointer bugs. pss/rss are reported in KiB by
                        // ApplicationExitInfo.
                        "pss_kb" to exit.pss,
                        "rss_kb" to exit.rss,
                        "importance" to exit.importance,
                        "api_level" to Build.VERSION.SDK_INT,
                        "device_model" to Build.MODEL,
                        "device_manufacturer" to Build.MANUFACTURER,
                        "os_version" to (Build.VERSION.RELEASE ?: "unknown"),
                    )
                    enqueueCrash(props)
                } catch (t: Throwable) {
                    Log.w(TAG, "NativeCrashDrain entry skipped", t)
                }
            }

            // Persist the new high-water mark even if we drained zero
            // entries — keeps the dedup correct on subsequent launches.
            if (newestPid != lastSeenPid && prefs != null) {
                try {
                    prefs.edit().putInt(KEY_LAST_PID, newestPid).apply()
                } catch (t: Throwable) {
                    Log.w(TAG, "NativeCrashDrain prefs persist failed", t)
                }
            }
        } catch (t: Throwable) {
            // R6: never crash the host on drain failure. Worst case
            // we lose visibility into this batch of native crashes;
            // the next cold launch retries.
            Log.w(TAG, "NativeCrashDrain failed", t)
        }
    }

    /**
     * Parse the conventional Unix signal name out of an
     * [ApplicationExitInfo.description]. The platform's format isn't
     * a guaranteed API surface (we've seen both
     * `"SIGSEGV (Segmentation fault)"` and
     * `"signal 6 (SIGABRT), code 0"` across OEM builds), so we just
     * grab the first `SIG[A-Z]+` substring. Returns `"unknown"` when
     * the description is null/empty or contains no matching token.
     *
     * Exposed for the install-site documentation + future tests; the
     * runtime path is the only caller today.
     */
    internal fun extractSignalName(description: String?): String {
        if (description.isNullOrEmpty()) return "unknown"
        return try {
            SIGNAL_REGEX.find(description)?.value ?: "unknown"
        } catch (_: Throwable) {
            "unknown"
        }
    }
}
