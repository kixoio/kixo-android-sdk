package io.kixo.sdk.internal.attribution

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Delivers the canonical **install signal** (§0 §2, KIX-DL-01) once per
 * physical install — the Android half of the cross-platform install spine the
 * MMP attribution platform keys off.
 *
 * **Why this exists (BLOCKER A).** Before this, the Android SDK emitted NO
 * canonical install event — `KixoEventType` had no `Install` case and nothing
 * fired `app_install`. The backend keys install discovery on
 * `event_type === 'install'` ([AttributionContract.INSTALL_EVENT_TYPE]); with
 * Android never emitting it, `Link.installCount`, organic detection, and the
 * FREE-cap dedup unit were 100% dark on Android. This emitter closes that gap.
 *
 * Per the FROZEN §0 wire-contract:
 *   - The event NAME is `app_install`
 *     ([AttributionContract.APP_INSTALL_EVENT_NAME]).
 *   - The on-the-wire `event_type` is `install`
 *     ([AttributionContract.INSTALL_EVENT_TYPE], i.e. `KixoEventType.Install`)
 *     — install discovery keys on `event_type == 'install'`, NOT on
 *     `standard_kind` and NOT on the legacy `app_launch{is_first_launch}`
 *     lifecycle event.
 *   - It carries the `install_referrer` payload + `kixo_link_id`/`kixo_click_id`
 *     echo when the bounded Play Referrer read supplies them. Production passes
 *     those properties explicitly from [InstallSignalCoordinator]; the provider
 *     remains a narrow test/compatibility seam.
 *
 * ### Why dedicated acquisition state (not `app_launch{is_first_launch}`)
 * `ProcessLifecycleObserver` already stamps `is_first_launch` on `app_launch`.
 * We deliberately do NOT reuse that flag. [InstallAcquisitionStateStore] owns a
 * stable install id and event id until the backend explicitly accepts that
 * event. A local queue commit is only a proposal, not a delivered once-flag.
 *
 * Thread-safety: an in-process [AtomicBoolean] prevents duplicate queue rows.
 * Process restarts reconstruct the same event while backend acceptance is
 * unsettled.
 */
internal class InstallEmitter(
    private val state: InstallAcquisitionStateStore,
    /**
     * Commits the stable event into the durable queue. [onCommitted] is true
     * only after SQLite accepted the row; it is not a backend acknowledgement.
     */
    private val onEvent: (
        eventId: String,
        installId: String,
        startedAtMs: Long,
        properties: Map<String, Any?>,
        onCommitted: (Boolean) -> Unit,
    ) -> Unit,
    /**
     * Supplies the extra install properties known at emit time: the referrer-derived
     * `kixo_click_id`/`kixo_link_id` echo + the `install_referrer` payload, when
     * available. Mirrors the iOS `clickIdProvider` seam. Default: none.
     */
    private val propsProvider: () -> Map<String, Any?> = { emptyMap() },
    private val appVersion: String = "unknown",
    private val appBuild: String = "unknown",
) {

    /** True while this process knows the stable row is queued/in-flight. */
    private val queuedInProcess = AtomicBoolean(false)
    private val queueCommitObserver =
        java.util.concurrent.atomic.AtomicReference<(Boolean) -> Unit>({})

    /**
     * Queue the canonical `app_install` signal while backend acceptance is
     * unsettled. The stable event id makes reconstruction idempotent.
     *
     * @return true if the install signal was emitted on THIS call, false if it
     *   had already been emitted (idempotent no-op).
     */
    fun enqueueIfNeeded(
        readyProperties: Map<String, Any?>? = null,
    ): Boolean {
        if (!state.needsInstallDelivery()) return false
        if (!queuedInProcess.compareAndSet(false, true)) return false
        val identity = state.identity()
        if (identity == null) {
            queuedInProcess.set(false)
            return false
        }

        val props = LinkedHashMap<String, Any?>(8)
        props["app_version"] = appVersion
        props["build_number"] = appBuild
        props["platform"] = "android"
        // Merge resolver/referrer-supplied echo + install_referrer payload. The
        // canonical wire keys (kixo_click_id / kixo_link_id / install_referrer)
        // are §0-FROZEN and supplied by the provider verbatim — never re-spelled.
        try {
            for ((k, v) in readyProperties ?: propsProvider()) {
                if (v != null) props[k] = v
            }
        } catch (_: Throwable) {
            // R6 — a buggy provider must never block the install signal.
        }

        try {
            onEvent(
                identity.installEventId,
                identity.installId,
                identity.startedAtMs,
                props,
            ) { committed ->
                if (!committed) queuedInProcess.set(false)
                runCatching { queueCommitObserver.get().invoke(committed) }
            }
        } catch (_: Throwable) {
            queuedInProcess.set(false)
            runCatching { queueCommitObserver.get().invoke(false) }
            return false
        }
        return true
    }

    fun setQueueCommitObserver(observer: (Boolean) -> Unit) {
        queueCommitObserver.set(observer)
    }

    /** Explicit server-policy queue clears require rebuilding a pending install. */
    fun markQueueLost() {
        if (state.needsInstallDelivery()) queuedInProcess.set(false)
    }

    fun markAccepted(eventId: String): Boolean {
        val accepted = state.markInstallAccepted(eventId)
        if (accepted) queuedInProcess.set(true)
        return accepted
    }

    fun markRejected(eventId: String, reason: String): Boolean {
        val rejected = state.markInstallRejected(eventId, reason)
        if (rejected) queuedInProcess.set(true)
        return rejected
    }
}
