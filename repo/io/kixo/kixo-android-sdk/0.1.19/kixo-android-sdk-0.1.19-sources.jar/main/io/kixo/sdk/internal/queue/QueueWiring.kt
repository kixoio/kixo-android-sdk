package io.kixo.sdk.internal.queue

import android.content.Context
import io.kixo.sdk.KixoConfiguration
import io.kixo.sdk.StandardProperty
import io.kixo.sdk.internal.context.DeviceInfo
import io.kixo.sdk.internal.identity.IdentityManager
import io.kixo.sdk.internal.lifecycle.CollectionBoundaryGate
import io.kixo.sdk.internal.model.DataCollection
import io.kixo.sdk.internal.model.ConfigRequest
import io.kixo.sdk.internal.model.InitRequest
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.model.toJsonElement
import io.kixo.sdk.internal.privacy.PiiFilter
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import io.kixo.sdk.internal.storage.EventStorageHelper
import io.kixo.sdk.internal.storage.SqliteEventStore
import io.kixo.sdk.internal.transport.HttpClientFactory
import io.kixo.sdk.internal.transport.Transport
import io.kixo.sdk.internal.transport.TransportContract
import java.time.Instant
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import kotlin.random.Random

/**
 * Builds the live [EventQueue] from real peer-agent types and exposes
 * a public-facade-facing wrapper [KixoEventQueueRef].
 *
 * **Wave 6 refactor (May 2026):** earlier revisions wrapped every peer
 * type (`storage.EventStore`, `transport.Transport`, `model.KixoEvent`,
 * `model.BatchPayload`, `context.DeviceInfo`, `model.EnrichedContext`)
 * in a queue-side adapter so the queue could declare narrow
 * "parallel-universe" stub interfaces. The adapters added ~280 LOC
 * with no behavioural value once Agent 5's parallel-build phase ended.
 *
 * This file now wires the queue against the real types directly.
 * [KixoEventQueueRef] is the only remaining wrapper, and only because
 * the public facade's `EventQueueRef` interface in `Kixo.kt` is
 * `private` — we can't satisfy it directly from a non-nested type.
 *
 * Per AGENT_BRIEFING.md §6 file-ownership: this file lives in
 * `internal/queue/` (Agent 5's folder) because the wiring is a queue
 * concern. We READ peer types but never modify them.
 */
/**
 * Functional handle the public facade uses to wrap into the
 * `Kixo.PushTransportBridge` private interface. SAM-style so the
 * facade's anonymous-object adapter is a one-liner.
 */
internal fun interface PushTransportInvoke {
    operator fun invoke(token: String, provider: io.kixo.sdk.PushProvider)
}

internal object QueueWiring {

    /**
     * Build the live `EventQueue` + return an [KixoEventQueueRef]
     * suitable for the public facade's `Wiring.queueRef` slot.
     *
     * Side effects (in order):
     *  1. Construct the real `SqliteEventStore` at `<filesDir>/kixo/events.db`.
     *  2. Construct the shared `OkHttpClient` (debug-build logging on).
     *  3. Construct the real `Transport` against the configured base URL.
     *  4. Seed `ConfigHolder` from the [KixoConfiguration] snapshot.
     *  5. Construct the queue-internal `BatchPayloadAssembler` with
     *     the real `DeviceInfo`.
     *  6. Construct the queue with the real store + transport +
     *     assembler + a SupervisorJob-rooted scope. No adapters.
     *  7. Optimistically transition lifecycle to `Running` so events
     *     ship right away. If creds are wrong, backend's 401 →
     *     `PausedByServer("http_401")` flips state via the existing
     *     apply-response path.
     *  8. Return [KixoEventQueueRef] for the public facade.
     */
    /**
     * Aggregate of everything `QueueWiring.build` constructs that the
     * facade needs to wire up. Lets us hand back the queue ref AND the
     * push-transport bridge AND the underlying `Transport` (so future
     * subsystems — replay uploader, etc — can share the same OkHttp
     * client + creds without rebuilding).
     */
    internal data class Built(
        val queueRef: KixoEventQueueRef,
        val pushTransport: PushTransportInvoke,
        val transport: Transport,
        val httpClient: okhttp3.OkHttpClient,
        val scope: CoroutineScope,
        val identity: IdentityManager,
        val replayPolicy: ReplayRuntimePolicy,
        /** Starts /init exactly once, after replay lifecycle wiring is active. */
        val startControlPlane: () -> Unit,
    )

    fun build(
        context: Context,
        config: KixoConfiguration,
        identity: IdentityManager,
        deviceInfo: DeviceInfo,
        releaseId: String? = null,
        collectionBoundaryGate: CollectionBoundaryGate,
        onAcceptedEventIds: (Set<String>) -> Unit = {},
        onPermanentEventIds: (Set<String>) -> Unit = {},
        onDurableQueueCleared: () -> Unit = {},
        onRunning: () -> Unit = {},
    ): Built {
        // 1. Real store. The Helper builds the
        //    SupportSQLiteOpenHelper (lazy file create at /filesDir/kixo/),
        //    SqliteEventStore wraps it.
        val databaseFileName = EventStorageHelper.scopedFileName(
            environment = config.environment,
            projectId = config.projectId,
            apiHost = config.apiHost,
        )
        val store = SqliteEventStore(
            EventStorageHelper(context, databaseFileName).create(),
            maxRows = config.maxBufferSize,
        )
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

        // 2. + 3. HTTP client + transport. Logging on in debug.
        val httpClient = HttpClientFactory.create(enableLogging = config.debug)
        val json = Json {
            ignoreUnknownKeys = true
            encodeDefaults = false
        }
        val transport = Transport(
            httpClient = httpClient,
            baseUrl = config.apiHost,
            json = json,
            collectionBoundaryGate = collectionBoundaryGate,
        )
        val replayPolicy = ReplayRuntimePolicy.create(
            context = context,
            environment = config.environment,
            apiHost = config.apiHost,
            projectId = config.projectId,
            bundleId = context.packageName,
        )

        // 4. Seed ConfigHolder from the user's KixoConfiguration so
        //    BatchPayloadAssembler.assemble() reads the right env / creds.
        ConfigHolder.set(
            ConfigHolder.Snapshot(
                projectId = config.projectId,
                apiKey = config.apiKey,
                environment = config.environment,
                apiHost = config.apiHost,
                appVersion = appVersion(context),
                bundleId = context.packageName,
                releaseId = releaseId.orEmpty(),
                maxBufferSize = config.maxBufferSize,
                flushAt = 20,
                flushIntervalMs = 30_000L,
                debug = config.debug,
            ),
        )

        // 5. Assembler now takes the real DeviceInfo — no adapter.
        val assembler = BatchPayloadAssembler(deviceInfo = deviceInfo)

        // 6. Queue itself. Real types throughout — no adapters.
        val queue = EventQueue(
            store = store,
            transport = transport,
            payloadAssembler = assembler,
            scope = scope,
            flushAt = 20,
            flushIntervalMs = 30_000L,
            maxBufferSize = config.maxBufferSize,
            collectionBoundaryGate = collectionBoundaryGate,
            onAcceptedEventIds = onAcceptedEventIds,
            onPermanentEventIds = onPermanentEventIds,
            onDurableQueueCleared = onDurableQueueCleared,
            onRunning = onRunning,
        )

        // 7. Stay Initialising until /init resolves. Cold-start events buffer
        // durably, but none can cross the wire before the server kill-switch
        // and collection policy are known (parity with Web/iOS).
        // 8. Wave 6: real /api/sdk/init wiring. Fires async on the
        // SDK scope so cold-launch isn't blocked. On success we
        // stamp the resolved `release_id` into ConfigHolder so
        // subsequent batches embed it (vs the empty-string fallback
        // that triggers backend auto-discovery on every batch).
        // On `paused: true` (server kill-switch) we transition the
        // lifecycle to PausedByServer — events stop shipping.
        //
        // Retry transient failures with capped exponential backoff + jitter;
        // after each burst the jittered thirty-minute control loop tries again. The queue
        // stays Initialising/buffered until a real response arrives.
        val controlPlaneStarted = AtomicBoolean(false)
        val startControlPlane = {
            if (controlPlaneStarted.compareAndSet(false, true)) {
                scope.launch {
                    // Do not open collection while rows claimed by a prior
                    // process may still be hidden as in-flight. SQL failures
                    // propagate from SqliteEventStore and retry here; cold
                    // events continue buffering durably in Initialising.
                    queue.recoverInFlightUntilSuccess("Startup")
                    runInitWithRetry(
                        config,
                        context,
                        transport,
                        queue,
                        replayPolicy,
                    )
                }
            }
            Unit
        }

        // 9. Public-facade-facing wrapper + push bridge using the same
        //    transport + scope.
        val queueRef = KixoEventQueueRef(queue, identity, deviceInfo)
        val pushBridge = buildPushTransportBridge(
            transport,
            identity,
            scope,
            collectionBoundaryGate,
        )
        return Built(
            queueRef,
            pushBridge,
            transport,
            httpClient,
            scope,
            identity,
            replayPolicy,
            startControlPlane,
        )
    }

    /**
     * Real implementation of `Kixo.PushTransportBridge` — sends a
     * plaintext push token to `/api/sdk/push/register`. Wave 7 fix:
     * before this, `Kixo.setPushToken(...)` routed through a no-op
     * bridge so the token never actually reached the backend.
     *
     * Token plaintext crosses the wire here ONLY (per AGENT_BRIEFING.md
     * R10). Every other event-stream reference uses SHA-256.
     */
    fun buildPushTransportBridge(
        transport: TransportContract,
        identity: IdentityManager,
        scope: CoroutineScope,
        collectionBoundaryGate: CollectionBoundaryGate,
    ): PushTransportInvoke = PushTransportInvoke { token, provider ->
        // Keep raw-token registration on the identity boundary so a logout
        // cannot let an already-admitted request escape with retired identity.
        collectionBoundaryGate.launchTask(scope) { collectionEpoch ->
            val cfg = ConfigHolder.snapshot()
            if (cfg.projectId.isEmpty() || cfg.apiKey.isEmpty()) {
                return@launchTask
            }
            val req = io.kixo.sdk.internal.model.PushRegisterRequest(
                projectId = cfg.projectId,
                apiKey = cfg.apiKey,
                deviceId = identity.deviceId(),
                userId = identity.userId(),
                token = token,
                // platform default = "android"
                releaseId = cfg.releaseId,
                bundleId = cfg.bundleId,
                environment = cfg.environment,
                sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
            )
            try {
                val ok = transport.postPushRegister(req, collectionEpoch)
                if (!ok && cfg.debug) {
                    android.util.Log.w(
                        "Kixo.Push",
                        "registerPushToken failed (transient or 4xx); the next setPushToken() call retries",
                    )
                }
            } catch (t: Throwable) {
                // R6 — never crash the host.
                if (cfg.debug) android.util.Log.w("Kixo.Push", "registerPushToken threw", t)
            }
        }
    }

    /**
     * `/api/sdk/init` bootstrap + live config poller. Each cycle retries a
     * transient outage with capped exponential backoff, then waits thirty
     * minutes (±10% jitter per arm, so a fleet of devices doesn't herd the
     * endpoint) before refreshing again. Polling continues while
     * server-paused so an operator unpause takes effect without an app restart.
     */
    private suspend fun runInitWithRetry(
        config: KixoConfiguration,
        context: Context,
        transport: Transport,
        queue: EventQueue,
        replayPolicy: ReplayRuntimePolicy,
    ) {
        val req = InitRequest(
            projectId = config.projectId,
            apiKey = config.apiKey,
            bundleId = context.packageName,
            appVersion = appVersion(context),
            build = appBuild(context),
            environment = config.environment,
            sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
        )
        var initResolved = false
        var appId = ""
        var releaseId = ""
        var refreshImmediately = false
        controlPlaneLoop@ while (currentCoroutineContext().isActive) {
            var attempt = 0
            var resolvedThisCycle = false
            while (attempt < INIT_RETRY_ATTEMPTS && currentCoroutineContext().isActive) {
                try {
                    if (!initResolved) {
                        val requestGeneration = queue.controlPlaneGeneration()
                        val resp = transport.postInit(req)
                        if (resp == null) throw ControlPlaneUnresolved
                        // The top-level init kill switch is semantically the
                        // same global data-collection pause as
                        // data_collection.paused. Persist that effective value
                        // in the process-wide snapshot too: reset/recovery
                        // paths consult the holder after this coroutine returns
                        // and must not be able to
                        // restart replay while the project remains paused.
                        var effectivePaused = false
                        var replayPolicyOn = false
                        val applied = queue.applyIfControlPlaneGenerationCurrent(requestGeneration) {
                            val resolvedDataCollection = resolveDataCollection(
                                resp.dataCollection,
                                topLevelPaused = resp.paused,
                            )
                            // Publish policy before changing lifecycle so every
                            // tracker sees the new gates on its next emission.
                            DataCollectionHolder.set(resolvedDataCollection)
                            // Live gates only cover what is emitted from here
                            // on. Judge the cold-start rows admitted before any
                            // policy existed against this first authority, and
                            // hold the flush path until that is done.
                            queue.reconcilePrePolicyBuffer(resolvedDataCollection)
                            applyDataCollectionSideEffects(
                                resolvedDataCollection,
                                config.debug,
                                topLevelPaused = resp.paused,
                                replayPolicy = replayPolicy,
                            )
                            ConfigHolder.setResolvedApp(
                                appId = resp.appId,
                                releaseId = resp.releaseId,
                            )
                            appId = resp.appId
                            releaseId = resp.releaseId

                            effectivePaused = resolvedDataCollection?.paused == true
                            replayPolicyOn = replayPolicy.snapshot().enabled

                            if (effectivePaused) {
                                val reason = resp.pausedReason
                                    ?: if (resp.dataCollection?.paused == true) {
                                        "data_collection_paused"
                                    } else {
                                        "init_paused"
                                    }
                                queue.setServerPaused(reason)
                                if (config.debug) {
                                    android.util.Log.w(
                                        "Kixo",
                                        "/api/sdk/init paused; reason=$reason; polling continues",
                                    )
                                }
                            } else {
                                queue.setServerRunning()
                                val collectionRecovered =
                                    io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap
                                        .commitPendingCollectionRecoverySession()
                                if (collectionRecovered) {
                                    io.kixo.sdk.internal.replay.ReplayController
                                        .rearmRetainedStartForCollectionBoundary()
                                }
                                if (replayPolicyOn) {
                                    try {
                                        io.kixo.sdk.internal.replay.ReplayController.startPendingIfArmed()
                                    } catch (t: Throwable) {
                                        if (config.debug) {
                                            android.util.Log.w(
                                                "Kixo",
                                                "replay startPendingIfArmed threw",
                                                t,
                                            )
                                        }
                                    }
                                }
                            }
                        }
                        if (!applied) continue@controlPlaneLoop
                        if (effectivePaused) queue.retireCollectionNetworkCalls()

                        if (config.debug) {
                            val tag = if (attempt == 0) {
                                "init/config ok"
                            } else {
                                "init/config ok after ${attempt + 1} attempts"
                            }
                            android.util.Log.d(
                                "Kixo",
                                "$tag: release_id=${resp.releaseId} app=${resp.appName} " +
                                    "max_batch=${resp.maxBatchSize ?: "default"} " +
                                    "paused=$effectivePaused replay_policy_on=$replayPolicyOn",
                            )
                        }
                        resolvedThisCycle = true
                        // `/init` establishes release/app identity once. The
                        // backend's `/config` route evaluates the same project,
                        // billing, SDK-catalogue, and minimum-version latches,
                        // so every later refresh stays on that canonical path.
                        initResolved = true
                        // `/init` establishes release/app identity. Follow it
                        // immediately with the dedicated `/config` endpoint so
                        // live project policy has one canonical refresh source.
                        refreshImmediately = true
                        break
                    } else {
                        val requestGeneration = queue.controlPlaneGeneration()
                        val resp = transport.getConfig(
                            ConfigRequest(
                                projectId = config.projectId,
                                apiKey = config.apiKey,
                                appId = appId,
                                releaseId = releaseId,
                                bundleId = context.packageName,
                                environment = config.environment,
                                sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
                            ),
                        ) ?: throw ControlPlaneUnresolved
                        var effectivePaused = false
                        val applied = queue.applyIfControlPlaneGenerationCurrent(requestGeneration) {
                            val resolvedDataCollection = resolveDataCollection(
                                resp.dataCollection,
                                topLevelPaused = resp.paused,
                            )
                            DataCollectionHolder.set(resolvedDataCollection)
                            // No-op unless `/config` is the first policy this
                            // process ever resolved (a `/init` that never
                            // answered). Reconciliation is one-shot.
                            queue.reconcilePrePolicyBuffer(resolvedDataCollection)
                            applyDataCollectionSideEffects(
                                resolvedDataCollection,
                                config.debug,
                                topLevelPaused = resp.paused,
                                replayPolicy = replayPolicy,
                            )
                            effectivePaused = resolvedDataCollection?.paused == true
                            if (effectivePaused) {
                                queue.setServerPaused(resp.pausedReason ?: "config_paused")
                            } else {
                                queue.setServerRunning()
                                val collectionRecovered =
                                    io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap
                                        .commitPendingCollectionRecoverySession()
                                if (collectionRecovered) {
                                    io.kixo.sdk.internal.replay.ReplayController
                                        .rearmRetainedStartForCollectionBoundary()
                                }
                                if (replayPolicy.snapshot().let {
                                        it.enabled
                                    }
                                ) {
                                    io.kixo.sdk.internal.replay.ReplayController.startPendingIfArmed()
                                }
                            }
                        }
                        if (!applied) continue@controlPlaneLoop
                        if (effectivePaused) queue.retireCollectionNetworkCalls()
                        if (config.debug) {
                            android.util.Log.d(
                                "Kixo",
                                "config ok: paused=$effectivePaused " +
                                    "replay_policy_on=${replayPolicy.snapshot().enabled}",
                            )
                        }
                        resolvedThisCycle = true
                        break
                    }
                } catch (_: ControlPlaneUnresolved) {
                    // Uniform retry path below.
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (t: Throwable) {
                    if (config.debug) {
                        android.util.Log.w(
                            "Kixo",
                            "SDK control-plane attempt ${attempt + 1} threw",
                            t,
                        )
                    }
                }

                attempt++
                if (attempt >= INIT_RETRY_ATTEMPTS) break
                val baseMs = (INIT_RETRY_BASE_DELAY_MS shl (attempt - 1))
                    .coerceAtMost(INIT_RETRY_MAX_DELAY_MS)
                val jitterMs = (baseMs * 0.5 * (Random.nextDouble() - 0.5)).toLong()
                delay((baseMs + jitterMs).coerceAtLeast(1_000L))
            }

            if (!resolvedThisCycle && config.debug) {
                android.util.Log.w(
                    "Kixo",
                    "SDK control plane unresolved after $INIT_RETRY_ATTEMPTS attempts; " +
                        "retrying next refresh cycle",
                )
            }
            if (refreshImmediately && initResolved) {
                refreshImmediately = false
            } else {
                // Unlike a bare delay, this is interruptible by an explicit
                // lifecycle refresh request.
                queue.awaitControlPlaneRefresh(configRefreshDelayMs())
            }
        }
    }

    /** Stackless sentinel used to share init/config retry control flow. */
    private object ControlPlaneUnresolved : Throwable(null, null, false, false)

    /** 30-min refresh base with ±10% jitter drawn fresh per arm. */
    private fun configRefreshDelayMs(): Long =
        (CONFIG_REFRESH_INTERVAL_MS * (0.9 + Random.nextDouble() * 0.2)).toLong()

    /**
     * Apply the side-effecting half of the data_collection contract:
     *  - push.contentMode / titlePreviewChars / bodyPreviewChars →
     *    rebuild PushTracker's [PushPayloadSanitizer] so subsequent
     *    `logPushReceived/Opened/etc.` honour the new policy.
     *  - paused → also notify ReplayController so frame capture
     *    halts in addition to the queue's PausedByServer flip.
     *
     * Pure value-routing — no Android system services touched here,
     * safe to invoke from the init coroutine. All error paths swallow
     * per AGENT_BRIEFING R6.
     */
    private fun applyDataCollectionSideEffects(
        dc: io.kixo.sdk.internal.model.DataCollection?,
        debug: Boolean,
        topLevelPaused: Boolean = false,
        replayPolicy: ReplayRuntimePolicy? = null,
    ) {
        val replayPolicyChange = replayPolicy?.apply(dc, topLevelPaused)
        if (replayPolicyChange?.artifactsInvalidated == true) {
            try {
                // A stricter project policy retires every staged/in-flight
                // artifact captured under the prior grant before restart.
                io.kixo.sdk.internal.replay.ReplayController.stopForRemotePolicy()
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "replay policy tightening stop threw", t)
            }
        }
        if (topLevelPaused) {
            try {
                io.kixo.sdk.internal.replay.ReplayController.stopForRemotePolicy()
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "top-level pause replay stop threw", t)
            }
        }
        // Missing data_collection is not replay permission. The scoped
        // runtime policy above resolved it to disabled; stop a previously
        // live stint before returning.
        if (dc == null) {
            io.kixo.sdk.internal.push.PushTracker.reset()
            try {
                io.kixo.sdk.internal.replay.ReplayController.stopForRemotePolicy()
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "missing replay policy stop threw", t)
            }
            return
        }

        // Push content-mode wiring. Pre-fix `updateContentMode` had
        // zero callers — operator dashboard's push redaction toggle was
        // 100% no-op on Android. Now flows through here on every /init.
        val pushCfg = dc.push
        if (pushCfg?.enabled == false) {
            io.kixo.sdk.internal.push.PushTracker.reset()
        }
        if (pushCfg != null) {
            try {
                val mode = io.kixo.sdk.internal.push.ContentMode.fromServerString(pushCfg.contentMode)
                io.kixo.sdk.internal.push.PushTracker.updateContentMode(
                    mode = mode,
                    titleLimit = pushCfg.titlePreviewChars
                        ?: io.kixo.sdk.internal.push.PushPayloadSanitizer.TITLE_PREVIEW_CHARS,
                    bodyLimit = pushCfg.bodyPreviewChars
                        ?: io.kixo.sdk.internal.push.PushPayloadSanitizer.BODY_PREVIEW_CHARS,
                )
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection push update threw", t)
            }
        }

        // Replay fan-out to ReplayController. Mirrors iOS
        // `applyRemoteConfig` (Kixo.swift:1942-1960).
        //
        // Two operator signals seal the in-flight session + tear down
        // the cost-heavy thermal/memory observers (queue lifecycle
        // handles the analytics-event side via setLifecycleState
        // upstream; frame capture is the side that needs an explicit
        // stop):
        //   - global `paused` (kill-switch)
        //   - S4: `replay.enabled == false` OR an EXPLICIT server rate
        //     <= 0 — an operator runtime-disable of replay specifically.
        //     Emit was already suppressed at tap time, but the phantom
        //     "live · 0" backend session + observers stayed resident;
        //     stop() (idempotent) seals them.
        //
        // Otherwise, when replay stays enabled, thread the effective
        // sample rate into the deterministic verdict via
        // `updateSampleRate` (S3 / KIX-UNI-22 parity). Sparse wire
        // contract (2026-07): the block being PRESENT with `sampleRate`
        // omitted means the backend elided the default — 100%, so push
        // fraction 1.0. An explicit wire rate (0-100 percent) still
        // wins (10 → 0.1) and an explicit 0 disables. The override is
        // applied on the NEXT start()/session-open — matching iOS, we
        // don't re-roll a live verdict.
        val replay = dc.replay
        val fractionalRate = replay?.effectiveSampleRateFraction() ?: 0.0
        val replayOff = topLevelPaused || dc.paused == true ||
            replay?.enabled != true || fractionalRate <= 0.0
        if (replayOff) {
            try {
                // Keep the not-yet-fired infrastructure thunk intact. If an
                // operator later changes false→true, the next resolved project
                // policy may consume that deferred thunk without requiring an
                // app relaunch. No local replay flag authorises the start.
                io.kixo.sdk.internal.replay.ReplayController.stopForRemotePolicy()
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection replay stop threw", t)
            }
        } else {
            try {
                io.kixo.sdk.internal.replay.ReplayController.updateSampleRate(fractionalRate)
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection replay sampleRate update threw", t)
            }
        }

        // AND-CAP-04 — thread the server-resolved perf knobs into the
        // live ReplayConfig (structural/ocr re-enable, cadence,
        // compression). Only when replay is NOT being torn down above.
        // Enterprise gating is enforced server-side (replay-plan-gate),
        // so we faithfully apply whatever the server sends. Each value
        // is clamped by DirtyCadenceClamp; null (server said nothing)
        // leaves the compiled default. `heicQuality` (0-1 wire) maps to
        // our jpegQuality; `dirtyHeartbeatSec` (seconds) → ms.
        if (!replayOff) {
            try {
                io.kixo.sdk.internal.replay.ReplayController.applyRemoteReplayKnobs(
                    io.kixo.sdk.internal.replay.ReplayKnobs(
                        frameCaptureEnabled = replay.frameCaptureEnabled,
                        maxDurationMs = io.kixo.sdk.internal.replay.DirtyCadenceClamp
                            .maxDurationMs(replay.maxDurationSec),
                        structuralEnabled = replay.structuralEnabled,
                        ocrEnabled = replay.ocrEnabled,
                        captureMinIntervalMs =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .captureMinIntervalMs(replay.captureMinIntervalMs),
                        scrollEndCaptureEnabled = replay.scrollEndCaptureEnabled,
                        scrollEndMinIntervalSec = io.kixo.sdk.internal.replay.DirtyCadenceClamp
                            .scrollEndMinIntervalSec(replay.scrollEndMinIntervalSec),
                        postTapSettleMs =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .settleMs(replay.postTapSettleMs),
                        dirtyHeartbeatMs =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .heartbeatMs(replay.dirtyHeartbeatSec),
                        jpegQuality =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .jpegQualityFromHeic(replay.heicQuality),
                        captureScale =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .captureScale(replay.captureScale),
                        maxConcurrentCaptures =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .boundedConcurrency(replay.maxConcurrentCaptures),
                        maxConcurrentOcr =
                            io.kixo.sdk.internal.replay.DirtyCadenceClamp
                                .boundedConcurrency(replay.maxConcurrentOcr),
                    ),
                )
            } catch (t: Throwable) {
                if (debug) android.util.Log.w("Kixo", "applyDataCollection replay knobs update threw", t)
            }
        }
    }

    private fun resolveDataCollection(
        dc: DataCollection?,
        topLevelPaused: Boolean,
    ): DataCollection? = if (topLevelPaused) {
        (dc ?: DataCollection()).copy(paused = true)
    } else {
        dc
    }

    @androidx.annotation.VisibleForTesting
    internal fun resolveDataCollectionForTesting(
        dc: DataCollection?,
        topLevelPaused: Boolean,
    ): DataCollection? = resolveDataCollection(dc, topLevelPaused)

    /**
     * Test seam — drive the real [applyDataCollectionSideEffects]
     * replay/push routing (S3/S4 wiring) from a unit test without a
     * live /init round-trip. Mirrors the `resetForTesting` /
     * `nextSeqForTesting` seam convention elsewhere in the SDK.
     */
    @androidx.annotation.VisibleForTesting
    internal fun applyDataCollectionSideEffectsForTesting(
        dc: io.kixo.sdk.internal.model.DataCollection?,
        debug: Boolean = false,
        topLevelPaused: Boolean = false,
        replayPolicy: ReplayRuntimePolicy? = null,
    ) = applyDataCollectionSideEffects(dc, debug, topLevelPaused, replayPolicy)

    private const val INIT_RETRY_ATTEMPTS: Int = 6
    private const val INIT_RETRY_BASE_DELAY_MS: Long = 5_000L
    private const val INIT_RETRY_MAX_DELAY_MS: Long = 160_000L
    // Cross-SDK consistency (July 2026 review): all three SDKs poll config
    // every 30 min, jittered ±10% per arm via [configRefreshDelayMs].
    private const val CONFIG_REFRESH_INTERVAL_MS: Long = 30 * 60_000L

    private fun appBuild(context: Context): String =
        try {
            val info = context.packageManager.getPackageInfo(context.packageName, 0)
            // longVersionCode is API 28+; SDK minSdk is 24 so guard.
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                info.longVersionCode.toString()
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toString()
            }
        } catch (_: Throwable) {
            "0"
        }

    private fun appVersion(context: Context): String =
        try {
            context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "0.0.0"
        } catch (_: Throwable) {
            "0.0.0"
        }
}

// ─── EventQueueRef adapter (public-facade-facing) ─────────────────

/**
 * Wraps the real [EventQueue] for the public facade. The facade's
 * own `EventQueueRef` interface is `private` inside `object Kixo`,
 * so we expose the queue through this internal type and let
 * `Kixo.configure(...)` build a private anonymous adapter that
 * forwards to it.
 *
 * `enqueueCustom(eventType, eventName, properties)` builds a complete
 * real [KixoEvent] (UUID event_id + live identity stamps + map →
 * JsonObject conversion) and routes through `EventQueue.enqueue()`
 * via a launch on the SDK's process-global scope (the public API is
 * non-suspend).
 */
internal class KixoEventQueueRef(
    private val queue: EventQueue,
    private val identity: IdentityManager,
    private val deviceInfo: DeviceInfo,
    private val enqueueScope: CoroutineScope = SdkScope,
) {
    fun isCollectionRunning(): Boolean =
        queue.lifecycleState().value is LifecycleState.Running

    fun isServerPaused(): Boolean =
        queue.lifecycleState().value is LifecycleState.PausedByServer

    fun enqueueCustom(
        eventType: String,
        eventName: String,
        properties: Map<String, Any?>,
        // Finding #2 (July 2026) — the caller-supplied identity trait keys for
        // THIS identify()/setUserProperty() call. Only these are eligible for
        // the CRM-email wire exemption; anything else merged into `properties`
        // (super-properties, decorations) stays subject to PII redaction.
        identityTraitKeys: Set<String> = emptySet(),
    ) {
        val admission = captureCurrentIdentityAdmission() ?: return
        val trustedIdentityEvent = eventType == "identify" || eventType == "user_property"
        val realEvent = KixoEvent(
            eventId = UUID.randomUUID().toString(),
            deviceId = admission.deviceId,
            anonymousId = admission.anonymousId,
            userId = admission.userId,
            sessionId = admission.sessionId,
            fingerprint = admission.fingerprint,
            eventType = wireToEnum(eventType),
            eventName = eventName,
            // Critic BLOCKER Android-B1 (May 2026) — every `properties`
            // map shipped via Kixo.track / identify / screen /
            // setUserProperty / markGoal flows through here. Without
            // sanitization, raw customer-supplied free-text values
            // ship to the wire — including any embedded emails / cards
            // / phone numbers / tokens. iOS PiiFilter was wired only
            // to the Replay subsystem; the analytics enqueue path was
            // an unguarded hole. Sanitize STRING leaves AND KEYS
            // (a `{ "user@x.com": "…" }` map otherwise leaks the
            // address in the key position).
            // Sanitise first (PII redaction on customer free-text), THEN
            // stamp the attribution window — the `attribution_*` ids are
            // routing keys, not PII, so they must bypass the redactor (a
            // UUID/CUID brushing a regex must never be mangled). This is the
            // SINGLE chokepoint that closes AC-5 / §3.3 end-to-end: every
            // tracked event inside the 30-min window inherits the resolved
            // link/click/campaign.
            properties = decorateAttribution(
                sanitizePropertiesForWire(
                    properties,
                    trustedIdentityEvent = trustedIdentityEvent,
                    callerTraitKeys = identityTraitKeys,
                ).toJsonElement(),
            ),
            timestamp = Instant.now(),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(
            event = realEvent,
            expectedIdentityBoundaryGeneration = admission.generation,
            scope = enqueueScope,
        )
    }

    /**
     * Queue one canonical direct-link event with the caller's stable event ID.
     * The direct resolve outbox can therefore retry/relaunch without minting a
     * second logical ClickHouse event. The opening event intentionally does not
     * inherit a prior attribution window; the new window opens only after this
     * durable commit succeeds.
     */
    fun enqueueStableDeepLink(
        eventId: String,
        expectedAnonymousId: String,
        expectedDeviceId: String,
        originalUserId: String?,
        originalSessionId: String,
        originalFingerprint: String,
        createdAtMs: Long,
        properties: Map<String, Any?>,
        onCommitted: (Boolean) -> Unit,
    ) {
        if (!EVENT_ID_PATTERN.matches(eventId) ||
            expectedAnonymousId.isBlank() ||
            expectedDeviceId.isBlank() ||
            originalSessionId.isBlank() ||
            originalFingerprint.isBlank() ||
            createdAtMs <= 0
        ) {
            onCommitted(false)
            return
        }
        val admission = queue.captureIdentityAdmission { generation ->
            val anonymousId = identity.anonymousId()
            val deviceId = identity.deviceId()
            if (anonymousId != expectedAnonymousId || deviceId != expectedDeviceId) {
                null
            } else {
                DeepLinkAdmission(generation, deviceId, anonymousId)
            }
        }
        if (admission == null) {
            onCommitted(false)
            return
        }
        val event = KixoEvent(
            eventId = eventId,
            deviceId = admission.deviceId,
            anonymousId = admission.anonymousId,
            userId = originalUserId,
            sessionId = originalSessionId,
            fingerprint = originalFingerprint,
            eventType = KixoEventType.DeepLink,
            eventName = io.kixo.sdk.internal.attribution.AttributionContract.DEEP_LINK_EVENT,
            properties = sanitizePropertiesForWire(properties).toJsonElement(),
            timestamp = Instant.ofEpochMilli(createdAtMs),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(
            event = event,
            onCommitted = onCommitted,
            expectedIdentityBoundaryGeneration = admission.generation,
            scope = enqueueScope,
        )
    }

    /**
     * Queue a custom event under a caller-stable UUID and acknowledge only
     * after SQLite commits it. This is the durable boundary used by hosts that
     * must recover an interaction after process death without minting a second
     * logical event.
     */
    fun enqueueStableCustom(
        eventId: String,
        eventType: String,
        eventName: String,
        properties: Map<String, Any?>,
        onCommitted: (Boolean) -> Unit,
    ) {
        if (!EVENT_ID_PATTERN.matches(eventId)) {
            onCommitted(false)
            return
        }
        val admission = captureCurrentIdentityAdmission()
        if (admission == null) {
            onCommitted(false)
            return
        }
        val event = KixoEvent(
            eventId = eventId,
            deviceId = admission.deviceId,
            anonymousId = admission.anonymousId,
            userId = admission.userId,
            sessionId = admission.sessionId,
            fingerprint = admission.fingerprint,
            eventType = wireToEnum(eventType),
            eventName = eventName,
            // A push open starts a new attribution window after this commit;
            // it must not inherit an older click's attribution decoration.
            properties = sanitizePropertiesForWire(properties).toJsonElement(),
            timestamp = Instant.now(),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(
            event = event,
            onCommitted = onCommitted,
            expectedIdentityBoundaryGeneration = admission.generation,
            scope = enqueueScope,
        )
    }

    /**
     * Queue the stable physical-install event. Unlike [enqueueCustom], the
     * caller supplies both IDs and receives the durable SQLite commit result.
     */
    fun enqueueInstall(
        eventId: String,
        installId: String,
        startedAtMs: Long,
        properties: Map<String, Any?>,
        onCommitted: (Boolean) -> Unit,
    ) {
        if (!INSTALL_ID_PATTERN.matches(installId) ||
            !EVENT_ID_PATTERN.matches(eventId) ||
            startedAtMs <= 0
        ) {
            onCommitted(false)
            return
        }
        val admission = captureCurrentIdentityAdmission()
        if (admission == null) {
            onCommitted(false)
            return
        }
        val event = KixoEvent(
            eventId = eventId,
            deviceId = admission.deviceId,
            anonymousId = admission.anonymousId,
            userId = admission.userId,
            sessionId = admission.sessionId,
            fingerprint = admission.fingerprint,
            eventType = KixoEventType.Install,
            eventName = io.kixo.sdk.internal.attribution.AttributionContract.APP_INSTALL_EVENT_NAME,
            installId = installId,
            properties = decorateAttribution(
                sanitizePropertiesForWire(properties).toJsonElement(),
            ),
            timestamp = Instant.ofEpochMilli(startedAtMs),
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(
            event = event,
            onCommitted = onCommitted,
            expectedIdentityBoundaryGeneration = admission.generation,
            scope = enqueueScope,
        )
    }

    /**
     * Wave 8 — accept a fully-built [KixoEvent] from a caller that has
     * already minted the event id, identity stamps, and fingerprint
     * itself. Used by [io.kixo.sdk.internal.interaction.TouchInterceptor]
     * which needs control over the gesture-time fingerprint snapshot
     * (so the screen_id stamped on a tap matches the screen the user
     * was looking at when the touch landed, NOT the screen they may
     * have transitioned to by the time the queue's enqueue coroutine
     * is dispatched).
     *
     * Callers that pass an `EventContext` placeholder (e.g.
     * [io.kixo.sdk.internal.interaction.TouchInterceptor]'s
     * `EMPTY_EVENT_CONTEXT`) get it overwritten here with the real
     * per-event context from [deviceInfo] so the wire payload always
     * carries enriched device info.
     *
     * **Critic Round 3 BLOCKER Android-B1 (May 2026)** — every property
     * `JsonObject` is routed through [sanitizePropertiesForWire] so
     * `TouchInterceptor`'s raw `target_text` (EditText contents — emails,
     * phones, card numbers typed by the end-user) never reaches the
     * wire. Pre-fix only [enqueueCustom] sanitised; this method bypassed
     * the chokepoint and shipped raw text to ClickHouse `tap.target_text`.
     * The sanitiser handles `JsonObject` walks directly (see
     * `sanitizeJsonObject` in this file), so we re-wrap the result.
     */
    fun enqueueEvent(event: KixoEvent) {
        // Pre-built interaction/lifecycle events carry their own identity
        // snapshot. Work that reaches this adapter after reset must not borrow
        // the successor generation merely because the async hop starts late.
        val expectedGeneration = queue.captureIdentityAdmission { generation ->
            if (event.deviceId != identity.deviceId() ||
                event.anonymousId != identity.anonymousId()
            ) {
                null
            } else {
                generation
            }
        } ?: return
        val sanitizedProperties = sanitizeJsonObjectForWire(event.properties)
        // Attribution window inheritance also applies to pre-built events
        // (taps / screen-visits). Same post-sanitise ordering as enqueueCustom.
        val decorated = decorateAttribution(sanitizedProperties)
        val enriched = event.copy(
            properties = decorated,
            context = deviceInfo.perEventContext(),
        )
        queue.enqueueAsync(
            event = enriched,
            expectedIdentityBoundaryGeneration = expectedGeneration,
            scope = enqueueScope,
        )
    }

    fun flush() = queue.flush()
    fun flushBlocking(timeoutMs: Long): Boolean = queue.flushBlocking(timeoutMs)
    fun requestControlPlaneRefresh() = queue.requestControlPlaneRefresh()
    fun rotateForIdentityReset(
        onBoundaryStarted: () -> Unit,
        onReady: () -> Unit,
    ) = queue.rotateForIdentityReset(onBoundaryStarted, onReady)

    /**
     * Forward live queue health to the facade-side diagnostics
     * surface. Cheap; non-blocking. See [EventQueue.diagnostics].
     */
    fun diagnostics(): QueueDiagnostics = queue.diagnostics()

    private data class IdentityAdmission(
        val generation: Long,
        val deviceId: String,
        val anonymousId: String,
        val userId: String?,
        val sessionId: String,
        val fingerprint: String,
    )

    private data class DeepLinkAdmission(
        val generation: Long,
        val deviceId: String,
        val anonymousId: String,
    )

    private fun captureCurrentIdentityAdmission(): IdentityAdmission? =
        queue.captureIdentityAdmission { generation ->
            IdentityAdmission(
                generation = generation,
                deviceId = identity.deviceId(),
                anonymousId = identity.anonymousId(),
                userId = identity.userId(),
                sessionId = currentSessionId(),
                fingerprint = currentFingerprint(),
            )
        }

    private fun currentSessionId(): String =
        io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap.currentSessionId()
            ?: "boot-${UUID.randomUUID()}"

    private fun currentFingerprint(): String =
        io.kixo.sdk.internal.screen.ScreenIdentity.current().screenId

    private fun wireToEnum(eventType: String): KixoEventType {
        // Defensive: backend rejects unknown event_types as permanent
        // failures, so mapping to .Custom is the safe sink for
        // unrecognised tokens (mirrors iOS). Match against @SerialName
        // wire value (snake_case), not enum constant name (PascalCase).
        return KixoEventType.values().firstOrNull { enumWireValue(it) == eventType }
            ?: KixoEventType.Custom
    }

    private companion object {
        val INSTALL_ID_PATTERN = Regex("^[A-Za-z0-9._:-]{8,128}$")
        val EVENT_ID_PATTERN = Regex(
            "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-5][0-9a-fA-F]{3}-" +
                "[89aAbB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$",
        )
    }

    private fun enumWireValue(t: KixoEventType): String {
        // Cheap mapping — kotlinx.serialization @SerialName is what we
        // need but its lookup requires reflection; the enum's `name`
        // field is reachable from the constant's declaration order.
        // This mirrors `Json.encodeToString(serializer, t).removeSurrounding("\"")`
        // without paying serialization cost per enqueue.
        return when (t) {
            KixoEventType.ScreenView -> "screen_view"
            KixoEventType.Tap -> "tap"
            KixoEventType.Scroll -> "scroll"
            KixoEventType.Network -> "network"
            KixoEventType.Crash -> "crash"
            KixoEventType.Custom -> "custom"
            KixoEventType.SessionStart -> "session_start"
            KixoEventType.SessionEnd -> "session_end"
            KixoEventType.Identify -> "identify"
            KixoEventType.Group -> "group"
            KixoEventType.Lifecycle -> "lifecycle"
            KixoEventType.Navigation -> "navigation"
            KixoEventType.Gesture -> "gesture"
            KixoEventType.PushOpen -> "push_open"
            KixoEventType.PushReceived -> "push_received"
            KixoEventType.PushDismissed -> "push_dismissed"
            KixoEventType.PushSilent -> "push_silent"
            KixoEventType.PushAction -> "push_action"
            KixoEventType.PushPermission -> "push_permission"
            KixoEventType.PushTokenInvalidated -> "push_token_invalidated"
            KixoEventType.DeepLink -> "deep_link"
            KixoEventType.Iap -> "iap"
            KixoEventType.UserProperty -> "user_property"
            // §0 §2 / §2-cont — the install-discovery + referrer-enrichment
            // wire values. wireToEnum("install"/"attribution") now round-trips
            // to the right enum (was falling through to Custom → "custom",
            // BLOCKER A / B).
            KixoEventType.Install -> "install"
            KixoEventType.Attribution -> "attribution"
            KixoEventType.ScreenVisit -> "screen_visit"
            KixoEventType.Goal -> "goal"
        }
    }
}

/**
 * Helper to launch a suspend `enqueue` from the non-suspend public API
 * surface. Lives on a process-global SDK scope rooted in SupervisorJob
 * so a single failed enqueue doesn't tear peers down.
 */
private fun EventQueue.enqueueAsync(
    event: KixoEvent,
    onCommitted: ((Boolean) -> Unit)? = null,
    expectedIdentityBoundaryGeneration: Long,
    scope: CoroutineScope = SdkScope,
) {
    scope.launch {
        val committed = runCatching {
            enqueue(
                event,
                expectedIdentityBoundaryGeneration =
                    expectedIdentityBoundaryGeneration,
            )
        }.getOrDefault(false)
        onCommitted?.let { callback ->
            runCatching { callback(committed) }
        }
    }
}

private object SdkScope : CoroutineScope by CoroutineScope(SupervisorJob() + Dispatchers.Default)

/**
 * Known profile identity fields that customers intentionally submit through
 * identify()/setUserProperty(). The `$` spelling is canonical; the bare form
 * is accepted as an ingestion alias and promoted by the backend.
 */
private val EXPLICIT_IDENTITY_TRAIT_KEYS: Set<String> = buildSet {
    StandardProperty.entries
        .filter { it.pack == StandardProperty.Pack.IDENTITY }
        .forEach { property ->
            add(property.key)
            add(property.key.removePrefix("\$"))
        }
}

// ─── PII sanitizer for the enqueue path ───────────────────────────
//
// Critic BLOCKER Android-B1 (May 2026). Every customer-supplied
// `properties` map ships through here on its way to the wire. We
// walk the structure recursively, routing every `String` value AND
// every `String` key through [PiiFilter.DEFAULT.redact] so the wire
// payload never carries a raw email / phone / card / SSN / JWT / IBAN.
//
// Depth bound = [MAX_SANITIZE_DEPTH]. Past that we drop the value
// silently (rather than throwing) — host apps occasionally hand us
// cycle-bearing or pathologically-deep maps and crashing is a worse
// outcome than truncating the payload (AGENT_BRIEFING.md R6).
//
// The filter is [PiiFilter.DEFAULT] (no NER) for cost reasons — this
// path runs on every `track()` call from the host's hot UI thread,
// so we keep allocations bounded to the regex set and skip ML Kit.
// Replay-side captures (where richer NER coverage matters) keep
// their own NER-enabled filter wired separately in `Kixo.kt`.

// ─── Attribution-window decorate (the enqueue chokepoint) ──────────
//
// AC-5 / §3.3 fix (June 2026). `InstallAttributionStore.recordOpen` (deferred
// referrer + warm App-Link via `Kixo.handleDeepLink`) and
// `PushAttributionStore.recordOpen` (push_open) open a 30-min window; this is
// the SINGLE place every outbound event reads that window so it inherits
// `attribution_*`. Pre-fix both stores' `decorate(...)` had NO production
// caller — only their own unit tests — so the window opened but no event ever
// inherited it (the install-store half was the P0-spine equivalent of the
// already-unwired push-store pattern; this wires BOTH).
//
// Push decorates FIRST, then the install store's first-write-wins fills any
// remaining keys (they use disjoint key sets — `attribution_campaign_id` vs
// `attribution_campaign` — so they never fight; the only shared key is the
// diagnostic `attribution_age_ms`, where whichever window opened more recently
// — i.e. push, decorated first — wins, which is the correct last-touch age).
// Runs POST-sanitise so the routing ids bypass PII redaction. Both stores
// return the SAME reference on the closed-window no-op fast path, so an event
// outside any window pays only two cheap lock-guarded timestamp comparisons.
internal fun decorateAttribution(properties: JsonObject): JsonObject {
    val afterPush = io.kixo.sdk.internal.push.PushAttributionStore.decorate(properties)
    return io.kixo.sdk.internal.attribution.InstallAttributionStore.decorate(afterPush)
}

internal const val MAX_SANITIZE_DEPTH: Int = 6

/**
 * Top-level entry — sanitize an already-built `JsonObject` from a
 * pre-fingerprinted caller (TouchInterceptor / ScreenVisitRecorder /
 * etc) before it lands in [EventQueue.enqueueAsync]. Mirrors
 * [sanitizePropertiesForWire] but skips the `Map` → `JsonObject`
 * round-trip the public-API path needs. Critic Round 3 BLOCKER
 * Android-B1 (May 2026): without this the `enqueueEvent` chokepoint
 * stays a PII hole for `tap.target_text` and any other
 * pre-serialised pre-fingerprinted event.
 */
internal fun sanitizeJsonObjectForWire(properties: JsonObject): JsonObject {
    if (properties.isEmpty()) return properties
    return sanitizeJsonObject(properties, depth = 0)
}

/**
 * Top-level entry — sanitize the public-API property map. Always
 * returns a fresh `Map<String, Any?>` (never mutates the caller's
 * map; mutation would be observable from a `markGoal(...)`-style
 * caller that retains the props for re-use).
 */
internal fun sanitizePropertiesForWire(
    properties: Map<String, Any?>,
    trustedIdentityEvent: Boolean = false,
    callerTraitKeys: Set<String> = emptySet(),
): Map<String, Any?> {
    // Critic R2-H-N2 (May 2026): never return the caller's reference
    // even on the empty fast-path. `emptyMap()` is the Kotlin stdlib
    // singleton immutable map — safe to share, no allocation cost,
    // and ensures the sanitizer's contract ("always returns a fresh
    // map" — see KDoc above) holds uniformly.
    if (properties.isEmpty()) return emptyMap()
    if (trustedIdentityEvent) {
        val out = LinkedHashMap<String, Any?>(properties.size)
        for ((key, value) in properties) {
            // Finding #2/#3 (July 2026) — the CRM-email exemption is scoped
            // to the CALLER'S explicit per-call identity traits ONLY. A key
            // is passed raw ONLY when ALL three hold:
            //   (a) the caller supplied it in THIS identify()/setUserProperty()
            //       call — `callerTraitKeys`. A super-property, decoration, or
            //       any key merged into the event dict later is NOT trusted
            //       even if it is spelled like an identity field (bare "email"
            //       / "name" free text no longer bypasses redaction).
            //   (b) it is a recognised profile identity field
            //       (`EXPLICIT_IDENTITY_TRAIT_KEYS`).
            //   (c) its value is a scalar String/number/boolean. A nested
            //       Map/List/Array under $email/$name must NOT smuggle raw
            //       PII — it is recursively sanitized like any other value.
            if (key in callerTraitKeys &&
                key in EXPLICIT_IDENTITY_TRAIT_KEYS &&
                isRawExemptibleScalar(value)
            ) {
                out[key] = value
            } else {
                val cleanKey = PiiFilter.DEFAULT.redact(key)
                out[cleanKey] = sanitizeAny(value, depth = 1)
            }
        }
        return out
    }
    return sanitizeMap(properties, depth = 0)
}

/**
 * The CRM-identity wire exemption only passes a SCALAR value raw. A
 * `String`/`Number`/`Boolean` under a caller identity key is deliberate
 * profile data; anything structural (Map / List / Array / Json*) must
 * still be recursed through [sanitizeAny] so nested PII can never ride
 * an identity key onto the wire unredacted (finding #3, July 2026).
 */
private fun isRawExemptibleScalar(value: Any?): Boolean = when (value) {
    is String, is Number, is Boolean -> true
    else -> false
}

private fun sanitizeMap(map: Map<*, *>, depth: Int): Map<String, Any?> {
    if (depth >= MAX_SANITIZE_DEPTH) return emptyMap()
    val out = LinkedHashMap<String, Any?>(map.size)
    for ((k, v) in map) {
        val rawKey = k?.toString() ?: continue
        val cleanKey = PiiFilter.DEFAULT.redact(rawKey)
        out[cleanKey] = sanitizeAny(v, depth + 1)
    }
    return out
}

private fun sanitizeAny(value: Any?, depth: Int): Any? {
    if (depth >= MAX_SANITIZE_DEPTH) return null
    return when (value) {
        null -> null
        is String -> PiiFilter.DEFAULT.redact(value)
        // Critic R2-H-N1 (May 2026): when a caller hands us an already-
        // JSON-converted property map (e.g. `GoalMarker.mark` →
        // `Kixo.kt:GoalSink.enqueueGoal` passes a `JsonObject` whose
        // values are `JsonPrimitive` / `JsonObject` / `JsonArray`),
        // the raw `else -> value` branch let JsonPrimitive strings
        // through unsanitized. Walk the JsonElement tree explicitly:
        is JsonPrimitive -> sanitizeJsonPrimitive(value)
        is JsonObject -> sanitizeJsonObject(value, depth)
        is JsonArray -> sanitizeJsonArray(value, depth)
        is Map<*, *> -> sanitizeMap(value, depth)
        is List<*> -> value.map { sanitizeAny(it, depth + 1) }
        is Array<*> -> value.map { sanitizeAny(it, depth + 1) }
        // Numbers / Booleans / etc. PiiFilter doesn't apply — they're
        // not free-text customer input. Pass through unchanged.
        else -> value
    }
}

/**
 * Redact the textual `content` of a JSON string primitive. Numeric /
 * boolean / null primitives are returned as-is — they aren't
 * free-text customer input that could carry an email / phone /
 * card. We preserve the wrapping `JsonPrimitive` type so downstream
 * `JsonObject`/`JsonArray` reconstruction stays type-safe (the
 * enqueue path eventually re-serializes via `toJsonElement()`).
 */
private fun sanitizeJsonPrimitive(value: JsonPrimitive): JsonPrimitive {
    if (!value.isString) return value
    val content = value.contentOrNull ?: return value
    if (content.isEmpty()) return value
    val redacted = PiiFilter.DEFAULT.redact(content)
    return if (redacted == content) value else JsonPrimitive(redacted)
}

private fun sanitizeJsonObject(obj: JsonObject, depth: Int): JsonObject {
    if (depth >= MAX_SANITIZE_DEPTH) return JsonObject(emptyMap())
    val out = LinkedHashMap<String, JsonElement>(obj.size)
    for ((k, v) in obj) {
        val cleanKey = PiiFilter.DEFAULT.redact(k)
        out[cleanKey] = sanitizeJsonElement(v, depth + 1)
    }
    return JsonObject(out)
}

private fun sanitizeJsonArray(arr: JsonArray, depth: Int): JsonArray {
    if (depth >= MAX_SANITIZE_DEPTH) return JsonArray(emptyList())
    return JsonArray(arr.map { sanitizeJsonElement(it, depth + 1) })
}

private fun sanitizeJsonElement(value: JsonElement, depth: Int): JsonElement {
    if (depth >= MAX_SANITIZE_DEPTH) return JsonNull
    return when (value) {
        is JsonPrimitive -> sanitizeJsonPrimitive(value)
        is JsonObject -> sanitizeJsonObject(value, depth)
        is JsonArray -> sanitizeJsonArray(value, depth)
    }
}
