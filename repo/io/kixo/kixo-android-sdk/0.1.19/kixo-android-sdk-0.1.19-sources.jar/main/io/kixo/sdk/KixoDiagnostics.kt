package io.kixo.sdk

/**
 * Read-only health snapshot of the running SDK. Surfaces enough
 * state for a host engineer to answer "why aren't my events
 * reaching the dashboard?" without a debugger:
 *
 *   - Buffer size (events not yet flushed)
 *   - Whether we're in retry / cooldown
 *   - Server-side `paused` kill-switch state
 *   - Lifecycle state (initialising / running / recovering / paused)
 *   - Whether the SDK was even initialised
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Diagnostics.swift`. Returned
 * by [Kixo.diagnostics] — host apps dump it onto a debug screen or
 * to their own crash reporter to triage SDK-flow issues without
 * running Kixo under a debugger.
 *
 * The data class is intentionally a value type; all properties are
 * stable, JSON-friendly types so a host can serialise the snapshot
 * to their own crash-reporter / log aggregation without us caring
 * about lifetime.
 */
public data class KixoDiagnostics(
    /**
     * Top-level "is the SDK alive" flag. False when [Kixo.configure]
     * was never called or threw mid-init.
     */
    val initialised: Boolean,

    /**
     * Server-controlled kill-switch from `/api/sdk/init`. `true`
     * means events are being dropped at enqueue time. Equivalent to
     * `lifecycleState == "pausedByServer"` — kept as a separate
     * boolean for parity with the iOS API and ease of one-line
     * debug-screen rendering.
     */
    val paused: Boolean,

    /**
     * Resolved environment (`"development"` / `"production"`).
     * Empty string when [initialised] is false.
     */
    val environment: String,

    /**
     * Resolved API host the SDK is targeting. Empty string when
     * [initialised] is false. Matches the host the next batch will
     * POST to (`<apiHost>/api/sdk/batch`).
     */
    val apiHost: String,

    /**
     * Current SDK lifecycle state — one of `"initialising"`,
     * `"running"`, `"recovering"`, `"pausedByServer"`. Strings
     * (rather than an enum) so callers can deserialise the snapshot
     * from JSON without holding the enum type at compile time.
     *
     * State machine docs live next to [Kixo]'s internal lifecycle
     * field. The transitions are:
     *
     *   - **initialising** — SDK constructed; `/api/sdk/init` not yet
     *     resolved. Events buffer to the queue but flush is gated.
     *   - **running** — normal operation; queue flushing on cadence.
     *   - **recovering** — too many consecutive batch failures;
     *     pivoted to re-fetching `/api/sdk/init` to learn whether to
     *     resume, stay paused, or keep retrying.
     *   - **pausedByServer** — server returned `paused: true`.
     *     Events drop at the enqueue gate (NOT buffered) until the
     *     next config refresh returns active again.
     */
    val lifecycleState: String,

    /**
     * Wall-clock millis (epoch) of the most recent successful flush,
     * or `null` if no batch has been accepted by the server yet.
     * Useful for "time since events last reached the backend" UIs.
     */
    val lastFlushAtMillis: Long?,

    /**
     * Last error string from the transport layer, or `null` if no
     * failure has occurred. Capped at ~256 chars by the queue (so a
     * stack trace doesn't bloat this snapshot). Diagnostic only —
     * the SDK does NOT surface this to end-users.
     */
    val lastError: String?,

    /** Current event-queue health. */
    val queue: QueueHealth,

    /**
     * SDK self-test routing flag, internal use only.
     */
    val internalDevForced: Boolean = false,

    /** Exact effective mirror of the dashboard replay control plane. */
    val replay: ReplayHealth = ReplayHealth(),

    /**
     * Play Install Referrer read-state machine status — one of `"UNREAD"`,
     * `"READ_OK_POST_PENDING"`, `"DONE"`. Lets the smoke test / a host debug
     * screen assert the deterministic-attribution read happened exactly once.
     * `"UNREAD"` when the referrer subsystem is disabled, paused, or unavailable.
     */
    val installReferrerState: String = "UNREAD",

    /**
     * `true` when the referrer POST permanently failed (a 4xx, or 5xx retries
     * exhausted) so the deterministic install was read but never recorded
     * server-side. Diagnostic only — surfaces a wiring/auth problem.
     */
    val referrerPostFailed: Boolean = false,

    /**
     * The last deterministic install-validation status (KIX-MMP-FRAUD-01):
     * `not_run` / `disabled` / `collection_paused` / `unavailable` (Play Integrity API
     * absent) / `validated` / `replayed` / `invalid_sig` / `wrong_bundle` /
     * `absent` / `error`. `validated` proves the install is REAL
     * (anti-replay / anti-spoof), NOT the attribution source.
     */
    val installValidationStatus: String = "not_run",

    /**
     * Android Privacy Sandbox ARA (KIX-MMP-ARA-01) enable flag — mirrors
     * [KixoConfiguration.araEnabled]. `false` when the host disabled ARA
     * registration. Default `false` (uninitialised snapshot).
     */
    val araEnabled: Boolean = false,

    /**
     * `true` when the on-device AdServices `MeasurementManager` runtime is
     * present so ARA source/trigger registration can actually run. `false` on
     * older devices / devices without the Privacy-Sandbox SDK extension (ARA
     * silently no-ops there). Resolved on the first registration attempt; `false`
     * until then. Lets the smoke test / a host debug screen assert the honest
     * platform ceiling (ARA is an opportunistic fallback, not a guarantee).
     */
    val araAvailable: Boolean = false,
) {
    /**
     * Health of the SQLite + in-memory event queue. Mirrors iOS
     * `KixoDiagnostics.QueueHealth`.
     */
    public data class QueueHealth(
        /**
         * Events currently buffered (in-memory + SQLite combined)
         * waiting to flush.
         */
        val bufferedEventCount: Int,

        /**
         * Max events the queue holds before FIFO-dropping the
         * oldest. Default 200, overridable via
         * [KixoConfiguration.Builder.maxBufferSize].
         */
        val bufferCap: Int,

        /**
         * Consecutive flush failures since the last 2xx response.
         * Resets to 0 on success.
         */
        val consecutiveFailures: Int,

        /** True while a flush is in flight (single-flight gate). */
        val isFlushing: Boolean,

        /**
         * Which retry tier the state machine is in:
         *
         *   - `"healthy"` — no failures, normal flushInterval cadence
         *   - `"rapid"`   — failures 1–10, exponential backoff (5–60s)
         *   - `"slow"`    — failures 11–29, 60-second heartbeat
         *   - `"cooldown"`— failures 30+, 30-minute heartbeat (also
         *     triggers the lifecycle pivot to `"recovering"`)
         */
        val retryTier: String,
    )

    public data class ReplayHealth(
        val projectResolved: Boolean = false,
        val enabled: Boolean = false,
        val active: Boolean = false,
        /** Canonical wire unit (0..100 percent). */
        val sampleRate: Double = 0.0,
        val maskInputs: Boolean = true,
        val captureOnCellular: Boolean = false,
        val maxDurationSec: Double = 300.0,
        val frameCaptureEnabled: Boolean = true,
        val structuralEnabled: Boolean = false,
        /** Decoded for cross-platform parity; Android has no tile pipeline. */
        val tileCaptureEnabled: Boolean = false,
        val ocrEnabled: Boolean = false,
        val captureMinIntervalMs: Double = 800.0,
        val scrollEndMinIntervalSec: Double = 0.5,
        val scrollEndCaptureEnabled: Boolean = false,
        val postTapSettleMs: Double = 500.0,
        val dirtyHeartbeatSec: Double = 5.0,
        val heicQuality: Double = 0.15,
        val captureScale: Double = 0.85,
    )

    public companion object {
        /**
         * "Disabled" diagnostics returned when [Kixo.configure] was
         * never called — keeps the API non-throwing without forcing
         * the host to handle nullables.
         */
        @JvmField
        public val Uninitialised: KixoDiagnostics = KixoDiagnostics(
            initialised = false,
            paused = false,
            environment = "",
            apiHost = "",
            lifecycleState = "uninitialised",
            lastFlushAtMillis = null,
            lastError = null,
            queue = QueueHealth(
                bufferedEventCount = 0,
                bufferCap = 0,
                consecutiveFailures = 0,
                isFlushing = false,
                retryTier = "healthy",
            ),
        )
    }
}
