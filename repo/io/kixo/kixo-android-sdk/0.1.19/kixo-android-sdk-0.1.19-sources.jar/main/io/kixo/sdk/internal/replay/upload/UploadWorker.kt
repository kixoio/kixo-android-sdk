package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import io.kixo.sdk.internal.replay.ReplayRuntimePolicy
import java.io.File
import java.io.IOException
import java.time.Instant

/**
 * WorkManager-backed PUT of a previously-staged frame to a fresh,
 * server-authorised GCS URL. Reading inputs from [WorkerParameters.inputData]:
 *
 *  - `local_file_path` — absolute path to the staging file written
 *    by [JpegEncoder.writeToFile] (or [StructuralEncoder] then
 *    written via the same path).
 *  - project/session/install/seq/kind metadata needed to obtain an exact lease
 *    from `/replay/frames/sign` immediately before every PUT. A persisted batch
 *    lease is integrity-checked but never substitutes for this remote authority:
 *    replay may have been disabled after that lease was issued.
 *
 * **Why WorkManager (vs raw OkHttp from a coroutine):**
 *  - **Survives process death.** Android can kill our process
 *    seconds after the user backgrounds the app — coroutines die
 *    with it. WorkManager persists the work request via SQLite,
 *    and re-enqueues when the process restarts. iOS achieves the
 *    same via background URLSession; WorkManager is the canonical
 *    Android equivalent.
 *  - **System-managed backoff.** WorkManager's
 *    `BackoffPolicy.EXPONENTIAL` handles transient failures with
 *    OS-native scheduling — it cooperates with Doze, App Standby,
 *    and battery savers, none of which our own retry loop would
 *    respect.
 *  - **Network constraints.** [androidx.work.Constraints] gates
 *    execution on `NetworkType.CONNECTED` (or `.UNMETERED` when
 *    the customer disabled cellular replay) — we don't burn the
 *    user's data plan when wifi-only is configured.
 *
 * **Returning Result:**
 *  - 2xx → [Result.success]; the staging file is deleted (the
 *    only copy of the frame, no longer needed).
 *  - 4xx (except 429) → [Result.failure]; the upload is
 *    permanently dropped. The signed URL is dead — retrying would
 *    only hit the same 4xx. The raw staging file is deleted; screen
 *    pixels are never retained in an unbounded forensic directory.
 *  - 429 / 5xx / network → [Result.retry]; WorkManager applies its
 *    own backoff schedule.
 *
 * **Anti-crash:** every failure path swallows + logs (R6). A
 * worker exception would propagate to WorkManager's status as
 * `FAILED` — not a host crash — but we still prefer a clean
 * Result.failure return so the dashboard's worker-status badge
 * is meaningful.
 *
 * **OkHttpClient injection:** the worker is constructed by
 * WorkManager's reflective factory, so we can't pass dependencies
 * at construction. We pull the shared client from
 * [UploadWorkerSingletons.httpClient] which the SDK's bootstrap
 * pre-populates. Tests override it via the same hook.
 */
internal class UploadWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        val localPath = inputData.getString(KEY_LOCAL_FILE_PATH)
        val replayPolicyToken = inputData.getString(KEY_REPLAY_POLICY_TOKEN)

        if (localPath.isNullOrBlank()) {
            // Permanent failure — caller built the work request wrong.
            // No retry will ever fix missing inputs; log so the bug is
            // visible in dev.
            Log.w(TAG, "Missing local_file_path — failing")
            return androidx.work.ListenableWorker.Result.failure()
        }

        val file = File(localPath)
        if (!file.exists() || file.length() == 0L) {
            // The staging file vanished between scheduling and
            // execution — likely because the cache was cleared. Not
            // a retryable condition.
            Log.w(TAG, "Staging file missing or empty: $localPath")
            ReplayPendingUploadStore.delete(file)
            ReplayUploadCompletionRegistry.notifyTerminal(file.absolutePath)
            return androidx.work.ListenableWorker.Result.failure()
        }

        // Re-check the LIVE project policy at the last boundary before
        // opening a socket. WorkManager constraints are immutable: a frame
        // queued while cellular was allowed could otherwise upload after the
        // dashboard flipped to Wi-Fi-only. The generation token also makes an
        // old identity/project worker terminal after reset or policy rotation.
        val network = currentNetworkState()
        when (
            ReplayRuntimePolicy.workerDecision(
                token = replayPolicyToken,
                connected = network.connected,
                metered = network.metered,
            )
        ) {
            ReplayRuntimePolicy.WorkerDecision.DISCARD -> {
                return terminalFailure(file)
            }
            ReplayRuntimePolicy.WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY -> {
                return androidx.work.ListenableWorker.Result.retry()
            }
            ReplayRuntimePolicy.WorkerDecision.UPLOAD -> Unit
        }

        val client = UploadWorkerSingletons.httpClient
            ?: run {
                // SDK isn't initialised in this process — pre-warm
                // failure. Retry on the off chance the host process
                // re-inits before WorkManager retries us.
                Log.w(TAG, "HttpClient unavailable; retrying")
                return androidx.work.ListenableWorker.Result.retry()
            }

        val kind = inputData.getString(KEY_FRAME_KIND)?.let(FrameKind::fromWire)
        val signInput = ReplayFrameSigner.Input(
            baseUrl = inputData.getString(KEY_API_BASE_URL).orEmpty(),
            projectId = inputData.getString(KEY_PROJECT_ID).orEmpty(),
            apiKey = inputData.getString(KEY_API_KEY).orEmpty(),
            sessionId = inputData.getString(KEY_SESSION_ID).orEmpty(),
            installationId = inputData.getString(KEY_INSTALLATION_ID).orEmpty(),
            seq = inputData.getLong(KEY_FRAME_SEQ, -1L),
            kind = kind ?: run {
                return terminalFailure(file)
            },
            expectedGcsPath = inputData.getString(KEY_EXPECTED_GCS_PATH).orEmpty(),
            policyToken = replayPolicyToken.orEmpty(),
        )
        // The original URL may have expired while WorkManager waited for Wi-Fi,
        // but its immutable frame binding must still validate before re-signing.
        val persistedLease = cachedLease(inputData, requireFresh = false)
            ?: return terminalFailure(file)
        val authority = authorizeLeaseForPut(persistedLease) {
            val signingNetwork = currentNetworkState()
            ReplayFrameSignCoordinator.shared.sign(
                client = client,
                input = signInput,
                connected = signingNetwork.connected,
                metered = signingNetwork.metered,
            )
        }
        val freshLease = when (authority) {
            is ReplayFrameSigner.Outcome.Fresh -> authority.lease
            is ReplayFrameSigner.Outcome.PolicyRejected -> {
                return resultForPolicyDecision(authority.decision, file)
            }
            ReplayFrameSigner.Outcome.Retry ->
                return androidx.work.ListenableWorker.Result.retry()
            ReplayFrameSigner.Outcome.PermanentFailure,
            ReplayFrameSigner.Outcome.RemotePaused,
            -> return terminalFailure(file)
        }
        if (!leaseMatchesExpectedFrame(
                lease = freshLease,
                expectedSeq = signInput.seq,
                expectedKind = signInput.kind,
                expectedGcsPath = signInput.expectedGcsPath,
            )
        ) {
            return terminalFailure(file)
        }
        val contentType = freshLease.contentType ?: signInput.kind.contentType
        val maxBytes = freshLease.maxBytes ?: DEFAULT_MAX_BYTES
        if (contentType != signInput.kind.contentType ||
            maxBytes <= 0L ||
            file.length() > maxBytes
        ) {
            return terminalFailure(file)
        }

        return when (
            val outcome = putFile(
                client = client,
                signedUrl = freshLease.url,
                file = file,
                contentType = contentType,
                maxBytes = maxBytes,
                replayPolicyToken = replayPolicyToken,
            )
        ) {
            is PutOutcome.Success -> {
                // Frame landed safely; staging file no longer needed.
                if (!discardPermanentlyRejectedFile(file)) {
                    Log.d(TAG, "Couldn't delete staging file: $localPath")
                }
                ReplayPendingUploadStore.delete(file)
                ReplayUploadCompletionRegistry.notifyTerminal(file.absolutePath)
                androidx.work.ListenableWorker.Result.success()
            }
            is PutOutcome.PermanentFailure -> {
                // A rejected frame is raw customer screen data. Never retain
                // it in a global forensic directory after a permanent 4xx.
                terminalFailure(file)
            }
            is PutOutcome.PolicyRejected -> resultForPolicyDecision(outcome.decision, file)
            is PutOutcome.TransientFailure -> {
                // 429/5xx/network — let WorkManager back off.
                Log.d(TAG, "Transient failure (${outcome.reason}); retrying via WorkManager")
                androidx.work.ListenableWorker.Result.retry()
            }
        }
    }

    private suspend fun putFile(
        client: OkHttpClient,
        signedUrl: String,
        file: File,
        contentType: String,
        maxBytes: Long,
        replayPolicyToken: String?,
    ): PutOutcome = withContext(Dispatchers.IO) {
        val req = runCatching {
            val body = file.asRequestBody(contentType.toMediaType())
            Request.Builder()
                .url(signedUrl)
                .put(body)
                .header("Content-Type", contentType)
            // GCS V4 signed URLs require x-goog-content-length-range
            // to match the value the signer placed in extension
            // headers — bit-for-bit. Wave 9 plumbs the cap from the
            // sign-route response via [KEY_MAX_BYTES] so a future
            // server-side bump (e.g. allow larger structural
            // sidecars) doesn't require a coordinated SDK release.
            // Mismatched strings — even by ONE byte — break the V4
            // signature and produce 403.
                .header(HEADER_GCS_RANGE, "0,$maxBytes")
                .build()
        }.getOrElse {
            return@withContext PutOutcome.PermanentFailure(400)
        }

        // Signing and PUT are separate sockets. Network transport may have
        // changed between them, so re-read it at this final egress boundary.
        val network = currentNetworkState()
        val guarded = try {
            ReplayRuntimePolicy.executeWorkerCall(
                token = replayPolicyToken,
                connected = network.connected,
                metered = network.metered,
                call = client.newCall(req),
            )
        } catch (e: IOException) {
            return@withContext PutOutcome.TransientFailure("IOException: ${e.message}")
        } catch (t: Throwable) {
            return@withContext PutOutcome.TransientFailure("unexpected: ${t.message}")
        }
        if (guarded is ReplayRuntimePolicy.WorkerCallResult.Rejected) {
            return@withContext PutOutcome.PolicyRejected(guarded.decision)
        }
        val response = (guarded as ReplayRuntimePolicy.WorkerCallResult.Executed).response

        response.use { resp ->
            val code = resp.code
            when {
                code in 200..299 -> PutOutcome.Success
                code == 429 || code in 500..599 -> PutOutcome.TransientFailure("HTTP $code")
                code in 400..499 -> PutOutcome.PermanentFailure(code)
                else -> PutOutcome.TransientFailure("unexpected HTTP $code")
            }
        }
    }

    private data class CurrentNetwork(val connected: Boolean, val metered: Boolean)

    private fun resultForPolicyDecision(
        decision: ReplayRuntimePolicy.WorkerDecision,
        file: File,
    ): androidx.work.ListenableWorker.Result = when (decision) {
        ReplayRuntimePolicy.WorkerDecision.DISCARD -> terminalFailure(file)
        ReplayRuntimePolicy.WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY,
        ReplayRuntimePolicy.WorkerDecision.UPLOAD,
        -> androidx.work.ListenableWorker.Result.retry()
    }

    private fun terminalFailure(file: File): androidx.work.ListenableWorker.Result {
        discardPermanentlyRejectedFile(file)
        ReplayPendingUploadStore.delete(file)
        ReplayUploadCompletionRegistry.notifyTerminal(file.absolutePath)
        return androidx.work.ListenableWorker.Result.failure()
    }

    private fun currentNetworkState(): CurrentNetwork = try {
        val manager = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE)
            as? ConnectivityManager
            ?: return CurrentNetwork(connected = false, metered = true)
        val network = manager.activeNetwork
            ?: return CurrentNetwork(connected = false, metered = true)
        val capabilities = manager.getNetworkCapabilities(network)
            ?: return CurrentNetwork(connected = false, metered = true)
        CurrentNetwork(
            connected = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
            metered = !capabilities.hasCapability(
                NetworkCapabilities.NET_CAPABILITY_NOT_METERED,
            ),
        )
    } catch (_: Throwable) {
        // Unknown network state never means permission to use cellular.
        CurrentNetwork(connected = false, metered = true)
    }

    private sealed interface PutOutcome {
        data object Success : PutOutcome
        data class PermanentFailure(val code: Int) : PutOutcome
        data class TransientFailure(val reason: String) : PutOutcome
        data class PolicyRejected(
            val decision: ReplayRuntimePolicy.WorkerDecision,
        ) : PutOutcome
    }

    companion object {
        /**
         * Persisted batch-lease binding. It must validate before any network
         * request, but the URL itself is never used for PUT: every worker still
         * obtains fresh remote authority through the bounded coordinator.
         */
        const val KEY_SIGNED_URL = "signed_url"
        const val KEY_SIGNED_URL_EXPIRES_AT = "signed_url_expires_at"
        const val KEY_LEASE_FRAME_SEQ = "lease_frame_seq"
        const val KEY_LEASE_FRAME_KIND = "lease_frame_kind"
        const val KEY_LEASE_GCS_PATH = "lease_gcs_path"
        const val KEY_LEASE_CONTENT_TYPE = "lease_content_type"
        const val KEY_LEASE_MAX_BYTES = "lease_max_bytes"
        const val KEY_LOCAL_FILE_PATH = "local_file_path"
        const val KEY_CONTENT_TYPE = "content_type"

        /**
         * Wave 9 — per-call cap echoed back from the sign route.
         * Stored as a `Long` (Data only supports a fixed set of
         * primitives — no Int width games). Defaults to
         * [DEFAULT_MAX_BYTES] when missing.
         */
        const val KEY_MAX_BYTES = "max_bytes"

        const val KEY_API_BASE_URL = "api_base_url"
        const val KEY_PROJECT_ID = "project_id"
        const val KEY_API_KEY = "api_key"
        const val KEY_SESSION_ID = "session_id"
        const val KEY_INSTALLATION_ID = "installation_id"
        const val KEY_FRAME_SEQ = "frame_seq"
        const val KEY_FRAME_KIND = "frame_kind"
        const val KEY_EXPECTED_GCS_PATH = "expected_gcs_path"

        /** Project+identity-scoped live replay-policy generation token. */
        const val KEY_REPLAY_POLICY_TOKEN = "replay_policy_token"

        private const val HEADER_GCS_RANGE = "x-goog-content-length-range"
        private const val LEASE_SAFETY_WINDOW_SECONDS = 60L

        /**
         * Fallback cap when [KEY_MAX_BYTES] isn't in inputData
         * (rare — stale work enqueued by an older ReplayUploader
         * surviving an SDK upgrade). 20 KB is the canonical
         * replay-frame cap across all platforms (iOS, Android,
         * web) — see backend `REPLAY_FRAME_MAX_BYTES` constant in
         * `apps/web/src/app/api/sdk/replay/session/start/route.ts`.
         */
        private const val DEFAULT_MAX_BYTES: Long = 20_000L

        internal fun cachedLease(
            data: androidx.work.Data,
            now: Instant = Instant.now(),
            requireFresh: Boolean = true,
        ): SignedUrlClient.SignedUrl? {
            val url = data.getString(KEY_SIGNED_URL)
                ?.takeIf { it.toHttpUrlOrNull()?.isHttps == true }
                ?: return null
            val expiresAt = data.getString(KEY_SIGNED_URL_EXPIRES_AT) ?: return null
            val expiry = runCatching { Instant.parse(expiresAt) }.getOrNull() ?: return null
            if (requireFresh &&
                !expiry.isAfter(now.plusSeconds(LEASE_SAFETY_WINDOW_SECONDS))
            ) {
                return null
            }
            val expectedSeq = data.getLong(KEY_FRAME_SEQ, -1L)
            val expectedKind =
                data.getString(KEY_FRAME_KIND)?.let(FrameKind::fromWire) ?: return null
            val expectedGcsPath =
                data.getString(KEY_EXPECTED_GCS_PATH)?.takeIf { it.isNotBlank() }
                ?: return null
            val expectedContentType =
                data.getString(KEY_CONTENT_TYPE)?.takeIf { it.isNotBlank() } ?: return null
            val expectedMaxBytes = data.getLong(KEY_MAX_BYTES, -1L)
            val leaseSeq = data.getLong(KEY_LEASE_FRAME_SEQ, -1L)
            val leaseKind = data.getString(KEY_LEASE_FRAME_KIND) ?: return null
            val leaseGcsPath =
                data.getString(KEY_LEASE_GCS_PATH)?.takeIf { it.isNotBlank() } ?: return null
            val leaseContentType =
                data.getString(KEY_LEASE_CONTENT_TYPE)?.takeIf { it.isNotBlank() } ?: return null
            val leaseMaxBytes = data.getLong(KEY_LEASE_MAX_BYTES, -1L)
            if (expectedSeq < 0L ||
                expectedContentType != expectedKind.contentType ||
                expectedMaxBytes <= 0L ||
                leaseSeq != expectedSeq ||
                leaseKind != expectedKind.wire ||
                leaseGcsPath != expectedGcsPath ||
                leaseContentType != expectedContentType ||
                leaseMaxBytes != expectedMaxBytes
            ) {
                return null
            }
            val lease = SignedUrlClient.SignedUrl(
                seq = leaseSeq,
                kind = leaseKind,
                url = url,
                expiresAt = expiresAt,
                gcsPath = leaseGcsPath,
                contentType = leaseContentType,
                maxBytes = leaseMaxBytes,
            )
            return lease.takeIf {
                leaseBindingMatchesExpectedFrame(
                    lease = it,
                    expectedSeq = expectedSeq,
                    expectedKind = expectedKind,
                    expectedGcsPath = expectedGcsPath,
                )
            }
        }

        /**
         * A cached lease proves only what the server authorised when it was
         * minted. Always ask the server again before uploading so a later
         * project pause/replay disable can veto the GCS PUT. [persistedLease] is
         * intentionally not returned; accepting it here would recreate the
         * remote-disable bypass this boundary exists to prevent.
         */
        internal suspend fun authorizeLeaseForPut(
            persistedLease: SignedUrlClient.SignedUrl?,
            requestFreshAuthority: suspend () -> ReplayFrameSigner.Outcome,
        ): ReplayFrameSigner.Outcome =
            if (persistedLease == null) {
                ReplayFrameSigner.Outcome.PermanentFailure
            } else {
                requestFreshAuthority()
            }

        internal fun leaseMatchesExpectedFrame(
            lease: SignedUrlClient.SignedUrl,
            expectedSeq: Long,
            expectedKind: FrameKind,
            expectedGcsPath: String,
        ): Boolean {
            if (!leaseBindingMatchesExpectedFrame(
                    lease = lease,
                    expectedSeq = expectedSeq,
                    expectedKind = expectedKind,
                    expectedGcsPath = expectedGcsPath,
                )
            ) {
                return false
            }
            val parsed = lease.url.toHttpUrlOrNull()?.takeIf {
                it.isHttps && it.port == 443 && it.username.isEmpty() &&
                    it.password.isEmpty() && it.fragment == null
            } ?: return false
            val expectedObject = parseCanonicalGcsPath(expectedGcsPath) ?: return false
            val encodedPath = parsed.encodedPath.removePrefix("/")
            val pathStyleObject = "${expectedObject.bucket}/${expectedObject.objectName}"
            val virtualHostedBucket = parsed.host.removeSuffix(GCS_VIRTUAL_HOST_SUFFIX)
            // The current backend signs only the documented global XML
            // endpoints. Regional endpoints are intentionally fail-closed
            // until the backend starts producing and testing them.
            return when {
                parsed.host == GCS_PATH_STYLE_HOST -> encodedPath == pathStyleObject
                parsed.host.endsWith(GCS_VIRTUAL_HOST_SUFFIX) ->
                    virtualHostedBucket == expectedObject.bucket &&
                        encodedPath == expectedObject.objectName
                else -> false
            }
        }

        private fun leaseBindingMatchesExpectedFrame(
            lease: SignedUrlClient.SignedUrl,
            expectedSeq: Long,
            expectedKind: FrameKind,
            expectedGcsPath: String,
        ): Boolean =
            expectedSeq >= 0L &&
                expectedGcsPath.isNotBlank() &&
                parseCanonicalGcsPath(expectedGcsPath) != null &&
                lease.seq == expectedSeq &&
                lease.kind == expectedKind.wire &&
                lease.gcsPath == expectedGcsPath &&
                lease.contentType?.let { it == expectedKind.contentType } != false &&
                lease.maxBytes?.let { it > 0L } != false

        private data class GcsObject(
            val bucket: String,
            val objectName: String,
        )

        /**
         * Replay object keys are backend-generated ASCII paths. Parse that
         * frozen contract without URI decoding: `%2F` must never collapse into
         * `/` and bind a signed URL for a different object.
         */
        private fun parseCanonicalGcsPath(value: String): GcsObject? {
            if (!value.startsWith(GCS_SCHEME_PREFIX) || value.length > MAX_GCS_PATH_LENGTH) {
                return null
            }
            val remainder = value.removePrefix(GCS_SCHEME_PREFIX)
            val separator = remainder.indexOf('/')
            if (separator <= 0 || separator == remainder.lastIndex) return null
            val bucket = remainder.substring(0, separator)
            val objectName = remainder.substring(separator + 1)
            if (!GCS_BUCKET.matches(bucket) || !GCS_OBJECT.matches(objectName) ||
                objectName.split('/').any { it.isBlank() || it == "." || it == ".." }
            ) {
                return null
            }
            return GcsObject(bucket, objectName)
        }

        /** Permanent upload failures must not create an unbounded raw cache. */
        internal fun discardPermanentlyRejectedFile(file: File): Boolean = runCatching {
            if (!file.exists() || file.delete()) {
                true
            } else {
                // If the directory entry cannot be removed, truncate it so no
                // customer pixels remain. A later cache sweep can remove the
                // now-empty file safely.
                file.outputStream().use { }
                file.delete()
                !file.exists() || file.length() == 0L
            }
        }.getOrDefault(false)

        private const val TAG = "Kixo.UploadWorker"
        private const val GCS_SCHEME_PREFIX = "gs://"
        private const val GCS_PATH_STYLE_HOST = "storage.googleapis.com"
        private const val GCS_VIRTUAL_HOST_SUFFIX = ".storage.googleapis.com"
        private const val MAX_GCS_PATH_LENGTH = 1_024
        private val GCS_BUCKET = Regex("[a-z0-9][a-z0-9._-]{1,61}[a-z0-9]")
        private val GCS_OBJECT = Regex("[A-Za-z0-9._/-]+")
    }
}

/**
 * WorkManager constructs workers via reflection so we can't inject
 * dependencies through the constructor. The SDK's bootstrap
 * (Agent 7) pokes the shared OkHttp client into this object once
 * per process; the worker reads it on `doWork`.
 *
 * **Why an `object` not a [androidx.work.WorkerFactory]:** a
 * custom factory requires the host app to wire it into their
 * WorkManager.initialize call. We don't want to require ANY host
 * setup beyond `Kixo.configure(...)`. The trade-off is that the
 * dependency lookup is "implicit" — but it's documented here +
 * tests can override.
 */
internal object UploadWorkerSingletons {
    @Volatile var httpClient: OkHttpClient? = null
}
