package io.kixo.sdk.internal.attribution.ara

import android.content.Context
import android.net.Uri
import android.util.Log
import android.view.InputEvent
import io.kixo.sdk.internal.transport.Endpoints
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Android Privacy Sandbox **Attribution Reporting API (ARA)** controller —
 * KIX-MMP-ARA-01, Phase A. The Android-only PARALLEL to SKAN: a redirect-
 * registered click → `registerSource`, install/first-open → `registerTrigger`,
 * and (Phase C, on-device) the OS delivers an event-level report to Kixo's
 * collection endpoint.
 *
 * ### Why reflection / feature-detection
 * `android.adservices.measurement.MeasurementManager` only exists on devices
 * carrying a recent **AdServices extension version** (SDK extension on top of
 * minSdk=24). The SDK MUST NOT crash `configure()` on a device without the
 * runtime, so the API is reached purely via reflection (mirrors
 * [io.kixo.sdk.internal.attribution.InstallValidator]'s Play-Integrity guard).
 * When the class isn't present we record [araAvailable] = false and no-op —
 * never an exception out of [registerSource] / [registerTrigger].
 *
 * ### Safety invariants (mirror InstallReferrerController / InstallValidator)
 *   - **Non-blocking:** registration runs on the injected [executor] (the SDK's
 *     background scope) — never the main thread.
 *   - **Bounded retry:** a transient registration failure retries up to
 *     [MAX_REGISTER_ATTEMPTS]; past that it's a logged no-op (no infinite loop).
 *   - **Server policy:** while collection is paused NOTHING is registered
 *     (the live decision is checked before scheduling and again on the worker).
 *   - **Routing:** the URIs are built from the SDK's resolved [baseUrl].
 *   - **No PII:** the only correlation key on the source URI is the
 *     `kixo_click_id` (an opaque minted id) + the link slug — never an advertising
 *     id (the OS owns the device-graph; we only register the source/trigger).
 *
 * Phase A is build + unit-tested; real on-device delivery additionally needs
 * Privacy-Sandbox ENROLLMENT (Phase C) — an async follow-up.
 */
internal class AraController(
    private val context: Context,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val executor: (Runnable) -> Unit,
    private val isCollectionDenied: () -> Boolean,
    /**
     * Final linearized admission around the reflective OS invocation. This keeps
     * the call on one side of an identity reset.
     */
    private val collectionCommit: ((() -> Boolean) -> Boolean?) = { operation ->
        if (isCollectionDenied()) null else operation()
    },
    private val debug: Boolean,
    /** Injectable availability probe (tests substitute a fake). Default = real
     *  reflection feature-detect of the AdServices MeasurementManager. */
    private val availabilityProbe: (Context) -> Boolean = ::detectMeasurementManager,
    /** Injectable source-registration sink (tests capture the URI + click id).
     *  Default = the real reflective `MeasurementManager.registerSource`. */
    private val registerSourceFn: (Context, Uri, InputEvent?) -> Boolean =
        ::reflectRegisterSource,
    /** Injectable trigger-registration sink. Default = reflective
     *  `MeasurementManager.registerTrigger`. */
    private val registerTriggerFn: (Context, Uri) -> Boolean = ::reflectRegisterTrigger,
) {
    /** Availability is resolved lazily once, on the first registration attempt. */
    private val availabilityChecked = AtomicBoolean(false)
    private val availableRef = AtomicBoolean(false)

    /** Whether ARA is usable on this device (AdServices runtime present). Read by
     *  [io.kixo.sdk.KixoDiagnostics]. Resolved on first use; false until then. */
    val araAvailable: Boolean get() = availableRef.get()

    private fun ensureAvailability(): Boolean {
        if (availabilityChecked.compareAndSet(false, true)) {
            availableRef.set(
                try {
                    availabilityProbe(context)
                } catch (_: Throwable) {
                    false
                },
            )
            if (debug && !availableRef.get()) {
                Log.d(TAG, "AdServices MeasurementManager unavailable — ARA no-op (fail-open).")
            }
        }
        return availableRef.get()
    }

    /**
     * Register a SOURCE for a Kixo deep-link click/handoff. Carries the
     * `kixo_click_id` (+ optional link `slug`) on the URI so the backend can
     * resolve the Link → project/app destination in the Register-Source header.
     *
     * No-op when collection is denied OR the AdServices runtime is absent.
     * Bounded-retry on a transient registration failure. Never throws.
     *
     * @param clickId the minted kixo_click_id carried by the click.
     * @param slug    the link slug (resolves the Link → android destination).
     * @param host    the public branded host that scopes [slug].
     * @param inputEvent the click's [InputEvent] (a navigation source needs one;
     *                   null falls back to an event source).
     */
    fun registerSource(
        clickId: String,
        slug: String?,
        host: String? = null,
        inputEvent: InputEvent?,
    ) {
        if (isCollectionDenied()) return
        if (clickId.isBlank() && slug.isNullOrBlank()) return
        val task = Runnable {
            try {
                if (!isCollectionDenied() && ensureAvailability()) {
                    val uri = buildSourceUri(clickId, slug, host)
                    withBoundedRetry("registerSource") {
                        registerSourceFn(context, uri, inputEvent)
                    }
                }
            } catch (t: Throwable) {
                if (debug) Log.d(TAG, "registerSource failed (non-fatal): ${t.message}")
            }
        }
        try {
            executor(task)
        } catch (t: Throwable) {
            if (debug) Log.d(TAG, "registerSource scheduling failed (non-fatal): ${t.message}")
        }
    }

    /**
     * Register a TRIGGER on install / first-open so the OS can attribute it to a
     * previously-registered source. No-op when collection is denied OR unavailable.
     *
     * @param triggerData the conversion bucket (0 = install; clamped server-side).
     * @param onRegistered invoked (on the executor) ONLY when registration was
     *   actually attempted on an available AdServices runtime. A server pause or
     *   unavailable-runtime no-op does not fire it. The caller uses this to
     *   persist its at-most-once flag so a device that LATER gains the runtime
     *   (the flag was never set on an earlier runtime-less launch) still registers
     *   on a future launch instead of being permanently skipped.
     */
    fun registerTrigger(
        triggerData: Int = 0,
        onFinished: (() -> Unit)? = null,
        onRegistered: (() -> Unit)? = null,
    ) {
        if (isCollectionDenied()) {
            onFinished?.invoke()
            return
        }
        val task = Runnable {
            try {
                if (!isCollectionDenied() && ensureAvailability()) {
                    val uri = buildTriggerUri(triggerData)
                    val attempted = withBoundedRetry("registerTrigger") {
                        registerTriggerFn(context, uri)
                    }
                    // Registration was attempted on an available runtime — let the
                    // caller commit its once-flag now (NOT before the runtime check).
                    if (attempted) onRegistered?.invoke()
                }
            } catch (t: Throwable) {
                if (debug) Log.d(TAG, "registerTrigger failed (non-fatal): ${t.message}")
            } finally {
                runCatching { onFinished?.invoke() }
            }
        }
        try {
            executor(task)
        } catch (t: Throwable) {
            runCatching { onFinished?.invoke() }
            if (debug) Log.d(TAG, "registerTrigger scheduling failed (non-fatal): ${t.message}")
        }
    }

    /** Run [op] up to [MAX_REGISTER_ATTEMPTS] times until it returns true. A
     *  false/throw is a transient failure; the last failure is a logged no-op. */
    private fun withBoundedRetry(label: String, op: () -> Boolean): Boolean {
        var attempt = 0
        while (attempt < MAX_REGISTER_ATTEMPTS) {
            if (isCollectionDenied()) return attempt > 0
            val verdict = try {
                collectionCommit(op)
            } catch (t: Throwable) {
                if (debug) Log.d(TAG, "$label admission threw: ${t.message}")
                null
            }
            if (verdict == null) return attempt > 0
            attempt++
            if (verdict) return true
        }
        if (debug) Log.d(TAG, "$label exhausted $MAX_REGISTER_ATTEMPTS attempts — giving up (no-op).")
        return attempt > 0
    }

    /** Build the Register-Source fetch URI (the backend reads click_id + slug). */
    internal fun buildSourceUri(
        clickId: String,
        slug: String?,
        host: String? = null,
    ): Uri {
        val base = Endpoints.url(baseUrl, Endpoints.ARA_SOURCE)
        val b = Uri.parse(base).buildUpon()
            .appendQueryParameter("project_id", projectId)
            .appendQueryParameter("api_key", apiKey)
        if (clickId.isNotBlank()) b.appendQueryParameter("click_id", clickId)
        if (!slug.isNullOrBlank()) b.appendQueryParameter("slug", slug)
        if (!host.isNullOrBlank()) b.appendQueryParameter("host", host)
        return b.build()
    }

    /** Build the Register-Trigger fetch URI. */
    internal fun buildTriggerUri(triggerData: Int): Uri {
        val base = Endpoints.url(baseUrl, Endpoints.ARA_TRIGGER)
        return Uri.parse(base).buildUpon()
            .appendQueryParameter("project_id", projectId)
            .appendQueryParameter("api_key", apiKey)
            .appendQueryParameter("package", context.packageName)
            .appendQueryParameter("trigger_data", triggerData.toString())
            .build()
    }

    companion object {
        private const val TAG = "Kixo.Ara"
        const val MAX_REGISTER_ATTEMPTS = 3

        /**
         * ONE shared daemon executor for the reflective AdServices callbacks
         * (`registerSource` / `registerTrigger` each take an Executor + a null
         * OutcomeReceiver). Creating `Executors.newSingleThreadExecutor()` per
         * invocation leaked a thread on every call (up to 3 with bounded retry)
         * since it was never `shutdown()`. A single process-wide daemon thread —
         * the InstallReferrer/InstallValidator convention — bounds it to one
         * idle thread and never blocks JVM exit. The OutcomeReceiver is null so
         * the executor only services the OS-side dispatch; reuse is safe.
         */
        private val adServicesExecutor: java.util.concurrent.Executor =
            java.util.concurrent.Executors.newSingleThreadExecutor { r ->
                Thread(r, "kixo-ara-adservices").apply { isDaemon = true }
            }

        /**
         * Feature-detect the AdServices `MeasurementManager` via reflection so the
         * SDK builds + runs on a minSdk=24 device WITHOUT the AdServices runtime.
         * Returns true only when the class is loadable AND a manager instance can
         * be obtained. Never throws.
         */
        fun detectMeasurementManager(context: Context): Boolean {
            return try {
                val cls = Class.forName("android.adservices.measurement.MeasurementManager")
                // `MeasurementManager.get(Context)` (S_V2+) is the documented
                // accessor; presence of the method is enough to confirm the
                // runtime is callable. A null return → unavailable.
                val getMethod = runCatching {
                    cls.getMethod("get", Context::class.java)
                }.getOrNull()
                if (getMethod != null) {
                    getMethod.invoke(null, context.applicationContext) != null
                } else {
                    // Fallback: getSystemService(MeasurementManager::class.java).
                    @Suppress("UNCHECKED_CAST")
                    context.applicationContext.getSystemService(cls as Class<Any>) != null
                }
            } catch (_: Throwable) {
                false
            }
        }

        /**
         * Reflectively call `MeasurementManager.registerSource(Uri, InputEvent,
         * Executor, OutcomeReceiver)`. Phase A fires the registration and treats a
         * non-throwing invocation as accepted (the OS handles the async outcome).
         * Returns false on any reflection / API failure so the caller can retry.
         */
        fun reflectRegisterSource(context: Context, uri: Uri, inputEvent: InputEvent?): Boolean {
            return try {
                val cls = Class.forName("android.adservices.measurement.MeasurementManager")
                val manager = obtainManager(context, cls) ?: return false
                val method = manager.javaClass.methods.firstOrNull {
                    it.name == "registerSource" && it.parameterTypes.size == 4
                } ?: return false
                method.invoke(manager, uri, inputEvent, adServicesExecutor, null)
                true
            } catch (_: Throwable) {
                false
            }
        }

        /**
         * Reflectively call `MeasurementManager.registerTrigger(Uri, Executor,
         * OutcomeReceiver)`. Returns false on any failure.
         */
        fun reflectRegisterTrigger(context: Context, uri: Uri): Boolean {
            return try {
                val cls = Class.forName("android.adservices.measurement.MeasurementManager")
                val manager = obtainManager(context, cls) ?: return false
                val method = manager.javaClass.methods.firstOrNull {
                    it.name == "registerTrigger" && it.parameterTypes.size == 3
                } ?: return false
                method.invoke(manager, uri, adServicesExecutor, null)
                true
            } catch (_: Throwable) {
                false
            }
        }

        private fun obtainManager(context: Context, cls: Class<*>): Any? {
            return runCatching {
                cls.getMethod("get", Context::class.java).invoke(null, context.applicationContext)
            }.getOrNull() ?: runCatching {
                @Suppress("UNCHECKED_CAST")
                context.applicationContext.getSystemService(cls as Class<Any>)
            }.getOrNull()
        }
    }
}
