package io.kixo.sdk.internal.storage

import android.content.Context
import android.util.Log
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory
import io.kixo.sdk.internal.storage.EventStorageContract.CREATE_INDEX_FLAG
import io.kixo.sdk.internal.storage.EventStorageContract.CREATE_INDEX_TIME
import io.kixo.sdk.internal.storage.EventStorageContract.CREATE_TABLE_EVENTS
import io.kixo.sdk.internal.storage.EventStorageContract.DB_DIR_NAME
import io.kixo.sdk.internal.storage.EventStorageContract.DB_FILE_NAME
import io.kixo.sdk.internal.storage.EventStorageContract.DB_VERSION
import java.io.File
import java.security.MessageDigest

/**
 * `androidx.sqlite` callback that owns the events database lifecycle
 * (create, upgrade, downgrade, configure). Deliberately uses the thin
 * framework wrapper (`SupportSQLiteOpenHelper`) instead of Room — Room
 * brings a 1.5 MB compiler + reflection-heavy runtime + annotation
 * processor for what amounts to one CRUD table. Per
 * `AGENT_BRIEFING.md` §5: "Room is heavy".
 *
 * **Why a separate helper class instead of inline:** [Callback] is the
 * one place we get a callback BEFORE the first transaction runs, and
 * the only place we can cleanly wire PRAGMAs that must be set on every
 * connection (WAL, synchronous, temp_store). Inlining this into
 * [SqliteEventStore] would tangle the lifecycle.
 *
 * @see EventStorageContract for the schema constants.
 * @see SqliteEventStore for the CRUD layer that uses this helper.
 */
internal class EventStorageHelper(
    private val context: Context,
    private val databaseFileName: String = DB_FILE_NAME,
) : SupportSQLiteOpenHelper.Callback(DB_VERSION) {

    /**
     * Build the framework-backed [SupportSQLiteOpenHelper] this callback
     * is wired into. We let the file path be lazy (constructed at
     * `openOrCreate` time) so the directory creation side-effect runs
     * once and only when the db is actually touched.
     */
    fun create(): SupportSQLiteOpenHelper {
        val dbDir = File(context.filesDir, DB_DIR_NAME)
        if (!dbDir.exists() && !dbDir.mkdirs()) {
            // Best-effort: log and continue. The framework helper will
            // also try to create the parent dir; if both fail we'll
            // surface a more specific error on first open() call.
            Log.w(TAG, "Failed to create $dbDir; relying on framework helper")
        }
        if (databaseFileName != DB_FILE_NAME) {
            // Legacy rows have no tenant marker. Guessing their owner after
            // an app switches project/environment can cross-send analytics;
            // discard the one-time unscoped queue instead.
            listOf(DB_FILE_NAME, "$DB_FILE_NAME-wal", "$DB_FILE_NAME-shm")
                .forEach { File(dbDir, it).delete() }
        }
        val dbPath = File(dbDir, databaseFileName).absolutePath

        // FrameworkSQLiteOpenHelperFactory wraps SQLiteOpenHelper. The
        // `name` we pass is the FULL path (the framework treats names
        // with separators as absolute paths). This keeps the db inside
        // our chosen `<filesDir>/kixo/` instead of the default
        // `<filesDir>/databases/` location, matching the iOS layout.
        val config = SupportSQLiteOpenHelper.Configuration.builder(context)
            .name(dbPath)
            .callback(this)
            .build()

        return FrameworkSQLiteOpenHelperFactory().create(config)
    }

    /**
     * Called the first time the DB is opened on a device — creates the
     * v1 schema. Idempotent via `IF NOT EXISTS` in the DDL so a partial
     * onCreate that crashed mid-way can resume on next open.
     *
     * Important: we do NOT touch PRAGMAs here. PRAGMAs are
     * connection-scoped, not database-scoped, so they belong in
     * [onConfigure] / [onOpen] which run on every open including
     * subsequent process launches.
     */
    override fun onCreate(db: SupportSQLiteDatabase) {
        db.execSQL(CREATE_TABLE_EVENTS)
        db.execSQL(CREATE_INDEX_TIME)
        db.execSQL(CREATE_INDEX_FLAG)
    }

    /**
     * Schema upgrade hook. The v1 schema is the only one that exists
     * today — but the framework requires this method, and we want to
     * be ready for v2+ without a panicked refactor when the time comes.
     *
     * Strategy for FUTURE versions: prefer additive `ALTER TABLE … ADD
     * COLUMN` over `DROP TABLE … CREATE` so we never lose pending
     * events to a schema bump. If a destructive change is genuinely
     * required (e.g. column type change in old sqlite), drain rows to
     * a temp table, recreate, copy back — all inside a transaction.
     *
     * For unknown forward jumps (downgrade scenario where the user
     * installed a newer SDK then rolled back), see [onDowngrade].
     */
    override fun onUpgrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.i(TAG, "Schema upgrade $oldVersion → $newVersion (no-op for v$DB_VERSION)")
        // Forward-compat slot — branch by oldVersion when v2 lands:
        //
        //   if (oldVersion < 2) {
        //       db.execSQL("ALTER TABLE ${TABLE_EVENTS} ADD COLUMN priority INTEGER NOT NULL DEFAULT 0;")
        //   }
        //   if (oldVersion < 3) { … }
        //
        // Each migration is monotone — never reads `newVersion` to
        // pick branches, only `oldVersion` — so the chain composes
        // cleanly across multi-version jumps (v1 → v3 runs both
        // blocks).
    }

    /**
     * Downgrade is rare in production (SDK consumers control the
     * version) but possible during dev. The default
     * [SupportSQLiteOpenHelper.Callback.onDowngrade] throws
     * `SQLiteException("Can't downgrade")` which would CRASH the
     * host app — not acceptable per R6 ("never crash the host app").
     *
     * Our policy: log + drop + recreate. We lose any pending events
     * the newer-version process queued, but the alternative (a
     * crash on every cold-launch until the user reinstalls) is much
     * worse. In production this branch should never fire.
     */
    override fun onDowngrade(db: SupportSQLiteDatabase, oldVersion: Int, newVersion: Int) {
        Log.w(
            TAG,
            "Schema DOWNGRADE $oldVersion → $newVersion — dropping events table to recover",
        )
        db.execSQL("DROP TABLE IF EXISTS ${EventStorageContract.TABLE_EVENTS};")
        onCreate(db)
    }

    /**
     * Set connection PRAGMAs. Called BEFORE any user query on every
     * open (process restart or otherwise). All four PRAGMAs are
     * non-default and load-bearing:
     *
     *  - `journal_mode=WAL` — readers don't block writers, durable
     *    on commit, ~2-3× faster bulk-insert vs default rollback
     *    journal. Trade-off: creates `-wal` + `-shm` sidecar files;
     *    we accept that.
     *  - `synchronous=NORMAL` — fsync on COMMIT only, not on every
     *    page write. Pairs with WAL for the safety/speed sweet spot
     *    Mixpanel/Realm/Apple Mail all use. `FULL` is overkill for
     *    an analytics queue (worst case: lose events from the last
     *    ~30s if the device hard-crashes, which is fine — the next
     *    session re-emits anyway).
     *  - `temp_store=MEMORY` — any sqlite-internal temp tables (sort
     *    spills, etc.) go to RAM not disk. We never create temp
     *    tables explicitly so this is mostly defensive.
     *  - `foreign_keys=OFF` — we have no FKs (one table). Explicit
     *    OFF makes the intent obvious to future maintainers. Default
     *    is also OFF on Android, but stating it is cheap insurance
     *    against an upstream default change.
     *
     * If any PRAGMA fails (older Android, FS doesn't support WAL
     * locking), we log and continue. The DB still works in default
     * mode, just slower. Per R6 we never throw out of this method.
     */
    override fun onConfigure(db: SupportSQLiteDatabase) {
        super.onConfigure(db)
        try {
            // `query` is required for PRAGMAs that return a row
            // (journal_mode does). `execSQL` would also work but
            // discards the result string we want for diagnostics.
            db.query("PRAGMA journal_mode=WAL;").use { c ->
                if (c.moveToFirst() && Log.isLoggable(TAG, Log.DEBUG)) {
                    Log.d(TAG, "journal_mode set to ${c.getString(0)}")
                }
            }
            db.execSQL("PRAGMA synchronous=NORMAL;")
            db.execSQL("PRAGMA temp_store=MEMORY;")
            db.execSQL("PRAGMA foreign_keys=OFF;")
        } catch (t: Throwable) {
            // R6: swallow + log. A PRAGMA failure must never crash the
            // host app. We continue with whatever defaults sqlite gives
            // us — slower, but functional.
            Log.w(TAG, "Failed to set PRAGMAs (continuing with defaults)", t)
        }
    }

    companion object {
        /** Stable tenant-specific filename; credentials never enter the path. */
        internal fun scopedFileName(
            environment: String,
            projectId: String,
            apiHost: String,
        ): String {
            val scope = "$environment\u0000$projectId\u0000${apiHost.trimEnd('/')}"
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(scope.toByteArray(Charsets.UTF_8))
                .take(12)
                .joinToString("") { "%02x".format(it.toInt() and 0xff) }
            return "events-$digest.db"
        }

        const val TAG: String = "Kixo.EventStorageHelper"
    }
}
