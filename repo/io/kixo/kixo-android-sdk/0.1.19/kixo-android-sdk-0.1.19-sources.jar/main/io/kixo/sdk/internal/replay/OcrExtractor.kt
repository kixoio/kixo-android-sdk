package io.kixo.sdk.internal.replay

import android.graphics.Bitmap
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * On-device text recognition over a captured `Bitmap`. Wraps Google
 * ML Kit `text-recognition` (`com.google.mlkit:text-recognition`)
 * via REFLECTION so the SDK does NOT hard-require the dependency at
 * runtime — host apps that don't bundle ML Kit get OCR no-op'd
 * silently.
 *
 * **Why reflection, not direct call:** ML Kit's text-recognition is
 * declared `compileOnly` in `kixo/build.gradle.kts` (~3 MB on-device
 * model + ~150 KB classes). If the host app doesn't `implementation`
 * it, the ClassLoader has no `com.google.mlkit.vision.text.*` types
 * and a direct `import` would crash at first reference. Using
 * `Class.forName` defers the lookup; if it fails we silently degrade
 * to "no OCR text, send the event without the sidecar."
 *
 * **Hard rule (no auto-LLM).** This is ML Kit's local model — same
 * category as iOS's `VNRecognizeTextRequest`. Vision via Anthropic /
 * OpenAI / Google Gemini happens ONLY through operator-invoked chat
 * actions. See AGENT_BRIEFING §3 R1.
 *
 * **Performance**:
 *  - ML Kit Text Recognition v2 runs ~30-100 ms on a Pixel 6 / iPhone
 *    13 class device against a 1080×2400 frame.
 *  - Off-main only — runs on `Dispatchers.Default` so UI never
 *    blocks. The semaphore caps fan-out at
 *    [ReplayConfig.maxConcurrentOcr] concurrent invocations
 *    (briefing §3 R4 "bounded everything").
 *
 * **PII pass.** Every recognized line goes through Agent 10's
 * [io.kixo.sdk.internal.privacy.PiiFilter] (injected here as a
 * lambda to keep the package boundary clean — see [PiiSanitizer]).
 * Email / phone / Luhn-validated CC numbers land `[redacted]`
 * BEFORE the result is returned to the upload pipeline (Agent 14).
 *
 * **PII privacy invariant.** This runs on the SAME `Bitmap` that
 * the upload pipeline receives — i.e. AFTER [RedactionEngine] has
 * rasterized opaque rects over `kxRedact` regions / password fields.
 * So OCR can only see what already left the device as pixels. We
 * can't leak more text than the upload itself would.
 *
 * **Lifecycle.** [shutdown] disposes the underlying ML Kit
 * `TextRecognizer` — important on session-end because the recogniser
 * pins ~5 MB of native scratch buffers. Idempotent.
 */
internal class OcrExtractor(
    /** Configuration handed from [ReplayController]. */
    private val config: ReplayConfig,
    /**
     * Lambda over Agent 10's
     * [io.kixo.sdk.internal.privacy.PiiFilter.redact] entry point.
     * Defaults to identity to keep this class JVM-test-friendly when
     * Agent 10's class isn't on the classpath. [ReplayController]
     * binds the real implementation at construction time.
     *
     * **Why a lambda, not a direct reference:** Agent 10's
     * `PiiFilter` is an instance-bearing class (it carries an
     * optional `EntityTagger`). Wrapping it in a lambda means this
     * file (Agent 13) doesn't construct that class — Agent 13 stays
     * in its folder per AGENT_BRIEFING §6 ownership rule.
     */
    private val piiSanitizer: (String) -> String = { it },
    /**
     * Live `ocrEnabled` gate. [ReplayController] binds this to its
     * `@Volatile` live [ReplayConfig] so a remote `/init` flip of
     * `ocrEnabled` takes effect on the ACTIVE session — the extractor
     * is built once at session start ([config]) and would otherwise
     * check a stale value. Defaults to the construction-time [config]
     * so JVM tests keep the old static behavior. The project concurrency
     * provider is likewise read for every admission.
     */
    private val liveOcrEnabled: () -> Boolean = { config.ocrEnabled },
    private val liveMaxConcurrentOcr: () -> Int = { config.maxConcurrentOcr },
) {

    /**
     * Lazy-loaded ML Kit `TextRecognizer` instance. Held as `Any?`
     * so this class compiles against `compileOnly` ML Kit and runs
     * without crashing when ML Kit is missing at runtime.
     *
     * `AtomicReference` makes the lazy-init thread-safe without
     * paying for a JVM monitor on every read.
     */
    private val recognizer = AtomicReference<Any?>()

    /**
     * Set to `true` after the FIRST attempt that throws
     * [ClassNotFoundException]. We don't retry — if the ClassLoader
     * doesn't have ML Kit on first call, it never will (the host
     * app's classpath is fixed at install time).
     */
    @Volatile
    private var mlkitMissing: Boolean = false

    /**
     * Bounded concurrency. Coroutine-aware semaphore so suspending
     * callers (the [ReplayController] capture pipeline) await
     * fairly rather than blocking a thread.
     */
    private val ocrSemaphore = Semaphore(permits = 8)
    private val ocrInFlight = AtomicInteger(0)

    /**
     * Critic 14 (HIGH) — serialise the FIRST-call ML Kit reflective
     * init. Without this, two coroutines racing the very first
     * `extract()` would each enter [obtainRecognizer] and run the
     * Class.forName/getMethod chain in parallel; first writer wins via
     * the AtomicReference CAS but the loser pays a wasted reflection
     * round-trip AND (more importantly) the duplicated `getClient(...)`
     * call materialises a second native ML Kit recogniser that is
     * never released. After init, [obtainRecognizer] short-circuits on
     * the cached AtomicReference inside the lock — uncontended fast
     * path, single Mutex acquire per call.
     */
    private val initMutex: Mutex = Mutex()

    /**
     * Recognise text on the supplied bitmap. Returns the full
     * concatenated text run-by-run, with PII placeholders applied
     * via the injected [piiSanitizer]. Returns the empty string on:
     *   - ML Kit dependency missing on classpath
     *   - ML Kit recognition fails (rare; usually ImageNotReady or
     *     Bitmap recycled)
     *   - OCR disabled in [config]
     *
     * **Threading**: callable from any coroutine context. Internally
     * dispatches to [Dispatchers.Default] for the JNI / native ML
     * Kit work — caller must NOT call from main if the host has a
     * frame budget at risk.
     *
     * **Hard cap** [ReplayConfig.maxConcurrentOcr] via a live atomic
     * admission counter plus an absolute eight-permit safety semaphore.
     * Excess callers drop their OCR sidecar instead of building a backlog.
     */
    suspend fun extract(bitmap: Bitmap): String {
        if (!liveOcrEnabled()) return ""
        if (mlkitMissing) return ""
        if (bitmap.isRecycled) return ""

        while (true) {
            val current = ocrInFlight.get()
            val ceiling = liveMaxConcurrentOcr().coerceIn(1, 8)
            if (current >= ceiling) return ""
            if (ocrInFlight.compareAndSet(current, current + 1)) break
        }

        return try {
            ocrSemaphore.withPermit {
                withContext(Dispatchers.Default) {
                    runMlkitOcr(bitmap)
                }
            }
        } finally {
            ocrInFlight.decrementAndGet()
        }
    }

    /**
     * Reflection-driven ML Kit invocation. Returns concatenated
     * recognised text (PII-sanitised) or empty on any failure path.
     *
     * Reflection layout (mirrors public ML Kit Java API):
     *   - `com.google.mlkit.vision.text.TextRecognition.getClient(options)`
     *     → `TextRecognizer`
     *   - `com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS`
     *   - `com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, rotation)`
     *   - `recognizer.process(inputImage)` → Task<Text>
     *   - `Text.getText()` → full string
     *
     * We use the sync-style `Tasks.await` only via a coroutine-
     * adapted callback so we don't block the dispatcher.
     */
    private suspend fun runMlkitOcr(bitmap: Bitmap): String {
        val rec = obtainRecognizer() ?: run {
            mlkitMissing = true
            return ""
        }

        val text: String = try {
            invokeProcess(rec, bitmap)
        } catch (t: Throwable) {
            // Log once per failure-class; ML Kit can throw IO,
            // IllegalArgument, or its own MlKitException. None should
            // crash the host (briefing R6). Falling back to empty
            // means the upload pipeline ships the event without the
            // OCR sidecar — graceful degradation.
            Log.w(TAG, "ML Kit OCR failed: ${t.javaClass.simpleName}", t)
            return ""
        }

        if (text.isBlank()) return ""

        // PII pass — Agent 10's regex+Luhn redactor (injected via
        // constructor lambda so we don't directly bind to the class).
        return piiSanitizer(text)
    }

    /**
     * Lazy-resolve the `TextRecognizer`. Returns `null` if ML Kit
     * isn't on the classpath.
     *
     * Critic 14 (HIGH) — serialised inside [initMutex] so two coroutines
     * racing the first call don't each run the reflection chain in
     * parallel. After init succeeds the fast-path early-return makes
     * subsequent calls cheap (they pay the Mutex acquire which is
     * uncontended once init has settled).
     */
    private suspend fun obtainRecognizer(): Any? = initMutex.withLock {
        // Fast path inside the lock — once init has populated the
        // AtomicReference, subsequent calls just re-read it. The lock
        // acquire is the only cost and it's uncontended after the
        // first concurrent burst.
        recognizer.get()?.let { return@withLock it }

        try {
            val optionsClass = Class.forName(MLKIT_OPTIONS_CLASS)
            val defaultOptions = optionsClass.getField("DEFAULT_OPTIONS").get(null)
                ?: return@withLock null

            val recognitionClass = Class.forName(MLKIT_RECOGNITION_CLASS)
            val getClientMethod = recognitionClass.getMethod(
                "getClient",
                Class.forName(MLKIT_OPTIONS_INTERFACE),
            )
            val rec = getClientMethod.invoke(null, defaultOptions) ?: return@withLock null

            // CAS — first writer wins; later threads pick up the same
            // instance. Inside the Mutex this is effectively single-
            // threaded, but the compareAndSet defends against a future
            // refactor that drops the Mutex.
            if (recognizer.compareAndSet(null, rec)) rec else recognizer.get()
        } catch (_: ClassNotFoundException) {
            null
        } catch (t: Throwable) {
            Log.w(TAG, "ML Kit recognizer init failed", t)
            null
        }
    }

    /**
     * Invoke `recognizer.process(InputImage.fromBitmap(...))` and
     * adapt the resulting `Task<Text>` to a coroutine. Returns the
     * concatenated text from `Text.getText()`.
     */
    private suspend fun invokeProcess(rec: Any, bitmap: Bitmap): String {
        // InputImage.fromBitmap(bitmap, rotation = 0)
        val inputImageClass = Class.forName(MLKIT_INPUT_IMAGE_CLASS)
        val fromBitmap = inputImageClass.getMethod(
            "fromBitmap",
            Bitmap::class.java,
            Int::class.javaPrimitiveType,
        )
        val image = fromBitmap.invoke(null, bitmap, 0) ?: return ""

        // recognizer.process(image) → Task<Text>
        val processMethod = rec.javaClass.getMethod("process", inputImageClass)
        val task = processMethod.invoke(rec, image) ?: return ""

        // Adapt Task<Text> to Deferred<String>. We don't import
        // com.google.android.gms.tasks.Task — adding listeners via
        // reflection means the SDK doesn't hard-link Play Services
        // either.
        val deferred = CompletableDeferred<String>()
        try {
            val onSuccessClass = Class.forName(GMS_ON_SUCCESS_LISTENER)
            val onFailureClass = Class.forName(GMS_ON_FAILURE_LISTENER)

            val onSuccess = java.lang.reflect.Proxy.newProxyInstance(
                onSuccessClass.classLoader,
                arrayOf(onSuccessClass),
            ) { _, _, args ->
                val textObj = args?.firstOrNull()
                val getTextMethod = try {
                    textObj?.javaClass?.getMethod("getText")
                } catch (_: NoSuchMethodException) {
                    null
                }
                val resolved = (getTextMethod?.invoke(textObj) as? String).orEmpty()
                deferred.complete(resolved)
                null
            }

            val onFailure = java.lang.reflect.Proxy.newProxyInstance(
                onFailureClass.classLoader,
                arrayOf(onFailureClass),
            ) { _, _, args ->
                val cause = args?.firstOrNull() as? Throwable
                deferred.completeExceptionally(
                    cause ?: RuntimeException("ML Kit OCR failure (no cause)"),
                )
                null
            }

            val addOnSuccess = task.javaClass.getMethod(
                "addOnSuccessListener", onSuccessClass,
            )
            val addOnFailure = task.javaClass.getMethod(
                "addOnFailureListener", onFailureClass,
            )

            addOnSuccess.invoke(task, onSuccess)
            addOnFailure.invoke(task, onFailure)
        } catch (t: Throwable) {
            // Reflection-binding failure means GMS is missing or the
            // API drift is bigger than we expected. Fail open with
            // empty text rather than throw.
            Log.w(TAG, "ML Kit task adapter failed", t)
            return ""
        }

        return deferred.await()
    }

    /**
     * Release ML Kit native scratch. Idempotent — call on
     * [ReplayController.stop] so we don't leak a ~5 MB
     * recognizer past the session boundary.
     */
    fun shutdown() {
        val rec = recognizer.getAndSet(null) ?: return
        try {
            rec.javaClass.getMethod("close").invoke(rec)
        } catch (_: Throwable) { /* swallow — best-effort */ }
    }

    companion object {
        private const val TAG = "Kixo"
        private const val MLKIT_RECOGNITION_CLASS =
            "com.google.mlkit.vision.text.TextRecognition"
        private const val MLKIT_OPTIONS_CLASS =
            "com.google.mlkit.vision.text.latin.TextRecognizerOptions"
        private const val MLKIT_OPTIONS_INTERFACE =
            "com.google.mlkit.vision.text.TextRecognizerOptionsInterface"
        private const val MLKIT_INPUT_IMAGE_CLASS =
            "com.google.mlkit.vision.common.InputImage"
        private const val GMS_ON_SUCCESS_LISTENER =
            "com.google.android.gms.tasks.OnSuccessListener"
        private const val GMS_ON_FAILURE_LISTENER =
            "com.google.android.gms.tasks.OnFailureListener"
    }
}
