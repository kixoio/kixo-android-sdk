package io.kixo.sdk.internal.replay.upload

import android.annotation.SuppressLint
import android.content.SharedPreferences
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json

/** Durable, retryable `/session/end` records keyed by session + installation. */
@SuppressLint("ApplySharedPref") // commit() is the crash-safety boundary for end retries.
internal class ReplayPendingEndStore(
    private val prefs: SharedPreferences,
    private val json: Json = Json { ignoreUnknownKeys = true; encodeDefaults = true },
) {
    @Serializable
    internal data class Record(
        val sessionId: String,
        val installationId: String,
        val stintId: String,
        val stintEpoch: Long = 1L,
        val endedAtIso: String,
        val frameCount: Int,
        val totalBytes: Long,
        val lastFrameSeq: Long? = null,
        val endReason: String,
        val framesDropped: Int = 0,
        val dropReasons: Map<String, Int>? = null,
    ) {
        val key: String get() = "$sessionId\u001f$installationId"
    }

    @Synchronized
    fun upsert(record: Record): Boolean {
        val records = readMutable()
        val index = records.indexOfFirst { it.key == record.key }
        if (index >= 0) records[index] = merge(records[index], record) else records += record
        return write(records)
    }

    @Synchronized
    fun snapshot(): List<Record> = readMutable().toList()

    @Synchronized
    fun containsUnchanged(record: Record): Boolean = readMutable().any { it == record }

    fun encode(record: Record): String = json.encodeToString(Record.serializer(), record)

    fun decode(encoded: String): Record? = runCatching {
        json.decodeFromString(Record.serializer(), encoded)
    }.getOrNull()

    /** Do not delete a newer cumulative record that raced this request. */
    @Synchronized
    fun removeIfUnchanged(sent: Record): Boolean {
        val records = readMutable()
        val removed = records.removeAll { it.key == sent.key && it == sent }
        return !removed || write(records)
    }

    /** A successful resume makes every prior stint-end record stale. */
    @Synchronized
    fun removeForSession(sessionId: String, installationId: String): Boolean {
        val records = readMutable()
        val removed = records.removeAll {
            it.sessionId == sessionId && it.installationId == installationId
        }
        return !removed || write(records)
    }

    private fun readMutable(): MutableList<Record> = runCatching {
        val encoded = prefs.getString(KEY, null) ?: return mutableListOf()
        json.decodeFromString(ListSerializer(Record.serializer()), encoded).toMutableList()
    }.getOrElse { mutableListOf() }

    private fun write(records: List<Record>): Boolean = runCatching {
        val edit = prefs.edit()
        if (records.isEmpty()) edit.remove(KEY)
        else edit.putString(KEY, json.encodeToString(ListSerializer(Record.serializer()), records))
        edit.commit()
    }.getOrDefault(false)

    private fun merge(old: Record, fresh: Record): Record {
        if (old.stintId != fresh.stintId || old.stintEpoch != fresh.stintEpoch) return fresh
        return fresh.copy(
            frameCount = maxOf(old.frameCount, fresh.frameCount),
            totalBytes = maxOf(old.totalBytes, fresh.totalBytes),
            lastFrameSeq = listOfNotNull(old.lastFrameSeq, fresh.lastFrameSeq).maxOrNull(),
            framesDropped = maxOf(old.framesDropped, fresh.framesDropped),
            dropReasons = mergeReasons(old.dropReasons, fresh.dropReasons),
        )
    }

    private fun mergeReasons(
        old: Map<String, Int>?,
        fresh: Map<String, Int>?,
    ): Map<String, Int>? {
        if (old.isNullOrEmpty()) return fresh
        if (fresh.isNullOrEmpty()) return old
        return (old.keys + fresh.keys).associateWith { key ->
            maxOf(old[key] ?: 0, fresh[key] ?: 0)
        }
    }

    companion object {
        internal const val PREFS_NAME = "io.kixo.sdk.replay.lifecycle"
        const val KEY = "pending_end_records_v1"
    }
}
