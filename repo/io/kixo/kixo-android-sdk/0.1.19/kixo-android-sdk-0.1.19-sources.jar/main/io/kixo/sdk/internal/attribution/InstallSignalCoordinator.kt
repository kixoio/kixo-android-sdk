package io.kixo.sdk.internal.attribution

import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Coordinates the canonical install signal with the bounded Play Referrer read.
 *
 * Application startup never waits on this coordinator. Only the queued
 * `app_install` event is delayed, for at most [timeoutMs], so the first Play
 * Referrer result can supply the deterministic click id and referrer bag.
 * Backend resolve/POST work is deliberately outside the wait: once the local
 * Play payload is available, offline or slow networking must not turn a
 * deterministic install into an organic one.
 */
internal class InstallSignalCoordinator(
    private val emitter: InstallEmitter,
    private val timeoutMs: Long = DEFAULT_TIMEOUT_MS,
    private val scheduleTimeout: (delayMs: Long, task: () -> Unit) -> (() -> Unit),
    private val canEmit: () -> Boolean = { true },
    private val commitRetryDelaysMs: LongArray = DEFAULT_COMMIT_RETRY_DELAYS_MS,
) {
    private val started = AtomicBoolean(false)
    private val completed = AtomicBoolean(false)
    private val deadlineReached = AtomicBoolean(false)
    private val outcome = AtomicReference<InstallReferrerReadOutcome?>(null)
    private val cancelTimeout = AtomicReference<(() -> Unit)?>(null)
    private val cancelCommitRetry = AtomicReference<(() -> Unit)?>(null)
    private val commitRetryAttempt = java.util.concurrent.atomic.AtomicInteger(0)

    /**
     * Arm the finite wait. Idempotent under duplicate bootstrap edges, so only
     * one timer can ever compete with the local referrer result.
     */
    fun start() {
        if (completed.get()) return
        if (started.compareAndSet(false, true)) {
            val cancellation = try {
                scheduleTimeout(timeoutMs) {
                    deadlineReached.set(true)
                    tryEmit()
                }
            } catch (_: Throwable) {
                // A rejected scheduler must degrade to an immediate organic
                // install, never leave the canonical signal waiting forever.
                deadlineReached.set(true)
                null
            }
            if (cancellation != null) {
                cancelTimeout.set(cancellation)
                if (completed.get()) cancelTimer()
            }
        }
        tryEmit()
    }

    /**
     * Receive the first terminal local read outcome. Later callbacks are ignored:
     * Play Referrer is immutable and the canonical install is exact-once.
     */
    fun onReferrerOutcome(value: InstallReferrerReadOutcome) {
        outcome.compareAndSet(null, value)
        tryEmit()
    }

    /**
     * Re-arm after the durable queue was cleared or a prior enqueue was
     * rejected by a server-policy gate. Stable IDs keep this idempotent.
     */
    fun retryIfUnsettled() {
        cancelCommitRetry.getAndSet(null)?.invoke()
        commitRetryAttempt.set(0)
        completed.set(false)
        tryEmit()
    }

    /**
     * SQLite commits are asynchronous relative to [enqueueIfNeeded]. A failed
     * append must re-arm the coordinator itself; waiting for another lifecycle
     * transition can strand the canonical install for the whole process.
     */
    fun onQueueCommitResult(committed: Boolean) {
        if (committed) {
            cancelCommitRetry.getAndSet(null)?.invoke()
            commitRetryAttempt.set(0)
            return
        }
        completed.set(false)
        scheduleCommitRetry()
    }

    private fun tryEmit() {
        if (!started.get() || completed.get() || !canEmit()) return

        val current = outcome.get()
        if (current == null && !deadlineReached.get()) return

        val properties = when (current) {
            is InstallReferrerReadOutcome.Enriched -> current.properties
            is InstallReferrerReadOutcome.Unavailable, null -> emptyMap()
        }
        if (!completed.compareAndSet(false, true)) return

        cancelTimer()
        if (!emitter.enqueueIfNeeded(properties)) {
            completed.set(false)
        }
    }

    private fun cancelTimer() {
        try {
            cancelTimeout.getAndSet(null)?.invoke()
        } catch (_: Throwable) {
            // Cancellation is best-effort; [completed] remains the exact-once gate.
        }
    }

    private fun scheduleCommitRetry() {
        if (!canEmit()) return
        val attempt = commitRetryAttempt.getAndIncrement()
        val delayMs = commitRetryDelaysMs.getOrNull(attempt) ?: return
        if (cancelCommitRetry.get() != null) return
        val cancellation = try {
            scheduleTimeout(delayMs) {
                cancelCommitRetry.set(null)
                tryEmit()
            }
        } catch (_: Throwable) {
            null
        }
        if (cancellation != null &&
            !cancelCommitRetry.compareAndSet(null, cancellation)
        ) {
            cancellation()
        }
    }

    companion object {
        /** Keeps app startup non-blocking while covering normal Play binder latency. */
        const val DEFAULT_TIMEOUT_MS = 2_000L
        private val DEFAULT_COMMIT_RETRY_DELAYS_MS =
            longArrayOf(250L, 1_000L, 5_000L)
    }
}

/**
 * Local Play Referrer readiness for the canonical install signal.
 *
 * `Unavailable` is intentionally property-free: unsupported Play services,
 * terminal errors, and bounded transient failures are honest organic installs.
 */
internal sealed interface InstallReferrerReadOutcome {
    data class Enriched(val properties: Map<String, Any?>) : InstallReferrerReadOutcome
    data class Unavailable(val reason: String) : InstallReferrerReadOutcome
}
