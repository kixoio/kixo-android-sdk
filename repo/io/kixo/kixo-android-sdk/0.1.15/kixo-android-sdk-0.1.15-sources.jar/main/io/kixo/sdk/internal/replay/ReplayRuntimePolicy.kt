package io.kixo.sdk.internal.replay

import android.content.Context
import androidx.annotation.VisibleForTesting
import io.kixo.sdk.internal.model.DataCollection
import io.kixo.sdk.internal.replay.upload.ReplayPendingUploadStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.Call
import okhttp3.Callback
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume

/**
 * Project-scoped, server-authoritative replay policy.
 *
 * A dedicated object is used instead of reading a process-global Boolean so
 * old WorkManager jobs cannot inherit a later project's cellular permission.
 * The generation is persisted and rotated at privacy/identity boundaries;
 * an old worker token can therefore never become valid again after logout,
 * reset, opt-out, or consent revocation.
 */
internal class ReplayRuntimePolicy private constructor(
    private val scope: String,
    initialGeneration: Long,
    initialPrivacyAllowed: Boolean,
    initialPolicyFingerprint: String?,
    private val persistGeneration: (Long) -> Unit,
    private val persistResolvedPolicy: (Long, String) -> Unit,
    /** Must be synchronous: privacy APIs do not return with raw bytes on disk. */
    private val purgeReplayArtifacts: () -> Unit,
    /** Durable WorkManager rescheduler used when Wi-Fi-only is loosened. */
    private val onCellularLoosened: (ReplayRuntimePolicy) -> Unit,
    /** Rebuild WorkSpecs from sidecars after a process restart. */
    private val onRestoredPolicyResolved: (ReplayRuntimePolicy, Boolean) -> Unit,
) {
    internal data class Snapshot(
        val generation: Long,
        val resolved: Boolean,
        val enabled: Boolean,
        val sampleRateFraction: Double,
        val captureOnCellular: Boolean,
        val maskInputs: Boolean,
        val privacyAllowed: Boolean,
    )

    internal enum class WorkerDecision {
        UPLOAD,
        WAIT_FOR_NETWORK_OR_POLICY,
        DISCARD,
    }

    /**
     * Replay JSON RPCs use the same generation gate as WorkManager PUTs.
     * Cleanup may run while replay itself is disabled, but never after a
     * privacy/identity boundary or against an unresolved project policy.
     */
    internal enum class CallAuthority {
        DATA,
        CLEANUP,
    }

    internal sealed interface WorkerCallResult {
        data class Executed(val response: Response) : WorkerCallResult
        data class Rejected(val decision: WorkerDecision) : WorkerCallResult
    }

    internal class CallRejectedException : IOException("replay policy rejected network call")

    internal data class ApplyResult(
        /** Old staged/queued artifacts must not survive this policy edge. */
        val artifactsInvalidated: Boolean,
    )

    private val state = AtomicReference(
        Snapshot(
            generation = initialGeneration,
            resolved = false,
            enabled = false,
            sampleRateFraction = 0.0,
            captureOnCellular = false,
            maskInputs = true,
            privacyAllowed = initialPrivacyAllowed,
        ),
    )
    private val stateUpdates = MutableStateFlow(state.get())
    private val persistedPolicyFingerprint = AtomicReference(initialPolicyFingerprint)

    /**
     * Serialises the in-memory transition and its durable write.
     *
     * AtomicReference alone is not enough here: `apply()` could publish
     * generation N, get suspended before `commit()`, then an opt-out could
     * publish+persist N+1 before the first call finally persisted N again.
     * A process death in that state would resurrect an already-retired worker
     * token. Keeping every policy mutation and persistence callback under one
     * monitor preserves the same total order in memory and on disk.
     */
    private val mutationLock = Any()

    /**
     * Calls that have crossed the final permission check and have been handed
     * to OkHttp. Registration and `Call.enqueue()` both happen while holding
     * [mutationLock]. Therefore a privacy boundary either wins first (the call
     * is never enqueued), or wins second and synchronously calls `cancel()`
     * before that public boundary returns.
     */
    private val activeCalls = LinkedHashSet<Call>()
    private val cellularLooseningListeners = ConcurrentHashMap.newKeySet<() -> Unit>()

    init {
        publish(state.get())
    }

    /**
     * Replace every remote value. Sparse wire contract (2026-07):
     * an ABSENT `replay` block means replay is OFF (fail-closed,
     * unchanged); a PRESENT block may omit default-valued fields, and
     * a missing `sampleRate` means the default — 100% (fraction 1.0).
     * An explicit rate still wins, and an explicit 0 hard-disables.
     */
    fun apply(dataCollection: DataCollection?, topLevelPaused: Boolean): ApplyResult {
        var notifyCellularLoosened = false
        var reconcileRestoredPolicy: Boolean? = null
        val result = synchronized(mutationLock) {
            val replay = dataCollection?.replay
            val rate = replay?.effectiveSampleRateFraction() ?: 0.0
            val previous = state.get()
            val candidate = previous.copy(
                resolved = true,
                enabled = !topLevelPaused && dataCollection?.paused != true &&
                    replay?.enabled == true && rate > 0.0,
                sampleRateFraction = rate,
                captureOnCellular = replay?.captureOnCellular == true,
                // Privacy-safe legacy default: mask every input unless the
                // project explicitly turns this off.
                maskInputs = replay?.maskInputs != false,
            )
            notifyCellularLoosened = previous.resolved && previous.enabled &&
                candidate.enabled && !previous.captureOnCellular && candidate.captureOnCellular
            val tightened = previous.resolved && (
                (previous.enabled && !candidate.enabled) ||
                    (!previous.maskInputs && candidate.maskInputs) ||
                    (previous.captureOnCellular && !candidate.captureOnCellular) ||
                    candidate.sampleRateFraction < previous.sampleRateFraction
                )
            val fingerprint = fingerprint(candidate)
            // A worker token may outlive the process that captured its bytes.
            // On the first config after restart, the token survives only when
            // the fresh project policy is equal to or looser than the policy
            // under which those bytes were staged. Any tightening rotates it.
            val oldFingerprint = persistedPolicyFingerprint.get()
            val restoredPolicy = parseFingerprint(oldFingerprint)
            val restoredPolicyTightened = !previous.resolved && (
                restoredPolicy == null || isTightening(restoredPolicy, candidate)
            )
            if (!previous.resolved && restoredPolicy != null &&
                !restoredPolicy.captureOnCellular && candidate.captureOnCellular &&
                candidate.enabled && !restoredPolicyTightened
            ) {
                notifyCellularLoosened = true
            }
            val artifactsInvalidated = tightened || restoredPolicyTightened
            val next = if (artifactsInvalidated) {
                candidate.copy(generation = previous.generation + 1L)
            } else {
                candidate
            }
            state.set(next)
            persistedPolicyFingerprint.set(fingerprint)
            publish(next)
            if (artifactsInvalidated || oldFingerprint != fingerprint) {
                // One synchronous SharedPreferences transaction binds the
                // generation and fingerprint across process death.
                persistResolvedPolicy(next.generation, fingerprint)
            }
            if (artifactsInvalidated) retireArtifactsLocked()
            if (!previous.resolved && !artifactsInvalidated) {
                reconcileRestoredPolicy = candidate.captureOnCellular
            }
            ApplyResult(artifactsInvalidated = artifactsInvalidated)
        }
        reconcileRestoredPolicy?.let { captureOnCellular ->
            runCatching { onRestoredPolicyResolved(this, captureOnCellular) }
        }
        if (notifyCellularLoosened) {
            // WorkManager constraints are immutable. Live uploaders replace
            // their still-staged UNMETERED requests with CONNECTED requests;
            // the durable scanner covers requests restored after process death.
            runCatching { onCellularLoosened(this) }
            cellularLooseningListeners.toList().forEach { listener ->
                runCatching(listener)
            }
        }
        return result
    }

    /**
     * A replay RPC can discover a server kill-switch before the slower config
     * poll. Retire the worker generation and remain fail-closed until a fresh
     * `/init` or `/config` response replaces the policy.
     */
    fun denyUntilFreshRemotePolicy() = synchronized(mutationLock) {
        val previous = state.get()
        val next = previous.copy(
            generation = previous.generation + 1L,
            resolved = false,
            enabled = false,
            sampleRateFraction = 0.0,
            captureOnCellular = false,
            maskInputs = true,
        )
        state.set(next)
        publish(next)
        persistGeneration(next.generation)
        retireArtifactsLocked()
    }

    fun snapshot(): Snapshot = state.get()

    fun workerToken(): String {
        val current = state.get()
        return "$scope:${current.generation}"
    }

    /** Register a live-session wakeup for Wi-Fi-only → cellular-allowed. */
    fun addCellularLooseningListener(listener: () -> Unit): () -> Unit {
        cellularLooseningListeners += listener
        return { cellularLooseningListeners.remove(listener) }
    }

    /** Suspend without a polling loop until cleanup is locally permissible. */
    suspend fun awaitFreshPrivacyPolicy(): Snapshot =
        stateUpdates.first { it.resolved && it.privacyAllowed }

    /**
     * Final in-process boundary for replay JSON calls. The captured token is
     * session-scoped; a reset, opt-out, remote pause, or stricter project
     * policy makes it permanently stale.
     */
    suspend fun executeCall(
        token: String,
        authority: CallAuthority,
        call: Call,
    ): Response = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { runCatching { call.cancel() } }
        val admitted = try {
            synchronized(mutationLock) {
                if (!callAllowedLocked(token, authority)) return@synchronized false
                enqueueLocked(
                    call,
                    object : Callback {
                        override fun onFailure(call: Call, e: IOException) {
                            unregister(call)
                            if (continuation.isActive) {
                                continuation.resumeWith(Result.failure(e))
                            }
                        }

                        override fun onResponse(call: Call, response: Response) {
                            unregister(call)
                            if (continuation.isActive) {
                                continuation.resume(response)
                            } else {
                                response.close()
                            }
                        }
                    },
                )
                true
            }
        } catch (t: Throwable) {
            if (continuation.isActive) continuation.resumeWith(Result.failure(t))
            true
        }
        if (!admitted && continuation.isActive) {
            runCatching { call.cancel() }
            continuation.resumeWith(Result.failure(CallRejectedException()))
        }
    }

    /** Publish local session state only while its network grant is current. */
    fun runIfCallAllowed(
        token: String,
        authority: CallAuthority,
        block: () -> Unit,
    ): Boolean = synchronized(mutationLock) {
        if (!callAllowedLocked(token, authority)) return@synchronized false
        block()
        true
    }

    /**
     * Re-open the local privacy gate without trusting the policy snapshot that
     * predates the opt-out/consent-silent interval. The control-plane loop must
     * apply a fresh `/init` or `/config` response before replay or an upload
     * worker becomes eligible again.
     */
    fun resumeAwaitingFreshPolicy() = synchronized(mutationLock) {
        val next = state.get().copy(
            resolved = false,
            enabled = false,
            sampleRateFraction = 0.0,
            captureOnCellular = false,
            maskInputs = true,
            privacyAllowed = true,
        )
        state.set(next)
        publish(next)
    }

    /**
     * Hard privacy boundary. Rotating first invalidates every already-enqueued
     * replay worker; restoring consent later cannot resurrect the old token.
     */
    fun hardPrivacyDeny() = synchronized(mutationLock) {
        rotateLocked(privacyAllowed = false)
    }

    /** Logout/reset boundary while collection itself remains permitted. */
    fun rotateIdentityBoundary() = synchronized(mutationLock) {
        // Read the privacy bit under the same mutation lock. Reading it first
        // and passing it into a later locked rotate lets a concurrent opt-out
        // win between those operations and then get accidentally re-enabled.
        rotateLocked(privacyAllowed = state.get().privacyAllowed)
    }

    private fun rotateLocked(privacyAllowed: Boolean) {
        val next = state.get().let {
            it.copy(generation = it.generation + 1L, privacyAllowed = privacyAllowed)
        }
        state.set(next)
        publish(next)
        // Synchronous persistence is intentional: a process kill immediately
        // after opt-out/reset must not restore an old worker generation.
        persistGeneration(next.generation)
        retireArtifactsLocked()
    }

    private fun publish(snapshot: Snapshot) {
        stateUpdates.value = snapshot
        registry[scope] = this
    }

    private fun callAllowedLocked(token: String, authority: CallAuthority): Boolean {
        val parsed = parseToken(token) ?: return false
        if (parsed.first != scope) return false
        val live = state.get()
        if (parsed.second != live.generation || !live.resolved || !live.privacyAllowed) {
            return false
        }
        return authority == CallAuthority.CLEANUP || live.enabled
    }

    private fun enqueueLocked(call: Call, callback: Callback) {
        activeCalls += call
        try {
            // Deliberately under mutationLock: registration without enqueue
            // would leave a cancel-before-enqueue window after optOut returns.
            call.enqueue(callback)
        } catch (t: Throwable) {
            activeCalls.remove(call)
            throw t
        }
    }

    private fun unregister(call: Call) {
        synchronized(mutationLock) { activeCalls.remove(call) }
    }

    private fun retireArtifactsLocked() {
        val calls = activeCalls.toList()
        activeCalls.clear()
        calls.forEach { runCatching { it.cancel() } }
        runCatching(purgeReplayArtifacts)
    }

    private suspend fun executeWorkerCall(
        tokenGeneration: Long,
        connected: Boolean,
        metered: Boolean,
        cleanupAuthority: Boolean,
        call: Call,
    ): WorkerCallResult = suspendCancellableCoroutine { continuation ->
        continuation.invokeOnCancellation { runCatching { call.cancel() } }
        var decision = WorkerDecision.DISCARD
        try {
            synchronized(mutationLock) {
                decision = if (cleanupAuthority) {
                    decideCleanup(state.get(), tokenGeneration)
                } else {
                    decide(
                        live = state.get(),
                        tokenGeneration = tokenGeneration,
                        connected = connected,
                        metered = metered,
                    )
                }
                if (decision == WorkerDecision.UPLOAD) {
                    enqueueLocked(
                        call,
                        object : Callback {
                            override fun onFailure(call: Call, e: IOException) {
                                unregister(call)
                                if (continuation.isActive) {
                                    continuation.resumeWith(Result.failure(e))
                                }
                            }

                            override fun onResponse(call: Call, response: Response) {
                                unregister(call)
                                if (continuation.isActive) {
                                    continuation.resume(WorkerCallResult.Executed(response))
                                } else {
                                    response.close()
                                }
                            }
                        },
                    )
                }
            }
        } catch (t: Throwable) {
            if (continuation.isActive) continuation.resumeWith(Result.failure(t))
            return@suspendCancellableCoroutine
        }
        if (decision != WorkerDecision.UPLOAD && continuation.isActive) {
            runCatching { call.cancel() }
            continuation.resume(WorkerCallResult.Rejected(decision))
        }
    }

    companion object {
        private const val PREFS_NAME = "io.kixo.sdk.replay.runtime_policy"
        private const val GENERATION_PREFIX = "generation_"
        private const val POLICY_FINGERPRINT_PREFIX = "policy_fingerprint_"
        private val registry = ConcurrentHashMap<String, ReplayRuntimePolicy>()

        fun create(
            context: Context,
            environment: String,
            apiHost: String,
            projectId: String,
            bundleId: String,
            privacyAllowed: Boolean,
        ): ReplayRuntimePolicy {
            val scope = scopeFor(environment, apiHost, projectId, bundleId)
            val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val generation = prefs.getLong(GENERATION_PREFIX + scope, 0L)
            val policyFingerprint = prefs.getString(POLICY_FINGERPRINT_PREFIX + scope, null)
            val replayOptedOut = ReplayOptOutStore.isOptedOut(context, projectId)
            // One-time compatibility cleanup for pre-boundary SDKs that moved
            // permanent 4xx frames into a global, collision-prone directory.
            runCatching {
                File(context.cacheDir, "kixo-replay/failed").deleteRecursively()
            }
            return ReplayRuntimePolicy(
                scope = scope,
                initialGeneration = generation,
                initialPrivacyAllowed = privacyAllowed && !replayOptedOut,
                initialPolicyFingerprint = policyFingerprint,
                persistGeneration = { value ->
                    // commit(), not apply(): see rotate()'s process-kill
                    // ordering contract. A failed write still leaves the
                    // in-process registry safely rotated.
                    runCatching {
                        prefs.edit().putLong(GENERATION_PREFIX + scope, value).commit()
                    }
                },
                persistResolvedPolicy = { value, fingerprint ->
                    runCatching {
                        prefs.edit()
                            .putLong(GENERATION_PREFIX + scope, value)
                            .putString(POLICY_FINGERPRINT_PREFIX + scope, fingerprint)
                            .commit()
                    }
                },
                purgeReplayArtifacts = {
                    // Raw pixels and the crash-recovery identity breadcrumb
                    // are both retired before a privacy/reset boundary returns.
                    runCatching {
                        File(context.cacheDir, "kixo-replay").deleteRecursively()
                    }
                    runCatching {
                        File(context.filesDir, "kixo/replay-events").deleteRecursively()
                    }
                    runCatching {
                        context.getSharedPreferences(
                            io.kixo.sdk.internal.replay.upload.ReplayPendingEndStore.PREFS_NAME,
                            Context.MODE_PRIVATE,
                        ).edit().clear().commit()
                    }
                },
                onCellularLoosened = { policy ->
                    ReplayPendingUploadStore.rescheduleAllForCellular(
                        context = context,
                        runtimePolicy = policy,
                    )
                },
                onRestoredPolicyResolved = { policy, captureOnCellular ->
                    ReplayPendingUploadStore.reconcileAll(
                        context = context,
                        runtimePolicy = policy,
                        captureOnCellular = captureOnCellular,
                    )
                },
            )
        }

        /** WorkManager-side live decision; unknown process policy waits. */
        fun workerDecision(
            token: String?,
            connected: Boolean,
            metered: Boolean,
        ): WorkerDecision {
            val parsed = parseToken(token) ?: return WorkerDecision.DISCARD
            val policy = registry[parsed.first]
                ?: return WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY
            return synchronized(policy.mutationLock) {
                decide(
                    live = policy.state.get(),
                    tokenGeneration = parsed.second,
                    connected = connected,
                    metered = metered,
                )
            }
        }

        /**
         * WorkManager's decision, call registration, and enqueue are one
         * indivisible policy operation. A preceding diagnostic decision is
         * never treated as authority to open a later socket.
         */
        suspend fun executeWorkerCall(
            token: String?,
            connected: Boolean,
            metered: Boolean,
            call: Call,
        ): WorkerCallResult {
            val parsed = parseToken(token)
                ?: return WorkerCallResult.Rejected(WorkerDecision.DISCARD)
            val policy = registry[parsed.first]
                ?: return WorkerCallResult.Rejected(WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY)
            return policy.executeWorkerCall(
                tokenGeneration = parsed.second,
                connected = connected,
                metered = metered,
                cleanupAuthority = false,
                call = call,
            )
        }

        /** Durable session/end worker gate; replay may be disabled, privacy may not. */
        suspend fun executeWorkerCleanupCall(
            token: String?,
            call: Call,
        ): WorkerCallResult {
            val parsed = parseToken(token)
                ?: return WorkerCallResult.Rejected(WorkerDecision.DISCARD)
            val policy = registry[parsed.first]
                ?: return WorkerCallResult.Rejected(WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY)
            return policy.executeWorkerCall(
                tokenGeneration = parsed.second,
                connected = true,
                metered = false,
                cleanupAuthority = true,
                call = call,
            )
        }

        /** Apply a data-plane pause only if the reporting worker is current. */
        fun denyWorkerTokenUntilFreshPolicy(token: String?): Boolean {
            val parsed = parseToken(token) ?: return false
            val policy = registry[parsed.first] ?: return false
            return synchronized(policy.mutationLock) {
                if (policy.state.get().generation != parsed.second) return@synchronized false
                policy.denyUntilFreshRemotePolicy()
                true
            }
        }

        @VisibleForTesting
        internal fun decide(
            live: Snapshot,
            tokenGeneration: Long,
            connected: Boolean,
            metered: Boolean,
        ): WorkerDecision = when {
            tokenGeneration != live.generation -> WorkerDecision.DISCARD
            !live.privacyAllowed -> WorkerDecision.DISCARD
            !live.resolved -> WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY
            !live.enabled -> WorkerDecision.DISCARD
            !connected -> WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY
            metered && !live.captureOnCellular ->
                WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY
            else -> WorkerDecision.UPLOAD
        }

        private fun decideCleanup(live: Snapshot, tokenGeneration: Long): WorkerDecision = when {
            tokenGeneration != live.generation -> WorkerDecision.DISCARD
            !live.privacyAllowed -> WorkerDecision.DISCARD
            !live.resolved -> WorkerDecision.WAIT_FOR_NETWORK_OR_POLICY
            else -> WorkerDecision.UPLOAD
        }

        @VisibleForTesting
        internal fun createForTesting(
            scope: String,
            generation: Long = 0L,
            privacyAllowed: Boolean = true,
            policyFingerprint: String? = null,
            onPersistGeneration: (Long) -> Unit = {},
            onPersistResolvedPolicy: (Long, String) -> Unit = { _, _ -> },
            onPurgeReplayArtifacts: () -> Unit = {},
            onCellularLoosened: (ReplayRuntimePolicy) -> Unit = {},
            onRestoredPolicyResolved: (ReplayRuntimePolicy, Boolean) -> Unit = { _, _ -> },
        ): ReplayRuntimePolicy = ReplayRuntimePolicy(
            scope = scope,
            initialGeneration = generation,
            initialPrivacyAllowed = privacyAllowed,
            initialPolicyFingerprint = policyFingerprint,
            persistGeneration = onPersistGeneration,
            persistResolvedPolicy = onPersistResolvedPolicy,
            purgeReplayArtifacts = onPurgeReplayArtifacts,
            onCellularLoosened = onCellularLoosened,
            onRestoredPolicyResolved = onRestoredPolicyResolved,
        )

        @VisibleForTesting
        internal fun resetForTesting() {
            registry.values.toSet().forEach { policy ->
                synchronized(policy.mutationLock) { policy.retireArtifactsLocked() }
            }
            registry.clear()
        }

        private fun parseToken(token: String?): Pair<String, Long>? {
            if (token.isNullOrBlank()) return null
            val separator = token.lastIndexOf(':')
            if (separator <= 0 || separator == token.lastIndex) return null
            val generation = token.substring(separator + 1).toLongOrNull() ?: return null
            return token.substring(0, separator) to generation
        }

        private fun fingerprint(snapshot: Snapshot): String = listOf(
            snapshot.enabled,
            snapshot.sampleRateFraction.toBits(),
            snapshot.captureOnCellular,
            snapshot.maskInputs,
        ).joinToString("|")

        private data class PersistedPolicy(
            val enabled: Boolean,
            val sampleRateFraction: Double,
            val captureOnCellular: Boolean,
            val maskInputs: Boolean,
        )

        private fun parseFingerprint(value: String?): PersistedPolicy? {
            val parts = value?.split('|') ?: return null
            if (parts.size != 4) return null
            val enabled = parts[0].toBooleanStrictOrNull() ?: return null
            val rateBits = parts[1].toLongOrNull() ?: return null
            val rate = Double.fromBits(rateBits)
            if (!rate.isFinite() || rate !in 0.0..1.0) return null
            val cellular = parts[2].toBooleanStrictOrNull() ?: return null
            val maskInputs = parts[3].toBooleanStrictOrNull() ?: return null
            return PersistedPolicy(enabled, rate, cellular, maskInputs)
        }

        private fun isTightening(previous: PersistedPolicy, candidate: Snapshot): Boolean =
            (previous.enabled && !candidate.enabled) ||
                (!previous.maskInputs && candidate.maskInputs) ||
                (previous.captureOnCellular && !candidate.captureOnCellular) ||
                candidate.sampleRateFraction < previous.sampleRateFraction

        private fun scopeFor(
            environment: String,
            apiHost: String,
            projectId: String,
            bundleId: String,
        ): String {
            val raw = listOf(environment, apiHost.trimEnd('/'), projectId, bundleId)
                .joinToString("\u001f")
            val digest = MessageDigest.getInstance("SHA-256")
                .digest(raw.toByteArray(Charsets.UTF_8))
            return digest.take(16).joinToString("") { "%02x".format(it) }
        }
    }
}
