package io.kixo.sdk.internal.model

import kotlinx.serialization.Serializable

/**
 * Typed mirror of the `data_collection` payload returned by
 * `POST /api/sdk/init`. Wire shape lives at
 * `kixo-backend/apps/web/src/lib/sdk/data-collection-defaults.ts`.
 *
 * **Coverage fix (May 2026).** Previously the SDK parsed the entire
 * `data_collection` blob as a raw `JsonObject` and never routed it
 * anywhere — operator dashboard toggles were 100% no-op on Android.
 * This type + [io.kixo.sdk.internal.queue.DataCollectionHolder] +
 * the per-subsystem emit-time gating restored full coverage.
 *
 * Every field is nullable so the SDK can distinguish:
 *  - server affirmatively SET `false`  → suppress
 *  - server affirmatively SET `true`   → allow
 *  - server DIDN'T SEND the field      → fall back to safe default
 *
 * The convention across all consumers is **default-allow on null** —
 * if the server didn't ship `data_collection.core.pageViews`, we
 * still record page views. The conservative degradation is for the
 * `paused` flag only, which is read separately by the queue's
 * lifecycle machine.
 */
@Serializable
internal data class DataCollection(
    val paused: Boolean? = null,
    val core: CoreConfig? = null,
    val engagement: EngagementConfig? = null,
    val performance: PerformanceConfig? = null,
    val heatmaps: HeatmapsConfig? = null,
    val replay: ReplayDataConfig? = null,
    val device: DeviceConfig? = null,
    val privacy: PrivacyConfig? = null,
    val attribution: AttributionConfig? = null,
    val screenshots: ScreenshotsConfig? = null,
    val identity: IdentityConfig? = null,
    val push: PushConfig? = null,
) {
    @Serializable internal data class CoreConfig(
        val pageViews: Boolean? = null,
        val sessions: Boolean? = null,
        val errors: Boolean? = null,
    )

    @Serializable internal data class EngagementConfig(
        val clicks: Boolean? = null,
        val scrollDepth: Boolean? = null,
        val forms: Boolean? = null,
        val rageClicks: Boolean? = null,
        val deadClicks: Boolean? = null,
        val engagementTime: Boolean? = null,
        val refreshLoop: Boolean? = null,
    )

    @Serializable internal data class PerformanceConfig(
        val webVitals: Boolean? = null,
        val networkRequests: Boolean? = null,
        val resourceErrors: Boolean? = null,
        val perfBudget: Boolean? = null,
    )

    @Serializable internal data class HeatmapsConfig(
        val clicks: Boolean? = null,
        val mouseMovement: Boolean? = null,
        val scrollDepth: Boolean? = null,
    )

    @Serializable internal data class ReplayDataConfig(
        val enabled: Boolean? = null,
        // Server emits 0-100 percent; ReplayController honours via
        // `/100` to get a 0-1 fraction the Sampler expects.
        val sampleRate: Double? = null,
        val maskInputs: Boolean? = null,
    )

    @Serializable internal data class DeviceConfig(
        val hardwareInfo: Boolean? = null,
        val connectionInfo: Boolean? = null,
        val batteryInfo: Boolean? = null,
        val context: Boolean? = null,
        val lifecycle: Boolean? = null,
    )

    @Serializable internal data class PrivacyConfig(
        val collectIPs: Boolean? = null,
        val geoLocation: Boolean? = null,
        val userAgent: Boolean? = null,
    )

    @Serializable internal data class AttributionConfig(
        val enabled: Boolean? = null,
        val clickIds: Boolean? = null,
        val utm: Boolean? = null,
        val referrer: Boolean? = null,
    )

    @Serializable internal data class ScreenshotsConfig(
        val enabled: Boolean? = null,
        val quality: Int? = null,
        val maxWidth: Int? = null,
        val excludedScreens: List<String>? = null,
    )

    @Serializable internal data class IdentityConfig(
        val collectEmail: Boolean? = null,
        val collectPhone: Boolean? = null,
        val collectName: Boolean? = null,
        val collectLocation: Boolean? = null,
        val collectPushTokens: Boolean? = null,
        val hashPiiBeforeStorage: Boolean? = null,
    )

    @Serializable internal data class PushConfig(
        val enabled: Boolean? = null,
        // "full" | "preview" | "hash_only" — see
        // `io.kixo.sdk.internal.push.ContentMode`.
        val contentMode: String? = null,
        val titlePreviewChars: Int? = null,
        val bodyPreviewChars: Int? = null,
    )
}
