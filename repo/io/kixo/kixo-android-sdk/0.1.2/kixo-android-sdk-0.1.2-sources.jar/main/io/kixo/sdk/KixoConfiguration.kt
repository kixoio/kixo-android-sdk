package io.kixo.sdk

import android.content.Context
import android.content.pm.ApplicationInfo

/**
 * Configuration for the Kixo SDK. Constructed via [Builder] (Kotlin
 * DSL or Java fluent), then handed to [Kixo.configure].
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Configuration.swift`
 * (`ConfigurationOptions` / `Configuration` pair). On iOS the two are
 * separate — `ConfigurationOptions` is public, `Configuration` is
 * internal. On Android we collapse to one public class, keep the
 * tunables exposed, and slot the `projectId` / `apiKey` parsing into
 * the same place.
 *
 * **Why a Builder, not a `data class` with default arguments?** The
 * config has 18+ fields, most with reasonable defaults. A Kotlin
 * data-class call site like:
 * ```
 * KixoConfiguration("kx_proj_…", "kx_key_…", autoTrackTaps = true,
 *     replaySampleRate = 0.05, maxBufferSize = 200, …)
 * ```
 * doesn't read well past 5-6 named arguments and is hostile to Java
 * callers (who'd need to thread defaults manually since named
 * arguments aren't a Java feature). The Builder pattern stays
 * idiomatic for both languages and gives Java a clean fluent API.
 *
 * **Idempotency contract:** [Kixo.configure] is idempotent — passing
 * a different [KixoConfiguration] on a second call from the same
 * process is a WARN-logged no-op. So the values frozen here on the
 * FIRST call are the ones that govern the SDK lifetime.
 *
 * **Internal-only:** this class is **not** `@Serializable` — it
 * never crosses the wire. All wire-format DTOs live under
 * `io.kixo.sdk.internal.model` (Agent 2 owns).
 */
public class KixoConfiguration private constructor(
    /**
     * Project identifier (`kx_proj_…`). Issued in the dashboard
     * "SDK keys" panel. Required; the Builder rejects empty values.
     */
    public val projectId: String,

    /**
     * API key (`kx_key_…`). Public-by-design ingest credential —
     * paired to [projectId] on the backend.
     *
     * **Not secret.** The customer's mobile app ships this in their
     * compiled APK; anyone unzipping the APK can read it. The
     * backend's anomaly detection layer protects against abuse —
     * this is the same model as Segment's `writeKey` and Mixpanel's
     * project token. See briefing R10 — this is why we never rotate
     * "leaked" SDK keys.
     */
    public val apiKey: String,

    /**
     * Resolved environment string — `"development"` / `"staging"` /
     * `"production"` / custom. Drives `defaultApiHost` selection.
     * See [Builder.environment] for the auto-detection logic.
     */
    public val environment: String,

    /**
     * Resolved ingest host (e.g. `"https://sdk.dev.kixo.io"`). All
     * SDK endpoints are built as `"$apiHost/api/sdk/<path>"`.
     */
    public val apiHost: String,

    /**
     * If true, the SDK logs verbose diagnostic messages via
     * `android.util.Log` (`Log.d("Kixo", …)`). Auto-detected from
     * the host app's `applicationInfo.flags & FLAG_DEBUGGABLE` —
     * release builds default to `false`.
     */
    public val debug: Boolean,

    // ─── Auto-tracking flags ────────────────────────────────────

    /**
     * Auto-emit `screen_view` events on every Activity/Fragment
     * resume + Compose nav-graph destination change. Default `true`.
     */
    public val autoTrackScreens: Boolean,

    /**
     * Auto-classify [MotionEvent]s into the gesture taxonomy
     * (tap/long_press/swipe/multi_tap/pinch/scroll_end) per
     * briefing R7 and emit `tap` / `long_press` / etc events.
     * Default `true`.
     */
    public val autoTrackTaps: Boolean,

    /**
     * **Deprecated — no-op since alpha14.** Network auto-tracking via
     * an SDK-shipped `OkHttpInterceptor` is on the roadmap but not in
     * this release. Setting this flag has no effect; no `network`
     * events are emitted from Android. The flag stays on the public
     * API for source-compatibility with hosts that already wired it,
     * but will be removed in a future major version. For HTTP
     * observability today, instrument your own `Interceptor` and call
     * `Kixo.track("network", mapOf("url" to ..., "status" to ...))`.
     */
    @Deprecated(
        message = "Network auto-tracking is not implemented on Android. " +
            "Setting this flag has no effect. Will be removed in a future major release.",
        level = DeprecationLevel.WARNING,
    )
    public val autoTrackNetwork: Boolean,

    /** Install crash + ANR handlers and emit `crash` events. */
    public val autoTrackCrashes: Boolean,

    /**
     * Maintain a session boundary based on [sessionTimeoutMillis] of
     * background-time and emit `session_start` / `session_end` events.
     */
    public val autoTrackSessions: Boolean,

    /**
     * Wrap FCM `MessagingService` and `Activity.onCreate` notification
     * intent extraction; emit `push_received` / `push_open` /
     * `push_dismissed`. Safe no-op when the host app doesn't use
     * push at all. Default `true`.
     */
    public val autoTrackPush: Boolean,

    /**
     * Seconds (in ms) after a `push_open` during which subsequent
     * events inherit push attribution properties (`kixo_campaign_id`,
     * `kixo_delivery_id`). Default 30 minutes — matches iOS.
     */
    public val pushAttributionWindowMillis: Long,

    /**
     * Background-time threshold (ms) after which the next foreground
     * starts a new `session_id`. Default 30 seconds — matches iOS.
     */
    public val sessionTimeoutMillis: Long,

    // ─── Queue tunables ─────────────────────────────────────────

    /**
     * Periodic flush cadence (ms). The queue flushes whenever
     * [flushAt] events accumulate OR this many ms elapse, whichever
     * fires first. Default 30 seconds — matches iOS.
     */
    public val flushIntervalMillis: Long,

    /**
     * Event-count threshold that triggers an immediate flush (without
     * waiting for [flushIntervalMillis]). Default 20 — matches iOS.
     */
    public val flushAt: Int,

    /**
     * Maximum number of events the in-memory + SQLite queue will
     * hold before it starts dropping the OLDEST event (FIFO). Caps
     * memory growth during extended backend outages.
     *
     * 200 is a deliberate conservative default per iOS — typical
     * mobile users generate 10-50 events per session, so 200 covers
     * ~5-7 full sessions of buffered backlog. Hosts that need to
     * preserve more on long outages bump this; hosts paranoid
     * about memory pull it down.
     *
     * **Trade-off:** thundering-herd protection (when our servers
     * recover) does NOT come from this cap — it comes from the
     * jittered retry schedule in the queue. A larger cap doesn't
     * hurt the backend any more than a smaller one; it just buys
     * more loss tolerance per client.
     */
    public val maxBufferSize: Int,

    // ─── Replay ─────────────────────────────────────────────────

    /**
     * Master replay switch. Default OFF — opting in is explicit.
     * When `true`, the replay subsystem starts after `/api/sdk/init`
     * returns the `release_id`. Replay falls back to a no-op on
     * devices that don't pass the device-tier check (Agent 13 owns).
     */
    public val replayEnabled: Boolean,

    /**
     * Reservoir baseline sample rate (0.0..1.0). Independent of
     * trigger-based capture (rage-click / crash override the
     * reservoir on a per-session basis). Stickiness on-device:
     * the same install always records or always doesn't, with
     * re-roll-on-rate-increase semantics. See iOS `Sampler.swift`.
     *
     * Clamped to `[0.0, 1.0]` in [Builder.replaySampleRate].
     */
    public val replaySampleRate: Double,

    /**
     * When `false` (default), replay frame uploads pause on cellular
     * and resume on Wi-Fi. Frames still spill to disk so no data is
     * lost; only the radio cost is gated.
     */
    public val replayCaptureOnCellular: Boolean,
) {

    /**
     * Builder for [KixoConfiguration]. Required: [projectId] and
     * [apiKey] (passed to the Builder constructor — they have no
     * meaningful default). Everything else has a default.
     *
     * Kotlin idiom — `apply` block:
     * ```
     * val config = KixoConfiguration.Builder("kx_proj_…", "kx_key_…")
     *     .autoTrackScreens(true)
     *     .replayEnabled(false)
     *     .build()
     * ```
     *
     * Java idiom — fluent calls:
     * ```
     * KixoConfiguration config = new KixoConfiguration.Builder("kx_proj_…", "kx_key_…")
     *     .autoTrackScreens(true)
     *     .replayEnabled(false)
     *     .build();
     * ```
     */
    public class Builder(
        private val projectId: String,
        private val apiKey: String,
    ) {
        // ─── Defaults — match iOS ConfigurationOptions ──────────
        private var environment: String? = null
        private var apiHost: String? = null
        private var debug: Boolean? = null

        private var autoTrackScreens: Boolean = true
        private var autoTrackTaps: Boolean = true
        private var autoTrackNetwork: Boolean = true
        private var autoTrackCrashes: Boolean = true
        private var autoTrackSessions: Boolean = true
        private var autoTrackPush: Boolean = true
        private var pushAttributionWindowMillis: Long = 30L * 60 * 1000  // 30 min
        private var sessionTimeoutMillis: Long = 30L * 1000              // 30 s

        private var flushIntervalMillis: Long = 30L * 1000               // 30 s
        private var flushAt: Int = 20
        private var maxBufferSize: Int = 200

        private var replayEnabled: Boolean = false
        private var replaySampleRate: Double = 0.05
        private var replayCaptureOnCellular: Boolean = false

        /**
         * Override the auto-detected environment. Pass one of
         * `"development"` / `"staging"` / `"production"`, or a custom
         * tag your backend recognises (e.g. `"qa"`, `"preprod"`).
         *
         * When NOT set, [build] auto-detects from `Context.applicationInfo`:
         *   - `FLAG_DEBUGGABLE` set → `"development"`
         *   - otherwise → `"production"`
         *
         * Custom tags route to the production host UNLESS [apiHost] is
         * also set explicitly — same behaviour as iOS.
         */
        public fun environment(environment: String): Builder = apply {
            this.environment = environment
        }

        /**
         * Override the resolved ingest host. By default [build] picks
         * from environment:
         *   - `"development"` → `https://sdk.dev.kixo.io`
         *   - `"staging"`     → `https://sdk.staging.kixo.io`
         *   - everything else → `https://sdk.kixo.io`
         *
         * Hosts that need a custom backend (self-hosted Kixo, on-prem)
         * pass an explicit URL here. Trailing `/` is stripped to keep
         * URL concatenation `"$apiHost/api/sdk/init"` clean.
         */
        public fun apiHost(apiHost: String): Builder = apply {
            this.apiHost = apiHost.trimEnd('/')
        }

        /**
         * Override the auto-detected debug flag. By default [build]
         * derives from `Context.applicationInfo.flags & FLAG_DEBUGGABLE` —
         * release builds (Play Store / App Bundles) get `false`,
         * debuggable builds get `true`.
         *
         * Setting this to `true` in a release build floods Logcat with
         * SDK diagnostic output — useful only when reproducing customer
         * issues with their permission.
         */
        public fun debug(debug: Boolean): Builder = apply { this.debug = debug }

        public fun autoTrackScreens(enabled: Boolean): Builder = apply {
            this.autoTrackScreens = enabled
        }

        public fun autoTrackTaps(enabled: Boolean): Builder = apply {
            this.autoTrackTaps = enabled
        }

        /**
         * **Deprecated — no-op since alpha14.** See
         * [KixoConfiguration.autoTrackNetwork]. Kept on the Builder
         * for source-compatibility; will be removed in a future
         * major release.
         */
        @Deprecated(
            message = "Network auto-tracking is not implemented on Android. " +
                "This setter has no effect. Will be removed in a future major release.",
            level = DeprecationLevel.WARNING,
        )
        public fun autoTrackNetwork(enabled: Boolean): Builder = apply {
            this.autoTrackNetwork = enabled
        }

        public fun autoTrackCrashes(enabled: Boolean): Builder = apply {
            this.autoTrackCrashes = enabled
        }

        public fun autoTrackSessions(enabled: Boolean): Builder = apply {
            this.autoTrackSessions = enabled
        }

        public fun autoTrackPush(enabled: Boolean): Builder = apply {
            this.autoTrackPush = enabled
        }

        /** @param millis Push attribution window length, in ms. */
        public fun pushAttributionWindowMillis(millis: Long): Builder = apply {
            require(millis >= 0) { "pushAttributionWindowMillis must be >= 0" }
            this.pushAttributionWindowMillis = millis
        }

        /** @param millis Background-time before a new session starts. */
        public fun sessionTimeoutMillis(millis: Long): Builder = apply {
            require(millis >= 0) { "sessionTimeoutMillis must be >= 0" }
            this.sessionTimeoutMillis = millis
        }

        /** @param millis Periodic flush cadence (ms). */
        public fun flushIntervalMillis(millis: Long): Builder = apply {
            require(millis > 0) { "flushIntervalMillis must be > 0" }
            this.flushIntervalMillis = millis
        }

        /** @param count Event-count threshold to flush immediately. */
        public fun flushAt(count: Int): Builder = apply {
            require(count > 0) { "flushAt must be > 0" }
            this.flushAt = count
        }

        /**
         * @param size Max queue size before FIFO drops kick in. We
         * honour the host's value as-is; we considered clamping
         * upward to [flushAt] (so a batch could always assemble
         * before drops kick in) but that hid surprises — a host
         * setting `maxBufferSize: 10` deserves to see those drops
         * immediately rather than the SDK silently overriding.
         * Same rationale as iOS.
         */
        public fun maxBufferSize(size: Int): Builder = apply {
            require(size > 0) { "maxBufferSize must be > 0" }
            this.maxBufferSize = size
        }

        public fun replayEnabled(enabled: Boolean): Builder = apply {
            this.replayEnabled = enabled
        }

        /**
         * @param rate Replay reservoir sample rate. Clamped to
         * `[0.0, 1.0]` — values outside this range are coerced
         * silently rather than thrown so a config typo doesn't
         * crash the host app at init.
         */
        public fun replaySampleRate(rate: Double): Builder = apply {
            this.replaySampleRate = rate.coerceIn(0.0, 1.0)
        }

        public fun replayCaptureOnCellular(allowed: Boolean): Builder = apply {
            this.replayCaptureOnCellular = allowed
        }

        /**
         * Materialise the [KixoConfiguration]. Auto-detection runs
         * here so a Builder constructed before `Application.onCreate`
         * still picks up the right environment when [Kixo.configure]
         * lands.
         *
         * @param context Application context — used solely for the
         *   environment + debug auto-detection. NOT held by the
         *   resulting [KixoConfiguration]. Pass `applicationContext`
         *   to avoid Activity leaks.
         */
        public fun build(context: Context): KixoConfiguration {
            require(projectId.isNotBlank()) { "projectId must not be blank" }
            require(apiKey.isNotBlank()) { "apiKey must not be blank" }

            val resolvedEnvironment = environment ?: detectEnvironment(context)
            val resolvedApiHost = apiHost ?: defaultApiHost(resolvedEnvironment)
            val resolvedDebug = debug ?: detectDebug(context)

            return KixoConfiguration(
                projectId = projectId,
                apiKey = apiKey,
                environment = resolvedEnvironment,
                apiHost = resolvedApiHost,
                debug = resolvedDebug,
                autoTrackScreens = autoTrackScreens,
                autoTrackTaps = autoTrackTaps,
                autoTrackNetwork = autoTrackNetwork,
                autoTrackCrashes = autoTrackCrashes,
                autoTrackSessions = autoTrackSessions,
                autoTrackPush = autoTrackPush,
                pushAttributionWindowMillis = pushAttributionWindowMillis,
                sessionTimeoutMillis = sessionTimeoutMillis,
                flushIntervalMillis = flushIntervalMillis,
                flushAt = flushAt,
                maxBufferSize = maxBufferSize,
                replayEnabled = replayEnabled,
                replaySampleRate = replaySampleRate,
                replayCaptureOnCellular = replayCaptureOnCellular,
            )
        }
    }

    public companion object {
        /**
         * Default ingest host per environment. Hosts wanting a
         * custom backend pass `apiHost` explicitly via [Builder.apiHost];
         * everything else falls into these three buckets. `staging`
         * is reserved — Kixo doesn't have a staging cluster yet, but
         * baking it in now keeps the contract stable when that env
         * lands. Matches iOS `defaultApiHost(for:)`.
         */
        @JvmStatic
        public fun defaultApiHost(environment: String): String =
            io.kixo.sdk.internal.KixoEndpoints.forEnvironment(environment)

        /**
         * Returns the default environment string.
         *
         * **v0.1.2: always `"production"`.** Previously this auto-promoted
         * debuggable builds to `"development"` via `FLAG_DEBUGGABLE`,
         * which leaked any customer's debug-build events to Kixo's
         * internal dev backend instead of their own Kixo project on
         * prod. The fix is intentionally global — debug AND release
         * builds default to prod. Internal-team SDK development
         * routes to dev only via an explicit
         * `KixoConfiguration.Builder(...).environment("development")`.
         *
         * The `context` parameter is unused since v0.1.2 but retained
         * on the signature for binary compatibility with hosts that
         * already wired it.
         */
        @JvmStatic
        @Suppress("UNUSED_PARAMETER")
        public fun detectEnvironment(context: Context): String = "production"

        /**
         * Default `debug` value. Mirrors the environment auto-detect:
         * debuggable builds get verbose logging, release builds stay
         * quiet so an end-user's Logcat isn't flooded.
         */
        @JvmStatic
        public fun detectDebug(context: Context): Boolean = isDebuggable(context)

        private fun isDebuggable(context: Context): Boolean {
            return try {
                (context.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
            } catch (t: Throwable) {
                // Defensive — never crash the host on a malformed
                // applicationInfo. Treat unknown as production
                // (safer default — release behaviour).
                false
            }
        }
    }
}
