package io.kixo.sdk.internal.replay.upload

import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Bitmap → byte[] encoders for replay frames. Default output is JPEG
 * because the universal-decode floor on Android is JPEG (every API
 * level since 1.x), and the player uses standard `<img>` tags.
 *
 * **Why not HEIC** (the iOS default):
 *  - `Bitmap.CompressFormat.HEIF` ships only on **API 28+** (per
 *    Android docs). Our minSdk is 24 — silent decode failures on
 *    Android 7/8 would leave gaps in the replay.
 *  - Player browsers also need to decode HEIF; Chrome/Firefox don't
 *    ship a native HEIF decoder yet (May 2026), so the dashboard
 *    would need to transcode server-side anyway. Round trip = no win.
 *  - WebP at API 18+ is the next-best efficiency tier; we expose
 *    [encodeWebp] for hosts willing to trade the compatibility tail
 *    for ~25% smaller payloads. JPEG stays the default.
 *
 * **Quality knob:** 85 is the perceptual sweet spot we calibrated
 * against the iOS HEIC q=0.20 frames — at 1080×2400 the JPEG sits
 * around ~70 KB versus HEIC's ~30 KB. Comfortably under the backend
 * signed-URL `maxBytes=250000` cap (see iOS `BackgroundUploader`'s
 * `GCS_REPLAY_CONTENT_LENGTH_RANGE`). If the cap drifts later, dial
 * quality down here — the cap value lives in [UploadWorker].
 *
 * **Off-main:** `Bitmap.compress` is CPU-heavy (~30-80 ms on a
 * mid-range device for a full-screen frame). All callers must invoke
 * from a coroutine on `Dispatchers.IO` or a worker — never from the
 * UI thread (briefing R6 — never block main > 16 ms).
 */
internal object JpegEncoder {

    /**
     * Encode a [Bitmap] to a JPEG byte array. Returns `null` only on
     * a `Bitmap.compress` failure (rare — almost always OOM under
     * memory pressure) so the caller can drop the frame instead of
     * uploading garbage.
     *
     * @param quality 0..100, JPEG perceptual quality. Default 85
     *        matches iOS HEIC q=0.20 at the byte level (within ~10%).
     */
    fun encodeJpeg(bitmap: Bitmap, quality: Int = 85): ByteArray? {
        // Defensive bounds-check rather than `require` — a config
        // typo shouldn't crash the host app (R6).
        val safeQuality = quality.coerceIn(1, 100)
        return try {
            ByteArrayOutputStream(estimateBufferSize(bitmap)).use { stream ->
                val ok = bitmap.compress(Bitmap.CompressFormat.JPEG, safeQuality, stream)
                if (!ok) {
                    Log.w(TAG, "JPEG encode returned false (OOM?) — dropping frame")
                    return null
                }
                stream.toByteArray()
            }
        } catch (t: Throwable) {
            // OutOfMemoryError, IOException — both swallow + log.
            // Replay is best-effort; one missing frame is fine.
            Log.w(TAG, "JPEG encode threw — dropping frame", t)
            null
        }
    }

    /**
     * Optional WebP encoder. Available on API 18+ for `WEBP` lossy
     * (every API our minSdk=24 covers) and API 30+ for `WEBP_LOSSY`
     * with explicit quality control. Falls back to the legacy
     * `WEBP` constant on older API levels.
     *
     * Hosts that want ~25% smaller frames at the cost of slightly
     * older browser-decoder support can switch by setting
     * `Configuration.replayFrameFormat = "webp"` (Agent 13's knob).
     * The default stays JPEG.
     */
    fun encodeWebp(bitmap: Bitmap, quality: Int = 80): ByteArray? {
        val safeQuality = quality.coerceIn(1, 100)
        val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+: WEBP_LOSSY honours the quality int directly.
            Bitmap.CompressFormat.WEBP_LOSSY
        } else {
            // API 24-29: legacy WEBP also honours quality (lossy mode).
            // The newer constant is a Google soft-deprecation warning
            // we silence with @Suppress at the call site.
            @Suppress("DEPRECATION")
            Bitmap.CompressFormat.WEBP
        }
        return try {
            ByteArrayOutputStream(estimateBufferSize(bitmap)).use { stream ->
                val ok = bitmap.compress(format, safeQuality, stream)
                if (!ok) {
                    Log.w(TAG, "WebP encode returned false — dropping frame")
                    return null
                }
                stream.toByteArray()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "WebP encode threw — dropping frame", t)
            null
        }
    }

    /**
     * Persist a byte array to disk atomically (write to `.tmp`, then
     * rename) so a crash mid-write never leaves a half-baked staging
     * file that [UploadWorker] would then PUT to GCS.
     *
     * Returns `true` on success. On failure the partial file is
     * removed — the upload will simply not be scheduled.
     */
    fun ByteArray.writeToFile(file: File): Boolean {
        // Make sure the parent dir exists; cacheDir/<sessionId>/ may
        // not have been created yet on the very first frame.
        val parent = file.parentFile
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            Log.w(TAG, "Failed to create cache parent dir ${parent.absolutePath}")
            return false
        }
        val tmp = File(file.parentFile, file.name + ".tmp")
        return try {
            FileOutputStream(tmp).use { it.write(this) }
            // `renameTo` on Android is atomic on the same filesystem
            // (which cacheDir always is) — UploadWorker will only
            // ever see the final filename.
            if (!tmp.renameTo(file)) {
                tmp.delete()
                Log.w(TAG, "Atomic rename failed for ${file.absolutePath}")
                false
            } else {
                true
            }
        } catch (t: Throwable) {
            tmp.delete()
            Log.w(TAG, "Failed to write ${file.absolutePath}", t)
            false
        }
    }

    /**
     * Heuristic initial buffer size: JPEG of a 1080×2400 frame at
     * q=85 is ~70-100 KB. Sizing the [ByteArrayOutputStream] up
     * front avoids 4-5 reallocations during compress (each one
     * doubles + memcpys). Cap at 1 MB so a giant Bitmap doesn't
     * pre-allocate more than necessary.
     */
    private fun estimateBufferSize(bitmap: Bitmap): Int {
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        // Rough rule: ~3 bytes/100 pixels at q=85.
        val estimate = (pixels * 3L / 100L).toInt().coerceAtLeast(8 * 1024)
        return estimate.coerceAtMost(1024 * 1024)
    }

    private const val TAG = "Kixo.JpegEncoder"
}
