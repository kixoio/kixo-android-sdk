package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Sentry-style enriched device context, sent **once per batch** so
 * the backend receives a single unified envelope across iOS / Android
 * / Web. Mirrors iOS `EnrichedContext` ([Context/EnrichedContext.swift]).
 *
 * The wire shape is: `{ device, os, runtime, hardware, app, culture,
 * browser? }`. `browser` is always null for native (iOS+Android) and
 * carries the user agent for the web SDK only. We keep the field on
 * the Android model for cross-platform parity but it MUST stay null
 * here — the field is omitted from the wire shape entirely when null
 * thanks to `encodeDefaults = false` on the parent encoder
 * configuration (Agent 4 owns transport).
 *
 * **All sub-field names are snake_case on the wire** (AGENT_BRIEFING.md
 * R3). Field order follows the iOS source so a side-by-side diff is
 * readable.
 */
@Serializable
internal data class EnrichedContext(
    @SerialName("device") val device: DeviceContext,
    @SerialName("os") val os: OSContext,
    @SerialName("browser") val browser: BrowserContext? = null,
    @SerialName("runtime") val runtime: RuntimeContext,
    @SerialName("hardware") val hardware: HardwareContext,
    @SerialName("app") val app: AppContext,
    @SerialName("culture") val culture: CultureContext? = null,
) {

    @Serializable
    internal data class DeviceContext(
        @SerialName("family") val family: String,
        @SerialName("model") val model: String,
        @SerialName("brand") val brand: String,
        @SerialName("type") val type: String,
        @SerialName("screen_width_px") val screenWidthPx: Int,
        @SerialName("screen_height_px") val screenHeightPx: Int,
        @SerialName("screen_density") val screenDensity: Double,
        @SerialName("orientation") val orientation: String,
        @SerialName("device_hash") val deviceHash: String? = null,
        @SerialName("device_class") val deviceClass: String,
        @SerialName("kernel_version") val kernelVersion: String? = null,
        @SerialName("boot_time") val bootTime: String? = null,
        @SerialName("is_simulator") val isSimulator: Boolean,
    )

    @Serializable
    internal data class OSContext(
        @SerialName("name") val name: String,
        @SerialName("version") val version: String,
        @SerialName("build") val build: String? = null,
        @SerialName("is_rooted") val isRooted: Boolean? = null,
    )

    /**
     * Always nil for native iOS / Android (no browser); kept for
     * wire-shape parity with the web SDK.
     */
    @Serializable
    internal data class BrowserContext(
        @SerialName("name") val name: String,
        @SerialName("version") val version: String,
    )

    @Serializable
    internal data class RuntimeContext(
        @SerialName("language") val language: String,
        @SerialName("languages") val languages: List<String>,
        @SerialName("timezone") val timezone: String,
    )

    @Serializable
    internal data class HardwareContext(
        @SerialName("memory_gb") val memoryGb: Int,
        @SerialName("cpu_cores") val cpuCores: Int,
        @SerialName("max_touch_points") val maxTouchPoints: Int,
        @SerialName("connection_type") val connectionType: String? = null,
        @SerialName("connection_downlink") val connectionDownlink: Double? = null,
        @SerialName("free_memory") val freeMemory: Double? = null,
        @SerialName("usable_memory") val usableMemory: Double? = null,
        @SerialName("battery_level") val batteryLevel: Float? = null,
        @SerialName("battery_temperature") val batteryTemperature: Float? = null,
        @SerialName("is_charging") val isCharging: Boolean? = null,
        @SerialName("processor_count") val processorCount: Int,
        @SerialName("free_storage") val freeStorage: Double? = null,
        @SerialName("storage_size") val storageSize: Double? = null,
        @SerialName("archs") val archs: List<String>? = null,
        @SerialName("brand") val brand: String,
        @SerialName("manufacturer") val manufacturer: String,
        @SerialName("screen_dpi") val screenDpi: Int? = null,
        @SerialName("low_memory") val lowMemory: Boolean? = null,
        @SerialName("thermal_state") val thermalState: String? = null,
        @SerialName("carrier") val carrier: String? = null,
    )

    @Serializable
    internal data class AppContext(
        @SerialName("version") val version: String,
        @SerialName("build") val build: String,
        @SerialName("bundle_id") val bundleId: String,
        @SerialName("name") val name: String,
        @SerialName("build_type") val buildType: String? = null,
        @SerialName("start_time") val startTime: String? = null,
        @SerialName("in_foreground") val inForeground: Boolean? = null,
    )

    @Serializable
    internal data class CultureContext(
        @SerialName("locale") val locale: String,
        @SerialName("calendar") val calendar: String,
        @SerialName("uses_24h_format") val uses24hFormat: Boolean,
        @SerialName("region") val region: String? = null,
    )
}
