package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Response body from `POST /api/sdk/batch`. Mirrors the shape parsed
 * in iOS `Transport.sendBatchWithAcks` ([Transport.swift] ~ line 168)
 * exactly:
 *
 * ```json
 * {
 *   "success": true,
 *   "accepted": 17,
 *   "accepted_event_ids": ["…", "…"],
 *   "errors": [
 *     { "index": 3, "event_id":"…", "message":"…", "permanent": true }
 *   ]
 * }
 * ```
 *
 * Plus the optional kill-switch fields the backend may return when
 * the SDK version is disabled (see backend `route.ts` ~ line 115):
 *
 * ```json
 * { "success": true, "accepted": 0, "paused": true,
 *   "paused_reason": "sdk_version_disabled" }
 * ```
 *
 * **Per-event ack contract (R5 Mixpanel-MPDB pattern):**
 *
 *  - Event-id in [acceptedEventIds] → DELETE from local store.
 *  - Event-id in [errors] with `permanent=true` → DELETE (no retry
 *    will help; client is misconfigured or the event is malformed).
 *  - Event-id in [errors] with `permanent=false` → reset SQLite
 *    `flag=0` so the event retries on the next flush tick.
 *  - Event-id present in the request batch but missing from BOTH
 *    arrays → defensive `transientFail` (per iOS Transport line
 *    ~200), so we re-enqueue rather than silently lose data when
 *    the backend has a bug.
 *
 * The Kotlin queue (Agent 5) implements this partitioning. The DTO
 * here only carries the wire shape.
 *
 * **Empty-list defaults**: both `accepted_event_ids` and `errors`
 * may be omitted entirely when the batch is empty / kill-switched.
 * We default to `emptyList()` so callers can iterate without null
 * checks. `accepted` is also defaulted because the kill-switch
 * branch returns `accepted: 0` but a transport-level 5xx may not
 * include the field at all (we synthesize it from the response).
 */
@Serializable
internal data class BatchResponse(
    @SerialName("success")
    val success: Boolean = false,

    @SerialName("accepted")
    val accepted: Int = 0,

    @SerialName("accepted_event_ids")
    val acceptedEventIds: List<String> = emptyList(),

    @SerialName("errors")
    val errors: List<BatchError> = emptyList(),

    /**
     * Set true when the backend wants the SDK to stop sending
     * (kill-switch / version disabled / temporary maintenance).
     * On true, the SDK transitions to `pausedByServer`, drops
     * future events silently, and refetches `/api/sdk/init`
     * periodically to recover.
     */
    @SerialName("paused")
    val paused: Boolean? = null,

    /**
     * Free-form reason code when [paused] is true. Known values:
     *   - `"sdk_version_disabled"` (most common)
     *   - `"below_min_sdk_version"`
     *   - `"maintenance"`
     * Unknown values mean "stop sending" all the same.
     */
    @SerialName("paused_reason")
    val pausedReason: String? = null,
) {

    /**
     * Per-event error payload inside [errors]. `index` is the slot
     * in the request `batch[]` array (0-based); `event_id` mirrors
     * the per-event UUID from the request so the queue can match
     * unambiguously even if the slot index drifts.
     */
    @Serializable
    internal data class BatchError(
        @SerialName("index")
        val index: Int? = null,

        @SerialName("event_id")
        val eventId: String,

        @SerialName("message")
        val message: String,

        @SerialName("permanent")
        val permanent: Boolean = false,
    )
}
