package io.kixo.sdk

/**
 * Read-only health snapshot of the running SDK. Surfaces enough
 * state for a host engineer to answer "why aren't my events
 * reaching the dashboard?" without a debugger:
 *
 *   - Buffer size (events not yet flushed)
 *   - Whether we're in retry / cooldown
 *   - Server-side `paused` kill-switch state
 *   - Lifecycle state (initialising / running / recovering / paused)
 *   - Whether the SDK was even initialised
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Diagnostics.swift`. Returned
 * by [Kixo.diagnostics] — host apps dump it onto a debug screen or
 * to their own crash reporter to triage SDK-flow issues without
 * running Kixo under a debugger.
 *
 * The data class is intentionally a value type; all properties are
 * stable, JSON-friendly types so a host can serialise the snapshot
 * to their own crash-reporter / log aggregation without us caring
 * about lifetime.
 */
public data class KixoDiagnostics(
    /**
     * Top-level "is the SDK alive" flag. False when [Kixo.configure]
     * was never called or threw mid-init.
     */
    val initialised: Boolean,

    /**
     * Server-controlled kill-switch from `/api/sdk/init`. `true`
     * means events are being dropped at enqueue time. Equivalent to
     * `lifecycleState == "pausedByServer"` — kept as a separate
     * boolean for parity with the iOS API and ease of one-line
     * debug-screen rendering.
     */
    val paused: Boolean,

    /**
     * Auto-detected environment (`"development"` / `"staging"` /
     * `"production"`) or whatever the host explicitly passed.
     * Empty string when [initialised] is false.
     */
    val environment: String,

    /**
     * Resolved API host the SDK is targeting. Empty string when
     * [initialised] is false. Matches the host the next batch will
     * POST to (`<apiHost>/api/sdk/batch`).
     */
    val apiHost: String,

    /**
     * Current SDK lifecycle state — one of `"initialising"`,
     * `"running"`, `"recovering"`, `"pausedByServer"`. Strings
     * (rather than an enum) so callers can deserialise the snapshot
     * from JSON without holding the enum type at compile time.
     *
     * State machine docs live next to [Kixo]'s internal lifecycle
     * field. The transitions are:
     *
     *   - **initialising** — SDK constructed; `/api/sdk/init` not yet
     *     resolved. Events buffer to the queue but flush is gated.
     *   - **running** — normal operation; queue flushing on cadence.
     *   - **recovering** — too many consecutive batch failures;
     *     pivoted to re-fetching `/api/sdk/init` to learn whether to
     *     resume, stay paused, or keep retrying.
     *   - **pausedByServer** — server returned `paused: true`.
     *     Events drop at the enqueue gate (NOT buffered) until the
     *     next config refresh returns active again.
     */
    val lifecycleState: String,

    /**
     * Wall-clock millis (epoch) of the most recent successful flush,
     * or `null` if no batch has been accepted by the server yet.
     * Useful for "time since events last reached the backend" UIs.
     */
    val lastFlushAtMillis: Long?,

    /**
     * Last error string from the transport layer, or `null` if no
     * failure has occurred. Capped at ~256 chars by the queue (so a
     * stack trace doesn't bloat this snapshot). Diagnostic only —
     * the SDK does NOT surface this to end-users.
     */
    val lastError: String?,

    /** Current event-queue health. */
    val queue: QueueHealth,
) {
    /**
     * Health of the SQLite + in-memory event queue. Mirrors iOS
     * `KixoDiagnostics.QueueHealth`.
     */
    public data class QueueHealth(
        /**
         * Events currently buffered (in-memory + SQLite combined)
         * waiting to flush.
         */
        val bufferedEventCount: Int,

        /**
         * Max events the queue holds before FIFO-dropping the
         * oldest. Default 200, overridable via
         * [KixoConfiguration.Builder.maxBufferSize].
         */
        val bufferCap: Int,

        /**
         * Consecutive flush failures since the last 2xx response.
         * Resets to 0 on success.
         */
        val consecutiveFailures: Int,

        /** True while a flush is in flight (single-flight gate). */
        val isFlushing: Boolean,

        /**
         * Which retry tier the state machine is in:
         *
         *   - `"healthy"` — no failures, normal flushInterval cadence
         *   - `"rapid"`   — failures 1–10, exponential backoff (5–60s)
         *   - `"slow"`    — failures 11–29, 60-second heartbeat
         *   - `"cooldown"`— failures 30+, 30-minute heartbeat (also
         *     triggers the lifecycle pivot to `"recovering"`)
         */
        val retryTier: String,
    )

    public companion object {
        /**
         * "Disabled" diagnostics returned when [Kixo.configure] was
         * never called — keeps the API non-throwing without forcing
         * the host to handle nullables.
         */
        @JvmField
        public val Uninitialised: KixoDiagnostics = KixoDiagnostics(
            initialised = false,
            paused = false,
            environment = "",
            apiHost = "",
            lifecycleState = "uninitialised",
            lastFlushAtMillis = null,
            lastError = null,
            queue = QueueHealth(
                bufferedEventCount = 0,
                bufferCap = 0,
                consecutiveFailures = 0,
                isFlushing = false,
                retryTier = "healthy",
            ),
        )
    }
}
