package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.util.Log
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.Response
import java.io.File
import java.io.IOException
import kotlin.coroutines.resume

/**
 * WorkManager-backed PUT of a previously-staged frame to a GCS
 * signed URL. Reading inputs from [WorkerParameters.inputData]:
 *
 *  - `signed_url` — the GCS signed PUT URL
 *  - `local_file_path` — absolute path to the staging file written
 *    by [JpegEncoder.writeToFile] (or [StructuralEncoder] then
 *    written via the same path).
 *  - `content_type` — `Content-Type` header for the PUT
 *
 * **Why WorkManager (vs raw OkHttp from a coroutine):**
 *  - **Survives process death.** Android can kill our process
 *    seconds after the user backgrounds the app — coroutines die
 *    with it. WorkManager persists the work request via SQLite,
 *    and re-enqueues when the process restarts. iOS achieves the
 *    same via background URLSession; WorkManager is the canonical
 *    Android equivalent.
 *  - **System-managed backoff.** WorkManager's
 *    `BackoffPolicy.EXPONENTIAL` handles transient failures with
 *    OS-native scheduling — it cooperates with Doze, App Standby,
 *    and battery savers, none of which our own retry loop would
 *    respect.
 *  - **Network constraints.** [androidx.work.Constraints] gates
 *    execution on `NetworkType.CONNECTED` (or `.UNMETERED` when
 *    the customer disabled cellular replay) — we don't burn the
 *    user's data plan when wifi-only is configured.
 *
 * **Returning Result:**
 *  - 2xx → [Result.success]; the staging file is deleted (the
 *    only copy of the frame, no longer needed).
 *  - 4xx (except 429) → [Result.failure]; the upload is
 *    permanently dropped. The signed URL is dead — retrying would
 *    only hit the same 4xx. The staging file is moved to a
 *    `failed/` directory for forensics (analogous to iOS).
 *  - 429 / 5xx / network → [Result.retry]; WorkManager applies its
 *    own backoff schedule.
 *
 * **Anti-crash:** every failure path swallows + logs (R6). A
 * worker exception would propagate to WorkManager's status as
 * `FAILED` — not a host crash — but we still prefer a clean
 * Result.failure return so the dashboard's worker-status badge
 * is meaningful.
 *
 * **OkHttpClient injection:** the worker is constructed by
 * WorkManager's reflective factory, so we can't pass dependencies
 * at construction. We pull the shared client from
 * [UploadWorkerSingletons.httpClient] which the SDK's bootstrap
 * pre-populates. Tests override it via the same hook.
 */
internal class UploadWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): androidx.work.ListenableWorker.Result {
        val signedUrl = inputData.getString(KEY_SIGNED_URL)
        val localPath = inputData.getString(KEY_LOCAL_FILE_PATH)
        val contentType = inputData.getString(KEY_CONTENT_TYPE) ?: "application/octet-stream"
        // Wave 9 — per-call max_bytes (echoed back from the sign
        // route by the SDK). Falls back to the default cap when an
        // older ReplayUploader didn't supply it (shouldn't happen
        // in-process, but defends against stale enqueued work
        // surviving an SDK upgrade).
        val maxBytes = inputData.getLong(KEY_MAX_BYTES, DEFAULT_MAX_BYTES)

        if (signedUrl.isNullOrBlank() || localPath.isNullOrBlank()) {
            // Permanent failure — caller built the work request wrong.
            // No retry will ever fix missing inputs; log so the bug is
            // visible in dev.
            Log.w(TAG, "Missing signed_url or local_file_path — failing")
            return androidx.work.ListenableWorker.Result.failure()
        }

        val file = File(localPath)
        if (!file.exists() || file.length() == 0L) {
            // The staging file vanished between scheduling and
            // execution — likely because the cache was cleared. Not
            // a retryable condition.
            Log.w(TAG, "Staging file missing or empty: $localPath")
            return androidx.work.ListenableWorker.Result.failure()
        }

        val client = UploadWorkerSingletons.httpClient
            ?: run {
                // SDK isn't initialised in this process — pre-warm
                // failure. Retry on the off chance the host process
                // re-inits before WorkManager retries us.
                Log.w(TAG, "HttpClient unavailable; retrying")
                return androidx.work.ListenableWorker.Result.retry()
            }

        return when (val outcome = putFile(client, signedUrl, file, contentType, maxBytes)) {
            is PutOutcome.Success -> {
                // Frame landed safely; staging file no longer needed.
                if (!file.delete()) {
                    Log.d(TAG, "Couldn't delete staging file: $localPath")
                }
                androidx.work.ListenableWorker.Result.success()
            }
            is PutOutcome.PermanentFailure -> {
                // 4xx (signed URL expired, content-length-range
                // violation, etc.). Move to failed/ for forensics.
                moveToFailed(file)
                androidx.work.ListenableWorker.Result.failure()
            }
            is PutOutcome.TransientFailure -> {
                // 429/5xx/network — let WorkManager back off.
                Log.d(TAG, "Transient failure (${outcome.reason}); retrying via WorkManager")
                androidx.work.ListenableWorker.Result.retry()
            }
        }
    }

    private suspend fun putFile(
        client: OkHttpClient,
        signedUrl: String,
        file: File,
        contentType: String,
        maxBytes: Long,
    ): PutOutcome = withContext(Dispatchers.IO) {
        val body = file.asRequestBody(contentType.toMediaType())
        val req = Request.Builder()
            .url(signedUrl)
            .put(body)
            .header("Content-Type", contentType)
            // GCS V4 signed URLs require x-goog-content-length-range
            // to match the value the signer placed in extension
            // headers — bit-for-bit. Wave 9 plumbs the cap from the
            // sign-route response via [KEY_MAX_BYTES] so a future
            // server-side bump (e.g. allow larger structural
            // sidecars) doesn't require a coordinated SDK release.
            // Mismatched strings — even by ONE byte — break the V4
            // signature and produce 403.
            .header(HEADER_GCS_RANGE, "0,$maxBytes")
            .build()

        val response: Response = try {
            executeAsync(client.newCall(req))
        } catch (e: IOException) {
            return@withContext PutOutcome.TransientFailure("IOException: ${e.message}")
        } catch (t: Throwable) {
            return@withContext PutOutcome.TransientFailure("unexpected: ${t.message}")
        }

        response.use { resp ->
            val code = resp.code
            when {
                code in 200..299 -> PutOutcome.Success
                code == 429 || code in 500..599 -> PutOutcome.TransientFailure("HTTP $code")
                code in 400..499 -> PutOutcome.PermanentFailure(code)
                else -> PutOutcome.TransientFailure("unexpected HTTP $code")
            }
        }
    }

    /**
     * Move a staging file to `<cacheDir>/kixo-replay/failed/` for
     * forensics. Matches the iOS `BackgroundUploader.moveToFailed`
     * pattern — operators occasionally need to inspect why a frame
     * stopped uploading.
     */
    private fun moveToFailed(file: File) {
        try {
            val failedRoot = File(applicationContext.cacheDir, "kixo-replay/failed")
            if (!failedRoot.exists()) failedRoot.mkdirs()
            val dest = File(failedRoot, file.name)
            if (!file.renameTo(dest)) {
                file.delete()
            }
        } catch (t: Throwable) {
            // Best-effort — if even the move fails, just delete the
            // staging file. We never crash the worker on cleanup.
            try { file.delete() } catch (_: Throwable) {}
        }
    }

    private suspend fun executeAsync(call: Call): Response =
        suspendCancellableCoroutine { cont ->
            cont.invokeOnCancellation {
                runCatching { call.cancel() }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    // CoroutineWorker drags ListenableWorker.Result into
                    // scope and shadows kotlin.Result — fully qualify.
                    if (cont.isActive) cont.resumeWith(kotlin.Result.failure(e))
                }
                override fun onResponse(call: Call, response: Response) {
                    if (cont.isActive) cont.resume(response)
                }
            })
        }

    private sealed interface PutOutcome {
        data object Success : PutOutcome
        data class PermanentFailure(val code: Int) : PutOutcome
        data class TransientFailure(val reason: String) : PutOutcome
    }

    companion object {
        const val KEY_SIGNED_URL = "signed_url"
        const val KEY_LOCAL_FILE_PATH = "local_file_path"
        const val KEY_CONTENT_TYPE = "content_type"

        /**
         * Wave 9 — per-call cap echoed back from the sign route.
         * Stored as a `Long` (Data only supports a fixed set of
         * primitives — no Int width games). Defaults to
         * [DEFAULT_MAX_BYTES] when missing.
         */
        const val KEY_MAX_BYTES = "max_bytes"

        private const val HEADER_GCS_RANGE = "x-goog-content-length-range"

        /**
         * Fallback cap when [KEY_MAX_BYTES] isn't in inputData
         * (rare — stale work enqueued by an older ReplayUploader
         * surviving an SDK upgrade). 20 KB is the canonical
         * replay-frame cap across all platforms (iOS, Android,
         * web) — see backend `REPLAY_FRAME_MAX_BYTES` constant in
         * `apps/web/src/app/api/sdk/replay/session/start/route.ts`.
         */
        private const val DEFAULT_MAX_BYTES: Long = 20_000L

        private const val TAG = "Kixo.UploadWorker"
    }
}

/**
 * WorkManager constructs workers via reflection so we can't inject
 * dependencies through the constructor. The SDK's bootstrap
 * (Agent 7) pokes the shared OkHttp client into this object once
 * per process; the worker reads it on `doWork`.
 *
 * **Why an `object` not a [androidx.work.WorkerFactory]:** a
 * custom factory requires the host app to wire it into their
 * WorkManager.initialize call. We don't want to require ANY host
 * setup beyond `Kixo.configure(...)`. The trade-off is that the
 * dependency lookup is "implicit" — but it's documented here +
 * tests can override.
 */
internal object UploadWorkerSingletons {
    @Volatile var httpClient: OkHttpClient? = null
}
