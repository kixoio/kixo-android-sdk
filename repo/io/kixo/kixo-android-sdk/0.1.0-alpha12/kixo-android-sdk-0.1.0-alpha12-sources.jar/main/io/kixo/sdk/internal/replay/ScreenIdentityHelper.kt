package io.kixo.sdk.internal.replay

/**
 * Bridge between the replay capture pipeline and Agent 9's screen
 * tracker.
 *
 * **Why this exists separately from a direct call:** Agent 9's
 * [io.kixo.sdk.internal.screen.ScreenTracker] is the canonical
 * source of "what's the current screen identity hash" but Agent 13
 * (replay) needs to:
 *  1. Stamp the identity onto every captured frame so the upload
 *     pipeline (Agent 14) can JOIN replay frames to flow events on
 *     the dashboard player.
 *  2. Detect "same screen as last tap" so [ReplayController] can
 *     dedup uploads and skip redundant OCR work (matches iOS
 *     `lastScreenIdentity` / `buildHashDedup`).
 *
 * Holding a `ScreenTracker` reference would force Agent 13 to
 * compile against another agent's folder. Instead we accept a
 * lambda — the only surface we need.
 *
 * **Stub interface.** When Agent 9 publishes the canonical
 * `currentScreenFingerprint(): String?` accessor, [ReplayController]
 * binds it via `ScreenIdentityHelper(screenTracker::currentFingerprint)`.
 * Until then, [ReplayController] supplies a `{ null }` lambda and
 * the dedup path simply never triggers — the upload pipeline still
 * works, it just sends a frame for every tap regardless of whether
 * the screen changed.
 *
 * **Hash format:** lower-case hex, 16 chars. Matches Agent 9's
 * [io.kixo.sdk.internal.screen.ScreenFingerprint] FNV-1a output and
 * also matches [StructuralSnapshotter.stableHash].
 */
internal class ScreenIdentityHelper(
    /**
     * Returns the current screen's structural fingerprint (16-char
     * hex) from Agent 9's screen tracker, or `null` when no screen
     * is registered yet (cold start, before first
     * `Activity.onResume`).
     */
    private val fingerprintProvider: () -> String? = { null },
) {

    /**
     * Snapshot the current screen identity. Called once per
     * captured frame so the upload pipeline can JOIN frames to flow
     * events. Returns `null` when no screen has been registered yet.
     *
     * Idempotent + cheap — Agent 9's tracker caches the fingerprint
     * per Activity, so this is an `AtomicReference.get()` on the hot
     * path.
     */
    fun currentScreenIdentity(): ScreenIdentity? {
        val fp = fingerprintProvider() ?: return null
        if (fp.isEmpty()) return null
        return ScreenIdentity(hash = fp)
    }

    /**
     * Whether the current screen identity differs from a previously
     * recorded one. Used by [ReplayController] for the
     * `lastScreenIdentity` dedup gate (matches iOS C.3 v3
     * `buildHashDedupEnabled = false` default — kept here as an
     * opt-in ops can flip via [ReplayConfig]).
     *
     * Returns `true` when EITHER the previous identity was null OR
     * the hashes differ. Returns `false` when both are present + equal.
     */
    fun hasChangedSince(previous: ScreenIdentity?): Boolean {
        val current = currentScreenIdentity() ?: return previous != null
        if (previous == null) return true
        return current.hash != previous.hash
    }
}

/**
 * Type-safe wrapper around the screen-identity hash so we don't
 * accidentally pass an event fingerprint or a node hash where a
 * screen hash was expected. Equality + hashCode delegate to the
 * underlying [hash] string so this is cheap to use as a Map key.
 *
 * @param hash 16-char lower-case hex from FNV-1a over the role+type
 *   tree. Guaranteed non-empty by [ScreenIdentityHelper.currentScreenIdentity].
 */
internal data class ScreenIdentity(val hash: String) {
    init {
        require(hash.isNotEmpty()) { "ScreenIdentity.hash must be non-empty" }
    }
}
