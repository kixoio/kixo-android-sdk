package io.kixo.sdk.internal.lifecycle

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.res.Configuration
import android.util.Log
import io.kixo.sdk.internal.model.KixoEventType
import kotlinx.coroutines.flow.MutableSharedFlow

/**
 * Bridges [ComponentCallbacks2.onTrimMemory] into:
 *   1. A `memory_warning` lifecycle event emitted to the EventQueue
 *      (so customers can see in-dashboard heatmaps of which app
 *      states correlate with memory pressure).
 *   2. A `Flow<MemoryPressure>` published on
 *      [KixoInternalBootstrap.memoryPressure] that other in-process
 *      subsystems collect — chiefly the replay subsystem (Agent 13)
 *      which mirrors iOS `ReplayController.lowMemoryMode`: drops
 *      pending capture posts and caps capture concurrency to 1 until
 *      the device recovers.
 *
 * **iOS parity context:** the iOS C.3v3 fix (April 28 2026 — see
 * MEMORY.md "iOS Session Replay v1 + v2 + Journey v2.0") added an
 * explicit memory-warning handler that drops `pendingPost` and
 * enters `lowMemoryMode` (capture concurrency cap = 1). Android's
 * equivalent signal is `onTrimMemory` rather than a single iOS
 * `didReceiveMemoryWarning` notification — the level granularity is
 * richer here and we map it down to a NORMAL/LOW/CRITICAL trichotomy
 * that other modules can react to without caring about the underlying
 * Android constants.
 *
 * Why we do NOT surface `TRIM_MEMORY_RUNNING_MODERATE`: that level
 * fires aggressively on some OEM ROMs (Xiaomi MIUI in particular)
 * even when the device has gigabytes of headroom, and over-reacting
 * to it would needlessly degrade replay quality. We only react when
 * the system tells us things are actually low or critical.
 *
 * Why we map `TRIM_MEMORY_UI_HIDDEN` to a transition emit instead of
 * a memory_warning: `TRIM_MEMORY_UI_HIDDEN` is the system telling us
 * the app went to background — it's a hint to release UI-only
 * resources and is NOT a memory-pressure signal. The
 * [ProcessLifecycleObserver] already emits app_background for the
 * UI signal; we'd be double-counting if we treated this as memory
 * pressure too.
 *
 * Wire shape of `memory_warning`:
 * ```
 * event_type=lifecycle, event_name=memory_warning,
 * properties = { "level": "RUNNING_LOW" | "RUNNING_CRITICAL" |
 *                         "COMPLETE" | "BACKGROUND" | "UI_HIDDEN" }
 * ```
 * The level string is the human-readable Android constant name (no
 * `TRIM_MEMORY_` prefix) — keeps the wire shape introspectable
 * without forcing the backend to memorise the integer mapping.
 */
internal class MemoryWarningObserver(
    @Suppress("unused") private val application: Application,
    private val pressureSink: MutableSharedFlow<MemoryPressure>,
    private val bus: LifecycleEventBus = LifecycleEventBus,
) : ComponentCallbacks2 {

    /**
     * Last published pressure level — used to debounce a NORMAL emit
     * after a LOW/CRITICAL so collectors don't flap.
     */
    @Volatile
    private var lastPressure: MemoryPressure = MemoryPressure.NORMAL

    override fun onTrimMemory(level: Int) {
        val (pressure, label) = classify(level)

        // Always emit the wire event (so the backend dashboard can
        // see the full history of trim signals), but only republish
        // on the in-process Flow when the pressure level actually
        // changes — collectors don't need a stream of identical LOWs
        // every few seconds.
        if (pressure != null) {
            try {
                bus.emit(
                    LifecycleEvent(
                        eventType = KixoEventType.Lifecycle,
                        eventName = "memory_warning",
                        properties = mapOf(
                            "level" to label,
                            "raw_level" to level,
                        ),
                    )
                )
            } catch (t: Throwable) {
                Log.w(TAG, "memory_warning emit failed", t)
            }

            if (pressure != lastPressure) {
                lastPressure = pressure
                // tryEmit on a SharedFlow with extraBufferCapacity > 0
                // never blocks and never throws; if the buffer is full
                // (every collector is dead-slow) we drop the event
                // rather than risk an ANR.
                pressureSink.tryEmit(pressure)
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        // No-op. Configuration changes (locale, orientation, dark mode)
        // are irrelevant for memory tracking.
    }

    override fun onLowMemory() {
        // Pre-API 14 callback. On modern Android this fires alongside
        // onTrimMemory(TRIM_MEMORY_COMPLETE) on devices below the
        // OOM threshold — treat the same as critical pressure.
        onTrimMemory(ComponentCallbacks2.TRIM_MEMORY_COMPLETE)
    }

    /**
     * Map an Android trim level into a [MemoryPressure] + a wire
     * label. Returns `null` pressure for levels we deliberately
     * don't surface.
     */
    private fun classify(level: Int): Pair<MemoryPressure?, String> {
        return when (level) {
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW ->
                MemoryPressure.LOW to "RUNNING_LOW"
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ->
                MemoryPressure.CRITICAL to "RUNNING_CRITICAL"
            ComponentCallbacks2.TRIM_MEMORY_COMPLETE ->
                MemoryPressure.CRITICAL to "COMPLETE"
            // Levels we deliberately ignore for the pressure flow:
            ComponentCallbacks2.TRIM_MEMORY_RUNNING_MODERATE ->
                MemoryPressure.NORMAL to "RUNNING_MODERATE"
            ComponentCallbacks2.TRIM_MEMORY_BACKGROUND ->
                null to "BACKGROUND"
            ComponentCallbacks2.TRIM_MEMORY_MODERATE ->
                null to "MODERATE"
            ComponentCallbacks2.TRIM_MEMORY_UI_HIDDEN ->
                null to "UI_HIDDEN"
            else ->
                null to "UNKNOWN_$level"
        }
    }

    private companion object {
        private const val TAG = "Kixo"
    }
}
