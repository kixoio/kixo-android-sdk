package io.kixo.sdk.internal.model

import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import java.time.Instant

/**
 * Single Kixo event as it travels on the wire. Mirrors iOS
 * `KixoEvent` ([Models/Event.swift]) one-for-one — same fields, same
 * snake_case JSON keys, same nullability contract.
 *
 * **Wire format (AGENT_BRIEFING.md §4 + R3):**
 * ```
 * {
 *   "event_id": "uuid",
 *   "device_id": "uuid",
 *   "anonymous_id": "uuid",
 *   "user_id": null | "string",
 *   "session_id": "uuid",
 *   "fingerprint": "hex",
 *   "event_type": "screen_view|tap|...",
 *   "event_name": "string",
 *   "properties": { ... },
 *   "timestamp": "ISO8601",
 *   "context": { "platform":"android", ... }
 * }
 * ```
 *
 * **Critical contracts:**
 *
 *  - `user_id` MUST serialize as `"user_id": null` when the end-user
 *    is unidentified, NOT be omitted from the JSON. The backend
 *    `EventInputSchema` treats absent vs null differently for
 *    PARTITION KEY purposes (anonymous_id-only sessions). We force
 *    this with `@EncodeDefault(EncodeDefault.Mode.ALWAYS)` so the
 *    parent encoder's `encodeDefaults = false` setting (used to
 *    keep optional `EnrichedContext` sub-fields slim) does not
 *    accidentally drop nulls here.
 *
 *  - `timestamp` is the wall-clock instant the event was generated
 *    on the device (NOT when it was queued or shipped). Use
 *    `System.currentTimeMillis()` → `Instant.ofEpochMilli`. Per
 *    briefing anti-example §11, never use `SystemClock.elapsedRealtime`
 *    — that is a monotonic boot-relative tick, useless for analytics.
 *
 *  - `properties` is an arbitrary `JsonObject`. The public-API call
 *    site converts a `Map<String, Any?>` via [toJsonElement] BEFORE
 *    constructing this DTO. By the time we reach this type the data
 *    has already passed the type guard.
 *
 *  - `event_id` is the per-event UUID we hand back to the SQLite
 *    event store as the primary key. It MUST round-trip into the
 *    backend's `accepted_event_ids[]` response so the queue can
 *    DELETE the right rows (R5 Mixpanel-MPDB pattern).
 */
@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
@Serializable
internal data class KixoEvent(
    @SerialName("event_id")
    val eventId: String,

    @SerialName("device_id")
    val deviceId: String,

    @SerialName("anonymous_id")
    val anonymousId: String,

    /**
     * Nullable when the SDK has no `Kixo.identify(userId, ...)` yet.
     * Always serialized — `"user_id": null` not absent.
     */
    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("user_id")
    val userId: String? = null,

    @SerialName("session_id")
    val sessionId: String,

    /**
     * Structural-fingerprint hash for the event surface. For
     * `screen_view` this is the `ScreenFingerprint` FNV-1a over the
     * view-hierarchy roles. For other events the originator picks a
     * stable hex string (often the same screen fingerprint).
     */
    @SerialName("fingerprint")
    val fingerprint: String,

    @SerialName("event_type")
    val eventType: KixoEventType,

    @SerialName("event_name")
    val eventName: String,

    @SerialName("properties")
    val properties: JsonObject,

    @Serializable(with = Iso8601InstantSerializer::class)
    @SerialName("timestamp")
    val timestamp: Instant,

    @SerialName("context")
    val context: EventContext,
)
