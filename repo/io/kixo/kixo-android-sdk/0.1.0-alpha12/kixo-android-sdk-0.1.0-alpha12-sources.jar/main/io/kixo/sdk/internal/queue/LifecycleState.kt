package io.kixo.sdk.internal.queue

/**
 * SDK lifecycle phases. Drives whether the [EventQueue] accepts events,
 * whether it's allowed to flush, and whether a recovery loop needs to
 * re-fetch `/api/sdk/init` before resuming batch sends.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Kixo.swift` `enum LifecycleState`
 * verbatim:
 *
 * ```
 * .Initialising
 *   → on first /api/sdk/init success(active):  .Running
 *   → on success(paused or disabled):          .PausedByServer
 *   → after configRetryExhausted:              .PausedByServer
 * .Running
 *   → on EventQueue.consecutiveFailures >= cooldownThreshold:
 *                                              .Recovering
 *   → on server flipping paused/disabled at next refresh:
 *                                              .PausedByServer
 * .Recovering
 *   → on /api/sdk/init success(active):        .Running
 *   → on /api/sdk/init success(paused/disabled): .PausedByServer
 *   → on /api/sdk/init failure:                stays .Recovering
 *                                              (timer triggers another attempt)
 * .PausedByServer
 *   → on next config refresh returning active: .Running
 * ```
 *
 * **Per-state event semantics (CRITICAL):**
 *  - `Initialising`: events are **buffered** (the queue accepts the
 *    enqueue + writes to the durable store) but **not flushed** —
 *    we don't know yet whether the SDK is allowed to ship at all.
 *    A flush is kicked when [Initialising] → [Running].
 *  - `Running`: normal operation. Periodic flush is active; the
 *    threshold trigger (`enqueue` past `flushAt`) fires a flush.
 *  - `Recovering`: events are buffered but not flushed. The Kixo
 *    facade (Agent 1) is currently re-fetching `/api/sdk/init`
 *    on its own backoff schedule. When the refetch succeeds, it
 *    transitions us to either [Running] or [PausedByServer].
 *  - `PausedByServer`: events are **dropped at enqueue time**.
 *    The server has declared the SDK off (project kill-switch,
 *    SDK-version disabled, account suspended). Continuing to
 *    persist would just fill the disk with events the backend
 *    will never accept. The buffer is also drained when this state
 *    is entered so a 200-event backlog doesn't sit on disk.
 *
 * Implemented as a `sealed class` (not `enum`) because [PausedByServer]
 * carries an optional `reason` payload (`"sdk_version_disabled"`,
 * `"project_paused"`, etc.) — the lifecycle controller passes it
 * through from the server response so [Kixo.diagnostics] can surface
 * a meaningful explanation to the host engineer rather than a bare
 * "paused" boolean.
 *
 * Sealed class semantics give us:
 *   - exhaustive `when` checks at compile time
 *   - structural equality (the data-class member compares correctly)
 *   - parity with the iOS Swift enum which carries no payload but is
 *     conceptually closer to a sealed type
 */
internal sealed class LifecycleState {

    /** The bare wire-style name. Used in logs + [diagnostics] tier strings. */
    abstract val name: String

    /**
     * SDK is up but the first `/api/sdk/init` response hasn't landed.
     * Events buffer; flushing is blocked until we transition to
     * [Running]. This is the state immediately after `Kixo.configure`
     * returns and before the init request resolves.
     */
    object Initialising : LifecycleState() {
        override val name: String = "initialising"
    }

    /**
     * Steady state — server says "go", we're shipping events on the
     * normal cadence. Periodic flush timer ticks every
     * `flushIntervalMs`; the threshold (`flushAt`) trigger fires on
     * enqueue.
     */
    object Running : LifecycleState() {
        override val name: String = "running"
    }

    /**
     * After 30 consecutive failed batches we pivot from "retry the
     * batch endpoint" to "re-fetch `/api/sdk/init` first". Reasoning
     * (verbatim from iOS comment, same pivot semantics):
     *
     *  1. The backend may have flipped our SDK version to
     *     "disabled" while we were retrying — config tells us so
     *     we can stop wasting bandwidth.
     *  2. The project's `paused` may have changed — if the operator
     *     hit the kill-switch during the outage, we want to honour
     *     that.
     *  3. Continuing to hammer `/api/sdk/batch` every 30 minutes
     *     forever is the textbook thundering-herd-on-recovery
     *     pattern. Forcing the "first request after recovery is
     *     config" lets the backend route the config-fetch surge
     *     separately from the batch surge.
     *
     * While in this state events buffer normally (the cap still
     * applies — the FIFO drop-oldest rule keeps us from infinite
     * disk growth) but no flush is attempted.
     */
    object Recovering : LifecycleState() {
        override val name: String = "recovering"
    }

    /**
     * Server-controlled kill-switch. Events are **dropped at enqueue
     * time** and the durable buffer is drained — the server told us
     * not to send, so persisting them would only make the recovery
     * harder.
     *
     * @property reason Optional server-provided code: typical values
     *   are `"sdk_version_disabled"` (operator killed our SDK
     *   version), `"project_paused"` (operator paused the entire
     *   project), `"plan_expired"` (billing). Surfaced through
     *   [io.kixo.sdk.KixoDiagnostics] so a confused host engineer can
     *   read it from a debug screen without needing logcat.
     *
     *   Null when the server response carries no `paused_reason`
     *   field — the legacy "paused: true" without a reason is still
     *   honoured (we just can't tell the host why).
     */
    data class PausedByServer(val reason: String? = null) : LifecycleState() {
        override val name: String = "paused_by_server"
    }

    /** True iff this state allows the queue to *flush* events. Only [Running] does. */
    val allowsFlush: Boolean
        get() = this is Running

    /**
     * True iff this state allows new events to be **enqueued at all**.
     * `false` only for [PausedByServer] — every other state buffers.
     *
     * (The legacy iOS code calls `isPaused` with the same meaning;
     * both ways come down to a single check at the top of
     * [EventQueue.enqueue].)
     */
    val allowsEnqueue: Boolean
        get() = this !is PausedByServer
}
