package io.kixo.sdk.internal.transport

import android.util.Log
import okhttp3.ConnectionPool
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/**
 * Singleton OkHttp factory. The SDK shares ONE [OkHttpClient] across
 * every [Transport] call (batch / init / identify / push / replay /
 * signed-URL upload) so connection pooling, DNS cache and threadpool
 * are reused. Per OkHttp docs, creating a new client per request is
 * the #1 cause of native socket leaks in long-lived processes.
 *
 * Timeouts are calibrated for an analytics SDK on a flaky cellular
 * link, not a desktop benchmark — favour "give up early and retry"
 * over "wait forever and tie up a worker":
 *  - **connect**: 10 s — DNS + TLS handshake. Anything longer means
 *    the carrier is offline; back off.
 *  - **read / write**: 30 s — backend p99 for /api/sdk/batch is well
 *    under 1 s. 30 s buys huge headroom for cold-Lambda + ClickHouse
 *    pressure spikes without holding the wakelock open indefinitely.
 *  - **call**: 30 s — total ceiling. Saves us from infinite redirect
 *    loops / mis-config. EventQueue's retry tier (rapid → slow →
 *    cooldown) handles longer outages, not the HTTP layer.
 *
 * Logging interceptor is attached only when `enableLogging=true` —
 * matches `debugImplementation(libs.okhttp.logging)` in the Gradle
 * config. The interceptor logs request/response bodies in clear,
 * which would leak PII in production. Release builds get a no-op.
 */
internal object HttpClientFactory {

    /**
     * Build the singleton OkHttpClient. Call once during SDK init and
     * reuse for the entire app lifetime. Subsequent calls return a
     * fresh instance — callers (e.g. tests with [okhttp3.mockwebserver.MockWebServer])
     * may override.
     *
     * @param enableLogging attach `HttpLoggingInterceptor` at BODY
     *        level. NEVER pass `true` in release builds; bodies
     *        contain customer event payloads + push tokens.
     */
    fun create(enableLogging: Boolean = false): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .writeTimeout(30, TimeUnit.SECONDS)
            .callTimeout(30, TimeUnit.SECONDS)
            // Critic 15 (HIGH) — pool bumped 8→16. Under sustained tap
            // bursts on a poor network, replay frame uploads can hold
            // up to 4 concurrent PUTs against signed GCS URLs (capped
            // by [io.kixo.sdk.internal.replay.CaptureSlot]) PLUS the
            // periodic /batch keep-alive PLUS the ReplayEventBatcher
            // POSTs to /replay/events PLUS init / push / signed-url
            // refills. With pool=8 the periodic batch flush could sit
            // waiting for an idle connection on a stuck cellular link
            // and miss its 30 s tick. 16 connections × 5-min keep-alive
            // covers the worst-case tap+replay+events fan-out plus
            // headroom for spikes; idle connections roll out of the
            // pool well before they become a memory drag.
            .connectionPool(ConnectionPool(16, 5, TimeUnit.MINUTES))
            // Retry on transient connectivity hiccups WITHOUT changing
            // the request shape (so a half-second wifi glitch doesn't
            // bubble up as a transient failure that ticks the
            // EventQueue's retry counter).
            .retryOnConnectionFailure(true)

        if (enableLogging) {
            // BODY level prints the entire request + response body.
            // Pre-redaction PII inside event payloads will be visible
            // in logcat — gated to debug builds only.
            //
            // The interceptor dep is `compileOnly` so it doesn't ship
            // in the AAR. Host apps that want body logging in release
            // builds must add it themselves; we no-op silently if the
            // class isn't on the runtime classpath.
            tryAttachLoggingInterceptor(builder)
        }

        return builder.build()
    }

    /**
     * Reflective attach so the SDK doesn't hard-require okhttp-logging
     * at runtime. Returns silently when the host doesn't ship the dep.
     */
    @Suppress("UNCHECKED_CAST")
    private fun tryAttachLoggingInterceptor(builder: OkHttpClient.Builder) {
        try {
            val cls = Class.forName("okhttp3.logging.HttpLoggingInterceptor")
            val instance = cls.getDeclaredConstructor().newInstance()
            // .level = Level.BODY via reflection
            val levelEnum = Class.forName("okhttp3.logging.HttpLoggingInterceptor\$Level")
            val bodyLevel = levelEnum.enumConstants.first { it.toString() == "BODY" }
            cls.getMethod("setLevel", levelEnum).invoke(instance, bodyLevel)
            builder.addInterceptor(instance as Interceptor)
        } catch (_: ClassNotFoundException) {
            Log.d("Kixo.HttpClient", "okhttp-logging dep not on classpath; release build, body logging disabled.")
        } catch (t: Throwable) {
            Log.w("Kixo.HttpClient", "Failed to attach logging interceptor: ${t.message}")
        }
    }
}
