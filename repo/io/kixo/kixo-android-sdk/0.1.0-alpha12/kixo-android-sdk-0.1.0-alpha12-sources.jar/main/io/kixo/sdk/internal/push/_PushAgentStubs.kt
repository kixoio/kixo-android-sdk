@file:Suppress("unused")

package io.kixo.sdk.internal.push

import io.kixo.sdk.PushProvider

/**
 * Agent-coordination stubs for the push subsystem.
 *
 * Per AGENT_BRIEFING.md §6, an agent that needs types from another
 * agent's folder may declare lightweight stand-ins in their own
 * folder until the owning agent's types land. This file groups
 * those stubs so the deletion path is one `git rm`.
 *
 * **Owners of the real types:**
 *   - [EventQueueBridge] → Agent 5 (`io.kixo.sdk.internal.queue`)
 *   - [IdentityDedupBridge] → Agent 5 (`io.kixo.sdk.internal.queue`
 *     or `io.kixo.sdk.internal.identity` — Agent 15 also touches
 *     identity, see briefing §6)
 *   - [PushTransportBridge] → Agent 4 (`io.kixo.sdk.internal.transport`)
 *
 * When the real types land, replace these `interface`s with imports
 * and delete this file. The push subsystem talks to the rest of the
 * SDK ONLY through the [PushBridges] aggregate, so the swap is a
 * single binding change in `Kixo.configure(...)`.
 *
 * The wire-format event-type strings live in [KixoEventTypeWire] —
 * we don't depend on Agent 2's `KixoEventType` enum because pulling
 * that import in here would couple the push-singleton tests to the
 * model package's serialization config (which carries kotlinx-
 * serialization annotations and a transitive cost on test JVM
 * startup). The string constants are short and the @SerialName
 * values in `KixoEventType.kt` are the source of truth — see the
 * doc comment on each constant.
 */

/**
 * Minimum surface PushTracker calls on the queue. Agent 5's real
 * `EventQueue` will accept richer arguments (timestamp override,
 * super-properties merge, etc.); this stub captures only what the
 * push code needs. The wire-format event-type string is what's
 * passed in — the queue maps it to its enum form internally.
 */
internal interface EventQueueBridge {
    fun enqueue(eventType: String, properties: Map<String, Any?>)
}

/**
 * Per-process dedup. Returns `true` iff the SDK should emit a fresh
 * `setPushToken` call to the backend — i.e. this is a new (token,
 * provider) pair we haven't seen since process start.
 *
 * **Agent 5 contract:** the implementation MUST be cheap (single
 * map lookup), thread-safe, and stateless across process restarts
 * (we want token rotations to re-trigger registration even when the
 * token text happens to match a value the device used in a prior
 * process — the backend's `PushToken.lastSeenAt` is what dedups
 * THERE; on the device we just want to avoid intra-process spam).
 */
internal interface IdentityDedupBridge {
    fun shouldEmitPushToken(tokenSha256: String, provider: PushProvider): Boolean
}

/**
 * Push-specific transport surface. Carved off from Agent 4's full
 * `Transport` so the push code doesn't have to depend on the batch /
 * init / replay endpoints it doesn't use.
 */
internal interface PushTransportBridge {
    /**
     * Fire-and-forget POST to `/api/sdk/push/register`. The raw
     * token IS sent here — this is the only code path in the SDK
     * permitted to do so per AGENT_BRIEFING.md R10. Implementor
     * handles retry + circuit-breaker; the caller does NOT block.
     */
    fun registerPushToken(token: String, provider: PushProvider)
}

/**
 * Aggregate handed to [PushTracker.bind] from `Kixo.configure(...)`.
 * Lets the wiring change atomically (you can't observe a partial
 * swap of "queue updated, transport not yet").
 */
internal data class PushBridges(
    val eventQueue: EventQueueBridge,
    val identityDedup: IdentityDedupBridge,
    val transport: PushTransportBridge,
)

/**
 * Wire-format event-type strings for the push subsystem. The values
 * MUST match the `@SerialName` strings in
 * `io.kixo.sdk.internal.model.KixoEventType` — see the briefing's
 * R3 (snake_case wire format).
 *
 * We intentionally keep this as bare string constants here rather
 * than importing the enum from Agent 2's package. Two reasons:
 *
 *  1. Decouples push tests from kotlinx-serialization wiring (the
 *     enum is `@Serializable`).
 *  2. Lets push code compile + test before Agent 2 finalises the
 *     enum's exact shape.
 *
 * If/when Agent 2's enum is deemed stable for cross-package use, we
 * can swap [KixoEventTypeWire] for the real `KixoEventType` and
 * delete this — `enqueue()` already takes a string.
 */
internal enum class KixoEventTypeWire(val wireValue: String) {
    PUSH_RECEIVED("push_received"),
    PUSH_OPEN("push_open"),
    PUSH_DISMISSED("push_dismissed"),
    PUSH_ACTION("push_action"),
    PUSH_SILENT("push_silent"),
    PUSH_TOKEN_INVALIDATED("push_token_invalidated"),
}
