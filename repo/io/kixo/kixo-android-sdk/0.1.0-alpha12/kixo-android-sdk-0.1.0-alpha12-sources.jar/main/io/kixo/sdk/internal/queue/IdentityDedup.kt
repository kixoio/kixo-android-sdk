package io.kixo.sdk.internal.queue

import io.kixo.sdk.PushProvider
import java.security.MessageDigest

/**
 * Suppress duplicate identify / user_property / push_token events.
 *
 * Mirrors the iOS dedup pass in `kixo-ios-sdk/Sources/Kixo/Kixo.swift`
 * (`lastIdentifyHash`, `lastUserPropertyHash`, `lastPushTokenHash`).
 * From the iOS comment: "Observed on LikePost: 41 `identify`, 37
 * `user_property`, 10 `push_token` per device in a 2h window — because
 * the host app calls these on every app_foreground / screen change
 * even when nothing has changed."
 *
 * **Why hash, not deep-equals:** an SDK that holds the user's full
 * trait map in memory keys a multi-MB property bag in long-lived
 * state. SHA-256 of the canonical-JSON form is 32 bytes. We don't
 * need cryptographic strength — collision-resistance to silently-
 * drop a real change is the only safety property required, and a 256-
 * bit hash gives us that with absurd headroom (2^-128 false-negative
 * rate). MD5 / FNV would suffice; SHA-256 is the platform default and
 * needs no third-party dep.
 *
 * **Threading:** all mutations + reads are guarded by `synchronized`
 * blocks against `this`. The dedup is called from the public
 * `Kixo.identify(...)` / `setUserProperty(...)` / `setPushToken(...)`
 * surface, which fans in from arbitrary host threads. A coroutine
 * mutex would be tidier but requires the call site to be `suspend`,
 * and we don't want to force the public API surface to be suspend.
 *
 * **What goes through dedup vs not:**
 *   - `identify`        → dedupes on `(userId, traits)` tuple hash
 *   - `user_property`   → dedupes per-key on `(value)` hash. Multi-
 *     property calls go through one key at a time.
 *   - `push_token`      → dedupes on `(token, provider)` hash. Token
 *     rotation produces a new hash; reporting the same token twice
 *     in a session is the primary noise we suppress.
 *
 * **What doesn't dedupe (and why):**
 *   - `track`, `screen`, `markGoal`, push lifecycle events — these
 *     are observations of what the user DID, not declarations of
 *     who they are. Dropping a duplicate `track("button_clicked")`
 *     would lose real signal. Dropping a duplicate `identify` with
 *     the same traits costs nothing because the backend's identity
 *     row is upsert-keyed on user_id.
 *
 * **Reset semantics:** [reset] clears all three caches. Called from
 * `Kixo.reset()` after a logout so that a re-identify with the same
 * (user_id, traits) tuple after a logout fires once — otherwise the
 * post-logout user's first identify would be silently dropped.
 */
internal class IdentityDedup {

    /**
     * Last-seen hash of the (`user_id`, `traits`) pair from
     * [shouldEmitIdentify]. `null` until first identify call.
     */
    private var lastIdentifyHash: ByteArray? = null

    /**
     * Per-key hash map for [shouldEmitUserProperty]. Each property
     * dedupes independently — `setUserProperty("plan", "pro")` and
     * `setUserProperty("country", "US")` keep separate slots.
     *
     * `LinkedHashMap` keeps insertion order so debug logs / future
     * dump-state diagnostics are reproducible.
     */
    private val lastUserPropertyHash: LinkedHashMap<String, ByteArray> = LinkedHashMap()

    /**
     * Last-seen hash of the (`token`, `provider`) pair from
     * [shouldEmitPushToken]. `null` until first push-token call.
     */
    private var lastPushTokenHash: ByteArray? = null

    /**
     * Decide whether an `identify` event should be emitted to the
     * queue. Returns `true` if (userId, traits) has changed since the
     * last call (or this is the first call), `false` if it's a no-op.
     *
     * Updates the cached hash on `true` so the NEXT call with the
     * same payload is suppressed.
     *
     * **Note on null userId:** the iOS code merges `["user_id":
     * userId]` into the traits before hashing. We do the same so that
     * `identify(userId="alice", traits=...)` and a separate later
     * `identify(userId="bob", traits=...)` with identical traits both
     * fire — they describe different users.
     */
    fun shouldEmitIdentify(userId: String?, traits: Map<String, Any?>): Boolean {
        // Build a canonical map: traits + user_id under a reserved key.
        // The reserved key uses a colon so it can't collide with a
        // legitimate trait name (trait keys are validated to alpha-
        // numeric + underscore upstream).
        val payload: MutableMap<String, Any?> = LinkedHashMap(traits.size + 1)
        payload.putAll(traits)
        payload["__user_id__"] = userId
        val hash = sha256OfMap(payload)
        return synchronized(this) {
            if (lastIdentifyHash != null && lastIdentifyHash!!.contentEquals(hash)) {
                false
            } else {
                lastIdentifyHash = hash
                true
            }
        }
    }

    /**
     * Decide whether a single `user_property` change should be
     * emitted. Each (key, value) is tracked independently — a
     * `setUserProperties({a:1, b:2})` call invokes this twice and may
     * suppress one but not the other.
     *
     * Returns `true` if the value differs from the last cached value
     * for this key (or it's a new key), `false` if it's the same.
     */
    fun shouldEmitUserProperty(key: String, value: Any?): Boolean {
        val hash = sha256OfValue(value)
        return synchronized(this) {
            val existing = lastUserPropertyHash[key]
            if (existing != null && existing.contentEquals(hash)) {
                false
            } else {
                lastUserPropertyHash[key] = hash
                true
            }
        }
    }

    /**
     * Decide whether a `push_token` event should be emitted. Token
     * rotation (provider issues a new value) produces a new hash;
     * reporting the same token twice is the primary noise.
     *
     * The (token, provider) tuple is hashed because the same token
     * string under a different provider would mean a different
     * registration to the backend (theoretically — in practice
     * provider strings rarely change for a given install).
     */
    fun shouldEmitPushToken(token: String, provider: PushProvider): Boolean {
        // Compose `provider:token` so a token-prefix collision across
        // providers is impossible. Provider's wireValue is a stable
        // ASCII string ("fcm" / "hms" / "apns").
        val composed = "${provider.wireValue}:$token"
        val hash = sha256OfBytes(composed.encodeToByteArray())
        return synchronized(this) {
            if (lastPushTokenHash != null && lastPushTokenHash!!.contentEquals(hash)) {
                false
            } else {
                lastPushTokenHash = hash
                true
            }
        }
    }

    /**
     * Wipe all three caches. Called from `Kixo.reset()` after a
     * logout so a re-identify with the prior user's traits still
     * emits once. Cheap (three pointer assignments).
     */
    fun reset() {
        synchronized(this) {
            lastIdentifyHash = null
            lastUserPropertyHash.clear()
            lastPushTokenHash = null
        }
    }

    // ─── Hash helpers ────────────────────────────────────────────────

    /**
     * Stable SHA-256 of a `Map<String, Any?>`. Keys are sorted
     * lexicographically so reorderings between calls hash the same
     * (the iOS counterpart uses `JSONSerialization` with
     * `.sortedKeys`; we mirror that).
     *
     * Values are coerced via `toString()` — collision-resistance to
     * silently-drop a real change is what matters; absolute key-
     * universe coverage is not. The fallback in iOS is identical
     * (`String(describing:)`).
     */
    private fun sha256OfMap(map: Map<String, Any?>): ByteArray {
        val sb = StringBuilder(64)
        val sortedKeys = map.keys.sorted()
        for (key in sortedKeys) {
            sb.append(key)
            sb.append('=')
            sb.append(serializeValue(map[key]))
            sb.append('\u001E') // record separator — unprintable, can't
            // collide with a real character in a trait key/value
        }
        return sha256OfBytes(sb.toString().encodeToByteArray())
    }

    /** Stable SHA-256 of an arbitrary value. Mirrors `sha256OfMap` for scalars. */
    private fun sha256OfValue(value: Any?): ByteArray {
        return sha256OfBytes(serializeValue(value).encodeToByteArray())
    }

    /**
     * Coerce an arbitrary value to its dedup-stable string form.
     * Recurses into lists/maps so nested traits hash deterministically.
     *
     * - `null`        → `"null"` (a literal token, distinguishable
     *                    from the string `"null"` because the latter
     *                    would be wrapped in quotes by the caller)
     * - `Boolean`     → `"true"` / `"false"`
     * - `Number`      → bare digits via `toString`
     * - `String`      → wrapped in single quotes so `"true"` !=
     *                    `true` !=  the string `"true"`
     * - `Map<*, *>`   → recursive, sorted by key
     * - `Iterable<*>` → recursive, order preserved (lists are ordered
     *                    semantically; reordering a tag list IS a
     *                    real change)
     * - other         → `toString` (best-effort; same as iOS fallback)
     */
    private fun serializeValue(value: Any?): String {
        if (value == null) return "null"
        return when (value) {
            is Boolean -> value.toString()
            is Number -> value.toString()
            is String -> "'$value'"
            is Map<*, *> -> {
                val sb = StringBuilder(32)
                sb.append('{')
                val keys = value.keys.mapNotNull { it?.toString() }.sorted()
                for ((idx, k) in keys.withIndex()) {
                    if (idx > 0) sb.append(',')
                    sb.append(k).append(':').append(serializeValue(value[k]))
                }
                sb.append('}')
                sb.toString()
            }
            is Iterable<*> -> {
                val sb = StringBuilder(32)
                sb.append('[')
                var first = true
                for (e in value) {
                    if (!first) sb.append(',')
                    first = false
                    sb.append(serializeValue(e))
                }
                sb.append(']')
                sb.toString()
            }
            else -> value.toString()
        }
    }

    /** Single SHA-256 evaluation. Cached MessageDigest is not safe for
     *  concurrent use, so a fresh instance per call is the simplest correct
     *  thing — the cost of `MessageDigest.getInstance("SHA-256")` is dominated
     *  by the hash computation itself, this is not a hot path. */
    private fun sha256OfBytes(bytes: ByteArray): ByteArray {
        val md = MessageDigest.getInstance("SHA-256")
        return md.digest(bytes)
    }
}
