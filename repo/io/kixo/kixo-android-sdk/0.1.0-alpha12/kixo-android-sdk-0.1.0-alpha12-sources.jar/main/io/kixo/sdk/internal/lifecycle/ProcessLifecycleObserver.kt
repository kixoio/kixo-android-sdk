package io.kixo.sdk.internal.lifecycle

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.util.Log
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import io.kixo.sdk.internal.model.KixoEventType

/**
 * Process-wide lifecycle observer attached to
 * [androidx.lifecycle.ProcessLifecycleOwner.get].lifecycle.
 *
 * Emits:
 *   - `app_launch`     — once per process. Fired the first time
 *                        ON_START arrives. Properties: `is_first_launch`,
 *                        `version`, `build`. The first-launch flag is
 *                        persisted in `SharedPreferences("kixo_lifecycle_state")`
 *                        under key `has_launched`, mirroring the iOS
 *                        `kixo_launched_before` `UserDefaults` key.
 *   - `app_foreground` — every ON_START. Properties: `bg_duration_ms`
 *                        (millis since last `app_background`, null on
 *                        the very first foreground of the process).
 *   - `app_background` — every ON_STOP. Properties: `fg_duration_ms`
 *                        (millis since the most recent `app_foreground`).
 *
 * Why ProcessLifecycleOwner and not Application.ActivityLifecycle-
 * Callbacks? The Activity callbacks fire per-Activity (so a config-
 * change rotation looks like a background→foreground bounce, and
 * navigating between Activities can briefly leave zero foregrounded).
 * `ProcessLifecycleOwner` debounces these and only flips between
 * STARTED / CREATED states for the entire process — exactly the
 * "the user has the app open" / "the user does not" signal we want.
 *
 * **Mirrors iOS [LifecycleTracker.swift]** — `app_launch` /
 * `app_foreground` / `app_background` / (no `app_terminate`: Android
 * has no reliable termination callback short of an OS kill, and the
 * iOS terminate is more of a clean-quit signal than a true kill,
 * so parity is intentionally lossy here).
 *
 * Why elapsedRealtime() and not currentTimeMillis() for fg/bg
 * durations? `currentTimeMillis()` jumps around when the user changes
 * timezones or NTP corrects the clock — `SystemClock.elapsedRealtime()`
 * is monotonic and never goes backwards. iOS uses `Date()` for these
 * which has the same risk; we deliberately do better here. (See
 * AGENT_BRIEFING.md §11 anti-examples.)
 */
internal class ProcessLifecycleObserver(
    private val bus: LifecycleEventBus,
) : DefaultLifecycleObserver {

    /**
     * Construct using the singleton bus — convenience for
     * [KixoInternalBootstrap]. Tests inject a fake bus directly.
     */
    constructor() : this(LifecycleEventBus)

    @Volatile
    private var hasFiredLaunch: Boolean = false

    /**
     * elapsedRealtime() millis when the most recent `app_foreground`
     * fired. Null while in the background.
     */
    @Volatile
    private var foregroundedAtMs: Long? = null

    /**
     * elapsedRealtime() millis when the most recent `app_background`
     * fired. Null until the first background transition.
     */
    @Volatile
    private var backgroundedAtMs: Long? = null

    override fun onStart(owner: LifecycleOwner) {
        // Fire app_launch BEFORE app_foreground on the first ON_START,
        // matching iOS where LifecycleTracker.init runs trackAppLaunch
        // before any of the foreground notification observers can
        // possibly fire.
        if (!hasFiredLaunch) {
            hasFiredLaunch = true
            fireAppLaunch()
        }

        val now = SystemClock.elapsedRealtime()
        val bgMs: Long? = backgroundedAtMs?.let { now - it }
        backgroundedAtMs = null
        foregroundedAtMs = now

        bus.emit(
            LifecycleEvent(
                eventType = KixoEventType.Lifecycle,
                eventName = "app_foreground",
                properties = mapOf(
                    "bg_duration_ms" to bgMs,
                ),
            )
        )

        // Tell the SessionTracker about the foreground transition. The
        // tracker decides whether the gap exceeded sessionTimeoutMs
        // and a new session_start should fire.
        SessionTrackerHook.onForeground(bgDurationMs = bgMs)
    }

    override fun onStop(owner: LifecycleOwner) {
        val now = SystemClock.elapsedRealtime()
        val fgMs: Long = foregroundedAtMs?.let { now - it } ?: 0L
        foregroundedAtMs = null
        backgroundedAtMs = now

        bus.emit(
            LifecycleEvent(
                eventType = KixoEventType.Lifecycle,
                eventName = "app_background",
                properties = mapOf(
                    "fg_duration_ms" to fgMs,
                ),
            )
        )

        SessionTrackerHook.onBackground()
    }

    private fun fireAppLaunch() {
        val info = KixoInternalBootstrap.appBuildInfo()
        val isFirst = readAndSetFirstLaunchFlag()
        bus.emit(
            LifecycleEvent(
                eventType = KixoEventType.Lifecycle,
                eventName = "app_launch",
                properties = mapOf(
                    "is_first_launch" to isFirst,
                    "version" to info.version,
                    "build" to info.build,
                ),
            )
        )
    }

    /**
     * Read and (if absent) set the persistent first-launch flag.
     * Returns `true` if this is the first launch ever (or after the
     * user cleared app data). Returns `false` on every subsequent
     * launch.
     *
     * Wrapped in try/catch because SharedPreferences disk I/O can
     * throw on certain corruption scenarios (DEAD_OBJECT_EXCEPTION
     * on some OEM ROMs). On any failure we conservatively report
     * `false` — better to under-report a first-launch than to crash
     * the host app on cold start.
     */
    private fun readAndSetFirstLaunchFlag(): Boolean {
        return try {
            val prefs = persistentStore() ?: return false
            val launched = prefs.getBoolean(KEY_HAS_LAUNCHED, false)
            if (!launched) {
                prefs.edit().putBoolean(KEY_HAS_LAUNCHED, true).apply()
            }
            !launched
        } catch (t: Throwable) {
            Log.w(TAG, "first-launch flag read failed", t)
            false
        }
    }

    private fun persistentStore(): SharedPreferences? {
        // The bootstrap captured the Application; reach back through
        // it for a SharedPreferences. Keeping the lookup lazy means
        // tests that bypass bootstrap (and never call configure) still
        // run through onStart() without crashing.
        val ctx: Context = KixoInternalBootstrap.applicationOrNull() ?: return null
        return ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    internal companion object {
        private const val TAG = "Kixo"
        const val PREFS_NAME = "kixo_lifecycle_state"
        const val KEY_HAS_LAUNCHED = "has_launched"
    }
}

/**
 * Tiny indirection to push process-lifecycle transitions into
 * [SessionTracker] without making the observer hold a tracker
 * reference (which would couple ordering — process observer is
 * registered before SessionTracker.start() in some test paths).
 *
 * The hook reads the live tracker from [KixoInternalBootstrap] each
 * time so a tracker swapped in for tests is honoured immediately.
 */
internal object SessionTrackerHook {
    fun onForeground(bgDurationMs: Long?) {
        KixoInternalBootstrap.sessionTrackerOrNull()
            ?.onProcessForeground(bgDurationMs = bgDurationMs)
    }

    fun onBackground() {
        KixoInternalBootstrap.sessionTrackerOrNull()
            ?.onProcessBackground()
    }
}
