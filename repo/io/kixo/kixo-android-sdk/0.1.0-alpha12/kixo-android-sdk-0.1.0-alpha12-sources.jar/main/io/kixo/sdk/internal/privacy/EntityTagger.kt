package io.kixo.sdk.internal.privacy

import android.util.Log
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Optional on-device NER wrapper around ML Kit Entity Extraction.
 *
 * ## Why this exists at all
 * The regex set in [PiiPatterns] catches structured PII (email, card,
 * SSN). It does NOT catch things like a person's name in a label
 * ("Welcome back, Anna"), a city ("Send to Berlin"), or an
 * organization. For replay snapshots in apps that show user-generated
 * content prominently, NER is a meaningful safety net.
 *
 * Operator must opt in (off by default) because:
 *  - It pulls a runtime dep that's `compileOnly` (~5MB).
 *  - The annotator allocates model data on first use.
 *  - It's slower than regex (~5-15ms per call vs <0.1ms).
 *
 * ## Reflection-based access
 * The ML Kit dep is `compileOnly` per AGENT_BRIEFING.md §5 (so a
 * customer can exclude it without breaking the SDK). That means we
 * cannot static-import any `com.google.mlkit.nl.entityextraction.*`
 * symbol at compile time — the SDK module must build with ML Kit
 * absent. So this class loads classes via [Class.forName] and
 * dispatches reflectively. If any class isn't found at runtime
 * (host app excluded the dep), [tryCreate] returns null and the
 * tagger silently no-ops.
 *
 * ## Thread-safety — the iOS C.3v3 lesson, ported
 * iOS C.3v3 (April 28 2026) crashed with EXC_BAD_ACCESS in
 * `enumerateTags` because [NLTagger] was concurrently called from
 * up to 4 OCR-queue tasks. The fix was [NSLock] around every
 * `tagger.string = text` + `enumerateTags` cycle.
 *
 * ML Kit's `EntityExtractor` is documented as not concurrency-safe.
 * Same risk profile (the OCR queue can have up to 4 concurrent
 * captures per [AGENT_BRIEFING.md R4]). Same fix: a [ReentrantLock]
 * serialises every annotator call. Worst-case wait under contention
 * is bounded by ocrQueue depth × per-call latency = 4 × 15ms = 60ms,
 * which is invisible inside the OCR pipeline (well under one frame).
 */
internal class EntityTagger private constructor(
    private val annotator: Any,
    private val annotateMethod: java.lang.reflect.Method,
    private val annotationStartGetter: java.lang.reflect.Method,
    private val annotationEndGetter: java.lang.reflect.Method,
    private val annotationEntitiesGetter: java.lang.reflect.Method,
    private val entityTypeGetter: java.lang.reflect.Method,
) {
    /**
     * Single lock that serialises every annotator call. See class
     * doc for why this is critical (concurrent calls crash the host
     * app). Must hold across BOTH the annotate request AND the
     * result extraction — the underlying API holds internal state
     * tied to the in-flight call.
     */
    private val lock = ReentrantLock()

    /**
     * Find PII-relevant entities in [text]. Returns name / location /
     * organisation matches as [PiiMatch] entries with [PiiKind.NAME]
     * or [PiiKind.ENTITY].
     *
     * Synchronous and may block up to ~60ms under heavy contention.
     * NEVER call from the main thread — caller is expected to be
     * on the OCR queue (cap 4 concurrent per AGENT_BRIEFING.md R4).
     *
     * Failures (annotator threw, SecurityException, OOM) swallow
     * silently and return [emptyList] — per AGENT_BRIEFING.md R6,
     * the SDK never crashes the host app on a privacy-helper
     * malfunction. We log a warning but do NOT log [text] (R10).
     */
    fun findEntities(text: String): List<PiiMatch> {
        if (text.isEmpty()) return emptyList()
        return try {
            // Lock held across the whole call. ML Kit's annotator is
            // not concurrency-safe; see class doc § Thread-safety.
            lock.withLock { annotateLocked(text) }
        } catch (t: Throwable) {
            // Don't log `text` — that's the very PII we're trying to
            // protect. Log only the exception type.
            Log.w(TAG, "EntityTagger.findEntities failed: ${t.javaClass.simpleName}")
            emptyList()
        }
    }

    private fun annotateLocked(text: String): List<PiiMatch> {
        // ML Kit's EntityExtractor.annotate(String) returns a Task
        // resolving to List<EntityAnnotation>. We're already on a
        // worker thread; use the synchronous-aware Task#getResult
        // via the Tasks helper (loaded reflectively).
        @Suppress("UNCHECKED_CAST")
        val task = annotateMethod.invoke(annotator, text) ?: return emptyList()
        // Tasks.await(task, 5, TimeUnit.SECONDS) — but we use a
        // bounded poll because adding the gms.tasks reflection cost
        // dwarfs the annotator itself. Most calls return synchronously
        // in ML Kit's worker thread by the time annotate() returns —
        // we just check isComplete + getResult.
        val annotations = waitForTask(task) as? List<*> ?: return emptyList()
        if (annotations.isEmpty()) return emptyList()

        val out = ArrayList<PiiMatch>(annotations.size)
        for (annotation in annotations) {
            if (annotation == null) continue
            val start = (annotationStartGetter.invoke(annotation) as? Int) ?: continue
            val end = (annotationEndGetter.invoke(annotation) as? Int) ?: continue
            if (start < 0 || end > text.length || end <= start) continue
            val entities = annotationEntitiesGetter.invoke(annotation) as? List<*> ?: continue
            for (entity in entities) {
                val type = entityTypeGetter.invoke(entity) as? Int ?: continue
                val kind = mapEntityType(type) ?: continue
                out += PiiMatch(
                    kind = kind,
                    startIdx = start,
                    endIdx = end,
                    value = text.substring(start, end),
                )
                // One annotation can have multiple entity sub-types;
                // we only need the first PII-relevant one to flag the
                // span. Break out to avoid duplicate matches per span.
                break
            }
        }
        return out
    }

    /**
     * Bounded-time block on a `com.google.android.gms.tasks.Task`.
     * We avoid linking the GMS Tasks library by polling `isComplete`
     * + reading `getResult` reflectively. Up to 200ms — annotator
     * usually finishes in <20ms; 200ms is the OCR-queue's per-frame
     * budget so we won't dominate.
     */
    private fun waitForTask(task: Any): Any? {
        val taskCls = task.javaClass
        val isComplete = taskCls.getMethod("isComplete")
        val getResult = taskCls.getMethod("getResult")
        val deadline = System.currentTimeMillis() + TASK_AWAIT_BUDGET_MS
        while (true) {
            if (isComplete.invoke(task) == true) {
                return getResult.invoke(task)
            }
            if (System.currentTimeMillis() >= deadline) return null
            // Short busy-spin. Sleep briefly to release the CPU.
            Thread.sleep(TASK_POLL_INTERVAL_MS)
        }
    }

    /**
     * ML Kit Entity Extraction defines TYPE_PERSON, TYPE_ADDRESS,
     * TYPE_PHONE, etc. as integer constants. We map only the ones
     * that pose a privacy risk; phone is already covered by regex
     * so we skip it here to avoid double-redaction on the same span.
     *
     * The numeric constants come from
     * `com.google.mlkit.nl.entityextraction.Entity` — TYPE_PERSON=10,
     * TYPE_ADDRESS=1, others vary by SDK version. Conservative:
     * we use a small allowlist and treat anything we don't know as
     * non-PII (false negative) rather than redact it (false positive
     * destroys analytics value).
     */
    private fun mapEntityType(type: Int): PiiKind? = when (type) {
        TYPE_PERSON -> PiiKind.NAME
        TYPE_ADDRESS -> PiiKind.ENTITY
        else -> null
    }

    internal companion object {
        private const val TAG = "Kixo.EntityTagger"

        /**
         * ML Kit's `Entity.TYPE_PERSON`. Pinned because reflective
         * lookup of the constant is expensive vs hard-coding the
         * one int. If ML Kit renumbers (unlikely — this is a public
         * API contract), we silently no-op which is safe.
         */
        private const val TYPE_PERSON = 10

        /**
         * ML Kit's `Entity.TYPE_ADDRESS`.
         */
        private const val TYPE_ADDRESS = 1

        private const val TASK_AWAIT_BUDGET_MS: Long = 200
        private const val TASK_POLL_INTERVAL_MS: Long = 5

        /**
         * Reflective constructor. Returns null if the ML Kit Entity
         * Extraction classes aren't on the runtime classpath — this
         * is the expected state when the host app excluded the
         * optional dep, and the SDK silently degrades to regex-only
         * sanitization.
         *
         * Side-effects: triggers ML Kit's model download on first
         * call. If the model isn't downloaded yet, the first
         * [findEntities] call will return an empty list (annotator
         * throws "model not downloaded"). Operator should call
         * `EntityExtraction.getClient(...).downloadModelIfNeeded()`
         * out of band before opting in.
         */
        internal fun tryCreate(): EntityTagger? {
            return try {
                val extractionCls = Class.forName(
                    "com.google.mlkit.nl.entityextraction.EntityExtraction",
                )
                val optionsCls = Class.forName(
                    "com.google.mlkit.nl.entityextraction.EntityExtractorOptions",
                )
                val builderCls = Class.forName(
                    "com.google.mlkit.nl.entityextraction.EntityExtractorOptions\$Builder",
                )
                val annotationCls = Class.forName(
                    "com.google.mlkit.nl.entityextraction.EntityAnnotation",
                )
                val entityCls = Class.forName(
                    "com.google.mlkit.nl.entityextraction.Entity",
                )

                // EntityExtractorOptions.ENGLISH (string constant on
                // EntityExtractorOptions.ModelIdentifier).
                val modelIdField = optionsCls.getField("ENGLISH")
                val modelId = modelIdField.get(null) ?: return null

                val builderCtor = builderCls.getConstructor(String::class.java)
                val builder = builderCtor.newInstance(modelId.toString())
                val buildMethod = builderCls.getMethod("build")
                val options = buildMethod.invoke(builder) ?: return null

                val getClient = extractionCls.getMethod("getClient", optionsCls)
                val annotator = getClient.invoke(null, options) ?: return null

                val annotateMethod = annotator.javaClass
                    .getMethod("annotate", String::class.java)

                EntityTagger(
                    annotator = annotator,
                    annotateMethod = annotateMethod,
                    annotationStartGetter = annotationCls.getMethod("getStart"),
                    annotationEndGetter = annotationCls.getMethod("getEnd"),
                    annotationEntitiesGetter = annotationCls.getMethod("getEntities"),
                    entityTypeGetter = entityCls.getMethod("getType"),
                )
            } catch (cnf: ClassNotFoundException) {
                // Expected when the host app excluded the dep.
                null
            } catch (t: Throwable) {
                // Anything else (SecurityException, NoSuchMethodError
                // from an ML Kit version we don't recognise) → soft
                // fail. We log type only, never user input.
                Log.w(TAG, "EntityTagger init failed: ${t.javaClass.simpleName}")
                null
            }
        }
    }
}
