package io.kixo.sdk.internal.screen

import android.view.View
import android.view.ViewGroup

/**
 * Content-invariant structural fingerprint of an Android view
 * hierarchy. Mirrors iOS
 * [ScreenFingerprint](kixo-ios-sdk/Sources/Kixo/AutoTrack/ScreenFingerprint.swift)
 * one-for-one — same FNV-1a algorithm, same role-tree shape, same
 * truncation rules.
 *
 * **AGENT_BRIEFING.md §3 R8 contract — DO NOT VIOLATE.**
 *
 * The hash MUST be invariant to:
 *   - text contents (`TextView.text`, `EditText.text`,
 *     `Button.text`, `contentDescription`)
 *   - colours (background, tint, text colour)
 *   - fonts (typeface, text size, font weight)
 *   - layout dimensions ([View.measuredWidth] / [View.measuredHeight])
 *     and absolute positions
 *   - locale (including LTR / RTL flip — same screen across English
 *     and Arabic must produce the same hash)
 *   - theme (light / dark — same screen in both modes must produce
 *     the same hash)
 *   - dynamic state — list scroll position, RecyclerView item count,
 *     EditText focus, Spinner selection
 *   - device size / density — Pixel 6 vs Pixel Tablet at the same
 *     screen must produce the same hash
 *
 * The hash MUST change when:
 *   - the structural shape of the role tree changes (a new
 *     navigation pane appears, a sheet wraps the screen, a
 *     completely different layout takes over after a route)
 *   - the role distribution changes meaningfully (the empty-state
 *     placeholder is replaced by a list, the loading skeleton is
 *     replaced by populated content — captured here as
 *     [ScreenStateProbe] and emitted as a sibling
 *     `screen_state` field, not folded into the fingerprint hash)
 *
 * **Why FNV-1a not Kotlin's [Any.hashCode]:** Kotlin/JVM strings hash
 * deterministically across runs (unlike Python's randomised SipHash),
 * but composing them via `Pair.hashCode` / `List.hashCode` mixes them
 * with [Object.hashCode] which is identity-based and re-randomised per
 * process. FNV-1a is a 17-LOC pure function — same input = same output
 * forever — which is the requirement for cross-session backend dedup.
 *
 * **Performance budget:** ~1 ms for a 200-node tree on a Pixel 6,
 * cheap enough to run synchronously on the main thread inside
 * [ScreenTracker.maybeRecordVisit]. Bounded by [MAX_DEPTH] and
 * [MAX_BREADTH] so a pathologically deep / wide hierarchy can't
 * stall an Activity transition.
 */
internal object ScreenFingerprint {

    /**
     * Tree-traversal cap. Mirrors iOS
     * `RoleTreeBuilder.maxDepth = 12`. Most Android hierarchies are
     * 8-10 deep; ConstraintLayout-flat designs are 4-6. A wrapping
     * navigation host adds 2-3. 12 covers >99% of real screens
     * without measurable cost; deeper trees collapse the deep parts
     * to "elided" so the fingerprint is still STRUCTURALLY meaningful
     * (you can't see the leaves but the upper shape is hashed).
     */
    private const val MAX_DEPTH = 12

    /**
     * Per-node child count cap. Lists are normalised to a single
     * template item BEFORE breadth limiting, so a 1000-row
     * RecyclerView still fingerprints to one [Role.List] node with
     * one synthesized child. The breadth limit applies to genuinely
     * wide UIs (e.g. dashboards with 30 stat tiles in a flow layout).
     */
    private const val MAX_BREADTH = 30

    /**
     * Empty / not-yet-measured screen sentinel. Returned when:
     *   - [rootView] is null
     *   - [rootView] has zero children
     *   - [rootView] has zero measured size (still inflating)
     *
     * Distinct from a real fingerprint because no real layout
     * collapses to FNV-1a-of-the-empty-byte-string.
     */
    private const val EMPTY_SENTINEL = "Screen_empty"

    /** FNV-1a 64-bit constants (identical to iOS [FNV1a]). */
    private const val FNV_OFFSET_BASIS: Long = -3750763034362895579L  // 0xcbf29ce484222325 unsigned
    private const val FNV_PRIME: Long = 1099511628211L

    /**
     * Compute the structural fingerprint of [rootView].
     *
     * Returns the 8-char hex prefix of the FNV-1a 64-bit hash. The
     * caller composes the canonical screen id as
     * `"Screen_$hexPrefix"` for the dedup-fallback name.
     *
     * **Threading:** call from the main thread only — Android's view
     * tree is not safe to read off-main (per AGENT_BRIEFING.md §3 R6
     * "ANR risk: never block main thread > 16 ms"; this fits in 1 ms
     * for normal trees).
     */
    fun compute(rootView: View?): String {
        if (rootView == null) return EMPTY_SENTINEL
        // Zero-sized roots happen during inflation; the role tree
        // would be misleadingly tiny. Treat as empty so we never
        // emit a screen_visit before layout has run.
        if (rootView.width == 0 && rootView.height == 0) return EMPTY_SENTINEL
        if (rootView is ViewGroup && rootView.childCount == 0) return EMPTY_SENTINEL

        var hash = FNV_OFFSET_BASIS
        hash = combineNode(rootView, depth = 0, hash = hash)
        return formatHex8(hash)
    }

    /**
     * Recursive flatten + hash. Mirrors iOS
     * `RoleTreeBuilder.build(from:)` + `hash(_:)` collapsed into a
     * single pass — Android view tree access is cheap and we don't
     * need the intermediate [Role] tree for any other purpose
     * (Agent 13's StructuralSnapshotter walks the tree separately).
     */
    private fun combineNode(view: View, depth: Int, hash: Long): Long {
        if (depth > MAX_DEPTH) {
            // Collapse rather than truncate: emit a deterministic
            // "elided" marker so two screens whose deep tails are
            // pruned still hash differently if their ABOVE-MAX_DEPTH
            // shape differs.
            return combineByte(hash, ELIDED_MARKER)
        }

        val role = RoleClassifier.classify(view)
        var h = combineByte(hash, role.code)

        // List normalisation: a [Role.List] node hashes its FIRST
        // child only (template item) regardless of how many real
        // items the adapter is showing. Mirrors iOS
        // `RoleTreeBuilder` collection-normalisation.
        //
        // For RecyclerView/ListView specifically the visible children
        // count varies as the user scrolls — so even within a single
        // session the fingerprint would drift if we hashed all
        // children. The normalisation makes "scrolled list" and
        // "fresh list" identical.
        val childCount = if (view is ViewGroup) view.childCount else 0
        if (childCount == 0) {
            // Leaf — terminate the role-only path with a structural
            // depth marker so a flat container vs a leaf at depth N
            // can't accidentally collide.
            return combineByte(h, LEAF_MARKER)
        }

        val effectiveCount: Int = when (role) {
            Role.List -> {
                // Hash exactly one template child — see comment above.
                1
            }
            else -> minOf(childCount, MAX_BREADTH)
        }

        // Encode the structural arity so two screens with the same
        // role chain but different child counts still differ.
        h = combineInt(h, effectiveCount)

        view as ViewGroup
        for (i in 0 until effectiveCount) {
            val child = view.getChildAt(i) ?: continue
            // Skip GONE children — they don't contribute to the
            // user-visible structure. View.GONE = 8.
            if (child.visibility == View.GONE) continue
            h = combineNode(child, depth = depth + 1, hash = h)
        }
        // Sibling separator so [A,B] and [AB] (single composite)
        // can't collide on the same parent.
        return combineByte(h, SIBLING_END_MARKER)
    }

    // ─── FNV-1a primitives ──────────────────────────────────────────

    private fun combineByte(state: Long, byte: Byte): Long {
        // FNV-1a step: hash = (hash xor byte) * prime, all unsigned
        // mod 2^64. Java/Kotlin Long is signed but xor / wrap-around
        // multiply give bit-identical results.
        var h = state
        h = h xor (byte.toLong() and 0xFFL)
        h *= FNV_PRIME
        return h
    }

    private fun combineInt(state: Long, value: Int): Long {
        var h = state
        var v = value
        // Hash 4 bytes little-endian (matches iOS combine(_ int: Int)
        // which writes 8 bytes; but our Int is 4 bytes — tagging the
        // upper 4 with zeros gives the same logical input as iOS for
        // small ints, which is the only kind we feed here).
        for (i in 0 until 4) {
            h = combineByte(h, (v and 0xFF).toByte())
            v = v ushr 8
        }
        return h
    }

    /**
     * Emit the lower 32 bits as 8-char hex. Matches iOS
     * `ScreenFingerprint.hexPrefix` so a screen that fingerprints
     * identically on iOS and Android (same structural design)
     * produces the same `Screen_<hex>` string.
     */
    private fun formatHex8(hash: Long): String {
        val low32 = (hash and 0xFFFFFFFFL).toInt()
        // toUInt().toString(16) avoids the negative-int sign-extension
        // problem; padStart('0') gives the canonical 8-char form.
        return low32.toUInt().toString(16).padStart(8, '0')
    }

    // ─── Structural markers (tag bytes that can't collide with
    //     [Role.code] values, all of which are 1..10) ─────────────

    /** Tag byte for "subtree elided at MAX_DEPTH". */
    private const val ELIDED_MARKER: Byte = 0xFE.toByte()

    /** Tag byte for "leaf node — no children". */
    private const val LEAF_MARKER: Byte = 0xFD.toByte()

    /** Tag byte for "end of children for the current parent". */
    private const val SIBLING_END_MARKER: Byte = 0xFC.toByte()

    /**
     * Sentinel value an external caller can compare against to
     * detect the "empty" case without reaching for the literal.
     */
    const val EMPTY_FINGERPRINT: String = EMPTY_SENTINEL
}
