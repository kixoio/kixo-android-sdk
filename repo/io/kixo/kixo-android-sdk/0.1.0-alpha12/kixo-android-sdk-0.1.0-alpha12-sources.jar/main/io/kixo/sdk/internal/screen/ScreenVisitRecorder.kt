package io.kixo.sdk.internal.screen

import android.util.Log
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject

/**
 * Emits a lightweight `screen_visit` event on every accepted screen
 * change. Mirrors iOS [FlowRecorder] — always-on (NOT gated by replay
 * sample verdict) so `/journey` Flows / App Map / Funnel get full
 * coverage even on sessions that aren't sampled for replay.
 *
 * **Why a separate stream from `screen_view`:** historically iOS used
 * `event_type = screen_view`. That path is unreliable on iOS 26 SwiftUI
 * Metal-direct (10 events/day vs 190 replay tap rows) and the same
 * pattern is expected on Android Compose. `screen_visit` is the
 * always-on, structurally-derived signal; `screen_view` from
 * [Kixo.screen("name")] explicit calls is a separate (manual) signal.
 *
 * **Decoupling from EventQueue:** Agent 5 owns the actual
 * `EventQueue.enqueue` API. To keep the screen package independent we
 * bind via [emitter] — Agent 1's [Kixo.configure] sets the emitter
 * lambda once, pointing at `EventQueue.enqueue`. Until set, emissions
 * are buffered in [pendingBeforeBind] (capped at 32, drop-oldest) so
 * the early screens during cold-start aren't lost.
 *
 * Wire format mirrors iOS — same `event_type`, same property keys,
 * same snake_case (AGENT_BRIEFING.md §3 R3):
 *
 * ```
 * {
 *   "event_type":   "screen_visit",
 *   "event_name":   "<resolved screen name>",
 *   "fingerprint":  "<screen fingerprint hex>",
 *   "properties": {
 *     "screen_id":             "<fingerprint hex>",
 *     "screen_name":           "<resolved name>",
 *     "prev_screen_id":        "<previous fingerprint hex>" | null,
 *     "_kixo_name_candidates": [ {value, source, confidence}, ... ],
 *     "trigger":               "activity_resumed"|"fragment_resumed"|"compose_route"
 *   }
 * }
 * ```
 *
 * **Threading:** [recordVisit] is called from the main thread by
 * [ScreenTracker]; the emitter lambda is invoked synchronously and
 * Agent 5's [EventQueue] handles the off-main hop internally.
 */
internal object ScreenVisitRecorder {

    private const val TAG = "Kixo"

    /**
     * Cap on events buffered before the EventQueue emitter is bound.
     * Unbounded buffering would let a misconfigured host that never
     * calls [Kixo.configure] grow memory indefinitely. 32 is enough
     * for the typical "configure happens after the first 1-2 screens"
     * race; older entries silently drop.
     */
    private const val MAX_PENDING_BEFORE_BIND = 32

    /**
     * Single emitter slot, written once by [bindEmitter]. Volatile +
     * a single producer (Agent 1) means we don't need a lock around
     * read-then-call. The sigil "Emitter" is intentionally narrow —
     * it accepts only the per-event params we care about, not a
     * full [KixoEvent] DTO, so this file doesn't depend on Agent 2's
     * model package shape.
     */
    @Volatile
    private var emitter: Emitter? = null

    /** FIFO of unsent events (drop-oldest at cap). */
    private val pendingBeforeBind = ArrayDeque<PendingVisit>(MAX_PENDING_BEFORE_BIND)

    /**
     * Why this screen change happened, recorded so the backend can
     * reconstruct nav graphs. Mirrors iOS [ScreenVisit.TriggerKind]
     * but pruned to Android-relevant cases.
     */
    internal enum class Trigger(val wire: String) {
        ActivityResumed("activity_resumed"),
        FragmentResumed("fragment_resumed"),
        ComposeRoute("compose_route"),
        ExplicitOverride("explicit_override"),
    }

    /**
     * Single emission entrypoint. Idempotency / dedup is the caller's
     * responsibility ([ScreenTracker.maybeRecordVisit] does the 2 s
     * fingerprint window + 1 s name window — see iOS comment in
     * `ScreenTracker.swift` for the rationale on the dual window).
     *
     * The previous identity is read from [ScreenIdentity] BEFORE the
     * caller updates it, so this method receives the new snapshot
     * directly and computes `prev_screen_id` from the atomic
     * getAndSet result.
     */
    fun recordVisit(
        snapshot: ScreenIdentity.Snapshot,
        previous: ScreenIdentity.Snapshot,
        trigger: Trigger,
    ) {
        val visit = PendingVisit(
            screenId = snapshot.screenId,
            screenName = snapshot.screenName,
            prevScreenId = previous.screenId.takeIf { it.isNotEmpty() },
            candidates = snapshot.candidates,
            trigger = trigger,
            wallClockMillis = System.currentTimeMillis(),
        )

        val em = emitter
        if (em == null) {
            // Pre-configure cold-start race — buffer for later flush.
            synchronized(pendingBeforeBind) {
                if (pendingBeforeBind.size >= MAX_PENDING_BEFORE_BIND) {
                    pendingBeforeBind.removeFirst()
                }
                pendingBeforeBind.addLast(visit)
            }
            return
        }
        try {
            em.emit(visit.toEmission())
        } catch (t: Throwable) {
            // R6 — never crash the host. Emitter failure (e.g. queue
            // full because PausedByServer drained but emitter still
            // bound) just drops the visit.
            Log.w(TAG, "screen_visit emit failed", t)
        }
    }

    /**
     * Bind the emitter lambda. Agent 1 calls this once from
     * [Kixo.configure]; subsequent calls REPLACE the binding
     * (covers `Kixo.configure` reconfiguration during tests).
     *
     * Drains any pending visits buffered during cold-start.
     */
    fun bindEmitter(emitter: Emitter) {
        this.emitter = emitter
        val drained = synchronized(pendingBeforeBind) {
            val copy = pendingBeforeBind.toList()
            pendingBeforeBind.clear()
            copy
        }
        for (v in drained) {
            try {
                emitter.emit(v.toEmission())
            } catch (t: Throwable) {
                Log.w(TAG, "screen_visit drain emit failed", t)
            }
        }
    }

    /**
     * Test seam — clear the bound emitter and any pending buffer.
     * Production code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        emitter = null
        synchronized(pendingBeforeBind) { pendingBeforeBind.clear() }
    }

    // ─── Wire-format DTOs ───────────────────────────────────────────

    /**
     * Single screen-visit event passed across the package boundary.
     * Agent 1's emitter wires this into a full `KixoEvent` (Agent 2
     * model) — keeping this struct narrow + serialization-free means
     * Agent 9 doesn't compile-time depend on Agent 2.
     */
    internal data class Emission(
        val eventType: String,
        val eventName: String,
        val fingerprint: String,
        val properties: JsonObject,
        val timestampMillis: Long,
    )

    /** Emitter contract bound by Agent 1. */
    internal fun interface Emitter {
        fun emit(emission: Emission)
    }

    private data class PendingVisit(
        val screenId: String,
        val screenName: String,
        val prevScreenId: String?,
        val candidates: List<NameCandidate>,
        val trigger: Trigger,
        val wallClockMillis: Long,
    ) {
        fun toEmission(): Emission {
            val props = buildJsonObject {
                put("screen_id", JsonPrimitive(screenId))
                put("screen_name", JsonPrimitive(screenName))
                put(
                    "prev_screen_id",
                    if (prevScreenId == null) JsonNull else JsonPrimitive(prevScreenId),
                )
                put("trigger", JsonPrimitive(trigger.wire))
                put("_kixo_name_candidates", buildJsonArray {
                    for (c in candidates) {
                        add(
                            buildJsonObject {
                                put("value", JsonPrimitive(c.value))
                                put("source", JsonPrimitive(c.source.wireName()))
                                put("confidence", JsonPrimitive(c.confidence))
                            }
                        )
                    }
                })
            }
            return Emission(
                eventType = "screen_visit",
                eventName = screenName,
                fingerprint = screenId,
                properties = props,
                timestampMillis = wallClockMillis,
            )
        }
    }
}

/**
 * Pull the snake_case wire name for [NameSource]. Avoids reflection by
 * mirroring the [SerialName] annotations directly — kotlinx-serialization
 * IS the encoder so the values must match identically.
 */
private fun NameSource.wireName(): String = when (this) {
    NameSource.ExplicitOverride -> "explicit_override"
    NameSource.ActivityTitle -> "activity_title"
    NameSource.ToolbarTitle -> "toolbar_title"
    NameSource.FragmentTag -> "fragment_tag"
    NameSource.ComposeRoute -> "compose_route"
    NameSource.TopLabel -> "top_label"
    NameSource.Fingerprint -> "fingerprint"
}

