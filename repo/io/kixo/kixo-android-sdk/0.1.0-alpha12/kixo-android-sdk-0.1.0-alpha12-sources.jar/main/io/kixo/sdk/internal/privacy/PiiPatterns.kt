package io.kixo.sdk.internal.privacy

/**
 * Compiled regex constants and a Luhn checker, separated from
 * [PiiFilter] so the patterns table is reviewable in one place and
 * the Luhn helper is unit-testable in isolation.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Replay/PIIFilter.swift` patterns
 * table. Order is priority (first match wins per pass).
 *
 * ## Why eager compilation?
 * `Regex` compilation in Kotlin is non-trivial (~ms per pattern). The
 * SDK calls into [PiiFilter] from the OCR queue + every text-bearing
 * structural snapshot pass — compiling on every call would dominate
 * its own runtime. We compile once on first class-load via the
 * `internal val` initialiser and reuse the same `Regex` objects
 * forever.
 *
 * ## Anti-ReDoS
 * Every pattern is bounded by a fixed quantifier ceiling (`{2,15}`,
 * `{11,30}`, etc.) so Kotlin/Java's NFA-based engine can't catastrophic-
 * backtrack on adversarial input. The regex API used here is
 * `kotlin.text.Regex` which compiles to `java.util.regex.Pattern`
 * (Perl-compatible, NFA, prone to ReDoS — the bounded quantifiers
 * are our only protection, so DO NOT make any of these unbounded).
 */
internal object PiiPatterns {

    /**
     * One [Pattern] entry — the regex itself plus a flag indicating
     * whether matches require Luhn validation before being declared
     * PII. Only credit-card patterns set [requiresLuhn] = true: the
     * regex is intentionally permissive (accepts any 13-19 digit run
     * with optional separators) and Luhn rejects garbage like
     * "1234567890123" or barcode/SKU strings.
     */
    internal data class Pattern(
        val kind: PiiKind,
        val regex: Regex,
        val requiresLuhn: Boolean = false,
    )

    /**
     * The full pattern table, in priority order. Iteration in
     * [PiiFilter] runs each in turn against the source text; matches
     * from earlier patterns take precedence (we redact left-to-right
     * but the earlier-listed kinds get scanned first so their
     * placeholders win on collisions).
     *
     * **Pattern rationale (port from iOS PIIFilter.swift §Patterns):**
     *
     * 1. **Email** — RFC-friendly enough for ad-hoc redaction. Catches
     *    canonical `user@host.tld`. ASCII-only label part (no `\p{L}`)
     *    to keep ReDoS surface small; the iOS SDK is also ASCII here,
     *    Unicode label part is in the web SDK only.
     *
     * 2. **Phone (E.164)** — `+` followed by 8-15 digits. Matches
     *    `+14155551212`, `+79991234567`. Bounded `{8,15}` per E.164.
     *
     * 3. **Phone (US)** — `415 555 1212`, `(415) 555-1212`,
     *    `415-555-1212`, `415.555.1212`. Optional area-code parens.
     *
     * 4. **Credit card** — 13-19 digit run with optional spaces or
     *    dashes between groups. Luhn-gated (see [requiresLuhn]).
     *
     * 5. **SSN** — US 3-2-4: `123-45-6789`. The hyphenated form is
     *    the only one that meaningfully discriminates from random
     *    digit triples (`123456789` is too noisy to redact).
     *
     * 6. **JWT** — `eyJ` header marker followed by two more base64-url
     *    segments. Conservative: only fires on the canonical 3-segment
     *    shape, won't redact bare base64 strings.
     *
     * 7. **IBAN** — 2 letters + 2 digits + 11-30 alphanumerics. No
     *    checksum validation (would need country-specific table); we
     *    accept the positional pattern as redact-worthy since false
     *    positives on alphanumeric IDs are still better suppressed
     *    than IBANs leaking out.
     */
    internal val ALL: List<Pattern> = listOf(
        Pattern(
            kind = PiiKind.EMAIL,
            // Local part: alphanumerics + `._%+-`. Domain: alphanumerics
            // + `.-`, ending in a 2+ letter TLD. Bounded {2,24} on TLD
            // to anti-ReDoS. We intentionally don't anchor with `\b`
            // because Java word-boundary semantics around `+` and `-`
            // are inconsistent — the explicit char classes are the
            // boundary.
            regex = Regex("[A-Za-z0-9._%+\\-]{1,64}@[A-Za-z0-9.\\-]{1,255}\\.[A-Za-z]{2,24}"),
        ),
        Pattern(
            kind = PiiKind.PHONE,
            // E.164: `+` then 8 to 15 digits. Hard-bounded; no spaces
            // permitted in this form (separators belong to the US
            // pattern below).
            regex = Regex("\\+\\d{8,15}"),
        ),
        Pattern(
            kind = PiiKind.PHONE,
            // US: optional `(area)` then 3+3+4 with `-`, `.`, or space
            // separators. Optional country-code prefix `1` lives outside
            // the parens so `1 (415) 555-1212` matches.
            //
            // Two important constraints:
            //  - At least ONE explicit separator (`-`, `.`, space, or
            //    parens) is required between the digit groups so a
            //    raw 10-digit run like the first 10 digits of a
            //    16-digit credit card cannot steal the slot from the
            //    Luhn-validated card pattern below.
            //  - `(?<![\\d.\\-])` and `(?![\\d.\\-])` boundaries stop
            //    us greedily eating into adjacent digit runs (e.g. the
            //    last 4 digits of a credit card overflowing into the
            //    next sentence).
            regex = Regex(
                "(?<![\\d.\\-])" +
                    "(?:1[-.\\s])?" +
                    "(?:" +
                    "\\(\\d{3}\\)[-.\\s]?\\d{3}[-.\\s]?\\d{4}" + // (415) 555-1212
                    "|" +
                    "\\d{3}[-.\\s]\\d{3}[-.\\s]\\d{4}" + // 415-555-1212 / 415 555 1212 / 415.555.1212
                    ")" +
                    "(?![\\d.\\-])"
            ),
        ),
        Pattern(
            kind = PiiKind.CREDIT_CARD,
            // 13-19 digits with optional internal `-` or space.
            // Bounded by `{0,4}` on inter-digit separators so a
            // pathological input can't fan out. Luhn-validated by
            // [PiiFilter] before we declare it PII.
            regex = Regex("\\d(?:[ \\-]?\\d){12,18}"),
            requiresLuhn = true,
        ),
        Pattern(
            kind = PiiKind.SSN,
            // US: 3-2-4 with hyphen separator. Anchored on word
            // boundaries to avoid eating long digit runs (those are
            // either CC or false positives — we'd rather miss a
            // dash-less SSN than redact every account number).
            regex = Regex("\\b\\d{3}-\\d{2}-\\d{4}\\b"),
        ),
        Pattern(
            kind = PiiKind.JWT,
            // Three base64url segments separated by `.`. Header marker
            // `eyJ` is the deflated JSON `{"` so it's deterministic.
            // Bounded segment lengths per JWT structural limits.
            regex = Regex("eyJ[A-Za-z0-9_\\-]{4,1024}\\.[A-Za-z0-9_\\-]{4,4096}\\.[A-Za-z0-9_\\-]{8,4096}"),
        ),
        Pattern(
            kind = PiiKind.IBAN,
            // 2 letters + 2 digits + 11-30 alphanumerics. Word-bounded
            // so account numbers / hashes don't trigger false positives.
            regex = Regex("\\b[A-Z]{2}\\d{2}[A-Z0-9]{11,30}\\b"),
        ),
    )

    /**
     * Standard Luhn (mod-10) algorithm. Strips non-digits before
     * summing so input may include `-` or space separators (the regex
     * intentionally tolerates them).
     *
     * Returns `false` for inputs with fewer than 13 or more than 19
     * surviving digits — those bounds match the credit-card regex
     * above. A `false` result means "not a real card number" and the
     * caller should NOT redact (avoiding FP on barcodes / SKUs /
     * order numbers that happen to fall in the same digit-count band).
     *
     * Why a separate fun and not inlined? The iOS SDK keeps it a
     * private static for testability. Same here — [io.kixo.sdk.privacy]
     * tests can call this directly without going through the regex
     * pipeline.
     */
    @Suppress("MagicNumber")
    internal fun luhnValid(input: String): Boolean {
        // Walk in reverse, doubling every second digit. Cheaper than
        // building a list first; we only need an Int sum.
        var sum = 0
        var digitCount = 0
        var alt = false
        for (i in input.length - 1 downTo 0) {
            val ch = input[i]
            if (ch !in '0'..'9') continue
            var n = ch - '0'
            if (alt) {
                n *= 2
                if (n > 9) n -= 9
            }
            sum += n
            digitCount++
            alt = !alt
        }
        if (digitCount < 13 || digitCount > 19) return false
        return sum % 10 == 0
    }
}
