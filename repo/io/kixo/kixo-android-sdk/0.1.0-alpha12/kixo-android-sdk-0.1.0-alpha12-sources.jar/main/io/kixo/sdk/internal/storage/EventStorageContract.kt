package io.kixo.sdk.internal.storage

/**
 * Schema constants for the SDK's durable event store.
 *
 * Centralised so the SQL strings + the [EventStorageHelper] migration
 * code + the [SqliteEventStore] CRUD code reference the SAME column /
 * table names. A typo in any one of them used to be silent (sqlite
 * would happily create a misnamed column), so the convention is:
 * this file is the single source of truth, every SQL statement
 * concatenates against these constants.
 *
 * The schema deliberately mirrors Mixpanel's MPDB shape (one row per
 * event with a `flag` column for in-flight tracking) — see
 * [SqliteEventStore]'s class doc for the rationale. We keep the
 * exact same column names (`id`, `data`, `time`, `flag`) so anyone
 * familiar with MPDB or our iOS [SQLiteEventStore.swift] counterpart
 * recognises this immediately.
 */
internal object EventStorageContract {

    // ─── Database identity ────────────────────────────────────────

    /**
     * Sub-directory under `context.filesDir` where the db lives. We
     * prefer `filesDir` over `cacheDir` because `cacheDir` is purgeable
     * by the OS under storage pressure — that would silently lose the
     * pending-event queue. `filesDir` survives until the user clears
     * app data or uninstalls.
     */
    const val DB_DIR_NAME: String = "kixo"

    /**
     * Database file name. Lives at `<filesDir>/kixo/events.db`.
     * The companion WAL + SHM files (`events.db-wal`, `events.db-shm`)
     * are created by sqlite automatically once journal_mode=WAL is set.
     */
    const val DB_FILE_NAME: String = "events.db"

    /**
     * Schema version. Bump when a breaking change ships and add a
     * branch to [EventStorageHelper.onUpgrade]. v1 is the initial
     * MPDB-style single-table schema described below.
     */
    const val DB_VERSION: Int = 1

    // ─── Table & columns ──────────────────────────────────────────

    /** The one and only table. We never JOIN here — each event row is independent. */
    const val TABLE_EVENTS: String = "events"

    /** Stable event UUID (`KixoEvent.eventId`). PRIMARY KEY → de-dups idempotent retries. */
    const val COL_ID: String = "id"

    /**
     * The serialized [io.kixo.sdk.internal.model.KixoEvent] payload as a
     * UTF-8 JSON byte buffer. Stored as BLOB (not TEXT) so binary-safe
     * encoding choices (e.g. future protobuf migration) are a drop-in.
     */
    const val COL_DATA: String = "data"

    /**
     * Wall-clock time the event was created, **unix epoch
     * milliseconds** (`System.currentTimeMillis()`). Stored as REAL
     * (not INTEGER) to match the iOS column type — keeps the on-disk
     * file format identical between platforms in case a future
     * migration tool needs to read either.
     *
     * NOTE the unit difference: iOS uses **seconds** (double-precision
     * unix time via `Date.timeIntervalSince1970`), Android uses
     * **milliseconds**. The unit never crosses platform boundaries
     * (the db file never moves between iOS and Android), so this is
     * safe — but be careful if you compare `time` values to anything
     * external. Treat the unit as opaque outside this module.
     */
    const val COL_TIME: String = "time"

    /**
     * MPDB-style row state: 0 = pending, 1 = in-flight (claimed by a
     * checkout call but not yet ack'd by the server). On crash + next
     * launch [SqliteEventStore.recoverInFlight] resets all rows back
     * to 0 so the half-sent batch retries.
     *
     * Why not separate flags for retry/permanent-failure? The server's
     * per-event ack contract (R5 in `AGENT_BRIEFING.md`) says
     * permanent failures arrive as `errors[i].permanent=true` and the
     * SDK is expected to DELETE those rows just like accepted ones —
     * never an "unsent forever" state in the queue. So a single bit
     * is enough.
     */
    const val COL_FLAG: String = "flag"

    /** Pending — eligible for the next `checkout()`. */
    const val FLAG_PENDING: Int = 0

    /** In-flight — claimed by a checkout, awaiting server ack. */
    const val FLAG_IN_FLIGHT: Int = 1

    // ─── Indexes ──────────────────────────────────────────────────

    /**
     * `time ASC` is the FIFO claim order in [SqliteEventStore.checkout].
     * Without an index, claims would full-scan the table; with it,
     * even a 10k-row backlog claims in <1 ms.
     */
    const val IDX_TIME: String = "idx_${TABLE_EVENTS}_${COL_TIME}"

    /**
     * `flag` is filtered on every claim (`WHERE flag = 0`) and on
     * recovery (`UPDATE … WHERE flag = 1`). Cardinality is 2 so the
     * index isn't a huge win on small tables, but it's free in WAL
     * mode and earns its keep at scale.
     */
    const val IDX_FLAG: String = "idx_${TABLE_EVENTS}_${COL_FLAG}"

    // ─── Default knobs (override-able per-instance via constructor) ──

    /**
     * Maximum total rows in the buffer before [SqliteEventStore.append]
     * starts dropping oldest. Matches `KixoConfiguration.maxBufferSize`
     * default in the iOS SDK and the briefing's R4 hard cap. 200 events
     * × ~2 KB encoded = ~400 KB worst case on disk.
     */
    const val DEFAULT_MAX_ROWS: Int = 200

    /**
     * Default batch size for [SqliteEventStore.checkout]. The transport
     * layer (Agent 4) typically asks for less, but this caps a runaway
     * call and matches iOS's default load limit.
     */
    const val DEFAULT_CHECKOUT_LIMIT: Int = 100

    // ─── DDL (assembled from the constants above) ─────────────────

    /**
     * v1 schema. Run by [EventStorageHelper.onCreate]. The PRIMARY KEY
     * + DEFAULT clauses match the iOS counterpart byte-for-byte so
     * we get identical row layouts on disk.
     */
    val CREATE_TABLE_EVENTS: String = """
        CREATE TABLE IF NOT EXISTS $TABLE_EVENTS (
            $COL_ID TEXT PRIMARY KEY,
            $COL_DATA BLOB NOT NULL,
            $COL_TIME REAL NOT NULL,
            $COL_FLAG INTEGER NOT NULL DEFAULT $FLAG_PENDING
        );
    """.trimIndent()

    val CREATE_INDEX_TIME: String =
        "CREATE INDEX IF NOT EXISTS $IDX_TIME ON $TABLE_EVENTS($COL_TIME);"

    val CREATE_INDEX_FLAG: String =
        "CREATE INDEX IF NOT EXISTS $IDX_FLAG ON $TABLE_EVENTS($COL_FLAG);"
}
