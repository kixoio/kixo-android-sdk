package io.kixo.sdk.internal.lifecycle

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import java.lang.ref.WeakReference
import java.util.concurrent.CopyOnWriteArrayList

/**
 * Tracks the foreground-most Activity for the rest of the SDK to
 * grab via [currentActivity]. Used by:
 *   - The screen-fingerprint subsystem (Agent 9) to call
 *     `activity.window.decorView` and walk the view tree.
 *   - The replay subsystem (Agent 13) to root its frame snapshots
 *     in the right window.
 *   - Any future "show in-app message" feature that needs an Activity
 *     to attach a dialog to.
 *
 * **Strict rule (AGENT_BRIEFING.md §11 anti-examples + R6):** never
 * hold a strong reference to an Activity in a singleton — that's a
 * memory leak the size of the entire view hierarchy and easily one
 * of the most common Android SDK bugs. We use [WeakReference]
 * exclusively. Callers must tolerate `null` (the GC may have collected
 * the Activity between when `onActivityPaused` cleared our reference
 * and when the caller asked).
 *
 * Lifecycle ordering reminder (Android docs):
 *   onCreate → onStart → onResume → [onPause] → onStop → onDestroy
 *
 * We update the weak ref on `onResumed` (the canonical "this Activity
 * is the user-facing top one") and clear it on `onPaused` only when
 * the paused Activity matches our current top. This handles the
 * Activity A → Activity B transition cleanly: B's onResume happens
 * BEFORE A's onPause (yes really — see Android's Activity lifecycle
 * docs), so by the time A's onPause arrives the top is already B and
 * we leave the reference untouched.
 *
 * Thread safety: all `Application.ActivityLifecycleCallbacks` callbacks
 * fire on the main thread, so the @Volatile is just defensive
 * (callers may read `currentActivity()` from a worker thread).
 *
 * **Wave 8 — listener fan-out.** Other SDK subsystems
 * (`ScreenTracker`, `TouchInterceptor`) subscribe via [addListener] so
 * they can react to `onActivityCreated/Started/Resumed/Paused/Stopped`
 * without each registering its own
 * `Application.ActivityLifecycleCallbacks`. One central registration
 * keeps the host's callback-list tidy AND lets us guarantee
 * single-threaded ordering across all SDK observers (the platform
 * fires lifecycle callbacks on main, our fan-out is in-line).
 *
 * Listener exceptions are caught + logged per AGENT_BRIEFING R6 — a
 * misbehaving subsystem listener cannot break peer subsystems or the
 * host app.
 */
internal class ActivityLifecycleObserver : Application.ActivityLifecycleCallbacks {

    private companion object {
        const val TAG = "Kixo"
    }

    @Volatile
    private var topActivityRef: WeakReference<Activity> = WeakReference<Activity>(null)

    /**
     * Subscribers fanned out on every Activity lifecycle event. We use
     * [CopyOnWriteArrayList] so:
     *   - Reads (the lifecycle fan-out hot path) are lock-free.
     *   - Writes ([addListener] / [removeListener]) are O(N) but
     *     happen at most once per subsystem, at SDK configure time.
     *
     * Listeners can be added at any time AFTER the observer is
     * registered with the Application — they don't get backfill for
     * already-resumed Activities, but the ones that subscribe at
     * `Kixo.configure(...)` time normally land BEFORE the launcher
     * Activity reaches `onActivityResumed` (the platform creates the
     * Application before instantiating the launcher).
     */
    private val listeners: CopyOnWriteArrayList<KixoActivityListener> = CopyOnWriteArrayList()

    /**
     * The Activity currently in the resumed state, or `null` if none
     * is foregrounded (or the GC reclaimed it). Safe to call from
     * any thread.
     */
    fun currentActivity(): Activity? = topActivityRef.get()

    /**
     * Subscribe a listener. Idempotent — adding the same listener
     * twice is a no-op (CopyOnWriteArrayList semantics: the second
     * `add` would store a duplicate, which we explicitly avoid via
     * containment check). Safe to call from any thread.
     */
    fun addListener(listener: KixoActivityListener) {
        if (!listeners.contains(listener)) listeners.add(listener)
    }

    /** Unsubscribe a listener. Idempotent. */
    fun removeListener(listener: KixoActivityListener) {
        listeners.remove(listener)
    }

    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {
        // Track via onResumed for top-Activity, but FAN OUT onCreated
        // immediately — ScreenTracker uses onCreated to install its
        // optional FragmentManager.FragmentLifecycleCallbacks.
        fanOut("onActivityCreated") { it.onActivityCreated(activity, savedInstanceState) }
    }

    override fun onActivityStarted(activity: Activity) {
        // Fan out — TouchInterceptor uses onStarted to install its
        // per-window touch proxy + per-Activity scroll-end detector.
        fanOut("onActivityStarted") { it.onActivityStarted(activity) }
    }

    override fun onActivityResumed(activity: Activity) {
        topActivityRef = WeakReference(activity)
        // Fan out — ScreenTracker uses onResumed to drive a screen
        // visit attempt, which may emit `screen_view` and update
        // ScreenIdentity (TouchInterceptor reads ScreenIdentity to
        // stamp `screen_id` onto every tap event).
        fanOut("onActivityResumed") { it.onActivityResumed(activity) }
    }

    override fun onActivityPaused(activity: Activity) {
        // Only clear the reference if we ARE the top activity. This
        // handles the A → B transition: the platform fires
        // B.onResume → B.onStart → A.onPause, so by the time we get
        // A.onPause the topActivityRef is already pointing at B and
        // we mustn't null it out. Equality on the underlying Activity
        // pointer (===) is what we want — the WeakReference may have
        // already been cleared by the GC, in which case we no-op.
        val current = topActivityRef.get()
        if (current === activity) {
            // Don't null-out the ref on pause — the user might still
            // re-resume this same Activity (e.g. a transient dialog
            // dismissed). Leave the WeakReference in place; if the
            // Activity is destroyed later the GC reclaims it and
            // `currentActivity()` correctly returns null.
        }
        fanOut("onActivityPaused") { it.onActivityPaused(activity) }
    }

    override fun onActivityStopped(activity: Activity) {
        // Fan out — TouchInterceptor uses onStopped to restore the
        // original Window.Callback so the Activity can be GC'd cleanly
        // when its task moves to the background.
        fanOut("onActivityStopped") { it.onActivityStopped(activity) }
    }

    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {
        // No-op. No subsystem needs save-state notification today; we
        // omit the fan-out to avoid a hot-path allocation for an
        // event no listener cares about.
    }

    override fun onActivityDestroyed(activity: Activity) {
        val current = topActivityRef.get()
        if (current === activity) {
            // Explicit reset — even though the WeakReference would
            // eventually clear on its own, having a synchronous null
            // here means subsequent currentActivity() returns null
            // immediately rather than depending on GC scheduling.
            topActivityRef = WeakReference<Activity>(null)
        }
        fanOut("onActivityDestroyed") { it.onActivityDestroyed(activity) }
    }

    /**
     * Fan out the supplied callback to every registered listener,
     * catching per-listener exceptions so a misbehaving subsystem
     * (e.g. a hot-reload-time replay reset that throws inside a
     * Compose preview process) cannot break the rest of the SDK.
     *
     * The lambda receives a [KixoActivityListener] and is expected
     * to invoke ONE method on it. The [tag] is used in the WARN log
     * if any listener throws so triage can identify which lifecycle
     * stage was problematic.
     */
    private inline fun fanOut(tag: String, crossinline call: (KixoActivityListener) -> Unit) {
        // Snapshot the listener list once. CopyOnWriteArrayList's
        // iterator is already snapshot-safe but pulling it once per
        // dispatch saves a virtual call vs the live iterator.
        for (listener in listeners) {
            try {
                call(listener)
            } catch (t: Throwable) {
                Log.w(TAG, "Activity listener ${listener::class.java.simpleName} threw in $tag", t)
            }
        }
    }
}

/**
 * Subscriber interface for [ActivityLifecycleObserver]. Subsystems
 * implement only the methods they care about and rely on the default
 * empty bodies for the rest. All callbacks fire on the main thread
 * (the platform's `Application.ActivityLifecycleCallbacks` contract).
 *
 * **Why a single interface vs. multiple narrow ones:** every Android
 * subsystem we wire today (ScreenTracker, TouchInterceptor) needs
 * MULTIPLE lifecycle hooks (created+resumed for ScreenTracker,
 * started+stopped for TouchInterceptor). A single interface with
 * default `{}` impls keeps the registration boundary one-line per
 * subsystem and avoids the explosion of "this listener for created,
 * that one for resumed" wiring.
 */
internal interface KixoActivityListener {
    fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    fun onActivityStarted(activity: Activity) {}
    fun onActivityResumed(activity: Activity) {}
    fun onActivityPaused(activity: Activity) {}
    fun onActivityStopped(activity: Activity) {}
    fun onActivityDestroyed(activity: Activity) {}
}
