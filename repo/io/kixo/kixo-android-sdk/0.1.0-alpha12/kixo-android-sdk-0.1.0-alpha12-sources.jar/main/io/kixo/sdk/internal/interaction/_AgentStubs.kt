@file:Suppress("unused")

package io.kixo.sdk.internal.interaction

import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType

/**
 * Agent-coordination stubs for collaborators this folder depends on
 * but does not own. Per AGENT_BRIEFING §6, an agent that needs types
 * from another agent's folder may declare lightweight stand-ins in
 * their own folder until the owning agent's types land.
 *
 * **Owners of the real types:**
 *   - [EventQueueRef]            → Agent 5 (`io.kixo.sdk.internal.queue.EventQueue`)
 *   - [IdentityProviderRef]      → Agent 15 (`io.kixo.sdk.internal.identity.IdentityManager`)
 *   - [ScreenTrackerRef]         → Agent 9 (`io.kixo.sdk.internal.screen.ScreenTracker`)
 *   - [ActivityCallbacksRef]     → Agent 7 (`io.kixo.sdk.internal.lifecycle.ActivityLifecycleObserver`)
 *
 * The interfaces are deliberately minimal — they expose only the
 * surface this folder calls into. When the real owners land, this
 * file is deleted and the call sites switch to the canonical types
 * directly. Until then, [TouchInterceptor] and [ScrollEndDetector]
 * accept these interfaces in their constructors so unit tests can
 * inject fakes.
 */

/**
 * What we need from Agent 5's `EventQueue`. The full surface is
 * larger; we only call [enqueue] from the gesture pipeline.
 *
 * Per AGENT_BRIEFING.md anti-example §11, [enqueue] MUST be
 * non-blocking — implementations must not perform any IO inline.
 * The real `EventQueue` dispatches into its own coroutine.
 */
internal interface EventQueueRef {
    /**
     * Hand a fully-built event to the queue. Returns immediately;
     * the queue handles batching, persistence, retry, and ack
     * classification asynchronously.
     */
    fun enqueue(event: KixoEvent)
}

/**
 * What we need from Agent 15's `IdentityManager`. We just need the
 * three-tuple of stable identifiers to stamp on every event.
 *
 * `userId` is null until the host calls `Kixo.identify(...)`.
 */
internal interface IdentityProviderRef {
    fun deviceId(): String
    fun anonymousId(): String
    fun userId(): String?

    /**
     * Active session UUID. Rolls when the app backgrounds for >30s
     * (the Agent 9 SessionTracker rule). Stamped onto every event so
     * downstream session reconstruction is O(1).
     */
    fun sessionId(): String
}

/**
 * What we need from Agent 9's `ScreenTracker`. Returns the current
 * screen-fingerprint hash + a human-readable name candidate when
 * available. Both can be null for events fired before the first
 * `ACTION_DOWN` reaches a content view (e.g. system splash).
 */
internal interface ScreenTrackerRef {
    /**
     * Stable hex fingerprint of the current screen's view hierarchy.
     * Empty string if no screen has been registered yet.
     */
    fun currentScreenId(): String

    /**
     * Operator-friendly screen name (NameCandidateCollector winner).
     * Used as the event_name for the resulting tap event when the
     * tap target itself has no resolvable label.
     */
    fun currentScreenName(): String?
}

/**
 * What we need from Agent 7's `ActivityLifecycleObserver`. We
 * subscribe to attach our touch interception to each foregrounded
 * activity's window, and detach when it backgrounds.
 *
 * Implementations are expected to:
 *   - Invoke [onActivityStarted] on every `Application.ActivityLifecycleCallbacks#onActivityStarted`.
 *   - Invoke [onActivityStopped] on every `Application.ActivityLifecycleCallbacks#onActivityStopped`.
 *
 * Both receive the raw `Activity` so we can grab `activity.window`
 * + `activity.findViewById(android.R.id.content)` for the hit-test
 * resolver. We never hold a hard reference to the `Activity` past
 * the callback call (briefing anti-example §11).
 */
internal interface ActivityCallbacksRef {
    fun addCallback(callback: ActivityWindowCallback)
    fun removeCallback(callback: ActivityWindowCallback)
}

/**
 * Subscriber interface for [ActivityCallbacksRef]. Implementations
 * MUST treat the supplied `Any` as the host's `android.app.Activity`
 * — we accept `Any` so this interface can be unit-tested under JVM
 * without pulling in the Android stub jar at the protocol layer.
 */
internal interface ActivityWindowCallback {
    fun onActivityStarted(activity: Any)
    fun onActivityStopped(activity: Any)
}
