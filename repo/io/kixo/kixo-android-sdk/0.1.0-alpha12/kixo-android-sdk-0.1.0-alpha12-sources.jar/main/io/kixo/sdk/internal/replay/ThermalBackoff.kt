package io.kixo.sdk.internal.replay

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.util.Log
import androidx.annotation.RequiresApi
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Pauses replay capture when the device is thermally stressed, in
 * Low Power Mode, on critically low battery, or under sustained
 * memory pressure. Mirrors iOS [ThermalBackoff.swift] semantics
 * adapted to Android's [PowerManager] / [BatteryManager] APIs.
 *
 * **Why this matters:** the replay pipeline does perceivable work
 * on every tap — `View.draw()` snapshot (~5 ms), ML Kit OCR
 * (~60-100 ms on mid-tier devices), JPEG/HEIC encoding (~20 ms),
 * background HTTP upload (radio + CPU). On a hot device or in
 * battery-saver mode this stack can tip the user's perceived
 * performance over the edge — frames stutter, battery drains
 * visibly faster, and we just lost the customer's trust.
 *
 * **Trip points:**
 *  - [PowerManager.getCurrentThermalStatus] ≥
 *    [PowerManager.THERMAL_STATUS_SEVERE] (API 29+) → pause until
 *    state drops below `SEVERE`. The `SEVERE` level is Android's
 *    "performance is being throttled, reduce work" signal.
 *  - [PowerManager.isPowerSaveMode] = true → pause until the user
 *    disables Battery Saver. `ACTION_POWER_SAVE_MODE_CHANGED`
 *    fires both directions.
 *  - Battery level < 15 % AND not charging → pause. `ACTION_BATTERY_CHANGED`
 *    sticky broadcast supplies the level.
 *  - Memory pressure (Agent 7's [MemoryPressure.CRITICAL]) — wired
 *    by [ReplayController], not by this class directly.
 *
 * **What "pause" means:**
 *  - Calls the registered [onStateChange] closure with `shouldPause=true`.
 *  - [ReplayController] disables tap-handling there: new taps still
 *    emit metadata-only events but no Bitmap capture happens.
 *  - Frames already on disk continue uploading (no point holding
 *    them — they were captured pre-throttle, and uploads run on a
 *    background dispatcher that doesn't count against the
 *    foreground app's thermal budget).
 *  - Sampler verdict is unchanged; recovery is automatic.
 *
 * **API min-sdk note.** [PowerManager.getCurrentThermalStatus]
 * landed in API 29 (Android 10). On API 24-28 we degrade gracefully:
 * thermal trips never fire (Android pre-Q has no equivalent OS
 * signal), but battery + power-save-mode trips still work. That's
 * acceptable — pre-Android-10 devices represent < 5 % of the
 * install base today (May 2026) and the missing thermal coverage
 * fails open (capture continues), not closed.
 */
internal class ThermalBackoff internal constructor(
    private val context: Context,
    private val powerManager: PowerManager,
) {

    /**
     * `true` while replay is allowed; `false` while paused for
     * thermal / power / battery / memory reasons. Read by
     * [ReplayController] to gate its tap handler. Atomic because
     * [evaluate] can fire from broadcast-receiver threads.
     */
    private val isActive = AtomicBoolean(true)

    /**
     * Caller — typically [ReplayController] — registers a closure
     * to be invoked on each state transition. Thread: invoked on
     * whichever thread fired the trip (broadcast-receiver, main,
     * or thermal-listener executor).
     */
    @Volatile
    var onStateChange: ((shouldPause: Boolean, reason: PauseReason) -> Unit)? = null

    /**
     * Closed enum of pause reasons surfaced by [evaluate]. Wire
     * names match iOS [ThermalBackoff.PauseReason] for cross-
     * platform parity in observability dashboards.
     */
    enum class PauseReason(val wire: String) {
        /** [PowerManager.THERMAL_STATUS_SEVERE] or higher. */
        ThermalSevere("thermal_severe"),

        /** [PowerManager.THERMAL_STATUS_CRITICAL] / EMERGENCY. */
        ThermalCritical("thermal_critical"),

        /** [PowerManager.isPowerSaveMode]. */
        LowPower("low_power"),

        /** Battery level < 15 % and not charging. */
        LowBattery("low_battery"),

        /** Agent 7's `MemoryPressure.CRITICAL` — wired externally. */
        LowMemory("low_memory"),

        /** All trips cleared; capture resumes. */
        Recovered("recovered"),
    }

    private val powerSaveReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            evaluate()
        }
    }

    private val batteryReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            evaluate()
        }
    }

    /**
     * API-29+ thermal listener. Stored as `Any?` so a) the JVM-only
     * unit-test path doesn't depend on API-29 stubs, and b) we can
     * conditionally register only on supported devices.
     */
    private var thermalListener: Any? = null

    private val started = AtomicBoolean(false)

    /**
     * Begin observing. Idempotent — the second call is a cheap
     * no-op. Wires three independent signals:
     *   1. Power-save broadcast (`ACTION_POWER_SAVE_MODE_CHANGED`)
     *   2. Battery broadcast (`ACTION_BATTERY_CHANGED` sticky)
     *   3. API-29+ [PowerManager.OnThermalStatusChangedListener]
     *
     * After registration, runs an initial [evaluate] so the
     * controller's [onStateChange] hears the current state without
     * waiting for a trip event.
     */
    fun start() {
        if (!started.compareAndSet(false, true)) return

        try {
            context.registerReceiver(
                powerSaveReceiver,
                IntentFilter(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED),
            )
        } catch (t: Throwable) {
            // Some niche OEM builds reject this filter — log but keep
            // going; the API-29 thermal listener handles the most
            // important case anyway.
            Log.w(TAG, "power-save receiver register failed", t)
        }

        try {
            // ACTION_BATTERY_CHANGED is a sticky broadcast — register
            // returns the latest cached intent which `evaluate` reads
            // directly. So we do NOT need to wait for the first
            // change; we already have the current battery level.
            context.registerReceiver(
                batteryReceiver,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            )
        } catch (t: Throwable) {
            Log.w(TAG, "battery receiver register failed", t)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            registerThermalListenerApi29()
        }

        evaluate()
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun registerThermalListenerApi29() {
        try {
            val listener = PowerManager.OnThermalStatusChangedListener { evaluate() }
            powerManager.addThermalStatusListener(listener)
            thermalListener = listener
        } catch (t: Throwable) {
            Log.w(TAG, "thermal listener register failed", t)
        }
    }

    /**
     * Stop observing + release native registrations. Called on
     * [ReplayController.optOut]. Subsequent [start] calls re-arm.
     */
    fun stop() {
        if (!started.compareAndSet(true, false)) return
        runCatching { context.unregisterReceiver(powerSaveReceiver) }
        runCatching { context.unregisterReceiver(batteryReceiver) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            (thermalListener as? PowerManager.OnThermalStatusChangedListener)?.let {
                runCatching { powerManager.removeThermalStatusListener(it) }
            }
        }
        thermalListener = null
    }

    /**
     * Whether replay is currently allowed. Used by [ReplayController]
     * to guard its tap handler against firing during a trip when
     * the listener fired BEFORE the controller's start() landed
     * (race during cold start).
     */
    fun isCaptureAllowed(): Boolean = isActive.get()

    /**
     * Inspect every signal + push a coherent state to the
     * controller. Computed every time a trip fires rather than
     * caching, because the three signals can race and we want the
     * FINAL state to be self-consistent.
     *
     * Priority: thermal > low-power > low-battery. We surface the
     * MOST SEVERE current condition.
     */
    private fun evaluate() {
        val thermalReason: PauseReason? =
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                when (powerManager.currentThermalStatus) {
                    PowerManager.THERMAL_STATUS_CRITICAL,
                    PowerManager.THERMAL_STATUS_EMERGENCY,
                    PowerManager.THERMAL_STATUS_SHUTDOWN -> PauseReason.ThermalCritical
                    PowerManager.THERMAL_STATUS_SEVERE -> PauseReason.ThermalSevere
                    else -> null
                }
            } else {
                null
            }

        val lowPower: Boolean = try {
            powerManager.isPowerSaveMode
        } catch (t: Throwable) {
            // Defensive — we never let a missing OS feature crash
            // the host (briefing R6). Treat as "no signal" → no
            // pause from this axis.
            false
        }

        val lowBattery: Boolean = isLowBatteryAndNotCharging()

        val newPauseReason: PauseReason? = thermalReason
            ?: if (lowPower) PauseReason.LowPower
            else if (lowBattery) PauseReason.LowBattery
            else null

        if (newPauseReason != null) {
            if (isActive.compareAndSet(true, false)) {
                onStateChange?.invoke(true, newPauseReason)
            } else if (!isActive.get()) {
                // Already paused — fire the closure again so the
                // operator dashboard sees that the REASON changed
                // (e.g. thermal-severe → thermal-critical). Idempotent
                // for the controller (it's already paused).
                onStateChange?.invoke(true, newPauseReason)
            }
            return
        }

        if (isActive.compareAndSet(false, true)) {
            onStateChange?.invoke(false, PauseReason.Recovered)
        }
    }

    /**
     * Public hook for [ReplayController] to inject an external
     * pause / resume signal — e.g. when Agent 7's
     * [io.kixo.sdk.internal.lifecycle.MemoryPressure] flow goes
     * `CRITICAL`. Surfaced as [PauseReason.LowMemory] so the
     * dashboard observability bucket is correct.
     */
    fun externalPause(reason: PauseReason) {
        if (isActive.compareAndSet(true, false)) {
            onStateChange?.invoke(true, reason)
        }
    }

    /**
     * Counterpart to [externalPause]. Call when the external
     * condition has cleared. `evaluate()` re-checks the OS-level
     * signals before un-pausing — we don't want to flip ON if the
     * thermal trip is also still active.
     */
    fun externalResume() {
        evaluate()
    }

    /**
     * Battery sticky-broadcast inspection. Returns `true` when level
     * < 15 % AND we're not on USB / AC / wireless charge.
     *
     * Sticky broadcast means we don't need to wait for the next
     * `ACTION_BATTERY_CHANGED` event — `registerReceiver` returns
     * the cached intent immediately. We inspect that here.
     */
    private fun isLowBatteryAndNotCharging(): Boolean {
        return try {
            val intent = context.registerReceiver(
                /* receiver = */ null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ) ?: return false

            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

            if (level < 0 || scale <= 0) return false

            val pct = level * 100 / scale
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

            pct < LOW_BATTERY_PCT_THRESHOLD && !charging
        } catch (t: Throwable) {
            Log.w(TAG, "battery probe failed", t)
            false
        }
    }

    companion object {
        private const val TAG = "Kixo"

        /** Battery percentage below which we treat as "low" (matches iOS). */
        private const val LOW_BATTERY_PCT_THRESHOLD = 15

        /**
         * Test-only constructor seam. Production callers go through
         * [from] which acquires a real [PowerManager]; tests inject
         * mocks via this method.
         */
        @androidx.annotation.VisibleForTesting
        internal fun forTesting(
            context: Context,
            powerManager: PowerManager,
        ): ThermalBackoff = ThermalBackoff(context, powerManager)

        /** Production constructor — acquires the system [PowerManager]. */
        fun from(context: Context): ThermalBackoff {
            val pm = context.applicationContext
                .getSystemService(Context.POWER_SERVICE) as PowerManager
            return ThermalBackoff(context.applicationContext, pm)
        }
    }
}
