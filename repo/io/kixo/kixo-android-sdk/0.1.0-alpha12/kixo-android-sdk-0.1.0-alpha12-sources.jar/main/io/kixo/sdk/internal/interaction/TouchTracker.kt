package io.kixo.sdk.internal.interaction

import android.view.MotionEvent
import io.kixo.sdk.internal.interaction.GestureClassifier.GestureBatch
import io.kixo.sdk.internal.interaction.GestureClassifier.TouchTrack

/**
 * Per-pointer state machine that consumes raw `MotionEvent` actions
 * and emits a [GestureBatch] when the LAST finger lifts off the
 * screen.
 *
 * **Why a separate tracker rather than inline in [TouchInterceptor]:**
 *   - Pure JVM testable — no Android touch dispatch required.
 *   - Single ownership of the per-pointer dictionary; the
 *     interceptor is just plumbing to/from `Window.Callback`.
 *   - Mirrors the iOS architecture (`WindowEventInterceptor`
 *     keeps `touchStartLocations: [ObjectIdentifier(touch): CGPoint]`
 *     on the side, classifier is otherwise stateless).
 *
 * **Threading contract.** Called only from the UI thread (Android's
 * `Window.Callback.dispatchTouchEvent` runs on the main thread).
 * Because there is exactly one writer, the internal map is a plain
 * `MutableMap`, no synchronisation. Tests that drive this from a
 * background thread MUST serialise their calls externally.
 *
 * **No allocation on `ACTION_MOVE`.** That was the iOS perf hot
 * path. Move events are dispatched at 60-240 Hz during a scroll;
 * allocating per-event would balloon GC pressure. Our handler
 * intentionally returns `null` immediately on `ACTION_MOVE` without
 * even touching the active-pointer map (we never read intermediate
 * positions — the classifier wants `down → up`, not the trail).
 *
 * **Recently-removed buffer.** When a pointer goes up
 * (`ACTION_POINTER_UP`) but other fingers stay down, the gesture
 * isn't done yet. We move that pointer's [TouchTrack] into a
 * recently-removed list so when the LAST pointer finally lifts the
 * full multi-touch group is delivered to the classifier. The buffer
 * is bounded to prevent runaway accumulation if a pathological
 * sequence (host swallows ACTION_UP via `requestDisallowIntercept`,
 * we never see the close) keeps adding to it. Cleared on every
 * fresh `ACTION_DOWN` (initial finger).
 */
internal class TouchTracker {

    /** Active pointers indexed by `MotionEvent.getPointerId(...)`. */
    private val active = HashMap<Int, ActivePointer>(4)

    /** Pointers that lifted while others remain down. Drained on final UP. */
    private val recentlyRemoved = ArrayList<TouchTrack>(4)

    /**
     * Wall-clock timestamp of the gesture's first ACTION_DOWN.
     * `MotionEvent.getEventTime` is `SystemClock.uptimeMillis` —
     * monotonic, suitable for duration arithmetic, NOT a wall-clock
     * timestamp suitable for `KixoEvent.timestamp` (caller stamps
     * that itself per AGENT_BRIEFING anti-example §11).
     */
    private var gestureStartUptime: Long = 0L

    /**
     * Feed one MotionEvent action. Returns a [GestureBatch] only
     * when the gesture has fully terminated (last finger up OR
     * cancel). All intermediate actions return null — the caller
     * passes them through to the wrapped [android.view.Window.Callback]
     * unchanged.
     *
     * **Hard-bounded.** If `recentlyRemoved` ever exceeds 16 (more
     * fingers than any device supports) we snapshot what we have
     * and reset state — the gesture's lifecycle has clearly drifted
     * out of sync with what the system delivered to us.
     */
    fun onMotion(event: MotionEvent): GestureBatch? {
        val action = event.actionMasked
        when (action) {
            MotionEvent.ACTION_DOWN -> {
                // Fresh gesture — reset all state. ACTION_DOWN is
                // always pointer index 0 by Android contract.
                active.clear()
                recentlyRemoved.clear()
                gestureStartUptime = event.eventTime
                rememberDown(event, pointerIndex = 0)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                rememberDown(event, pointerIndex = event.actionIndex)
            }
            MotionEvent.ACTION_MOVE -> {
                // Intentionally no-op. We only track down + up
                // positions per the iOS bug post-mortem
                // (`feedback_perf_diagnosis.md`). Reading per-frame
                // positions here would (a) explode GC pressure during
                // active scroll and (b) re-introduce the false-tap
                // landmine that took 3 days to diagnose on iOS.
                return null
            }
            MotionEvent.ACTION_POINTER_UP -> {
                // One finger of a multi-touch gesture lifted; others
                // still down. Move the pointer's TouchTrack into the
                // pending-batch buffer.
                consumeUp(event, pointerIndex = event.actionIndex)
                if (recentlyRemoved.size > 16) {
                    // Defensive overflow valve: deliver what we have
                    // and reset. Should never fire on healthy input.
                    return finalizeBatch()
                }
                return null
            }
            MotionEvent.ACTION_UP -> {
                consumeUp(event, pointerIndex = event.actionIndex)
                return finalizeBatch()
            }
            MotionEvent.ACTION_CANCEL -> {
                // The system or a parent view stole the gesture
                // (e.g. `requestDisallowInterceptTouchEvent` flipped
                // mid-gesture by a containing scroll view). We
                // discard whatever was in flight — emitting a tap
                // here would create a phantom event the user did
                // not intend.
                active.clear()
                recentlyRemoved.clear()
                return null
            }
            else -> {
                // ACTION_HOVER_*, ACTION_BUTTON_PRESS, etc. We don't
                // classify hover events as taps; ignore.
                return null
            }
        }
        return null
    }

    private fun rememberDown(event: MotionEvent, pointerIndex: Int) {
        val pid = event.getPointerId(pointerIndex)
        active[pid] = ActivePointer(
            startX = event.getX(pointerIndex),
            startY = event.getY(pointerIndex),
            downAtMs = event.eventTime,
        )
    }

    private fun consumeUp(event: MotionEvent, pointerIndex: Int) {
        val pid = event.getPointerId(pointerIndex)
        val begin = active.remove(pid) ?: return
        recentlyRemoved.add(
            TouchTrack(
                pointerId = pid,
                startX = begin.startX,
                startY = begin.startY,
                endX = event.getX(pointerIndex),
                endY = event.getY(pointerIndex),
                downAtMs = begin.downAtMs,
                upAtMs = event.eventTime,
            )
        )
    }

    private fun finalizeBatch(): GestureBatch? {
        // Any pointer still in `active` at finalize time means the
        // host stole some pointers via `ACTION_CANCEL` mid-gesture
        // but kept others alive. Treat those as best-effort: synth
        // an `up` at the original `down` location so the classifier
        // sees them as zero-displacement participants (so a 2-finger
        // tap with one cancelled finger still classifies as
        // multi_tap rather than getting silently dropped).
        if (active.isNotEmpty()) {
            for ((pid, p) in active) {
                recentlyRemoved.add(
                    TouchTrack(
                        pointerId = pid,
                        startX = p.startX,
                        startY = p.startY,
                        endX = p.startX,
                        endY = p.startY,
                        downAtMs = p.downAtMs,
                        upAtMs = p.downAtMs,
                    )
                )
            }
            active.clear()
        }
        if (recentlyRemoved.isEmpty()) return null
        val batch = GestureBatch(recentlyRemoved.toList())
        recentlyRemoved.clear()
        return batch
    }

    /**
     * Reset all state. Called by the interceptor when the activity
     * goes to background — pending touches are not meaningful for
     * the next foreground session.
     */
    fun reset() {
        active.clear()
        recentlyRemoved.clear()
        gestureStartUptime = 0L
    }

    /**
     * Snapshot of a finger's down event. Allocated once per finger
     * per gesture (so 1-3 allocations for typical input) and freed
     * when the finger goes up.
     */
    private data class ActivePointer(
        val startX: Float,
        val startY: Float,
        val downAtMs: Long,
    )
}
