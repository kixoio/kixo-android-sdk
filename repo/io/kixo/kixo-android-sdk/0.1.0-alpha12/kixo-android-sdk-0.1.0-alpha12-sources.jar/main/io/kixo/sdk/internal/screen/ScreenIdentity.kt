package io.kixo.sdk.internal.screen

import java.util.concurrent.atomic.AtomicReference

/**
 * Process-wide singleton holding the current screen identity. Read by:
 *
 *  - **Agent 8 — InteractionTracker** (`io.kixo.sdk.internal.interaction`)
 *    — stamps `screen_id` / `screen_name` / `_kixo_name_candidates`
 *    onto every emitted tap / scroll event so the backend can join
 *    interactions to their hosting screen without a server-side
 *    `LAG OVER PARTITION BY session_id` query.
 *  - **Agent 13 — ReplayController** (`io.kixo.sdk.internal.replay`)
 *    — joins captured frames to the screen they belong to (the
 *    structural snapshot already carries the role tree, but the
 *    human-readable name comes from here).
 *  - **Agent 12 — Goal detection** — when `Kixo.markGoal` fires the
 *    goal needs to know which screen surfaced it.
 *
 * **Why an [AtomicReference] not a Flow:** the consumers above all
 * read a SNAPSHOT (latest value at the moment a tap fires); none of
 * them need to react to changes. AtomicReference gives us lock-free
 * single-instruction reads from any thread, which is the cheapest
 * possible primitive for the hot interaction path. If a future agent
 * needs a stream they can wrap this with their own [MutableStateFlow]
 * collector.
 *
 * **Threading:** writes happen from the main thread (via
 * [ScreenTracker]); reads can happen from any thread.
 *
 * **Initial value:** [Snapshot.UNKNOWN] until the first screen visit
 * is recorded. Consumers handle the unknown case by stamping an empty
 * `screen_id` and letting the backend fold the event into its parent
 * session's first known screen.
 */
internal object ScreenIdentity {

    /**
     * Current screen state, read once per consumer query.
     *
     * @property screenId Stable ID — the [ScreenFingerprint] hex prefix.
     *   `"empty"` until the first visit; never null.
     * @property screenName Best-guess human name from
     *   [NameCandidate.bestName]. Falls back to `"Screen_<hex>"`
     *   when no plausible candidate exists.
     * @property candidates Full multi-source candidate list. Goes onto
     *   subsequent events as `_kixo_name_candidates` so the backend
     *   sees ALL signals, not just the SDK's local pick — that lets
     *   server-side voting override a momentarily-wrong local pick
     *   based on cross-session frequency.
     */
    internal data class Snapshot(
        val screenId: String,
        val screenName: String,
        val candidates: List<NameCandidate>,
    ) {
        companion object {
            val UNKNOWN = Snapshot(
                screenId = "",
                screenName = "",
                candidates = emptyList(),
            )
        }
    }

    private val current = AtomicReference(Snapshot.UNKNOWN)

    /**
     * Lock-free snapshot read. Safe from any thread including the
     * tap-event hot path. Always non-null; returns [Snapshot.UNKNOWN]
     * before the first screen visit.
     */
    fun current(): Snapshot = current.get()

    /**
     * Update the current snapshot. Called by [ScreenTracker] from the
     * main thread on every accepted screen change. Returns the
     * PREVIOUS snapshot so [ScreenVisitRecorder] can stamp
     * `prev_screen_id` without an extra read.
     */
    fun update(snapshot: Snapshot): Snapshot = current.getAndSet(snapshot)

    /**
     * Test seam — reset to UNKNOWN between unit-test runs. Production
     * code never calls this; the AtomicReference is process-lifetime.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        current.set(Snapshot.UNKNOWN)
    }
}
