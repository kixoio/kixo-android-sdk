package io.kixo.sdk.internal.model

import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Request body for `POST /api/sdk/push/register`.
 *
 * **The ONLY place a plaintext push token leaves the device.** Per
 * AGENT_BRIEFING.md R10 + the iOS-parity contract: every other event
 * carrying a token-derived field uses SHA-256(token); the raw
 * `token` field below is the single exception, intentional, and
 * routes only to this endpoint (which itself stores the token
 * encrypted at rest server-side for delivery).
 *
 * **Wave 6 lesson** (`@EncodeDefault(ALWAYS)` on `platform`): the
 * SDK's Json instance is configured with `encodeDefaults = false`
 * to keep batches small. Without the explicit encode-default
 * directive, the `platform = "android"` default value gets dropped
 * from the wire. Backend then 400's because `platform` is required.
 * Same defensive pattern applied here as in [InitRequest] +
 * [BatchPayload].
 *
 * Wire shape (snake_case, matches `kixo-backend/apps/web/src/app/api/sdk/push/register/route.ts`):
 * ```json
 * {
 *   "project_id": "kx_proj_…",
 *   "api_key":    "kx_key_…",
 *   "device_id":  "uuid",
 *   "user_id":    "alex@example.com" | null,
 *   "token":      "<plaintext FCM/APNs token>",
 *   "platform":   "android"
 * }
 * ```
 */
@OptIn(ExperimentalSerializationApi::class)
@Serializable
internal data class PushRegisterRequest(
    @SerialName("project_id")
    val projectId: String,

    @SerialName("api_key")
    val apiKey: String,

    @SerialName("device_id")
    val deviceId: String,

    @SerialName("user_id")
    val userId: String? = null,

    /**
     * Plaintext push token. Bearer-class secret — DO NOT log, DO NOT
     * stash in any [KixoEvent], DO NOT include in any other endpoint's
     * payload. The endpoint stores it encrypted server-side.
     */
    @SerialName("token")
    val token: String,

    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("platform")
    val platform: String = "android",
)
