package io.kixo.sdk.internal.lifecycle

import android.app.Application
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.net.Uri
import android.util.Log

/**
 * No-op `ContentProvider` whose sole purpose is to give us a stable hook
 * into the host process **before** any `Activity` is launched. This is
 * the same trick Firebase uses (`FirebaseInitProvider`) and the AndroidX
 * `androidx.startup.InitializationProvider` is built around: the
 * platform calls every declared provider's `onCreate()` immediately
 * after `Application.onCreate()` returns (and BEFORE the launcher
 * Activity is created), giving us a guaranteed, host-app-agnostic
 * place to install lifecycle observers.
 *
 * Why this matters for us:
 *   - We want `app_launch` / `app_foreground` / `session_start` to fire
 *     reliably even when the host integrator forgets to call
 *     `Kixo.configure()` from `Application.onCreate()`. Without this
 *     provider, the very first foreground transition would be missed
 *     because [ProcessLifecycleObserver] would not yet be registered.
 *   - The `Application` reference captured here is what every other
 *     subsystem ([ActivityLifecycleObserver], [MemoryWarningObserver],
 *     `ReplayController`, `EventQueue`'s WorkManager scheduling) needs,
 *     so capturing it once at process start removes a class of
 *     hard-to-debug "context was null" race conditions.
 *
 * The manifest declares this provider with
 * `android:authorities="${applicationId}.kixo-initializer"` and
 * `android:exported="false"` so no other process can poke at it.
 *
 * See `kixo/src/main/AndroidManifest.xml` for the manifest entry.
 *
 * **Hard rule (AGENT_BRIEFING.md R6):** never crash the host app.
 * Anything thrown from [onCreate] propagates back into the system
 * server and tombstones the process — so we wrap every call to
 * [KixoInternalBootstrap.attach] in a defensive try/catch and merely
 * log the failure. The SDK then becomes a no-op for that launch, but
 * the host app continues to run.
 */
internal class KixoInitializerProvider : ContentProvider() {

    /**
     * Called by the platform after `Application.onCreate()` and before
     * any activity launches. We immediately hand the [Application]
     * context to [KixoInternalBootstrap] which is the single
     * idempotent entry point for everything lifecycle-shaped.
     *
     * Returning `true` is the canonical "I'm initialised" signal even
     * for no-op providers — the platform doesn't actually use the
     * return value, but conventionally `true` means OK.
     */
    override fun onCreate(): Boolean {
        val ctx = context ?: run {
            // Should never happen — the platform guarantees a non-null
            // context here. Log defensively and return; we'll bootstrap
            // again when Kixo.configure() is called from the host app.
            Log.w(TAG, "ContentProvider.onCreate received null context")
            return true
        }

        val app = ctx.applicationContext as? Application ?: run {
            // Some test environments (and a handful of weird host
            // configurations) wrap Application — fall back gracefully
            // and let Kixo.configure() do the bootstrap later.
            Log.w(TAG, "applicationContext is not an Application instance; deferring bootstrap")
            return true
        }

        try {
            KixoInternalBootstrap.attach(app)
        } catch (t: Throwable) {
            // Never crash the host app from here. If bootstrap fails
            // we lose lifecycle tracking for this process, but the
            // host integration keeps working.
            Log.e(TAG, "early bootstrap failed; SDK will retry on Kixo.configure()", t)
        }
        return true
    }

    // ─── No-op CRUD ──────────────────────────────────────────────────
    //
    // We never expose data through this provider, so every CRUD entry
    // point returns the safest "did nothing" value (null / 0 / empty
    // type). Returning anything else (e.g. throwing) would cause the
    // platform to mark the provider as broken and could even tombstone
    // certain code paths in some OEM ROMs.

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? = null

    override fun getType(uri: Uri): String? = null

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0

    private companion object {
        private const val TAG = "Kixo"
    }
}
