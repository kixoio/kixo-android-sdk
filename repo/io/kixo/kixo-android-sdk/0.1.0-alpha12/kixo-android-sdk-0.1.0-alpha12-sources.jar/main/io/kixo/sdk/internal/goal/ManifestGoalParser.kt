package io.kixo.sdk.internal.goal

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.util.Log

/**
 * Declarative-goal parser for the Android `<meta-data>` surface
 * (Wave 7 #C2 — Android-specific extension over iOS).
 *
 * **Surface shape — recognised manifest entries:**
 *
 * ```xml
 * <application>
 *   ...
 *   <meta-data
 *     android:name="io.kixo.sdk.goal.checkout_complete"
 *     android:value="trigger=view;value=49.99;currency=USD;step=true;once=session" />
 * </application>
 * ```
 *
 * The portion AFTER the `io.kixo.sdk.goal.` prefix is the goal name
 * (which goes through [GoalNameValidator] just like a programmatic
 * `Kixo.markGoal()` call). The `android:value` is a `;`-separated
 * key=value bag with the keys documented below.
 *
 * **Parsed-payload keys:**
 *
 *  | Key        | Type           | Default     | Notes                              |
 *  |------------|----------------|-------------|------------------------------------|
 *  | `trigger`  | `view\|click\|form_submit` | (none)  | Trigger source. Future work — see [TODO]. |
 *  | `value`    | Double         | (none)      | Optional `goal_value`.             |
 *  | `currency` | String         | (none)      | ISO-4217 — validated downstream.   |
 *  | `step`     | Boolean        | `false`     | Marks the goal as a funnel step.   |
 *  | `once`     | `session\|process\|always` | `session` | Mirrors [GoalDedup.DedupScope].    |
 *
 * **Cross-platform parity note:** iOS does NOT have an equivalent
 * declarative-from-Info.plist surface today (the iOS team rejected
 * adding one until the Android side bakes — see briefing). To keep
 * shipping value the trigger wiring is intentionally a no-op stub:
 * we parse, validate, and log every recognised entry so the host
 * engineer gets immediate feedback that their manifest declarations
 * are syntactically correct. The actual auto-fire from view /
 * click / form_submit observation will land once the iOS surface
 * lands AND we have an Android observation hook for it (Agent 9 owns
 * screen tracking; manifest-trigger plumbing will reuse that pipeline).
 *
 * **Why parse anyway right now?**
 *   - Lets host apps prepare their manifest entries today; when the
 *     trigger plumbing lands, no app code change required — just an
 *     SDK upgrade.
 *   - Validation feedback during integration is hugely valuable: a
 *     typo in the meta-data name produces a `Log.w` immediately,
 *     versus silently doing nothing forever.
 *   - The cost of the parse pass is one `getApplicationInfo` call +
 *     a Bundle iteration, both at `Kixo.configure()` time only.
 *     Negligible.
 *
 * **Error contract (R6 — never crash the host):** every code path here
 * is wrapped in try/catch. A malformed manifest entry logs + skips
 * just that entry; a missing `<meta-data>` block, a parse exception, or
 * a `PackageManager.NameNotFoundException` all produce a `Log.w` and
 * an empty result. The SDK MUST start cleanly even on a host with no
 * goal declarations or a host that pulled `tools:node="remove"` on
 * our `<meta-data>` block.
 *
 * **Thread safety:** [parseAndRegister] is intended to be called once
 * from `Kixo.configure()` on whichever thread the host invoked it on.
 * The internal state is purely local, so it's safe to invoke
 * concurrently — the worst case is duplicate log lines, never
 * a corruption.
 */
internal object ManifestGoalParser {

    private const val TAG = "Kixo"

    /**
     * Manifest meta-data key prefix. The portion AFTER the prefix is
     * the goal name. Mirrors how Crashlytics, Firebase, and most other
     * SDKs namespace their manifest entries.
     */
    internal const val META_DATA_PREFIX = "io.kixo.sdk.goal."

    /**
     * One parsed declarative goal. Held in [registered] for diagnostic /
     * future-trigger-wiring use. Public-readable inside the package so
     * tests + the eventual trigger pipeline can introspect.
     */
    internal data class DeclarativeGoal(
        /** Goal name (already validated against [GoalNameValidator]). */
        val name: String,
        /** Optional trigger spec — `"view" | "click" | "form_submit"`. */
        val trigger: String?,
        /** Optional revenue value. */
        val value: Double?,
        /** Optional ISO-4217 currency code. */
        val currency: String?,
        /** True iff this is part of a multi-step funnel. */
        val isStep: Boolean,
        /** Per-call dedup scope. */
        val dedupScope: GoalDedup.DedupScope,
    )

    /**
     * Registry of parsed declarative goals. Currently used only for
     * diagnostics (`Kixo.diagnostics()` may surface count); when
     * trigger wiring lands the screen / interaction trackers will
     * iterate this to decide whether to auto-fire.
     */
    @Volatile
    private var registered: List<DeclarativeGoal> = emptyList()

    /**
     * Read the host app's `AndroidManifest.xml` `<application>`
     * meta-data and parse every entry whose key starts with
     * [META_DATA_PREFIX]. Validated entries are logged at info level
     * and stashed in [registered]; rejected entries log at warn with
     * a precise reason so integration mistakes are easy to spot in
     * logcat.
     *
     * Returns the list of successfully registered goals so callers
     * (currently just `Kixo.configure()`, eventually unit tests) can
     * assert on the parse result without going through the singleton.
     */
    fun parseAndRegister(context: Context): List<DeclarativeGoal> {
        val parsed: List<DeclarativeGoal> = try {
            val bundle = readApplicationMetaData(context.applicationContext)
            if (bundle == null) emptyList() else parseBundle(bundle)
        } catch (t: Throwable) {
            // Defence in depth — we never want a parsing edge case to
            // prevent the SDK from initialising. iOS doesn't even have
            // this surface, so a host that totally lacks Kixo manifest
            // entries should still ship analytics fine.
            Log.w(TAG, "ManifestGoalParser: failed to read app meta-data; declarative goals disabled this session", t)
            emptyList()
        }
        registered = parsed
        if (parsed.isNotEmpty()) {
            Log.i(TAG, "ManifestGoalParser: registered ${parsed.size} declarative goal(s) from AndroidManifest.")
            // TODO(future): wire triggers — once Agent 9's screen tracker
            // and Agent 8's interaction taxonomy expose stable hooks,
            // iterate `registered` here and subscribe each entry to its
            // `trigger` source. For now we deliberately stop at parse +
            // validate so host apps can prepare their manifest declarations
            // ahead of the trigger plumbing landing.
        }
        return parsed
    }

    /**
     * Read-only snapshot of the currently-registered declarative goals.
     * Exposed for diagnostics + future test seams. Returns the empty
     * list if [parseAndRegister] hasn't run.
     */
    fun snapshot(): List<DeclarativeGoal> = registered

    /**
     * Test seam — wipe the registry. Production code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    internal fun resetForTesting() {
        registered = emptyList()
    }

    // ─── Internals (visible for unit testing without spinning up a real
    // PackageManager / Context) ──────────────────────────────────────

    /**
     * Pull the `<application>` meta-data Bundle for [context]. Wraps
     * the API-level fork between modern (Tiramisu+) `PackageInfoFlags`
     * vs the legacy int-flags overload.
     *
     * Returns `null` (not exception) on a host that doesn't expose
     * meta-data, has no Kixo entries, or whose `PackageManager` can't
     * find the package — every one of those is a normal-operation
     * outcome, not an error.
     */
    private fun readApplicationMetaData(appContext: Context): Bundle? {
        return try {
            val pm = appContext.packageManager
            val pkg = appContext.packageName
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getApplicationInfo(
                    pkg,
                    PackageManager.ApplicationInfoFlags.of(PackageManager.GET_META_DATA.toLong()),
                )
            } else {
                @Suppress("DEPRECATION")
                pm.getApplicationInfo(pkg, PackageManager.GET_META_DATA)
            }
            info.metaData
        } catch (e: PackageManager.NameNotFoundException) {
            Log.w(TAG, "ManifestGoalParser: package not found while reading meta-data", e)
            null
        } catch (t: Throwable) {
            Log.w(TAG, "ManifestGoalParser: unexpected error reading meta-data", t)
            null
        }
    }

    /**
     * Iterate the meta-data Bundle and convert every `io.kixo.sdk.goal.*`
     * entry into a [DeclarativeGoal]. Visible for testing so a unit
     * test can hand-roll a Bundle without spinning Robolectric.
     */
    @androidx.annotation.VisibleForTesting
    internal fun parseBundle(bundle: Bundle): List<DeclarativeGoal> {
        val out = ArrayList<DeclarativeGoal>()
        // Snapshot keys so a host modifying the Bundle mid-iteration
        // (extremely rare but theoretically possible if the host shares
        // its ApplicationInfo bundle elsewhere) can't trip us.
        for (rawKey in bundle.keySet().toList()) {
            if (!rawKey.startsWith(META_DATA_PREFIX)) continue
            val name = rawKey.substring(META_DATA_PREFIX.length)
            if (!GoalNameValidator.isValid(name)) {
                Log.w(
                    TAG,
                    "ManifestGoalParser: skipping '$rawKey' — goal name '$name' " +
                        "must match ^[a-z0-9_-]{3,64}$.",
                )
                continue
            }
            // Bundle entries can be either String or some other type
            // depending on how the host wrote `android:value="..."`
            // (the manifest compiler emits Strings for raw values,
            // but the platform also lets resource references resolve
            // to other types). We only accept String; anything else is
            // logged + skipped.
            val rawValue: String? = when (val v = bundle.get(rawKey)) {
                is String -> v
                null -> null
                else -> {
                    Log.w(
                        TAG,
                        "ManifestGoalParser: skipping '$rawKey' — value must be a String " +
                            "(got ${v::class.java.simpleName}).",
                    )
                    null
                }
            }
            val parsed = parseValueSpec(rawValue) ?: continue
            out.add(
                DeclarativeGoal(
                    name = name,
                    trigger = parsed.trigger,
                    value = parsed.value,
                    currency = parsed.currency,
                    isStep = parsed.isStep,
                    dedupScope = parsed.dedupScope,
                ),
            )
        }
        return out
    }

    /**
     * Parsed payload of a single `android:value="trigger=...;..."`
     * spec. Internal — callers in this file consume it directly.
     */
    private data class ParsedValueSpec(
        val trigger: String?,
        val value: Double?,
        val currency: String?,
        val isStep: Boolean,
        val dedupScope: GoalDedup.DedupScope,
    )

    /**
     * Parse the `key=value;key2=value2` payload. Returns `null` only
     * if the spec is so malformed there's nothing recoverable; every
     * other case logs the offending key and continues with the rest.
     */
    private fun parseValueSpec(raw: String?): ParsedValueSpec? {
        if (raw == null) {
            // Empty `android:value` is permitted — registers the goal
            // with no trigger / no value / default scope. Useful as a
            // pure declarative "this name is a goal" advisory.
            return ParsedValueSpec(
                trigger = null,
                value = null,
                currency = null,
                isStep = false,
                dedupScope = GoalDedup.DedupScope.Session,
            )
        }
        var trigger: String? = null
        var value: Double? = null
        var currency: String? = null
        var isStep = false
        var dedupScope: GoalDedup.DedupScope = GoalDedup.DedupScope.Session

        for (rawPair in raw.split(';')) {
            val pair = rawPair.trim()
            if (pair.isEmpty()) continue
            val eq = pair.indexOf('=')
            if (eq <= 0) {
                Log.w(TAG, "ManifestGoalParser: skipping malformed pair '$pair' (expected key=value)")
                continue
            }
            val k = pair.substring(0, eq).trim().lowercase()
            val v = pair.substring(eq + 1).trim()
            when (k) {
                "trigger" -> trigger = when (v.lowercase()) {
                    "view", "click", "form_submit" -> v.lowercase()
                    else -> {
                        Log.w(TAG, "ManifestGoalParser: ignoring unknown trigger='$v' (must be view|click|form_submit)")
                        null
                    }
                }
                "value" -> value = v.toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 }
                    ?: run {
                        Log.w(TAG, "ManifestGoalParser: ignoring invalid value='$v' (must be a finite, non-negative number)")
                        null
                    }
                "currency" -> currency = v.takeIf { Regex("^[A-Z]{3}$").matches(it) }
                    ?: run {
                        Log.w(TAG, "ManifestGoalParser: ignoring invalid currency='$v' (must be ISO-4217 ^[A-Z]{3}$)")
                        null
                    }
                "step" -> isStep = when (v.lowercase()) {
                    "true", "1", "yes" -> true
                    "false", "0", "no" -> false
                    else -> {
                        Log.w(TAG, "ManifestGoalParser: ignoring invalid step='$v' (must be true|false)")
                        false
                    }
                }
                "once" -> dedupScope = when (v.lowercase()) {
                    "session" -> GoalDedup.DedupScope.Session
                    "process" -> GoalDedup.DedupScope.Process
                    "always", "never" -> GoalDedup.DedupScope.Always
                    else -> {
                        Log.w(TAG, "ManifestGoalParser: ignoring unknown once='$v' (must be session|process|always)")
                        GoalDedup.DedupScope.Session
                    }
                }
                else -> {
                    Log.w(TAG, "ManifestGoalParser: ignoring unknown key='$k'")
                }
            }
        }

        return ParsedValueSpec(
            trigger = trigger,
            value = value,
            currency = currency,
            isStep = isStep,
            dedupScope = dedupScope,
        )
    }

}
