package io.kixo.sdk.internal.replay

import android.graphics.Bitmap
import android.util.Log

/**
 * Tiny ARGB_8888 bitmap pool. Wave 5 (Critic 2 HIGH).
 *
 * **Why a pool**: a 1080 × 2400 ARGB_8888 frame is ~10.4 MB. The
 * replay pipeline allocates one per tap, then again per scroll-end,
 * then again per refine-timer. Without a pool, sustained tap +
 * scroll bursts churn 30 MB/s through the GC and trigger
 * `WindowManager.Suppress[…]` allocation thrash on mid-tier devices.
 *
 * **Why so small (cap 2)**: the snapshotter holds at most one bitmap
 * being drawn into, the encoder pipeline holds one being read out
 * of. Anything above that is in OOM territory anyway — the
 * `CaptureSlot` semaphore (cap 3) already caps in-flight captures.
 *
 * **Pool policy**:
 *   - Keyed by exact `(width, height)` — orientation changes /
 *     split-screen don't share slots; mixed-size return goes to the
 *     wrong queue.
 *   - LRU within a key — most recently released is acquired next so
 *     hot pixels stay warm in CPU cache.
 *   - Eviction on `(width, height)` mismatch — if the active screen
 *     size changes (rotation, foldable unfold), older slots are
 *     recycled to free their native buffer.
 *
 * **Thread safety**: every public method is `synchronized` over the
 * private map. The pool is touched from the main thread (acquire by
 * snapshotter) AND background threads (release after JPEG encode),
 * so locking is required.
 *
 * **Anti-crash (R6)**: every entry point catches `OutOfMemoryError`
 * + every Throwable. A failing pool falls back to direct allocation
 * via `Bitmap.createBitmap` which itself catches OOM and returns
 * null. The host app never crashes because of the pool.
 */
internal object BitmapPool {

    private const val TAG = "Kixo.BitmapPool"
    private const val MAX_PER_KEY = 2

    /**
     * Pool keyed by (width, height). Each entry is a small ArrayDeque
     * (LRU stack) of bitmaps awaiting reuse. We hold them strongly —
     * the whole point is to outlive a single GC cycle. Memory
     * pressure handling: `clear()` is called from
     * [ReplayController.onMemoryWarning].
     */
    private val pool: MutableMap<Long, ArrayDeque<Bitmap>> = mutableMapOf()

    /** Encode (width, height) into a single Long key for HashMap lookup. */
    private fun key(width: Int, height: Int): Long =
        (width.toLong() shl 32) or (height.toLong() and 0xFFFFFFFFL)

    /**
     * Acquire a bitmap of the given dimensions. Reuses a pooled one
     * if available, allocates a fresh ARGB_8888 if not.
     *
     * Returns `null` on `OutOfMemoryError` — caller decides whether
     * to skip the capture or retry later.
     */
    fun acquireOrAlloc(width: Int, height: Int): Bitmap? {
        if (width <= 0 || height <= 0) return null

        val k = key(width, height)
        synchronized(this) {
            val queue = pool[k]
            if (queue != null && queue.isNotEmpty()) {
                // Pop the most-recently-released (LRU stack).
                return queue.removeLast()
            }
        }

        return try {
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        } catch (oom: OutOfMemoryError) {
            // Caller handles the null return — don't crash the host.
            null
        } catch (t: Throwable) {
            Log.w(TAG, "alloc failed (${width}x${height})", t)
            null
        }
    }

    /**
     * Return a bitmap to the pool. If the pool is at [MAX_PER_KEY]
     * for that size OR the bitmap is mutable-mismatched / recycled,
     * we drop it (leave to GC). Eviction also trims any keys that
     * don't match the current size — old screen geometry shouldn't
     * pin native buffers indefinitely.
     */
    fun release(bitmap: Bitmap?) {
        if (bitmap == null) return
        if (bitmap.isRecycled) return
        // Refuse to pool non-mutable bitmaps; they can't be redrawn
        // into and the canvas would crash on `lockHardwareCanvas`.
        if (!bitmap.isMutable) {
            recycleQuiet(bitmap)
            return
        }

        val k = key(bitmap.width, bitmap.height)
        synchronized(this) {
            val queue = pool.getOrPut(k) { ArrayDeque() }
            if (queue.size >= MAX_PER_KEY) {
                // Pool full for this size — drop the oldest (FIFO
                // eviction at cap), keep the just-returned one (it's
                // the freshest pixel buffer in CPU cache).
                val evicted = queue.removeFirst()
                recycleQuiet(evicted)
            }
            queue.addLast(bitmap)
        }
    }

    /**
     * Drop everything. Called from
     * [ReplayController.onMemoryWarning] (which itself wires up to
     * Agent 7's `MemoryPressure` flow). Recycles all pooled bitmaps
     * synchronously so their native pixel buffers come back to the
     * heap before the host's next allocation attempt.
     */
    fun clear() {
        synchronized(this) {
            for ((_, queue) in pool) {
                for (b in queue) recycleQuiet(b)
            }
            pool.clear()
        }
    }

    /**
     * Diagnostic — total bytes currently held by the pool. Surfaced
     * via `Kixo.diagnostics()` extras for troubleshooting reports.
     */
    fun heldBytes(): Long {
        var total = 0L
        synchronized(this) {
            for ((_, queue) in pool) {
                for (b in queue) total += b.allocationByteCount.toLong()
            }
        }
        return total
    }

    private fun recycleQuiet(bitmap: Bitmap) {
        try {
            if (!bitmap.isRecycled) bitmap.recycle()
        } catch (t: Throwable) {
            // Pool is best-effort; never crash the host on cleanup.
        }
    }
}
