package io.kixo.sdk.internal.identity

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.longOrNull

/**
 * Persistent key-value store for **user properties** (Mixpanel
 * "people properties" terminology).
 *
 * Mirrors the iOS counterpart's `_userProperties` dict in
 * `kixo-ios-sdk/Sources/Kixo/Identity/IdentityManager.swift`. Split
 * out into its own type on Android because:
 *  1. The persistence model is different (SharedPreferences vs
 *     UserDefaults) and worth its own surface for testability.
 *  2. The split lets [SuperPropertyStore] reuse the exact same shape
 *     without duplicating the JSON serialisation code.
 *  3. Agent 5 (`IdentityDedup`) is a downstream consumer; isolating
 *     the store gives it a single dependency.
 *
 * # Semantics — user_properties
 *
 * User properties describe WHO the end-user is (their plan, their
 * country, their feature flags, the variant they're enrolled in).
 * They:
 *  - Persist across sessions (a user's plan doesn't reset on cold
 *    start).
 *  - Survive `Kixo.reset()` UNLESS the host explicitly calls [clear].
 *    Rationale: when `Kixo.reset()` fires, the iOS [IdentityManager]
 *    DOES clear them — but the Android shape lets the host be more
 *    surgical (`reset()` clears identity; properties are owned by
 *    the property stores). The Kixo facade (Agent 1) is expected to
 *    call [clear] from its own `reset()` after [IdentityManager.reset]
 *    if it wants iOS-parity semantics.
 *  - Are merged into the `identify` event payload by the public API
 *    layer — this store does NOT auto-emit anything.
 *
 * # Persistence format
 *
 * One SharedPreferences string entry holds a kotlinx.serialization
 * JSON-encoded snapshot of the entire map. We chose JSON over
 * per-key SharedPreferences entries because:
 *  - Snapshot reads ([snapshot]) need ALL properties; iterating every
 *    SharedPreferences key per call is O(n) and SharedPreferences
 *    enumeration is slow on cold cache.
 *  - JSON gives a typed shape (numbers stay numbers, strings stay
 *    strings) that survives re-launches without coercion.
 *  - The whole map is bounded (typical apps set a handful of
 *    properties) so the JSON size is fine — measured at 1-2 KB
 *    typical, hard ceiling at 64 KB before we start dropping (the
 *    SharedPreferences value-size is unbounded but writing a megabyte
 *    blob defeats the point).
 *
 * **Why kotlinx.serialization and not org.json**: kotlinx.serialization
 * is already in the dep list (used by the model layer) and is pure
 * Kotlin — works in JVM unit tests without any Android stub library.
 * `org.json` is bundled in android.jar but is one of the classes
 * AGP unit tests stub out (so a `JSONObject(corrupt)` call throws
 * "Method not mocked" instead of `JSONException` in tests). Using
 * kotlinx.serialization keeps tests trivially runnable.
 *
 * # Threading
 *
 * In-memory map mutations run inside `synchronized(lock)`. The
 * SharedPreferences `apply()` is async-safe by contract; the JSON
 * serialisation happens INSIDE the lock so persistence captures
 * the same snapshot the in-memory map advertises (otherwise a
 * racing [snapshot] could see the write but persistence reflects
 * an older value).
 *
 * Reads go through a defensive copy so the caller never holds a
 * pointer into our mutable map.
 *
 * # Anti-example coverage
 *
 * Per AGENT_BRIEFING.md anti-examples:
 *  - We do NOT call SharedPreferences `commit()` (sync, blocks main
 *    thread). Always `apply()`.
 *  - We DO catch every parse failure during init — a corrupted
 *    blob from a previous SDK version drops to an empty map rather
 *    than crashing the host.
 */
internal class UserPropertyStore private constructor(
    private val prefs: SharedPreferences,
    private val storageKey: String,
) {

    private val lock = Any()

    /**
     * In-memory mirror of the persisted JSON blob. Rebuilt on init,
     * then kept in sync via every mutator.
     */
    private val map: LinkedHashMap<String, Any?> = LinkedHashMap()

    init {
        // Restore from persistence. Failures fall through to an empty
        // map — better to drop one corrupted snapshot than to crash
        // the host on first launch after an SDK upgrade.
        val raw = try {
            prefs.getString(storageKey, null)
        } catch (t: Throwable) {
            null
        }
        if (!raw.isNullOrEmpty()) {
            try {
                val obj = JSON.parseToJsonElement(raw).jsonObject
                for ((k, v) in obj) map[k] = unwrap(v)
            } catch (t: Throwable) {
                Log.w(TAG, "user-property restore failed; starting fresh", t)
                map.clear()
            }
        }
    }

    // ─── Public API ──────────────────────────────────────────────────

    /**
     * Set / overwrite a single property. Persists synchronously (in
     * memory) and asynchronously (to disk via SharedPreferences
     * `apply()`).
     *
     * `null` values are STORED (not removed) so the host can express
     * "explicitly unset on the backend". Use a separate `unset`-style
     * call upstream if "remove from local store" is the intent —
     * keeps the semantics symmetrical with iOS.
     */
    fun set(key: String, value: Any?) {
        synchronized(lock) {
            map[key] = value
            persistLocked()
        }
    }

    /**
     * Bulk-set multiple properties at once. ONE persistence write
     * for the whole batch — cheaper than N calls to [set].
     */
    fun setAll(map: Map<String, Any?>) {
        if (map.isEmpty()) return
        synchronized(lock) {
            for ((k, v) in map) this.map[k] = v
            persistLocked()
        }
    }

    /**
     * Read a single property. Returns `null` for both "key absent"
     * and "key explicitly stored as null" — callers needing to
     * distinguish should snapshot and check `containsKey`.
     */
    fun get(key: String): Any? {
        synchronized(lock) {
            return map[key]
        }
    }

    /**
     * Snapshot — value-copy of the entire map. Safe to mutate; the
     * store keeps its own copy. Iteration order matches insertion
     * order (LinkedHashMap) so debug dumps + identify-event emission
     * are reproducible across calls.
     */
    fun snapshot(): Map<String, Any?> {
        synchronized(lock) {
            return LinkedHashMap(map)
        }
    }

    /**
     * Drop every property. Persists the empty state to disk so a
     * cold start sees the cleared store. Used by `Kixo.reset()` (when
     * the facade chooses iOS-parity behaviour) and by tests.
     */
    fun clear() {
        synchronized(lock) {
            map.clear()
            // Remove the entire SharedPreferences key so a reinstall
            // of a fresh SDK version doesn't read a stale blob.
            prefs.edit().remove(storageKey).apply()
        }
    }

    // ─── Internal helpers ────────────────────────────────────────────

    /** MUST be called while holding `lock`. Persists `map` snapshot to disk. */
    private fun persistLocked() {
        val obj = buildJsonObjectFromMap(map)
        prefs.edit().putString(storageKey, JSON.encodeToString(JsonElement.serializer(), obj)).apply()
    }

    companion object {
        private const val TAG = "Kixo"

        /** Default SharedPreferences key for the user-property blob.
         *  Lives in the same `kixo_identity` namespace as identity
         *  ids so a single `getSharedPreferences` call backs both. */
        const val DEFAULT_STORAGE_KEY = "user_properties"

        /**
         * Shared JSON encoder for both stores. `encodeDefaults = true`
         * so a `null` value writes as `"key": null` (not omitted) —
         * matches the contract documented on [set].
         */
        private val JSON = Json {
            encodeDefaults = true
            explicitNulls = true
            isLenient = false
        }

        @Volatile
        private var instance: UserPropertyStore? = null

        /**
         * Acquire the process-wide singleton. Backed by the same
         * SharedPreferences namespace as [IdentityManager] so we
         * stay inside one xml file on disk.
         */
        fun getOrCreate(context: Context): UserPropertyStore {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: build(context.applicationContext).also { instance = it }
            }
        }

        /** Test-only — install an instance built from injected deps. */
        @androidx.annotation.VisibleForTesting
        fun installForTesting(value: UserPropertyStore?) {
            synchronized(this) { instance = value }
        }

        /** Test-only constructor that bypasses SharedPreferences acquisition. */
        @androidx.annotation.VisibleForTesting
        fun forTesting(
            prefs: SharedPreferences,
            storageKey: String = DEFAULT_STORAGE_KEY,
        ): UserPropertyStore = UserPropertyStore(prefs, storageKey)

        private fun build(appContext: Context): UserPropertyStore {
            val prefs = appContext.getSharedPreferences(
                IdentityManager.PREFS_NAME, Context.MODE_PRIVATE
            )
            return UserPropertyStore(prefs, DEFAULT_STORAGE_KEY)
        }

        /**
         * Build a [JsonObject] from a `Map<String, Any?>`. Coerces
         * each value via [wrap]; logs and skips entries whose key is
         * non-string-coercible (impossible by signature here, but
         * defensive in case a host sneaks in a `Map<Any, Any>`).
         */
        internal fun buildJsonObjectFromMap(map: Map<String, Any?>): JsonObject {
            val target = LinkedHashMap<String, JsonElement>(map.size)
            for ((k, v) in map) {
                target[k] = wrap(v)
            }
            return JsonObject(target)
        }

        /**
         * Coerce a value for JSON storage. Native JSON-representable
         * types pass through; everything else falls back to its
         * `toString()` representation — matches the iOS
         * [persistDict] coercion.
         *
         * Lists and maps recurse so a nested trait map round-trips.
         * `null` is represented as [JsonNull] so the slot is
         * preserved (vs being dropped).
         */
        internal fun wrap(value: Any?): JsonElement {
            return when (value) {
                null -> JsonNull
                is Boolean -> JsonPrimitive(value)
                is Int -> JsonPrimitive(value)
                is Long -> JsonPrimitive(value)
                is Double -> JsonPrimitive(value)
                is Float -> JsonPrimitive(value)
                is Number -> JsonPrimitive(value)
                is String -> JsonPrimitive(value)
                is Map<*, *> -> {
                    val target = LinkedHashMap<String, JsonElement>(value.size)
                    for ((k, v) in value) {
                        if (k != null) target[k.toString()] = wrap(v)
                    }
                    JsonObject(target)
                }
                is Iterable<*> -> JsonArray(value.map { wrap(it) })
                is Array<*> -> JsonArray(value.map { wrap(it) })
                else -> JsonPrimitive(value.toString())
            }
        }

        /**
         * Inverse of [wrap]: unpack a [JsonElement] back into Kotlin-
         * friendly types. JsonNull -> null, nested objects -> Map,
         * arrays -> List. Numbers come back as Int / Long / Double
         * depending on what fits.
         */
        internal fun unwrap(value: JsonElement): Any? {
            return when (value) {
                is JsonNull -> null
                is JsonObject -> {
                    val out = LinkedHashMap<String, Any?>()
                    for ((k, v) in value) out[k] = unwrap(v)
                    out
                }
                is JsonArray -> value.map { unwrap(it) }
                is JsonPrimitive -> {
                    if (value.isString) value.contentOrNull
                    else value.booleanOrNull
                        ?: value.intOrNull
                        ?: value.longOrNull
                        ?: value.doubleOrNull
                        ?: value.contentOrNull
                }
            }
        }
    }
}
