package io.kixo.sdk.internal.identity

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.os.Looper
import android.provider.Settings
import android.util.Log
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicReference

/**
 * Manages the SDK's three stable identity tokens — `device_id`,
 * `anonymous_id`, `user_id` — that stamp every outbound event.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Identity/IdentityManager.swift`
 * (and its companion `DeviceIdentifier.swift`) one-for-one but with
 * Android-specific persistence (SharedPreferences instead of Keychain)
 * and Android-specific `device_id` strategy (ANDROID_ID instead of
 * IDFV).
 *
 * # `device_id` strategy — stable across reinstalls AND factory resets
 *
 * The contract from the briefing is "stable across reinstalls". Here
 * is what each candidate gives us, and why we pick the one we pick.
 *
 *  | Source                     | Stable across reinstall? | Play policy OK? |
 *  |----------------------------|--------------------------|-----------------|
 *  | `Settings.Secure.ANDROID_ID` | ✅ (per device + signing key) | ✅ |
 *  | `IMEI` / `MAC` / `SIM serial` | ✅ | ❌ — REQUIRES a runtime perm + restricted in Play Console |
 *  | Advertising ID             | ❌ — user can reset; Play 14+ pivot to App Set ID | ⚠ |
 *  | App Set ID                 | ✅ (per developer + per device) | ✅ but requires extra dep + Play Services |
 *  | Random UUID in SharedPreferences | ❌ — wiped on uninstall | ✅ |
 *
 * `Settings.Secure.ANDROID_ID` is the ONLY value Android offers that:
 *  1. Survives an app uninstall + reinstall.
 *  2. Doesn't require a permission.
 *  3. Doesn't require Play Services.
 *
 * On Android 8 (API 26)+ ANDROID_ID is keyed `(app signing key, user,
 * device)` — perfect for our cross-install identity (we want the same
 * id every time the SAME app reinstalls on the SAME device, but the
 * BACKUP app (different signing key) gets a different id).
 *
 * **Why a SharedPreferences fallback then?** Two cases ANDROID_ID
 * fails us:
 *  1. Pre-Oreo bug `9774d56d682e549c` — a known-bad value emitted by
 *     a small fraction of pre-Android-2.2 devices. We treat it as
 *     null and synthesize a UUID instead.
 *  2. ANDROID_ID is wiped on factory reset. The user expects a fresh
 *     id — but our briefing says "stable across reinstalls". The
 *     contract is: ONCE we've recorded a device id (via ANDROID_ID
 *     or via UUID synthesis), we PERSIST it forever in
 *     SharedPreferences. So a future change in ANDROID_ID (extremely
 *     rare — only on factory reset) doesn't drift our id.
 *  3. Some emulators / Custom ROMs return null. UUID fallback covers
 *     them too.
 *
 * **What we do NOT use:**
 *  - IMEI / MAC / SIM serial — Play policy forbids ([Persistent device
 *    identifiers policy](https://support.google.com/googleplay/android-developer/answer/10144311)).
 *  - Advertising ID — semantically wrong (it's an ad-targeting id, not
 *    a device id; it can be reset by the user at will).
 *  - App Set ID — would force a Play Services dependency.
 *
 * # `anonymous_id` strategy
 *
 * UUID per install, persisted to SharedPreferences. Regenerated only
 * on `Kixo.reset()` (which is exactly the iOS contract — see
 * `IdentityManager.swift` reset()). We do NOT use ANDROID_ID for
 * `anonymous_id` because the two ids serve different purposes:
 *  - `device_id` identifies the DEVICE installation across the
 *    SDK's lifetime — same on app re-launch, same on app re-install.
 *  - `anonymous_id` identifies the SESSION-CHAIN of an unidentified
 *    user — same across re-launches, but RESET when the user logs
 *    out (or `Kixo.reset()` fires explicitly).
 *
 * # `user_id` strategy
 *
 * Set by `Kixo.identify(userId, traits)`. Persisted to
 * SharedPreferences so the identity survives an app re-launch
 * (otherwise the SDK would treat the user as anonymous on every
 * cold start). Cleared on `Kixo.reset()`.
 *
 * # Listener pattern
 *
 * Other subsystems need to react to a `reset()` call:
 *  - PushAttributionStore needs to flush its window (briefing R9 —
 *    a logout shouldn't carry push-attribution properties from the
 *    previous user into the next).
 *  - IdentityDedup needs to clear its hash caches so the post-logout
 *    user's first identify isn't silently dropped.
 *  - ReplayController needs to seal the active replay session — the
 *    next user starts a fresh one.
 *
 * The iOS counterpart is more procedural — `Kixo.swift` knows the
 * concrete subsystems and calls each one. On Android we use a
 * listener pattern so each subsystem registers itself; the manager
 * doesn't need to know about its consumers. This avoids the
 * `IdentityManager → ReplayController` circular dependency that
 * would otherwise force one of them out of `internal/identity/`.
 *
 * The listener list is a `CopyOnWriteArrayList` because:
 *  - Reads (during `reset()`) iterate the list inside a synchronized
 *    block — but the iteration ITSELF doesn't take a per-element
 *    lock, so a slow listener wouldn't block other registrations.
 *  - Writes (subsystem registration) are O(1) amortized but happen
 *    once per process — copy-on-write is cheap.
 *
 * # Threading
 *
 * Every read goes through an `AtomicReference`. Writes are guarded by
 * a `synchronized(lock)` block so the durable SharedPreferences write
 * happens INSIDE the critical section (rare — only on identify /
 * reset / setUserId). This is simpler than the iOS shape (NSLock +
 * separate serial persist queue) because:
 *  - SharedPreferences `apply()` is non-blocking (returns immediately;
 *    durably writes on a worker thread).
 *  - The Android target is "minSdk 24" — `apply()` is reliable.
 *
 * The `AtomicReference` reads are wait-free; the locked writes serialise
 * across competing identifies. Both fronts of the public API
 * (`Kixo.track()` reading via `deviceId()` and `Kixo.identify()` writing)
 * see the right value.
 */
internal class IdentityManager private constructor(
    private val prefs: SharedPreferences,
    androidIdProvider: () -> String?,
) {

    /** Lock for set/reset operations that mutate multiple keys atomically. */
    private val lock = Any()

    private val deviceIdRef: AtomicReference<String>
    private val anonymousIdRef: AtomicReference<String>
    private val userIdRef: AtomicReference<String?>

    /**
     * Listener registry. Any subsystem that cares about identity reset
     * registers here; on `reset()` we iterate and notify each. Iteration
     * happens INSIDE the lock so a registration mid-reset doesn't see a
     * half-reset state, but listener bodies execute on the calling
     * thread (the host's) — they MUST be cheap and non-blocking.
     */
    private val listeners: CopyOnWriteArrayList<IdentityListener> = CopyOnWriteArrayList()

    init {
        // Resolve device_id — see class doc for the algorithm. We do
        // this once at construction time, then persist forever.
        val resolvedDeviceId = resolveAndPersistDeviceId(androidIdProvider)
        deviceIdRef = AtomicReference(resolvedDeviceId)

        // Resolve anonymous_id — read existing or generate new + persist.
        val storedAnon = prefs.getString(KEY_ANONYMOUS_ID, null)
        val resolvedAnon = if (storedAnon.isNullOrBlank()) {
            val fresh = UUID.randomUUID().toString()
            prefs.edit().putString(KEY_ANONYMOUS_ID, fresh).apply()
            fresh
        } else {
            storedAnon
        }
        anonymousIdRef = AtomicReference(resolvedAnon)

        // Resolve user_id — null on first launch, restored across
        // re-launches once Kixo.identify(...) has been called.
        userIdRef = AtomicReference(prefs.getString(KEY_USER_ID, null))
    }

    // ─── Public read API ─────────────────────────────────────────────

    /** Stable installation id. See class doc for the strategy. */
    fun deviceId(): String = deviceIdRef.get()

    /**
     * Per-install anonymous id. Persisted across re-launches.
     * Regenerated on [reset].
     */
    fun anonymousId(): String = anonymousIdRef.get()

    /**
     * Identified user id, set by `Kixo.identify(userId, …)`.
     * `null` until the host calls identify; persisted across
     * re-launches; cleared on [reset].
     */
    fun userId(): String? = userIdRef.get()

    // ─── Public mutate API ───────────────────────────────────────────

    /**
     * Sets (or clears) the identified user id. Pass `null` to clear
     * without firing the full reset (rarely needed; mostly for
     * test setups that want to scrub identity without bumping
     * `anonymous_id`).
     *
     * The caller is responsible for the `identify` event emission +
     * IdentityDedup gating — this method just owns the persistence.
     */
    fun setUserId(id: String?) {
        synchronized(lock) {
            userIdRef.set(id)
            val editor = prefs.edit()
            if (id == null) editor.remove(KEY_USER_ID) else editor.putString(KEY_USER_ID, id)
            editor.apply()
        }
    }

    /**
     * Reset identity. Generates a fresh `anonymous_id`, clears
     * `user_id`, then notifies every registered [IdentityListener].
     * This is the post-logout flow.
     *
     * **Does NOT change `device_id`** — by design. The device hasn't
     * gone anywhere; only the identified-user state has been wiped.
     * iOS behaves the same way (`DeviceIdentifier.resetAnonymousId()`
     * regenerates anon, leaves device id untouched).
     */
    fun reset() {
        // Generate the new anon id outside the lock — UUID generation
        // is pure compute, no contention payoff to lock-holding.
        val newAnon = UUID.randomUUID().toString()

        synchronized(lock) {
            anonymousIdRef.set(newAnon)
            userIdRef.set(null)

            // Atomic-ish write — SharedPreferences.edit() collects, .apply()
            // commits async. There's no guarantee anon and user are
            // persisted in the same fsync but both writes are issued in
            // the same edit batch which gives us within-process atomicity
            // (a subsequent .getString() always sees both new values).
            prefs.edit()
                .putString(KEY_ANONYMOUS_ID, newAnon)
                .remove(KEY_USER_ID)
                .apply()

            // Notify listeners INSIDE the lock so a reset() racing with
            // a concurrent setUserId() doesn't fire listeners on a
            // stale anon id. Listener bodies must be cheap — they run
            // on the calling thread (typically the host's main thread
            // when `Kixo.reset()` is invoked from a logout handler).
            for (listener in listeners) {
                try {
                    listener.onReset()
                } catch (t: Throwable) {
                    // Briefing R6 — never crash the host. A buggy listener
                    // can't take down identity reset.
                    Log.w(TAG, "IdentityListener.onReset threw; continuing", t)
                }
            }
        }
    }

    // ─── Listener registration ───────────────────────────────────────

    /**
     * Register a subsystem that wants to be notified on [reset].
     * Idempotent — registering the same listener twice is a no-op.
     */
    fun addListener(listener: IdentityListener) {
        listeners.addIfAbsent(listener)
    }

    /** Unregister a previously-registered [IdentityListener]. */
    fun removeListener(listener: IdentityListener) {
        listeners.remove(listener)
    }

    // ─── Internal helpers ────────────────────────────────────────────

    private fun resolveAndPersistDeviceId(androidIdProvider: () -> String?): String {
        // Step 1: an existing persisted device id wins. Once recorded,
        // it never changes — even if ANDROID_ID later differs (factory
        // reset, ROM swap), we keep the first id we ever resolved.
        val existing = prefs.getString(KEY_DEVICE_ID, null)
        if (!existing.isNullOrBlank()) return existing

        // Step 2: try ANDROID_ID. Filter the known-bad value + null.
        val androidId = try {
            androidIdProvider()
        } catch (t: Throwable) {
            Log.w(TAG, "ANDROID_ID read failed", t)
            null
        }
        val candidate: String = when {
            androidId.isNullOrBlank() -> UUID.randomUUID().toString()
            androidId.equals(BAD_ANDROID_ID, ignoreCase = true) -> UUID.randomUUID().toString()
            else -> androidId
        }

        // Step 3: persist forever. The version key lets a future
        // migration reason about which scheme produced the id.
        prefs.edit()
            .putString(KEY_DEVICE_ID, candidate)
            .putInt(KEY_DEVICE_ID_VERSION, DEVICE_ID_VERSION)
            .apply()

        return candidate
    }

    companion object {
        private const val TAG = "Kixo"

        /** SharedPreferences namespace. Single file per app — keeps
         *  identity in one place and survives across our schema
         *  bumps via the [KEY_DEVICE_ID_VERSION] hint. */
        const val PREFS_NAME = "kixo_identity"

        const val KEY_DEVICE_ID = "device_id"
        const val KEY_DEVICE_ID_VERSION = "device_id_version"
        const val KEY_ANONYMOUS_ID = "anonymous_id"
        const val KEY_USER_ID = "user_id"

        /**
         * The famous pre-Oreo Bug 10603 value: a small fraction of
         * Android 2.2 devices emitted this exact constant from
         * Settings.Secure.ANDROID_ID. Filter it as a sentinel.
         * (Modern devices never hit this, but the cost of the check
         * is one string compare on init.)
         */
        const val BAD_ANDROID_ID = "9774d56d682e549c"

        /**
         * Bumped when the algorithm in [resolveAndPersistDeviceId]
         * changes in a way that would change which id is produced
         * for a given device. Existing persisted ids are always kept
         * regardless of version — the version is informational so a
         * future migration can decide what to do.
         */
        const val DEVICE_ID_VERSION = 1

        @Volatile
        private var instance: IdentityManager? = null

        /**
         * Acquire the process-wide singleton. Safe to call from any
         * thread; first caller wins. Uses double-checked locking on
         * a cheap sync object.
         *
         * **Main-thread warning (Critic 2 HIGH).** First-call
         * construction reads `Settings.Secure.ANDROID_ID` and
         * SharedPreferences synchronously — both are typically <50 ms
         * but can spike to 200+ ms on cold-cache boot, low-end
         * devices, or when the keystore is encrypted. We deliberately
         * KEEP the synchronous behaviour because most callers (the
         * first event after `Kixo.configure(...)`) need a non-null id
         * immediately. We just warn so a host that sees ANR signals
         * knows where to look — moving `Kixo.configure()` off the
         * main thread fixes it.
         */
        fun getOrCreate(context: Context): IdentityManager {
            instance?.let { return it }
            if (Looper.myLooper() == Looper.getMainLooper()) {
                Log.w(
                    TAG,
                    "IdentityManager initialized on main thread; first call may add ~50-200ms cold-start latency. Move Kixo.configure() off main if you see ANR signals.",
                )
            }
            return synchronized(this) {
                instance ?: build(context.applicationContext).also { instance = it }
            }
        }

        /** Test-only — install an instance built from injected dependencies. */
        @androidx.annotation.VisibleForTesting
        fun installForTesting(value: IdentityManager?) {
            synchronized(this) { instance = value }
        }

        /**
         * Test-only constructor — bypasses the SharedPreferences
         * acquisition so unit tests can inject a fake.
         */
        @androidx.annotation.VisibleForTesting
        fun forTesting(prefs: SharedPreferences, androidIdProvider: () -> String?): IdentityManager {
            return IdentityManager(prefs, androidIdProvider)
        }

        @SuppressLint("HardwareIds")
        private fun build(appContext: Context): IdentityManager {
            val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            val androidIdProvider: () -> String? = {
                Settings.Secure.getString(appContext.contentResolver, Settings.Secure.ANDROID_ID)
            }
            return IdentityManager(prefs, androidIdProvider)
        }
    }
}

/**
 * Subscriber interface for `IdentityManager.reset()`. Implementations
 * MUST be cheap — they run on the caller's thread (typically the host
 * app's main thread firing `Kixo.reset()` from a logout button).
 *
 * Wired by:
 *   - `IdentityDedup.reset()` (Agent 5) so post-logout identifies emit.
 *   - `PushAttributionStore.clear()` (Agent 11) so attribution windows
 *     don't carry across user identity boundaries.
 *   - `ReplayController.endSession()` (Agent 13) so the active replay
 *     session is sealed and a new one starts under the new anon id.
 *
 * Any thrown exception is caught + logged by the manager — a buggy
 * listener can NEVER crash the host app per briefing R6.
 */
internal interface IdentityListener {
    /**
     * Fired when `IdentityManager.reset()` has flipped the
     * `anonymous_id` and cleared `user_id`. By the time this is
     * called, the new ids are already live (a getter call from the
     * listener will see the post-reset state).
     */
    fun onReset()
}
