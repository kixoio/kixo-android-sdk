package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.time.Instant

/**
 * Request body for `POST /api/sdk/batch`. Mirrors iOS
 * `BatchPayload` ([Transport.swift] private struct) one-for-one
 * with snake_case JSON keys per AGENT_BRIEFING.md R3 + §4.
 *
 * **Field contracts:**
 *
 *  - `platform` is hard-coded to `"android"`. The backend uses this
 *    for routing (separate per-platform PII filters, replay codecs,
 *    etc.) — there is no other valid value emitted from this SDK.
 *
 *  - `release_id` comes from `/api/sdk/init`. If init has not yet
 *    completed (cold launch race) the queue may flush with an empty
 *    string — the backend tolerates this and falls through to its
 *    own auto-discovery path (see backend `route.ts` line ~128).
 *    Empty string is safe; null is NOT — the field must be present.
 *
 *  - `context` (the per-batch [EnrichedContext]) is nullable for the
 *    very first cold-launch batch where `DeviceContext` collection
 *    has not finished. iOS `Transport` sets `enrichedContext?` and
 *    sends `null` if absent; we mirror.
 *
 *  - `sent_at` is the moment the SDK actually flushes (not when the
 *    events were generated — that's per-event `timestamp`). The
 *    backend uses `sent_at` to detect clock skew vs server time.
 */
@OptIn(kotlinx.serialization.ExperimentalSerializationApi::class)
@Serializable
internal data class BatchPayload(
    @SerialName("project_id")
    val projectId: String,

    @SerialName("api_key")
    val apiKey: String,

    // Wave 6 fix: same encodeDefaults-omit risk as InitRequest. Force
    // emit so the backend sees `platform` even when the SDK's Json
    // instance has `encodeDefaults = false`. Without this, every
    // batch was getting routed through backend's auto-detect-platform
    // fallback (works but slower + slightly different per-event
    // projector path). Now `platform=android` is always on the wire.
    @kotlinx.serialization.EncodeDefault(kotlinx.serialization.EncodeDefault.Mode.ALWAYS)
    @SerialName("platform")
    val platform: String = "android",

    @SerialName("environment")
    val environment: String,

    @SerialName("sdk_version")
    val sdkVersion: String,

    /**
     * Host app's `versionName` from PackageManager.
     *
     * **Nullable on the wire (Critic 5 HIGH).** A non-null `String`
     * here meant the SDK had no way to encode "PackageManager threw
     * before context was fully wired" — the assembler would default
     * to `""` and the backend would store an empty string in
     * ClickHouse, polluting the `app_version` distribution. Null
     * cleanly signals "we don't know" so the backend can branch (use
     * `unknown` bucket / fall back to `release_id`'s embedded
     * version / drop from cohort splits). The cold-launch race that
     * lands a null is rare but real — version reads come from a
     * synchronous PackageManager call which can fail under DPC /
     * profile-restricted apps and during package-update-in-progress.
     */
    @SerialName("app_version")
    val appVersion: String?,

    @SerialName("bundle_id")
    val bundleId: String,

    @SerialName("release_id")
    val releaseId: String,

    @SerialName("context")
    val context: EnrichedContext? = null,

    @SerialName("batch")
    val batch: List<KixoEvent>,

    @Serializable(with = Iso8601InstantSerializer::class)
    @SerialName("sent_at")
    val sentAt: Instant,
)
