package io.kixo.sdk.internal.replay

/**
 * Feature-flag knobs for the replay capture pipeline. Mirrors the
 * iOS `ReplayController.Config` field-for-field so a Kixo team
 * operator can flip the same kill switches via `/api/sdk/config`
 * remote-config across both platforms.
 *
 * **Why so many flags?** The iOS SDK's April 28 2026 perf-bisect
 * (see `feedback_perf_diagnosis.md` in the Kixo memory) taught us
 * that "the SDK is slow" reports usually come down to ONE subsystem,
 * not the whole pipeline. Granular flags let ops binary-search the
 * failing subsystem on a real device by toggling one flag at a time
 * via remote config — no app update required.
 *
 * **Defaults** mirror the iOS C.3 v3 `Config`:
 *  - `frameCaptureEnabled = true` — master gate; without it the SDK
 *    still emits tap metadata events but no Bitmap raster work.
 *  - `preFrameEnabled = false` — the iOS team learned April 30 2026
 *    that pre-tap snapshot causes first-scroll lag (synchronous
 *    drawHierarchy on the main thread = ~30-50 ms cold-cache cost
 *    on first-of-session). Player UX is preserved by the
 *    "previous gesture's post-frame IS this gesture's before-frame"
 *    carry-forward semantic.
 *  - `safetyTimerEnabled = false` — duplicates `refineTimer`'s
 *    purpose; only useful when a NEW tap interrupts before refine
 *    fires (rare). Off by default to avoid two timers per tap.
 *  - `refineTimerEnabled = true` — the canonical "what changed
 *    after the gesture" capture (~1 s post-tap).
 *  - `scrollEndCaptureEnabled = true` — restored after the iOS
 *    `WindowEventInterceptor` rewrite eliminated the false-positive
 *    "scroll-as-tap" classification. Same WindowEventInterceptor bug
 *    cannot recur on Android because Agent 8's [GestureClassifier]
 *    uses `.began → .ended` total movement by design.
 *  - `structuralSnapshotEnabled = true` — Bitmap + JSON view-tree
 *    sidecar.
 *  - `ocrEnabled = true` — on-device ML Kit text recognition. Per
 *    AGENT_BRIEFING §3 R1: ML Kit only, never cloud.
 *  - `maxConcurrentCaptures = 3` — semaphore ceiling on in-flight
 *    captures (briefing §3 R4 "bounded everything"). Tightened to
 *    1 under memory pressure (see [CaptureSlot]).
 *  - `maxConcurrentOcr = 4` — ML Kit Vision is parallelisable but
 *    each invocation pins ~5-15 MB of intermediate tensors. Hard cap
 *    keeps us safe on iPhone-class memory.
 *  - `replaySampleRate = 0.05` — 5% baseline reservoir; rage-click /
 *    crash triggers force ON regardless. See [Sampler].
 *
 * **Lifecycle:** instantiated by [ReplayController.start] and held
 * for the duration of the SDK's lifetime. NOT mutated after start —
 * remote-config flips require a fresh `start()` call (matches iOS).
 *
 * **No serialisation annotation here.** This DTO never crosses the
 * wire; remote-config delivers individual fields via a separate
 * payload.
 */
internal data class ReplayConfig(
    /**
     * Master gate for Bitmap capture (pre + post + emergency). When
     * `false`, the SDK still emits tap metadata events but
     * [FrameSnapshotter] never runs → zero `View.draw()` work →
     * main-thread cost ≈ 0 ms per tap. Useful baseline test:
     * "is the SDK slow because of capture, or something else?"
     */
    val frameCaptureEnabled: Boolean = true,

    /**
     * Capture pre-frame at tap moment (~3-5 ms main-thread per tap).
     *
     * **DEFAULT OFF** per iOS April 30 2026. Causes first-scroll lag
     * (synchronous draw + render-server cold-cache cost ~30-50 ms on
     * first-of-session). Player UX preserved via post-frame
     * carry-forward — previous gesture's post-frame doubles as the
     * new gesture's "before" state. Tap dot still renders on top.
     */
    val preFrameEnabled: Boolean = false,

    /**
     * 350 ms safety post-frame timer.
     *
     * **DEFAULT OFF** per iOS April 30 2026. Duplicates `refineTimer`
     * purpose; only fires if a NEW tap interrupts before refine. With
     * most taps not having interruptions, two timers per tap was pure
     * overhead. `refineTimer` alone (gated on no-active-scroll) covers
     * the canonical "what changed after the gesture" case.
     */
    val safetyTimerEnabled: Boolean = false,

    /**
     * 1000 ms refine post-frame timer. Final settled state ~1 s after
     * tap. ~15-25 ms main-thread per tap when fired. Disabling loses
     * post-tap captures for taps with screen transitions.
     */
    val refineTimerEnabled: Boolean = true,

    /**
     * Capture-on-scroll-end so users who scroll without tapping still
     * advance the player's visual timeline. Each fire still acquires a
     * [CaptureSlot] so concurrent scrolls + taps cannot OOM. Plus the
     * per-instance rate-limit [scrollEndMinIntervalSec] (default 0.5 s
     * on iOS) — long scroll generates at most ~1 capture per window.
     *
     * Safe to leave on because Agent 8's [GestureClassifier] uses
     * `.began → .ended` total movement, so scroll-end never
     * masquerades as a tap (the iOS C.3 v4 root-cause fix).
     */
    val scrollEndCaptureEnabled: Boolean = true,

    /**
     * Minimum seconds between consecutive scroll-end captures within
     * a session. Even an unbounded flick stream produces at most one
     * snapshot per "scroll burst followed by pause" — no spam.
     */
    val scrollEndMinIntervalSec: Double = 0.5,

    /**
     * Master gate for structural snapshot pipeline (view-tree walk +
     * JSON encode). ~8-15 ms main-thread when fired.
     *
     * Disabled → player loses structural / hybrid / wireframe modes.
     * Pixel mode still works.
     */
    val structuralSnapshotEnabled: Boolean = true,

    /**
     * ML Kit on-device text recognition. ~60-100 ms worker per tap on
     * mid-tier devices, off-main only.
     *
     * **HARD RULE — see AGENT_BRIEFING §3 R1.** This is on-device ML
     * Kit (`com.google.mlkit:text-recognition`), NOT a cloud LLM.
     * Operator pays $0 per inference. Cloud OCR is server-side only,
     * gated behind operator-invoked chat actions.
     */
    val ocrEnabled: Boolean = true,

    /**
     * Cap on pipeline tasks across tap + scroll-end paths. Drop new
     * captures (fall back to metadata-only event) when at cap. Halves
     * to 1 under memory pressure (Agent 7's
     * [io.kixo.sdk.internal.lifecycle.MemoryPressure]).
     *
     * Why 3? On iPhone 17 Pro the iOS team measured 3 simultaneous
     * `drawHierarchy` raster pins as the safe ceiling — at 4+ we
     * started to see OOMs on 3 GB-class devices (iPhone 11/12). The
     * Android budget is similar; default cap = 3 unless operator
     * tunes via remote config.
     */
    val maxConcurrentCaptures: Int = 3,

    /**
     * Cap on concurrent ML Kit OCR tasks. Each invocation pins
     * intermediate tensors so unbounded fan-out at high tap rate can
     * exhaust the worker pool. Per AGENT_BRIEFING §3 R4 "bounded
     * everything" — never let a hot path become unbounded.
     */
    val maxConcurrentOcr: Int = 4,

    /**
     * Reservoir baseline sample rate (0.0..1.0). Independent of
     * trigger-based capture (rage-click / crash overrides force ON
     * for the affected session).
     *
     * Why on-device stickiness: the same install always records or
     * always doesn't, giving operators a useful "users with replay"
     * cohort and avoiding the analyst trap of "5% of MY sessions"
     * vs "5% of users." See [Sampler].
     */
    val replaySampleRate: Double = 0.05,
)
