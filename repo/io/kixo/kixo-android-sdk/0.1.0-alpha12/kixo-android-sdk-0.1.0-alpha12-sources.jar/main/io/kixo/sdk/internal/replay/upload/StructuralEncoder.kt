package io.kixo.sdk.internal.replay.upload

import android.util.Log
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream

/**
 * Encoder for structural snapshots (the JSON tree of view roles +
 * bounds + a11y labels) and OCR canonical-text payloads. These are
 * small but compress well — a typical structural snapshot is ~3-15
 * KB raw, ~1-4 KB gzipped.
 *
 * The Kixo backend's `/api/sdk/replay/frames/sign` endpoint signs a
 * cap of `maxBytes=20000` (Android canonical cap) — same cap as
 * image frames. Structural payloads are nowhere near that ceiling
 * but we gzip anyway when
 * the raw payload is large enough that the gzip overhead pays back:
 * the 18-byte gzip-wrapper + 256-byte LZ77 dictionary make gzipping
 * a 200-byte JSON blob a NET LOSS. Threshold of 1024 bytes is the
 * crossover point we calibrated against the iOS sample corpus.
 *
 * **GCS side:** the backend signs the URL with NO `Content-Encoding`
 * constraint — the gzipped bytes are stored verbatim. The dashboard
 * player checks the raw byte signature (`1f 8b` magic) and inflates
 * on read. This is consistent with what the iOS SDK does (HTTPGzip).
 *
 * **OCR text:** plain UTF-8 — no compression (already too small to
 * benefit + skipping the inflate step shaves ~5 ms off the player's
 * "show this frame" path).
 */
internal object StructuralEncoder {

    /**
     * Encode a JSON string to UTF-8 bytes. If the encoded payload
     * is larger than [GZIP_THRESHOLD_BYTES], the result is gzipped;
     * otherwise it's returned raw.
     *
     * Returns `null` only on a (very rare) `OutOfMemoryError` —
     * caller drops the payload silently per R6.
     *
     * @param json the structural snapshot serialised by Agent 13's
     *        StructuralSnapshotter via `kotlinx.serialization`.
     */
    fun encodeJson(json: String): ByteArray? {
        return try {
            val raw = json.toByteArray(Charsets.UTF_8)
            if (raw.size < GZIP_THRESHOLD_BYTES) {
                raw
            } else {
                gzip(raw) ?: raw // gzip failure → ship raw, still valid JSON
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Structural encode threw — dropping payload", t)
            null
        }
    }

    /**
     * Encode an OCR canonical-text string to UTF-8 bytes. No gzip —
     * see file kdoc.
     */
    fun encodeOcr(text: String): ByteArray? {
        return try {
            text.toByteArray(Charsets.UTF_8)
        } catch (t: Throwable) {
            Log.w(TAG, "OCR encode threw — dropping payload", t)
            null
        }
    }

    /**
     * Gzip the input. Returns the compressed bytes or `null` if the
     * stream itself fails (extraordinary — only on OOM). A null
     * return tells the caller to fall back to the raw payload — the
     * GCS object will be larger than ideal but the data still lands.
     */
    private fun gzip(raw: ByteArray): ByteArray? {
        return try {
            ByteArrayOutputStream(raw.size / 3).use { baos ->
                GZIPOutputStream(baos).use { gz ->
                    gz.write(raw)
                }
                baos.toByteArray()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "gzip failed — falling back to raw", t)
            null
        }
    }

    /**
     * Crossover threshold (bytes) at which gzip starts paying off.
     * Calibrated empirically against representative structural
     * snapshots — payloads under this size consistently get LARGER
     * after gzipping (header + dictionary overhead beats the LZ77
     * savings).
     */
    private const val GZIP_THRESHOLD_BYTES = 1024

    private const val TAG = "Kixo.StructuralEncoder"
}
