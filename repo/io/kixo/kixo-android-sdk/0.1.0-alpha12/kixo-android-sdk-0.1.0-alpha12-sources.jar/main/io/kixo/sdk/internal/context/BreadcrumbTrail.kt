package io.kixo.sdk.internal.context

import io.kixo.sdk.internal.model.toJsonElement
import java.time.Instant
import java.util.concurrent.ConcurrentLinkedDeque
import java.util.concurrent.atomic.AtomicInteger

/**
 * Thread-safe FIFO ring of breadcrumbs, capped at [MAX_SIZE] entries.
 *
 * Mirrors iOS [Context/BreadcrumbTrail.swift]. The trail is the
 * Sentry-style "what happened in the last N actions" timeline that
 * gets attached to crash reports + selected error events. It is held
 * in memory only — never persisted, never shipped on every event.
 *
 * **Why a singleton (`object`)**:
 *  - The trail is process-global by design: a navigation event from
 *    Activity A and a tap from Activity B should both land in the
 *    same trail, and a crash handler in a third location needs to
 *    [snapshot] without knowing which Activity owns it.
 *  - The state is small (≤ 100 references) so leak risk is bounded.
 *  - Singleton state is reset by tests via [clear]; no DI-friendly
 *    factory needed at the SDK boundary.
 *
 * **Why [ConcurrentLinkedDeque] instead of an ArrayDeque + lock**:
 *  - Most callsites are write-only: lifecycle observers, gesture
 *    interceptors, navigation hooks, and the public
 *    [io.kixo.sdk.Kixo.addBreadcrumb] facade all just `add`. A lock
 *    would serialise these across threads even though they don't
 *    conflict semantically.
 *  - Reads ([snapshot]) happen only on crash / on a flush attaching
 *    breadcrumbs to an error event — a few times a session at most.
 *  - The [AtomicInteger] size counter lets us evict the oldest
 *    entry without traversing the deque, keeping `add` O(1).
 *
 * **Why eviction is hard-locked**: an earlier revision used a
 * lock-free pre-evict loop that briefly overshot [MAX_SIZE] under
 * concurrent writers — under N concurrent writers the counter can
 * race past the cap unboundedly because each writer reads `size`
 * then races to add. Critic 3 flagged this as a real
 * memory-amplification bug under load. The fix wraps the
 * evict-then-add sequence in `synchronized(lock)` so the trail is
 * **strictly bounded — never exceeds MAX_SIZE**. The lock is held
 * for two `pollFirst` + `addLast` deque ops on the hot path: O(1)
 * amortised, briefly held, no allocations under the lock. This is a
 * tiny critical section relative to the upstream tap pipeline, and
 * still cheaper than the per-event JSON encode that follows.
 */
internal object BreadcrumbTrail {

    /**
     * Maximum entries retained. Beyond this the oldest is dropped on
     * each new add, FIFO. 100 matches iOS exactly; sized to fit a
     * typical session's worth of nav + interaction events without
     * blowing past the wire-payload budget when attached to a crash.
     */
    const val MAX_SIZE: Int = 100

    /**
     * Backing FIFO. We `addLast` for new entries and `pollFirst` for
     * eviction so the natural iteration order matches insertion order
     * (oldest → newest).
     */
    private val trail = ConcurrentLinkedDeque<Breadcrumb>()

    /**
     * Atomic size counter. [ConcurrentLinkedDeque.size] is O(n) so we
     * cannot use it on the hot path. We bump pre-add and decrement on
     * evict to keep the counter coherent without locks.
     */
    private val size = AtomicInteger(0)

    /**
     * Lock guarding the evict-then-add critical section. Held only for
     * the bounded pair of deque ops; reads ([snapshot]) bypass it
     * (ConcurrentLinkedDeque iterators are weakly consistent). See the
     * class-level "Why eviction is hard-locked" note.
     */
    private val lock = Any()

    /**
     * Append a breadcrumb. Thread-safe. If the trail is at capacity,
     * the oldest entry is evicted before insertion (FIFO).
     *
     * **PRIVACY WARNING — customer-supplied data.** [message] and the
     * values of [data] are best-effort PII-filtered when this trail is
     * attached to a crash report (see
     * [io.kixo.sdk.internal.crash.CrashTracker] which routes them
     * through [io.kixo.sdk.internal.privacy.PiiFilter] before
     * serialisation). The filter handles emails, phone numbers, SSNs,
     * Luhn-validated credit cards, JWTs, and IBANs — but it is
     * **best-effort, not exhaustive**. Customer SHOULD NOT put
     * plaintext PII (passwords, tokens, government IDs of unusual
     * formats) in breadcrumb [data] or [message]. Use opaque IDs
     * instead.
     *
     * @param category Free-form category, see [Breadcrumb] doc.
     * @param message Human-readable summary.
     * @param data Optional structured payload. Converted to
     *   [kotlinx.serialization.json.JsonObject] via [toJsonElement];
     *   unrepresentable values are dropped silently per the
     *   [io.kixo.sdk.internal.model.PropertyValue] contract.
     * @param level Severity, see [Breadcrumb] doc. Defaults to "info".
     * @param timestamp Override clock for tests; defaults to now.
     */
    fun add(
        category: String,
        message: String,
        data: Map<String, Any?>? = null,
        level: String = "info",
        timestamp: Instant = Instant.now(),
    ) {
        val crumb = Breadcrumb(
            timestamp = timestamp,
            category = category,
            message = message,
            data = data?.takeUnless { it.isEmpty() }?.toJsonElement(),
            level = level,
        )
        addCrumb(crumb)
    }

    /**
     * Append a pre-built breadcrumb. Same semantics as [add]. Mostly
     * useful for tests + internal callsites that already have a
     * [Breadcrumb] in hand.
     */
    fun add(crumb: Breadcrumb) {
        addCrumb(crumb)
    }

    private fun addCrumb(crumb: Breadcrumb) {
        // The evict-then-add pair must be atomic w.r.t. other writers
        // or N concurrent writers can drive the counter past MAX_SIZE
        // unboundedly (each reads `size` then races to add). Critic 3
        // flagged this. Hard lock keeps the trail strictly bounded.
        synchronized(lock) {
            while (size.get() >= MAX_SIZE) {
                if (trail.pollFirst() != null) {
                    size.decrementAndGet()
                } else {
                    // Deque emptied between size check and poll
                    // (impossible inside the lock, but defensive).
                    // Reset the counter to keep it aligned and continue.
                    size.set(trail.size)
                    break
                }
            }
            trail.addLast(crumb)
            size.incrementAndGet()
        }
    }

    /**
     * Returns an immutable snapshot of all current breadcrumbs in
     * insertion order (oldest first). Safe to call from any thread,
     * including signal / crash handlers — internally allocates a new
     * [ArrayList] from the deque iterator and never blocks writers.
     *
     * For attaching to a crash event, the caller serialises this
     * list as the `breadcrumbs` event-property.
     */
    fun snapshot(): List<Breadcrumb> {
        // ConcurrentLinkedDeque iterators are weakly consistent —
        // they reflect the state at some point during traversal but
        // don't throw ConcurrentModificationException. That's exactly
        // what we want for crash dumps: best-effort snapshot,
        // never fail.
        return ArrayList<Breadcrumb>(size.get().coerceAtLeast(0)).apply {
            for (c in trail) add(c)
        }
    }

    /** Remove all breadcrumbs. Used by `Kixo.reset()` and by tests. */
    fun clear() {
        trail.clear()
        size.set(0)
    }

    /** Current entry count. Strictly bounded — never exceeds [MAX_SIZE]. */
    fun count(): Int = size.get()
}
