package io.kixo.sdk.internal.transport

import io.kixo.sdk.internal.model.BatchResponse
import io.kixo.sdk.internal.model.KixoEvent

/**
 * Pure function that partitions a batch's events into
 * **(accepted, permanent, transient)** id buckets given the server's
 * [BatchResponse]. Lives apart from [Transport] so the partition
 * logic can be unit-tested without spinning a MockWebServer.
 *
 * **Defensive default (briefing §3 R5).** If an `event_id` from the
 * outgoing batch appears in NEITHER `accepted_event_ids` NOR
 * `errors[]`, treat it as **accepted**. The backend invariant is "every
 * batched event_id appears in exactly one of the two arrays", but a
 * missing entry MUST NOT be treated as transient or we'd loop forever
 * on a buggy backend deploy that silently drops some events from the
 * response. Choosing `accepted` errs on the side of "stop retrying
 * something the backend almost certainly stored" — at worst we lose
 * one analytic event; at best we don't pin the queue forever.
 *
 * (iOS Transport.swift made the OPPOSITE choice — defensive transient
 * — because the Mixpanel-style queue back then had unbounded retry. On
 * Android we have a hard 30-failure cooldown so the trade-off flips:
 * the safer of the two failure modes here is "drop, don't retry". The
 * AGENT_BRIEFING §3 R5 spec calls out the Android choice explicitly.)
 *
 * **Conflict resolution.** If an event id appears in BOTH arrays
 * (server bug), `errors[]` wins — better to drop / retry per the
 * server's stated intent than to silently mark it accepted. Within
 * `errors[]`, `permanent=true` wins over `permanent=false` (drop is
 * stricter than retry).
 *
 * **Index fallback.** Some legacy backend codepaths populate
 * `errors[].index` instead of `errors[].event_id`. We honour both:
 * if `event_id` is empty but `index` is in range, we look up the id
 * by position in the original batch.
 */
internal object AckClassifier {

    /**
     * Classify the given batch against the server response.
     *
     * @return Triple of (accepted, permanent, transient) event-id lists.
     *         All three are deduplicated; an id never appears in more
     *         than one bucket. Iteration order matches the original
     *         batch's order to keep DELETE/UPDATE statements stable in
     *         the SQLite store.
     */
    fun classify(
        events: List<KixoEvent>,
        response: BatchResponse,
    ): Triple<List<String>, List<String>, List<String>> {
        val batchIds = events.map { it.eventId }
        val batchIdSet = batchIds.toSet()

        // Resolve errors[] entries to event ids. Prefer `event_id`
        // (the new contract); fall back to `index` (legacy). Skip any
        // entry that resolves to nothing — the backend may emit
        // batch-level errors without a per-event id, and those don't
        // map to any event we sent.
        val permanentIds = mutableSetOf<String>()
        val transientIds = mutableSetOf<String>()
        for (err in response.errors) {
            // Agent 2 declares `eventId: String` (non-nullable) but
            // backend may omit it on legacy paths; treat empty as
            // "use index instead". A kotlinx.serialization decode of a
            // missing key would have already thrown, so an empty
            // string here is a deliberate sentinel.
            val id: String = if (err.eventId.isNotEmpty()) {
                err.eventId
            } else {
                err.index?.let { idx -> events.getOrNull(idx)?.eventId }
                    ?: continue
            }
            // Defensive: if the backend echoes an id we didn't send,
            // ignore it. We can't decide what to do with an event that
            // isn't in our local buffer.
            if (id !in batchIdSet) continue
            if (err.permanent) {
                permanentIds.add(id)
            } else {
                transientIds.add(id)
            }
        }
        // permanent wins over transient if a buggy server lists the
        // same id twice with conflicting flags — drop is stricter.
        transientIds.removeAll(permanentIds)

        // accepted = listed by server, intersected with our batch,
        // minus anything also flagged in errors[] (errors win — server
        // told us not to commit it).
        val acceptedFromServer = response.acceptedEventIds.toMutableSet()
        acceptedFromServer.retainAll(batchIdSet)
        acceptedFromServer.removeAll(permanentIds)
        acceptedFromServer.removeAll(transientIds)

        // Defensive default — see kdoc. Anything we sent that the
        // server didn't mention in EITHER array is treated as accepted.
        //
        // INTENTIONAL DIVERGENCE FROM iOS (Critic 5 + Briefing §3 R5):
        // AGENT_BRIEFING.md §3 R5 specifies for Android:
        //   "Missing from BOTH arrays → defensive: treat as `accepted`"
        // iOS Transport.swift defensively treats the same case as
        // transient. Both choices are wrong some of the time, but on
        // Android our hard 30-failure cooldown makes "stop retrying
        // something the backend probably stored" the safer failure mode
        // than "retry forever and burn the queue cooldown budget on
        // ghost rows the backend silently dropped". Future readers:
        // please do NOT flip this to match iOS without first revisiting
        // the briefing — the divergence is by design.
        val mentionedAnywhere =
            acceptedFromServer + permanentIds + transientIds
        val unmentioned = batchIds.filter { it !in mentionedAnywhere }
        acceptedFromServer.addAll(unmentioned)

        // Preserve original batch ordering in the returned lists so
        // downstream SQL / log lines aren't shuffled randomly between
        // runs — eases diffing test fixtures.
        val accepted = batchIds.filter { it in acceptedFromServer }
        val permanent = batchIds.filter { it in permanentIds }
        val transient = batchIds.filter { it in transientIds }
        return Triple(accepted, permanent, transient)
    }
}
