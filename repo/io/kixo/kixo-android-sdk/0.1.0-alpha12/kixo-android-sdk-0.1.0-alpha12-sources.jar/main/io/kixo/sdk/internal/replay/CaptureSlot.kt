package io.kixo.sdk.internal.replay

import java.util.concurrent.atomic.AtomicInteger

/**
 * Bounded-concurrency counter for the replay capture pipeline.
 *
 * Mirrors iOS [ReplayController.tryAcquireCaptureSlot]. The iOS
 * implementation uses a counter under `stateLock`; the Android port
 * uses [AtomicInteger] so the hot path doesn't enter a JVM monitor.
 *
 * **Why this exists** (per AGENT_BRIEFING §3 R4 "bounded everything"):
 *  - [FrameSnapshotter.snapshot] pins a `Bitmap` (~10 MB on a
 *    1080×2400 ARGB_8888 raster, more on higher-density tablets).
 *  - [OcrExtractor] pins ML Kit Vision tensors (~5-15 MB scratch).
 *  - The structural snapshotter pins a `JsonObject` of the entire
 *    view tree (~50-200 KB).
 *
 * Without a cap, rapid taps + scroll-ends pile retains and worker
 * tasks → OOM. Default cap = 3 (any more in-flight = drop the new
 * capture entirely; do NOT queue).
 *
 * **Why "drop, do not queue":** queueing would let backpressure grow
 * during a UI hot-spot and trigger captures AFTER the hot-spot ended
 * — at which point those frames document a settled state that's
 * already represented by the next "real" capture. Better to drop the
 * one tap and emit a metadata-only event than retain stale Bitmaps.
 *
 * **Memory-pressure tightening.** [tightenForMemoryPressure] is
 * called by [ReplayController] when Agent 7's
 * [io.kixo.sdk.internal.lifecycle.MemoryPressure] flow emits
 * [io.kixo.sdk.internal.lifecycle.MemoryPressure.CRITICAL]. Cap
 * drops to 1; restored on `NORMAL`.
 *
 * **Thread-safe.** All public methods use lock-free atomics.
 */
internal class CaptureSlot(
    private val baseline: Int,
) {

    /**
     * Live count of in-flight capture slots. Bumped by [tryAcquire],
     * decremented by [release]. NEVER goes negative — [release]
     * defends with a CAS guard.
     */
    private val inFlight = AtomicInteger(0)

    /**
     * Effective ceiling. Equals [baseline] under normal memory; drops
     * to 1 under [io.kixo.sdk.internal.lifecycle.MemoryPressure.CRITICAL].
     * Atomic because the memory-warning observer can write from any
     * thread while the capture pipeline reads from main.
     */
    private val ceiling = AtomicInteger(baseline)

    init {
        require(baseline >= 1) { "CaptureSlot baseline must be >= 1, was $baseline" }
    }

    /**
     * Try to reserve a slot. Returns `true` and increments the
     * in-flight counter if a slot was free; returns `false`
     * otherwise — the caller MUST drop the capture entirely.
     *
     * Lock-free CAS loop — no JVM monitor enter on the hot path.
     */
    fun tryAcquire(): Boolean {
        while (true) {
            val current = inFlight.get()
            if (current >= ceiling.get()) return false
            if (inFlight.compareAndSet(current, current + 1)) return true
        }
    }

    /**
     * Release a previously-acquired slot. Idempotent guard: never
     * decrements below zero so a buggy double-release does not let
     * the cap drift into negative territory.
     */
    fun release() {
        while (true) {
            val current = inFlight.get()
            if (current <= 0) return
            if (inFlight.compareAndSet(current, current - 1)) return
        }
    }

    /** Current in-flight count (test seam + diagnostics). */
    fun inFlightCount(): Int = inFlight.get()

    /** Current effective ceiling (test seam + diagnostics). */
    fun ceiling(): Int = ceiling.get()

    /**
     * Tighten the cap to 1 for the duration of memory pressure. The
     * iOS counterpart sets `lowMemoryMode = true` and clamps via
     * `maxInFlightCaptures`. Same semantics.
     */
    fun tightenForMemoryPressure() {
        ceiling.set(1)
    }

    /**
     * Restore the cap to its baseline. Called on memory-pressure
     * recovery (`NORMAL`) or on explicit reset.
     */
    fun restoreBaseline() {
        ceiling.set(baseline)
    }
}
