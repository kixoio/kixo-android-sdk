package io.kixo.sdk

import android.view.View
import io.kixo.sdk.internal.privacy.MaskRegistry

/**
 * Mark a [View] as sensitive so the Kixo SDK never captures its
 * pixels or text in session replay.
 *
 * **Always-redacted in replay snapshots.** When this flag is set the
 * replay pipeline:
 *  - Skips reading the view's `text` content into structural snapshots.
 *  - Rasterizes the view's bounding box as an opaque rectangle BEFORE
 *    the JPEG/WebP encode (so the pixels that leave the device are
 *    already obliterated — see AGENT_BRIEFING.md R2).
 *  - Treats any tap landing inside the view as a generic tap with
 *    no view-identity hint.
 *
 * **When you'd use this.** Most password / email / phone fields are
 * already auto-detected via [android.text.InputType] (see
 * [io.kixo.sdk.internal.privacy.StructuralRedactionRules]). Use this
 * for anything custom — proprietary content like a private chat
 * thread, an account-balance widget, or a draft-screen the user is
 * still composing — that the InputType heuristics can't see.
 *
 * **Idempotent.** Safe to call multiple times. Pass `mask = false` to
 * explicitly clear a previously-set mask (e.g. when the same view is
 * recycled into a non-sensitive role inside a [androidx.recyclerview.widget.RecyclerView]).
 *
 * **No memory leak.** The SDK holds the [View] reference weakly so
 * marking a view does NOT keep its [android.app.Activity] alive.
 *
 * Example:
 * ```kotlin
 * binding.privateBalanceLabel.setKixoMask(true)
 * binding.cardCvvField.setKixoMask(true)
 * ```
 *
 * **Jetpack Compose screens.** `androidx.compose.material(.material3).TextField`
 * is NOT a [View] subclass — the entire Compose tree is rendered into
 * a single host view (`AndroidComposeView`) that the SDK's structural
 * walker cannot introspect. To stay safe by default, the SDK
 * **wholesale-masks every AndroidComposeView host**. To opt back IN to
 * capture for a Compose screen you have audited for PII, mark the
 * **outermost ComposeView ancestor** with `setKixoMask(false)`. For
 * example, in your Activity:
 * ```kotlin
 * setContent { … }                 // the host view is the only ComposeView
 * findViewById<View>(android.R.id.content).getChildAt(0).setKixoMask(false)
 * ```
 * Once Compose-aware introspection ships (per-leaf SemanticsOwner
 * walk), this opt-in step will become unnecessary for screens whose
 * password/email semantics nodes are correctly tagged.
 *
 * @param mask `true` to mark sensitive; `false` to clear a prior mark.
 */
fun View.setKixoMask(mask: Boolean) {
    MaskRegistry.setMasked(this, mask)
}
