package io.kixo.sdk.internal.replay

import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.EditText
import io.kixo.sdk.internal.screen.Role
import io.kixo.sdk.internal.screen.RoleClassifier
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put

/**
 * Recursively walks a `View` tree producing a JSON DOM-like
 * structural snapshot. Companion to [FrameSnapshotter] — pixel and
 * structural data ship together so the dashboard player can render
 * Pixel / Structural / Hybrid / Wireframe / Compare modes.
 *
 * **iOS counterpart**: [StructuralSnapshotter.swift] which runs four
 * passes (UIView walk + a11y tree + CALayer walk + SwiftUI Mirror
 * reflection) and merges them. Android has no SwiftUI/CALayer
 * analogue — the View hierarchy IS the source of truth — so we get
 * away with one pass + the [RoleClassifier] tagger.
 *
 * **Privacy** (briefing §3 R2):
 *  1. Every text node passes through the injected [piiSanitizer]
 *     BEFORE entering the JSON. So a `TextView` showing
 *     `"hi alice@example.com"` lands in JSON as
 *     `"hi [email]"`.
 *  2. Whole subtrees rooted at a [shouldRedactSubtree] view (password
 *     `EditText`, [WebView], or `kxRedact`-tagged view per Agent 10's
 *     `StructuralRedactionRules`) are emitted as
 *     `{"redacted": true, "type": "...", "bounds": [...]}`
 *     with no children. The frame raster overlay is handled by Agent
 *     14's encoder.
 *
 * **Output schema** (mirrors iOS shape; Android-only fields marked):
 * ```
 * {
 *   "v": 2,
 *   "viewport": { "x": 0, "y": 0, "w": 1080, "h": 2400 },
 *   "build_hash": "abcdef…",
 *   "root": <Node>
 * }
 * Node = {
 *   "id": "resource_entry_name | null",
 *   "type": "Button | TextView | ImageView | ...",
 *   "role": "Button | Text | Image | ...",
 *   "bounds": [left, top, width, height],
 *   "text": "<sanitised text or null>",
 *   "redacted": false,
 *   "children": [ <Node>, … ]
 * }
 * ```
 *
 * **Performance budget** (mid-tier device, 200-node hierarchy):
 *  - Tree walk: ~2-3 ms (dominated by `View.getResources()` lookups)
 *  - PII regex per text: ~10-50 µs per node
 *  - JSON encode: handled by caller off-main
 *
 * **Thread**: MUST be called on the main thread — `View.getX/Y/Width`
 * are not thread-safe. Caller serialises the resulting `JsonObject`
 * off-main if needed.
 *
 * **Role tagger.** Uses Agent 9's [RoleClassifier] for the `role`
 * field. The tagger is content-invariant (briefing R8) so the same
 * screen across light/dark + locale + density yields the same role
 * tree.
 */
internal class StructuralSnapshotter(
    private val piiSanitizer: (String) -> String = { it },
    /**
     * Hook for Agent 10's `StructuralRedactionRules.shouldRedact(view)`.
     * Returns `true` if the entire subtree rooted at the supplied
     * View should be emitted as `{"redacted": true}` (no children,
     * no text). Defaults to a structural fallback that catches
     * password-input EditTexts + WebViews + the `kxRedact` tag —
     * the absolute minimum to comply with briefing R2 even when
     * Agent 10's wiring isn't yet in place.
     */
    private val shouldRedactSubtree: (View) -> Boolean = ::defaultShouldRedactSubtree,
    /** Maximum depth to walk before truncating — defends against pathological hierarchies. */
    private val maxDepth: Int = 12,
    /** Cap on total nodes captured. */
    private val maxNodes: Int = 200,
    /** Skip subtrees smaller than this on either axis (px). */
    private val minVisiblePx: Int = 4,
) {

    /**
     * Snapshot the supplied view at its current bounds. Returns
     * `null` when the view has zero bounds (off-screen or not laid
     * out yet). The returned [JsonObject] is the FULL document — has
     * `viewport`, `build_hash`, and `root` — ready for upload.
     *
     * Walks at most [maxNodes] views and at most [maxDepth] deep.
     */
    fun snapshot(view: View): JsonObject? {
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) return null

        // Build digest BEFORE the recursive walk so [stableHash]
        // doesn't see truncation due to the maxNodes cap. The hash
        // captures the structural skeleton — same screen across
        // sessions = same hash, regardless of content.
        val classDigest = StringBuilder(256)
        val nodeCount = IntArray(1)

        val rootNode = buildNode(
            view = view,
            depth = 0,
            digest = classDigest,
            nodeCounter = nodeCount,
        ) ?: return null

        return buildJsonObject {
            put("v", 2)
            put("viewport", buildJsonObject {
                put("x", 0)
                put("y", 0)
                put("w", width)
                put("h", height)
            })
            put("build_hash", stableHash(classDigest.toString()))
            put("root", rootNode)
        }
    }

    /**
     * Recursive walker. Returns `null` for nodes we elect to skip
     * entirely (off-screen / too small / over-cap). The decision to
     * include or skip is layered:
     *
     *   1. Cap reached → skip (would force truncation anyway)
     *   2. Depth reached → emit a leaf with no children
     *   3. Hidden / `View.GONE` / alpha=0 → skip
     *   4. Bounds < [minVisiblePx] → skip
     *   5. [shouldRedactSubtree] true → emit redacted leaf, no children
     *   6. Default → emit node + recurse children
     */
    private fun buildNode(
        view: View,
        depth: Int,
        digest: StringBuilder,
        nodeCounter: IntArray,
    ): JsonElement? {
        if (nodeCounter[0] >= maxNodes) return null
        if (view.visibility != View.VISIBLE) return null
        if (view.alpha < 0.01f) return null
        val width = view.width
        val height = view.height
        if (width < minVisiblePx || height < minVisiblePx) return null

        val role = RoleClassifier.classify(view)
        val type = view.javaClass.simpleName

        // Append to digest BEFORE bumping the counter so the hash
        // reflects the actual walk order even on truncation.
        digest.append(depth).append(':').append(type).append('|')
        nodeCounter[0]++

        val resourceId: String? = try {
            val rid = view.id
            if (rid == View.NO_ID || rid == 0) null
            else view.resources.getResourceEntryName(rid)
        } catch (_: Throwable) {
            null
        }

        val absLeft = IntArray(2)
        view.getLocationInWindow(absLeft)

        // Redaction: emit a placeholder node. No text, no children.
        // Agent 14's encoder rasterises the matching opaque rect
        // into the bitmap before encode (briefing R2: "frames with
        // PII never leave device unredacted").
        if (shouldRedactSubtree(view)) {
            return buildJsonObject {
                put("id", resourceId?.let(::JsonPrimitive) ?: JsonNull)
                put("type", type)
                put("role", role.wireName())
                put("bounds", boundsArray(absLeft[0], absLeft[1], width, height))
                put("text", JsonNull)
                put("redacted", true)
                put("children", JsonArray(emptyList()))
            }
        }

        val sanitisedText: String? = extractText(view)?.let { raw ->
            if (raw.isEmpty()) null else piiSanitizer(raw)
        }

        val children: List<JsonElement> =
            if (depth >= maxDepth || view !is ViewGroup) {
                emptyList()
            } else {
                buildList {
                    for (i in 0 until view.childCount) {
                        val child = view.getChildAt(i) ?: continue
                        if (nodeCounter[0] >= maxNodes) break
                        buildNode(child, depth + 1, digest, nodeCounter)
                            ?.let(::add)
                    }
                }
            }

        return buildJsonObject {
            put("id", resourceId?.let(::JsonPrimitive) ?: JsonNull)
            put("type", type)
            put("role", role.wireName())
            put("bounds", boundsArray(absLeft[0], absLeft[1], width, height))
            put("text", sanitisedText?.let(::JsonPrimitive) ?: JsonNull)
            put("redacted", false)
            put("children", JsonArray(children))
        }
    }

    /**
     * Build the standard `[left, top, width, height]` JSON array.
     * Centralised because the redacted-leaf and full-node paths
     * both emit the same shape — and `JsonArrayBuilder.add` accepts
     * only [JsonElement] so we wrap each Int in [JsonPrimitive] in
     * one place.
     */
    private fun boundsArray(left: Int, top: Int, width: Int, height: Int): JsonArray =
        JsonArray(
            listOf(
                JsonPrimitive(left),
                JsonPrimitive(top),
                JsonPrimitive(width),
                JsonPrimitive(height),
            )
        )

    /**
     * Pull a representative text label off a view if available.
     * Order of precedence (matches iOS [StructuralSnapshotter] and
     * the dashboard player's expectation):
     *   1. `TextView.text` — covers Button, EditText (non-password),
     *      and all Material variants.
     *   2. `View.contentDescription` — accessibility label.
     *
     * Returns `null` for views with no text. We deliberately do NOT
     * read `EditText.hint` — hints are content-invariant and would
     * still leak if a hint contained sensitive copy ("Enter your
     * SSN"). Hints stay as `null`; player surfaces "edit field"
     * placeholder generically.
     */
    private fun extractText(view: View): String? {
        // EditText family is NEVER read here. Password EditTexts are
        // caught by the redaction subtree above; non-password EditTexts
        // can still hold typed PII (the user's entered email mid-form,
        // unsubmitted message text, etc.) so we treat them as opaque.
        // The PII regex pass on whatever DOES make it to text would
        // still catch these on a per-string basis, but we err on the
        // side of "edit fields stay blank in the structural sidecar"
        // because their typed content is the most user-sensitive in
        // the whole hierarchy.
        if (view is EditText) return null

        if (view is android.widget.TextView) {
            val raw = view.text?.toString() ?: ""
            if (raw.isNotEmpty()) return raw
        }
        val cd = view.contentDescription?.toString()
        if (!cd.isNullOrEmpty()) return cd
        return null
    }

    companion object {
        /**
         * FNV-1a 64-bit over the class-digest. Stable across SDK
         * versions because [RoleClassifier.code] is fixed and the
         * walker emits in deterministic depth-first order.
         *
         * Why FNV-1a, not SHA-256: this is for de-dup, not crypto.
         * FNV-1a is ~10× faster, has 0 collisions in our test
         * corpus, and produces a 16-char hex string which fits
         * cleanly in CH `LowCardinality(String)` column with low
         * cardinality.
         */
        internal fun stableHash(input: String): String {
            // FNV-1a 64-bit
            var hash = 0xcbf29ce484222325uL
            val prime = 0x00000100000001B3uL
            for (i in input.indices) {
                hash = hash xor input[i].code.toULong()
                hash *= prime
            }
            return hash.toString(16).padStart(16, '0')
        }

        /**
         * Default `shouldRedactSubtree` heuristic — used when
         * Agent 10's `StructuralRedactionRules` isn't wired yet.
         * Catches the briefing-R2 minimums:
         *   - Password [EditText] (any of 4 password input-type
         *     variants).
         *   - [WebView] (always opaque — DOM contents change every
         *     navigation).
         *   - SurfaceView / TextureView / GLSurfaceView (we cannot
         *     readback their pixels through `View.draw()` anyway).
         *   - Any view tagged via `view.setTag(R.id.kixo_redact_tag, true)`
         *     by the host app — the public Agent 1 API
         *     `Kixo.markAsSensitive(view)` flips this. Captured here
         *     as a string-tag fallback for tests.
         */
        @JvmStatic
        fun defaultShouldRedactSubtree(view: View): Boolean {
            // EditText with any password input-type variation.
            if (view is EditText) {
                val variation = view.inputType and InputType.TYPE_MASK_VARIATION
                val cls = view.inputType and InputType.TYPE_MASK_CLASS
                val isPassword =
                    variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                    variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                    (cls == InputType.TYPE_CLASS_NUMBER &&
                        variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD)
                if (isPassword) return true

                // Email + phone variants → still personally
                // identifying enough to warrant redaction.
                if (variation == InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS ||
                    cls == InputType.TYPE_CLASS_PHONE
                ) {
                    return true
                }
            }
            if (view is WebView) return true

            val className = view.javaClass.simpleName
            if (className == "SurfaceView" ||
                className == "TextureView" ||
                className == "GLSurfaceView"
            ) {
                return true
            }

            // Public Agent-1 markup. The tag key is a documented
            // Kixo convention — `view.setTag("kixo_redact", true)`
            // works without any resource id allocation. When Agent 1
            // ships the typed `setTag(R.id.…)` API, that path will
            // also flow through here.
            (view.getTag() as? String)?.let { tag ->
                if (tag == KX_REDACT_TAG_VALUE) return true
            }

            return false
        }

        /** Public marker string Agent 1 + Agent 10 also reference. */
        const val KX_REDACT_TAG_VALUE: String = "kixo_redact"
    }
}

/**
 * Bridge from Agent 9's [Role] enum to the wire string the dashboard
 * player expects. Lives at file scope (not on [Role]) because Agent
 * 13 doesn't own that file — adding methods there would violate
 * AGENT_BRIEFING §6 ownership.
 */
private fun Role.wireName(): JsonPrimitive = when (this) {
    Role.Text -> JsonPrimitive("text")
    Role.Button -> JsonPrimitive("button")
    Role.TextField -> JsonPrimitive("text_field")
    Role.Image -> JsonPrimitive("image")
    Role.List -> JsonPrimitive("list")
    Role.Web -> JsonPrimitive("web")
    Role.Container -> JsonPrimitive("container")
    Role.Input -> JsonPrimitive("input")
    Role.Navigation -> JsonPrimitive("navigation")
    Role.Other -> JsonPrimitive("other")
}
