package io.kixo.sdk.internal.identity

import java.security.MessageDigest

/**
 * SHA-256 utility used by the identity subsystem (and any internal
 * caller that wants a stable hex digest of a string). Mirrors the
 * shape of [io.kixo.sdk.internal.push.Sha256Helper] used by the push
 * subsystem — we keep the helper local to `identity/` so this folder
 * doesn't reach into Agent 11's package for a one-line utility.
 *
 * **Why a separate copy and not a single shared helper?**
 *  - Per `AGENT_BRIEFING.md` §6 the file-ownership rule is "edit only
 *    your own folder; if you need a type someone else owns, declare a
 *    stub in your folder." A shared `internal/util/` directory would
 *    invent yet another owner and isn't documented in the briefing.
 *  - The cost is one ~30-LOC file. Cheap.
 *
 * Used by:
 *   - [IdentityManager] for trait-hashing in the [IdentityDedup]
 *     side-channel (Agent 5's `IdentityDedup` already does its own
 *     hashing, but the public `String.sha256()` extension is also
 *     exposed for ad-hoc use by other internal code).
 *   - [io.kixo.sdk.internal.diagnostics.Diagnostics] indirectly via
 *     content fingerprints when those are needed.
 *
 * **Thread safety**: each call constructs its own `MessageDigest`
 * instance — `MessageDigest` is stateful and not thread-safe, so
 * caching as a singleton would be a footgun. The cost of
 * `MessageDigest.getInstance("SHA-256")` is dominated by the digest
 * itself; caching saves nothing measurable.
 *
 * **Error handling**: defensive per `AGENT_BRIEFING.md` R6 — never
 * crash the host app. On any failure (extremely unlikely — `SHA-256`
 * is mandatory in the JRE spec), returns the empty string. Callers
 * that need to detect failure should check for `""`; callers that
 * just want a stable token (the common case) get a harmless fall-back.
 */

private val HEX_CHARS = "0123456789abcdef".toCharArray()

/**
 * SHA-256 of [this] string (UTF-8) returned as a 64-char lowercase
 * hex digest. Returns `""` on any failure.
 *
 * Implemented as an extension function so the call sites read like
 * `traitsString.sha256()` rather than the noisier
 * `Sha256Util.sha256(traitsString)`. Exposed as `internal` so it
 * doesn't leak past the SDK boundary.
 */
internal fun String.sha256(): String {
    return try {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest(this.toByteArray(Charsets.UTF_8))
        val out = CharArray(bytes.size * 2)
        for (i in bytes.indices) {
            val v = bytes[i].toInt() and 0xFF
            out[i * 2] = HEX_CHARS[v ushr 4]
            out[i * 2 + 1] = HEX_CHARS[v and 0x0F]
        }
        String(out)
    } catch (t: Throwable) {
        ""
    }
}
