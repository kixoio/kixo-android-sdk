package io.kixo.sdk.internal.context

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import io.kixo.sdk.internal.model.EnrichedContext
import io.kixo.sdk.internal.model.EventContext
import java.io.File
import java.security.MessageDigest
import java.time.Instant
import java.time.format.DateTimeFormatter
import java.util.Locale
import java.util.TimeZone

/**
 * Snapshots device / OS / runtime / hardware / app state for both the
 * per-event [EventContext] (lightweight, on every event) and the
 * per-batch [EnrichedContext] (Sentry-style, sent once per HTTP
 * batch).
 *
 * Mirrors iOS [Context/DeviceInfo.swift]. The split reflects the
 * backend's two storage shapes: ClickHouse `events` rows carry the
 * lightweight context inline (cheap to index), while the heavyweight
 * device profile is normalised onto the batch envelope so we don't
 * inflate every row.
 *
 * **Caching strategy** (mirrors iOS):
 *  - Heavyweight, immutable-per-launch values (kernel version, boot
 *    time, hardware fields, brand/model, app metadata) are computed
 *    ONCE in [init] and frozen.
 *  - Volatile values that legitimately change mid-session (battery
 *    level, charge state, connection type, orientation, free memory,
 *    free storage, in-foreground hint) are refetched per call.
 *
 * **Threading**: every method is safe to call from any thread.
 * Internally we never block on system services beyond the
 * non-blocking probes; the battery sticky-broadcast read is
 * documented as O(1) by the OS.
 *
 * **Permissions**: no runtime permissions required. INTERNET +
 * ACCESS_NETWORK_STATE are declared in the SDK's manifest (see
 * `AndroidManifest.xml`); everything else here uses public APIs that
 * Play policy treats as unrestricted.
 *
 * **Briefing R10 compliance**:
 *  - We do NOT read MAC address, IMEI, SIM serial, or hardware serial.
 *    The [deviceHash] is derived from BRAND + MODEL + ABI — strictly
 *    coarse-grained, NOT a stable hardware identifier per Play policy.
 *  - We do NOT request `READ_PHONE_STATE` for carrier name. The wire
 *    field stays null on Android by default; an operator who really
 *    needs carrier can pre-grant the permission and set it via their
 *    own super-property.
 */
internal class DeviceInfo(private val appContext: Context) {

    // ──────────────────────────────────────────────────────────────
    // Cached-once-per-launch state.
    //
    // Anything here is computed at construction time and kept for the
    // process lifetime. Immutable per launch by definition — phones
    // don't switch CPU cores, total RAM, app bundle id, or kernel
    // version mid-process.
    // ──────────────────────────────────────────────────────────────

    /** SDK init wall-clock. Used as `app.start_time`. */
    private val sdkStartTime: String =
        DateTimeFormatter.ISO_INSTANT.format(Instant.now())

    /** Process boot wall-clock derived from `SystemClock.elapsedRealtime`. */
    private val bootTimeIso: String? = run {
        val uptimeMs = SystemClock.elapsedRealtime()
        if (uptimeMs > 0) {
            val bootInstant = Instant.now().minusMillis(uptimeMs)
            DateTimeFormatter.ISO_INSTANT.format(bootInstant)
        } else null
    }

    /** Kernel version from `os.version` system property. */
    private val kernelVersion: String? =
        System.getProperty("os.version")?.takeIf { it.isNotBlank() }

    /** CPU core count, capped at ≥1 to satisfy the wire schema. */
    private val cpuCores: Int =
        Runtime.getRuntime().availableProcessors().coerceAtLeast(1)

    /** Total physical memory in bytes. 0 if probe failed. */
    private val totalMemoryBytes: Long = run {
        val am = safeService<ActivityManager>(Context.ACTIVITY_SERVICE)
        if (am != null) {
            val info = ActivityManager.MemoryInfo()
            try {
                am.getMemoryInfo(info)
                info.totalMem
            } catch (t: Throwable) {
                0L
            }
        } else 0L
    }

    /** Total storage in GB (rounded), or null if probe failed. */
    private val storageSizeGb: Double? = readStorageSize()

    /** Manufacturer ("Google", "Samsung", …). Trim to handle vendor noise. */
    private val brand: String = (Build.MANUFACTURER ?: "unknown").trim()

    /** "Pixel 8", "SM-S908U1", … — concatenation of MANUFACTURER + MODEL. */
    private val deviceModelString: String = run {
        val m = (Build.MODEL ?: "unknown").trim()
        if (brand.isNotBlank() && !m.startsWith(brand, ignoreCase = true)) {
            "$brand $m"
        } else m
    }

    /** Family string used by [EnrichedContext.DeviceContext.family]. */
    private val familyString: String = brand

    /**
     * Raw model identifier without the manufacturer prefix. Mirrors
     * iOS's [Build.MACHINE]-style identifier for cross-platform
     * pivots in dashboards.
     */
    private val rawModel: String = (Build.MODEL ?: "unknown").trim()

    /** Abis we run on, primary first. */
    private val supportedAbis: List<String> =
        Build.SUPPORTED_ABIS?.toList()?.takeIf { it.isNotEmpty() } ?: listOf("unknown")

    /** Coarse device tier (Flagship/Mid/Budget) → wire string. */
    private val deviceClassWireValue: String =
        DeviceClass.classify(totalMemoryBytes, cpuCores).wireValue

    /**
     * SHA-256(brand + model + primary_abi). Coarse — same hash for
     * every Pixel 8 worldwide. NOT a hardware serial; Play-policy safe.
     */
    private val deviceHashHex: String? = computeDeviceHash()

    /** Best-effort emulator detection. */
    private val isEmulator: Boolean = detectEmulator()

    /** Best-effort root detection (process can write to system paths). */
    private val isRooted: Boolean = detectRoot()

    /** Build display string ("UQ1A.240105.002"). */
    private val osBuildDisplay: String = (Build.DISPLAY ?: "unknown").trim()

    /** Cached bundle id. */
    private val packageName: String = appContext.packageName ?: "unknown"

    /**
     * Cached `(versionName, versionCode)` so we don't hit
     * PackageManager on every event. PackageManager calls are
     * surprisingly slow on cold start.
     */
    private val appVersion: Pair<String, String> = readAppVersion()

    /** Human-readable app label. May change on locale switch but rarely. */
    private val appLabel: String = run {
        try {
            val pm = appContext.packageManager
            pm.getApplicationLabel(appContext.applicationInfo)?.toString() ?: packageName
        } catch (t: Throwable) {
            packageName
        }
    }

    /** Build type heuristic (debuggable→"development" else "release"). */
    private val buildType: String = run {
        val flags = try {
            appContext.applicationInfo.flags
        } catch (t: Throwable) {
            0
        }
        if ((flags and android.content.pm.ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            "development"
        } else {
            "release"
        }
    }

    /**
     * Screen DPI. Capture at init (display config rarely changes
     * post-launch and is sticky enough for analytics). Density buckets
     * are 120/160/240/320/480/640 — backend can re-bucket downstream.
     */
    private val screenDpi: Int = readScreenDpi()

    // ──────────────────────────────────────────────────────────────
    // Public API — per-event lightweight context.
    // ──────────────────────────────────────────────────────────────

    /**
     * Lightweight context attached to EVERY event. Volatile fields
     * (battery, connection, locale, timezone) are refetched live.
     *
     * Mirrors iOS `DeviceInfo.current()` and the backend's
     * `EventContext` shape per AGENT_BRIEFING.md §4.
     */
    fun perEventContext(): EventContext {
        val display = currentDisplaySize()
        val battery = readBattery()
        return EventContext(
            platform = "android",
            deviceModel = deviceModelString,
            osVersion = osVersionString(),
            locale = currentLocaleTag(),
            timezone = TimeZone.getDefault().id ?: "UTC",
            screenWidth = display.first,
            screenHeight = display.second,
            connectionType = currentConnectionType(),
            // R10: never request READ_PHONE_STATE for carrier on
            // Android. Stays null by default; an operator who needs
            // it can attach via super-property.
            carrier = null,
            batteryLevel = battery?.first,
            isCharging = battery?.second,
        )
    }

    // ──────────────────────────────────────────────────────────────
    // Public API — per-batch enriched context.
    // ──────────────────────────────────────────────────────────────

    /**
     * Sentry-style enriched context, sent once per HTTP batch. Nearly
     * everything here is cached at init; volatile fields (orientation,
     * battery, free memory/storage, in-foreground state) are refetched.
     *
     * Mirrors iOS `DeviceInfo.enrichedContext()` and the backend's
     * `EnrichedContext` shape per AGENT_BRIEFING.md §4.
     */
    fun enrichedContext(): EnrichedContext {
        val display = currentDisplaySize()
        val orientation = currentOrientation(display.first, display.second)
        val battery = readBattery()
        val freeStorage = readFreeStorage()
        val freeMemory = readFreeMemoryMb()

        val deviceCtx = EnrichedContext.DeviceContext(
            family = familyString,
            model = rawModel,
            brand = brand,
            type = if (isTablet()) "tablet" else "phone",
            screenWidthPx = display.first,
            screenHeightPx = display.second,
            screenDensity = readScreenDensity(),
            orientation = orientation,
            deviceHash = deviceHashHex,
            deviceClass = deviceClassWireValue,
            kernelVersion = kernelVersion,
            bootTime = bootTimeIso,
            isSimulator = isEmulator,
        )

        val osCtx = EnrichedContext.OSContext(
            name = "Android",
            version = osVersionString(),
            build = osBuildDisplay,
            isRooted = isRooted,
        )

        val runtimeCtx = EnrichedContext.RuntimeContext(
            language = Locale.getDefault().language ?: "en",
            languages = preferredLanguages(),
            timezone = TimeZone.getDefault().id ?: "UTC",
        )

        val hardwareCtx = EnrichedContext.HardwareContext(
            memoryGb = (totalMemoryBytes / (1024L * 1024L * 1024L)).toInt(),
            cpuCores = cpuCores,
            // Android does not expose a max-touch-points API. 5 mirrors
            // iOS and is the practical capacitive-screen ceiling on
            // commodity hardware. Foldables / devkits with more do
            // exist but downstream analytics consumes this as
            // "phone vs tablet vs desktop"-grade granularity.
            maxTouchPoints = 5,
            connectionType = currentConnectionType(),
            connectionDownlink = null, // available on web only
            freeMemory = freeMemory,
            usableMemory = if (totalMemoryBytes > 0) {
                totalMemoryBytes.toDouble() / (1024.0 * 1024.0)
            } else null,
            batteryLevel = battery?.first,
            batteryTemperature = readBatteryTemperatureC(),
            isCharging = battery?.second,
            processorCount = cpuCores,
            freeStorage = freeStorage,
            storageSize = storageSizeGb,
            archs = supportedAbis,
            brand = brand,
            manufacturer = brand,
            screenDpi = screenDpi,
            lowMemory = isLowMemory(),
            thermalState = currentThermalState(),
            // Carrier mirrors per-event: null on Android by default.
            carrier = null,
        )

        val appCtx = EnrichedContext.AppContext(
            version = appVersion.first,
            build = appVersion.second,
            bundleId = packageName,
            name = appLabel,
            buildType = buildType,
            startTime = sdkStartTime,
            // Foreground state is best-effort; we don't pull
            // ProcessLifecycleOwner here to avoid a dependency on
            // Agent 7 (lifecycle). Agent 7 / facade can override
            // this in their context-augmentation step.
            inForeground = null,
        )

        val cultureCtx = EnrichedContext.CultureContext(
            locale = currentLocaleTag(),
            calendar = java.util.Calendar.getInstance().toString().substringBefore('['),
            uses24hFormat = uses24HourFormat(),
            region = currentRegion(),
        )

        return EnrichedContext(
            device = deviceCtx,
            os = osCtx,
            browser = null,
            runtime = runtimeCtx,
            hardware = hardwareCtx,
            app = appCtx,
            culture = cultureCtx,
        )
    }

    // ──────────────────────────────────────────────────────────────
    // Volatile probes.
    //
    // These are called per-event (battery, connection) or per-batch
    // (orientation, free memory). All wrapped in try/catch per R6.
    // ──────────────────────────────────────────────────────────────

    /**
     * Returns `(width_px, height_px)` for the primary display. We
     * read from [WindowManager.getDefaultDisplay] (deprecated post-30
     * but still valid; the new `WindowMetrics` API requires Activity
     * context that we don't have here). Falls back to the resources
     * Configuration if WindowManager is unavailable.
     */
    private fun currentDisplaySize(): Pair<Int, Int> {
        try {
            val wm = safeService<WindowManager>(Context.WINDOW_SERVICE)
            if (wm != null) {
                @Suppress("DEPRECATION")
                val display = wm.defaultDisplay
                if (display != null) {
                    val dm = DisplayMetrics()
                    @Suppress("DEPRECATION")
                    display.getRealMetrics(dm)
                    if (dm.widthPixels > 0 && dm.heightPixels > 0) {
                        return dm.widthPixels to dm.heightPixels
                    }
                }
            }
        } catch (t: Throwable) {
            // fall through
        }
        // Resources fallback — values are in dp via Configuration; we
        // multiply by density to recover px.
        return try {
            val cfg = appContext.resources.configuration
            val density = appContext.resources.displayMetrics.density.coerceAtLeast(1f)
            (cfg.screenWidthDp * density).toInt() to
                    (cfg.screenHeightDp * density).toInt()
        } catch (t: Throwable) {
            0 to 0
        }
    }

    /** Logical density (1.0 / 1.5 / 2.0 / 3.0 / …). */
    private fun readScreenDensity(): Double {
        return try {
            appContext.resources.displayMetrics.density.toDouble().coerceAtLeast(1.0)
        } catch (t: Throwable) {
            1.0
        }
    }

    /** DPI integer, captured at init. */
    private fun readScreenDpi(): Int {
        return try {
            appContext.resources.displayMetrics.densityDpi
        } catch (t: Throwable) {
            DisplayMetrics.DENSITY_DEFAULT
        }
    }

    /** "portrait" / "landscape" derived from runtime orientation. */
    private fun currentOrientation(widthPx: Int, heightPx: Int): String {
        return try {
            when (appContext.resources.configuration.orientation) {
                Configuration.ORIENTATION_LANDSCAPE -> "landscape"
                Configuration.ORIENTATION_PORTRAIT -> "portrait"
                else -> if (widthPx > heightPx) "landscape" else "portrait"
            }
        } catch (t: Throwable) {
            if (widthPx > heightPx) "landscape" else "portrait"
        }
    }

    /**
     * Read battery state via the sticky [Intent.ACTION_BATTERY_CHANGED]
     * broadcast. No permission required and no IPC overhead — the
     * sticky intent is cached by the OS.
     *
     * Returns `(level0to1, isCharging)` or null if the broadcast was
     * unavailable (rare; happens on emulators with no battery sim).
     */
    private fun readBattery(): Pair<Float, Boolean>? {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent: Intent? = appContext.registerReceiver(null, filter)
            if (intent == null) return null
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
            val pct = if (level >= 0 && scale > 0) {
                (level.toFloat() / scale.toFloat()).coerceIn(0f, 1f)
            } else null
            val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            if (pct == null) null else pct to charging
        } catch (t: Throwable) {
            null
        }
    }

    /** Battery temperature in °C (sticky broadcast extra is tenths of °C). */
    private fun readBatteryTemperatureC(): Float? {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent: Intent? = appContext.registerReceiver(null, filter)
            val tenths = intent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
            if (tenths > 0) tenths / 10f else null
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * Connection type via [ConnectivityManager.getNetworkCapabilities].
     * We use the modern API (24+) — older `activeNetworkInfo` is
     * deprecated and unreliable on newer OS versions.
     *
     * Returns "wifi" / "cellular" / "ethernet" / "vpn" / "none" or
     * null if the probe failed entirely.
     */
    private fun currentConnectionType(): String? {
        return try {
            val cm = safeService<ConnectivityManager>(Context.CONNECTIVITY_SERVICE)
                ?: return null
            val net = cm.activeNetwork ?: return "none"
            val caps = cm.getNetworkCapabilities(net) ?: return "none"
            when {
                caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> "vpn"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "wifi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "cellular"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH) -> "bluetooth"
                else -> "unknown"
            }
        } catch (t: Throwable) {
            null
        }
    }

    /** Free memory in MB from ActivityManager.MemoryInfo.availMem. */
    private fun readFreeMemoryMb(): Double? {
        return try {
            val am = safeService<ActivityManager>(Context.ACTIVITY_SERVICE) ?: return null
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            info.availMem.toDouble() / (1024.0 * 1024.0)
        } catch (t: Throwable) {
            null
        }
    }

    /** True if the system is reporting low memory. */
    private fun isLowMemory(): Boolean? {
        return try {
            val am = safeService<ActivityManager>(Context.ACTIVITY_SERVICE) ?: return null
            val info = ActivityManager.MemoryInfo()
            am.getMemoryInfo(info)
            info.lowMemory
        } catch (t: Throwable) {
            null
        }
    }

    /** Free storage on the data partition in GB. */
    private fun readFreeStorage(): Double? {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val freeBytes = stat.availableBytes
            freeBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        } catch (t: Throwable) {
            null
        }
    }

    /** Total storage on the data partition in GB. Cached at init. */
    private fun readStorageSize(): Double? {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val totalBytes = stat.totalBytes
            totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * Coarse thermal state. Available since API 29 via PowerManager;
     * earlier versions return null. We map `THERMAL_STATUS_*` to the
     * iOS thermal-state vocabulary so analytics queries can JOIN
     * cross-platform without translation.
     */
    private fun currentThermalState(): String? {
        return try {
            if (Build.VERSION.SDK_INT < 29) return null
            val pm = safeService<PowerManager>(Context.POWER_SERVICE) ?: return null
            when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "nominal"
                PowerManager.THERMAL_STATUS_LIGHT -> "fair"
                PowerManager.THERMAL_STATUS_MODERATE -> "fair"
                PowerManager.THERMAL_STATUS_SEVERE -> "serious"
                PowerManager.THERMAL_STATUS_CRITICAL -> "critical"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "critical"
                PowerManager.THERMAL_STATUS_SHUTDOWN -> "critical"
                else -> null
            }
        } catch (t: Throwable) {
            null
        }
    }

    /** OS version string. RELEASE is "14", "15", etc. */
    private fun osVersionString(): String =
        Build.VERSION.RELEASE ?: Build.VERSION.SDK_INT.toString()

    /** BCP-47-ish locale tag, e.g. "en_US". */
    private fun currentLocaleTag(): String {
        return try {
            Locale.getDefault().toString().ifEmpty { "en_US" }
        } catch (t: Throwable) {
            "en_US"
        }
    }

    /** ISO-3166 region code, or null if not resolvable. */
    private fun currentRegion(): String? {
        return try {
            Locale.getDefault().country?.takeIf { it.isNotBlank() }
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * Preferred languages list. On API 24+ we use [LocaleList.getAdjustedDefault]
     * for the user's full preference order; on lower versions just
     * the default singleton.
     */
    private fun preferredLanguages(): List<String> {
        return try {
            if (Build.VERSION.SDK_INT >= 24) {
                val list = android.os.LocaleList.getAdjustedDefault()
                val out = ArrayList<String>(list.size())
                for (i in 0 until list.size()) {
                    val lang = list[i].toLanguageTag()
                    if (lang.isNotBlank()) out.add(lang)
                }
                if (out.isEmpty()) listOf(Locale.getDefault().toLanguageTag()) else out
            } else {
                listOf(Locale.getDefault().toLanguageTag())
            }
        } catch (t: Throwable) {
            listOf("en")
        }
    }

    /** True if the device's smallest dimension is ≥600dp (Android tablet heuristic). */
    private fun isTablet(): Boolean {
        return try {
            appContext.resources.configuration.smallestScreenWidthDp >= 600
        } catch (t: Throwable) {
            false
        }
    }

    /** Locale-driven 24-hour clock probe. */
    private fun uses24HourFormat(): Boolean {
        return try {
            android.text.format.DateFormat.is24HourFormat(appContext)
        } catch (t: Throwable) {
            false
        }
    }

    // ──────────────────────────────────────────────────────────────
    // One-off init helpers.
    // ──────────────────────────────────────────────────────────────

    /**
     * Read app versionName/versionCode, surviving Tiramisu's
     * `getPackageInfo` overload split. We never throw — bad app meta
     * shouldn't crash the host (R6).
     */
    private fun readAppVersion(): Pair<String, String> {
        return try {
            val pm = appContext.packageManager
            @Suppress("DEPRECATION")
            val info: PackageInfo = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0))
            } else {
                pm.getPackageInfo(packageName, 0)
            }
            val name = info.versionName ?: "0.0.0"
            val code = if (Build.VERSION.SDK_INT >= 28) {
                info.longVersionCode.toString()
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toString()
            }
            name to code
        } catch (t: Throwable) {
            "0.0.0" to "0"
        }
    }

    /**
     * Coarse device hash. SHA-256(brand + model + primary_abi). NOT a
     * stable hardware id — every Pixel 8 worldwide produces the same
     * hash. Used for crude device-shape pivots in analytics.
     *
     * R10: this is intentionally NOT derived from MAC / IMEI / SIM /
     * SerialNumber — those are Play-policy-restricted identifiers we
     * deliberately don't access.
     */
    private fun computeDeviceHash(): String? {
        return try {
            val primaryAbi = supportedAbis.firstOrNull() ?: "unknown"
            val seed = "$brand-$rawModel-$primaryAbi"
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(seed.toByteArray(Charsets.UTF_8))
            digest.joinToString(separator = "") { byte ->
                ((byte.toInt() and 0xFF).toString(16).padStart(2, '0'))
            }
        } catch (t: Throwable) {
            null
        }
    }

    /**
     * Best-effort emulator detection. Mirrors the iOS
     * `targetEnvironment(simulator)` macro by sniffing build
     * fingerprints associated with the Android Emulator + Genymotion +
     * Bluestacks. Not foolproof but a strong signal.
     */
    private fun detectEmulator(): Boolean {
        val fp = (Build.FINGERPRINT ?: "").lowercase()
        val product = (Build.PRODUCT ?: "").lowercase()
        val model = (Build.MODEL ?: "").lowercase()
        val brand = (Build.BRAND ?: "").lowercase()
        val device = (Build.DEVICE ?: "").lowercase()
        val hardware = (Build.HARDWARE ?: "").lowercase()
        return fp.startsWith("generic") ||
                fp.startsWith("unknown") ||
                fp.contains("vbox") ||
                fp.contains("test-keys") ||
                model.contains("google_sdk") ||
                model.contains("emulator") ||
                model.contains("android sdk built for") ||
                brand.startsWith("generic") ||
                device.contains("generic") ||
                hardware == "goldfish" ||
                hardware == "ranchu" ||
                product.contains("sdk_gphone") ||
                product == "google_sdk" ||
                product == "sdk" ||
                product == "sdk_x86" ||
                product == "vbox86p"
    }

    /**
     * Best-effort root detection. Same spirit as iOS's
     * `isJailbroken()`: we look for known indicators (Magisk / SuperSU
     * binaries, su in the path, /system writability). Never definitive,
     * but strong enough to surface "this device might be rooted" in
     * dashboards.
     */
    private fun detectRoot(): Boolean {
        // Check for su binaries.
        val suPaths = arrayOf(
            "/system/bin/su",
            "/system/xbin/su",
            "/sbin/su",
            "/system/su",
            "/system/bin/.ext/.su",
            "/system/etc/init.d/99SuperSUDaemon",
            "/dev/com.koushikdutta.superuser.daemon/",
            "/system/app/Superuser.apk",
            "/system/app/SuperSU.apk",
            "/data/adb/magisk",
        )
        for (p in suPaths) {
            try {
                if (File(p).exists()) return true
            } catch (_: Throwable) {
                // ignore — best-effort
            }
        }

        // Build tags include "test-keys" on dev/userdebug builds —
        // a coarse but well-known signal.
        if ((Build.TAGS ?: "").contains("test-keys")) return true

        return false
    }

    // ──────────────────────────────────────────────────────────────
    // Misc helpers.
    // ──────────────────────────────────────────────────────────────

    /**
     * Convenience — typed system-service lookup that swallows
     * `getSystemService`'s nullability + cast pitfalls.
     */
    @Suppress("UNCHECKED_CAST")
    private fun <T> safeService(name: String): T? {
        return try {
            appContext.getSystemService(name) as? T
        } catch (t: Throwable) {
            null
        }
    }
}
