package io.kixo.sdk.internal.replay

import android.os.SystemClock

/**
 * One-slot thread-safe holder for the most-recent captured frame.
 *
 * **Why one slot, not many** (mirrors iOS [RingBuffer.swift] doc):
 *  - Replay's "pre-tap" semantic only needs "the last frame that
 *    isn't stale." Keeping more frames means higher peak memory
 *    (each `Bitmap` at 1080×2400 ARGB_8888 ≈ 10 MB pre-encode).
 *  - Older frames pre-date the user's last meaningful UI change and
 *    are misleading anyway — we want the frame closest to the tap,
 *    period.
 *  - Encoder back-pressure becomes a real concern as the buffer
 *    grows.
 *
 * **Threading model:**
 *  - Producer (main thread): [FrameSnapshotter] writes via [set]
 *    after layout-settled callbacks (`View.OnLayoutChangeListener`,
 *    keyboard-shown, scroll-end).
 *  - Consumer (main thread): [ReplayController.handleTap] reads via
 *    [peek] / [take] inside its tap pipeline.
 *
 * Both operations are main-thread today. We still synchronise on
 * `lock` because (a) v1.1 may move the encoder to a background
 * dispatcher and (b) the cost of a JVM monitor on the uncontested
 * path is negligible.
 *
 * **Memory safety.** [set] drops the previous bitmap reference
 * synchronously, so the prior frame becomes eligible for GC + native
 * Bitmap-pixel free as soon as no consumer is iterating on it. When
 * memory pressure arrives Agent 7's [MemoryPressure.CRITICAL] flow
 * triggers [ReplayController]'s tightening path which calls [take]
 * to drop the held bitmap immediately.
 *
 * @param T Pulled out of the iOS `RawFrame` for genericity — Android
 *   stores either an [android.graphics.Bitmap] (for the legacy
 *   single-frame path) or a richer `RawFrame` once the pipeline
 *   formalises tile + structural sidecars. Keep generic so the
 *   [Sampler] / unit tests can drive with primitive types.
 */
internal class RingBuffer<T : Any> {

    private val lock = Any()
    private var slot: T? = null

    /**
     * Wall-clock ms of the last [set]. Read by [hasFreshFrame] to
     * decide if the held frame is "still good enough" for the next
     * tap. Uses [SystemClock.elapsedRealtime] (not
     * `System.currentTimeMillis`) because we care about elapsed
     * duration, not wall-clock — system clock skew during a session
     * (NTP correction, manual adjustment) would otherwise make a
     * fresh frame look stale.
     */
    @Volatile
    private var lastSetElapsedMs: Long = 0L

    /**
     * Atomically replace the held value. The previous value's native
     * resources (e.g. `Bitmap` pixel buffer) become eligible for
     * release as soon as no other reference is held.
     */
    fun set(value: T) {
        synchronized(lock) {
            slot = value
            lastSetElapsedMs = SystemClock.elapsedRealtime()
        }
    }

    /**
     * Atomically read the held value without removing it. Used by the
     * tap interceptor — we keep the value in the slot so a SECOND
     * tap that follows in the same Choreographer tick can read the
     * same pre-image (the same pre-image is correct for both).
     */
    fun peek(): T? = synchronized(lock) { slot }

    /**
     * Atomically read AND clear. Used when the held value is
     * confirmed stale (e.g. on session end, on memory warning).
     */
    fun take(): T? = synchronized(lock) {
        val v = slot
        slot = null
        v
    }

    /**
     * Whether the slot currently holds a value whose [set] timestamp
     * is no older than [maxAgeMs] elapsed ms. Used by the tap path
     * to decide whether to take a synchronous emergency snapshot
     * (which is more expensive than a debounced layout-driven one).
     *
     * @param now Override for tests — defaults to live elapsed clock.
     */
    fun hasFreshFrame(
        maxAgeMs: Long,
        now: Long = SystemClock.elapsedRealtime(),
    ): Boolean = synchronized(lock) {
        if (slot == null) return@synchronized false
        (now - lastSetElapsedMs) <= maxAgeMs
    }
}
