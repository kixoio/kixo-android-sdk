package io.kixo.sdk.internal.replay.upload

/**
 * Per-frame upload kind. The four values are deliberately named to
 * match the wire-format `kind` field that the backend's
 * `/api/sdk/replay/frames/sign` endpoint expects (see iOS
 * `SignedURLClient.SignedURL.kind` — `"pre" | "post" | "structural"
 * | "ocr"`). Renaming any value here is a wire-format break.
 *
 * Why an enum vs a `String` constant set:
 *  - Compile-time exhaustive `when` over [FrameKind] so a future
 *    "video" or "audio" addition forces every call site to declare
 *    its handling.
 *  - Pool bookkeeping in [SignedUrlPool] indexes by `(seq, kind)`;
 *    the enum gives `EnumMap` a stable hash without boxing strings.
 *  - The iOS counterpart uses raw strings because Swift dictionaries
 *    have no enum-key advantage; on Kotlin/JVM we get cheaper maps
 *    + the safety, so it's free.
 *
 * **Default mime + extension** is exposed here (not at the encoder)
 * so [UploadWorker] can pull both the `Content-Type` header and the
 * cache-file extension from the same source-of-truth — diverging
 * the two has bitten the iOS SDK twice (HEIC files written with
 * `.jpg` extension caused player-side decode failures).
 */
internal enum class FrameKind(
    /** Wire-format `kind` string. Matches backend's signing route. */
    val wire: String,
    /** MIME type for the GCS PUT `Content-Type` header. */
    val contentType: String,
    /** File extension for the local staging-cache filename. */
    val fileExtension: String,
) {
    /** Pre-tap raster (frame BEFORE the user touched the screen). */
    PRE(wire = "pre", contentType = "image/jpeg", fileExtension = "jpg"),

    /** Post-tap raster (frame AFTER the tap settled). */
    POST(wire = "post", contentType = "image/jpeg", fileExtension = "jpg"),

    /** Structural snapshot — JSON tree of view roles + bounds. May be gzipped. */
    STRUCTURAL(wire = "structural", contentType = "application/json", fileExtension = "json"),

    /** Canonical OCR text extracted from the post-tap frame. */
    OCR(wire = "ocr", contentType = "text/plain; charset=utf-8", fileExtension = "txt"),
    ;

    companion object {
        /**
         * Resolve the wire string back to an enum, returning `null`
         * for unknown values. Used when re-hydrating signed URLs the
         * backend issued in [SignedUrlClient.SignedUrl.kind].
         *
         * Defensive: a future server-side addition (`"video"`) lands
         * before the SDK is updated; we drop the URL silently rather
         * than crashing the host app (briefing R6).
         */
        fun fromWire(wire: String): FrameKind? = entries.firstOrNull { it.wire == wire }
    }
}
