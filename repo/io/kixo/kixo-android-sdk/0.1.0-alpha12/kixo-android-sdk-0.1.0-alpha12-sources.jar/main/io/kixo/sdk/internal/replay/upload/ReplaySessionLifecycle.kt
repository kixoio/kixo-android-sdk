package io.kixo.sdk.internal.replay.upload

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import okhttp3.OkHttpClient
import java.time.Instant
import java.time.format.DateTimeFormatter

/**
 * Owns the lifecycle of a single replay session: open → seal.
 * Wraps:
 *   - [SignedUrlClient] for the start/end RPCs
 *   - [SignedUrlPool] for the per-frame URL leases
 *   - [ReplayEventBatcher] for the per-tap metadata stream
 *   - [ReplayUploader] for the orchestration
 *
 * Called by Agent 13's ReplayController. The controller decides
 * WHEN a session opens (sample-rate hit, rage-click trigger,
 * crash trigger); this class executes the open/close mechanics.
 *
 * **Crash defence:** writes session metadata to SharedPreferences
 * the moment a session opens. On the NEXT launch, [recoverFromCrash]
 * checks for any orphaned sessions (process killed before
 * session/end fired) and posts a session/end with reason
 * `app_terminated` so the backend doesn't sit with a "live · 0"
 * row. The backend ALSO has a 30-min idle-sweep cron as a
 * defence-in-depth fallback (see iOS C.4 phantom-session fix
 * lesson) — both layers help.
 *
 * **Why SharedPreferences not SQLite:** session metadata is small
 * (one row, < 200 bytes) and we need it durable past a force-kill.
 * SharedPreferences's commit semantics fit perfectly; spinning up
 * a SQLite db just for one row is overkill and adds a dependency
 * on Agent 3's storage helper.
 */
internal class ReplaySessionLifecycle(
    private val context: Context,
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val captureOnCellular: Boolean,
) {

    private val prefs: SharedPreferences by lazy {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    @Volatile private var current: Active? = null

    /**
     * Active session bundle exposed to [ReplayUploader] via
     * [activeUploader]. Null when no session is open.
     */
    private data class Active(
        val sessionId: String,
        val startedAt: Instant,
        val client: SignedUrlClient,
        val pool: SignedUrlPool,
        val batcher: ReplayEventBatcher,
        val uploader: ReplayUploader,
        val metadataOnly: Boolean,
        val metadataOnlyReason: String?,
    )

    /** The currently-active uploader, or null when no session is open. */
    fun activeUploader(): ReplayUploader? = current?.uploader

    /** True when the active session is in metadata-only mode (server quota). */
    fun metadataOnly(): Boolean = current?.metadataOnly == true

    /** Optional reason string the backend returned with metadata_only. */
    fun metadataOnlyReason(): String? = current?.metadataOnlyReason

    /**
     * Open a new replay session. Returns true on success (the
     * uploader is now ready for [ReplayUploader.uploadFrame] calls);
     * false on failure (network or server error — caller backs off).
     *
     * **Idempotency:** opening a second session while one is live
     * seals the first with reason `superseded` then opens the new
     * one. Caller should normally not do this — but a misbehaving
     * controller shouldn't strand state.
     */
    suspend fun openSession(
        sessionId: String,
        installationId: String,
        userId: String?,
        releaseId: String,
        triggers: List<String>,
        region: String,
        flags: Map<String, Boolean>? = null,
    ): Boolean {
        // Seal any leftover live session before opening a new one.
        if (current != null) {
            closeSession(EndReason.SUPERSEDED)
        }

        val startedAt = Instant.now()
        val client = SignedUrlClient(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
        )

        val response = client.startSession(
            sessionId = sessionId,
            installationId = installationId,
            userId = userId,
            releaseId = releaseId,
            startedAtIso = ISO.format(startedAt),
            triggers = triggers,
            region = region,
            initialUrlCount = 8,
            flags = flags,
        )
        if (response == null) {
            // /session/start failed. Nothing to clean up — the
            // controller will retry on its own backoff.
            Log.d(TAG, "openSession: server start failed for $sessionId")
            return false
        }

        // Persist the open session to SharedPreferences so the
        // next launch can detect a crash and seal it server-side.
        persistSession(sessionId, response.sessionId, startedAt)

        val pool = SignedUrlPool(
            client = client,
            sessionId = response.sessionId,
        )
        pool.seed(response.signedUrls)

        val batcher = ReplayEventBatcher(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
            sessionId = response.sessionId,
        ).apply { start() }

        val uploader = ReplayUploader(
            context = context,
            pool = pool,
            eventBatcher = batcher,
            sessionId = response.sessionId,
            captureOnCellular = captureOnCellular,
            metadataOnly = response.metadataOnly,
        )

        current = Active(
            sessionId = response.sessionId,
            startedAt = startedAt,
            client = client,
            pool = pool,
            batcher = batcher,
            uploader = uploader,
            metadataOnly = response.metadataOnly,
            metadataOnlyReason = response.metadataOnlyReason,
        )
        return true
    }

    /**
     * Seal the currently-open session. Drains the event batcher,
     * cancels any outstanding upload work, posts session/end, and
     * removes the SharedPreferences entry. No-op if no session is
     * open.
     */
    suspend fun closeSession(reason: EndReason) {
        val active = current ?: return
        current = null

        // 1. Drain the event batcher (its stop() does final flush).
        try { active.batcher.stop() } catch (t: Throwable) { Log.d(TAG, "batcher.stop threw", t) }

        // 2. Tell the backend the session is sealed. Best-effort —
        //    the 30-min idle-sweep cron will catch us if the call
        //    fails AND the next launch's crash recovery doesn't
        //    pick it up.
        val endedAt = Instant.now()
        try {
            active.client.endSession(
                sessionId = active.sessionId,
                endedAtIso = ISO.format(endedAt),
                frameCount = active.uploader.stagedFrameCount(),
                totalBytes = active.uploader.totalStagedBytes(),
                endReason = reason.wire,
            )
        } catch (t: Throwable) {
            Log.d(TAG, "endSession threw", t)
        }

        // 3. Cancel any outstanding upload work for this session.
        //    We don't WAIT for it — already-in-flight PUTs go
        //    through; queued ones get cancelled. The backend will
        //    receive late-arriving frames after `sealed=true` and
        //    accept them up to the retention boundary.
        active.uploader.cancelPendingUploads()

        // 4. Drop signed URLs we never used.
        try { active.pool.clear() } catch (t: Throwable) { Log.d(TAG, "pool.clear threw", t) }

        // 5. Wipe the persisted recovery breadcrumb.
        clearPersistedSession()
    }

    /**
     * On launch, check for a session that was open when the process
     * died and ship a session/end so the dashboard doesn't see a
     * "live · 0" row sitting forever. Mirrors the iOS C.4 phantom-
     * session fix.
     *
     * Returns the `session_id` we recovered (for diagnostics) or
     * null if there was nothing to recover.
     */
    suspend fun recoverFromCrash(): String? {
        val crashedSessionId = prefs.getString(KEY_OPEN_SESSION_ID, null) ?: return null
        Log.d(TAG, "Recovering crashed session $crashedSessionId")
        // Build a transient client just to ship the end RPC — the
        // pool / uploader / batcher are gone with the previous
        // process and we don't have the staged frame count.
        val client = SignedUrlClient(
            httpClient = httpClient,
            baseUrl = baseUrl,
            projectId = projectId,
            apiKey = apiKey,
        )
        try {
            client.endSession(
                sessionId = crashedSessionId,
                endedAtIso = ISO.format(Instant.now()),
                frameCount = 0,
                totalBytes = 0L,
                endReason = EndReason.APP_TERMINATED.wire,
            )
        } catch (t: Throwable) {
            // Network failure — the backend's idle-sweep will catch it.
            Log.d(TAG, "Crash-recovery end-session threw", t)
        }
        clearPersistedSession()
        return crashedSessionId
    }

    private fun persistSession(originalId: String, returnedId: String, startedAt: Instant) {
        try {
            prefs.edit()
                .putString(KEY_OPEN_SESSION_ID, returnedId)
                .putString(KEY_ORIGINAL_SESSION_ID, originalId)
                .putString(KEY_STARTED_AT, ISO.format(startedAt))
                .apply()
        } catch (t: Throwable) {
            Log.d(TAG, "persistSession threw", t)
        }
    }

    private fun clearPersistedSession() {
        try {
            prefs.edit()
                .remove(KEY_OPEN_SESSION_ID)
                .remove(KEY_ORIGINAL_SESSION_ID)
                .remove(KEY_STARTED_AT)
                .apply()
        } catch (t: Throwable) {
            Log.d(TAG, "clearPersistedSession threw", t)
        }
    }

    /**
     * Reasons we send to `/api/sdk/replay/session/end` — mirror
     * the iOS catalog. Backend dashboards group sessions by reason
     * for ops insight.
     */
    enum class EndReason(val wire: String) {
        FOREGROUND_TO_BACKGROUND("foreground_to_background"),
        APP_TERMINATED("app_terminated"),
        EXPLICIT_OPT_OUT("explicit_opt_out"),
        TIMEOUT("timeout"),
        LOW_MEMORY("low_memory"),
        SUPERSEDED("superseded"),
    }

    companion object {
        private const val PREFS_NAME = "io.kixo.sdk.replay.lifecycle"
        private const val KEY_OPEN_SESSION_ID = "open_session_id"
        private const val KEY_ORIGINAL_SESSION_ID = "original_session_id"
        private const val KEY_STARTED_AT = "started_at"

        private val ISO: DateTimeFormatter = DateTimeFormatter.ISO_INSTANT

        private const val TAG = "Kixo.ReplaySessionLifecycle"
    }
}
