package io.kixo.sdk.internal.replay

import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.SurfaceView
import android.view.PixelCopy
import android.view.Window
import android.os.Handler

/**
 * Renders an Activity's `decorView` (or any other [View]) into a
 * `Bitmap` for the replay upload pipeline. Mirrors iOS
 * [FrameSnapshotter.swift] semantics adapted to Android's two
 * available capture paths.
 *
 * **Two capture paths, one default:**
 *
 *  1. **`View.draw(Canvas)` against an offscreen `Bitmap`** —
 *     synchronous, blocks the main thread for ~3-5 ms on a
 *     1080×2400 hierarchy. THIS is the default. The iOS counterpart
 *     uses `UIGraphicsImageRenderer.image { drawHierarchy(...) }`
 *     which is the ~equivalent main-thread synchronous call.
 *
 *  2. **`PixelCopy.request(Window, Bitmap, callback)`** — async,
 *     reads the actual pixel-on-screen via the surface compositor.
 *     Required when a `SurfaceView` / `TextureView` / `GLSurfaceView`
 *     is in the hierarchy because `View.draw()` does NOT include
 *     surface buffers (they're composited at a different layer).
 *     We fall back to PixelCopy when [containsSurfaceView] returns
 *     `true`. Cost is similar (~5-15 ms) but comes back via callback
 *     so it doesn't block main.
 *
 * **Why not use PixelCopy unconditionally?** Some pre-Android-10
 * devices have buggy implementations that return all-black bitmaps
 * for ordinary View hierarchies. The `View.draw()` path works
 * everywhere from API 24 up. We pay the SurfaceView cost only when
 * we have to.
 *
 * **Output downscaling.** We render at 1.0× (the View's natural
 * pixel density) to keep the bitmap small. Scale is the upload
 * pipeline's concern (Agent 14) — the snapshotter's job is to
 * produce a faithful raster. Mirror iOS's "render then encode"
 * separation.
 *
 * **Thread.** Both paths require the main thread to read the
 * View's bounds + start the draw. PixelCopy completes off-main via
 * its [Handler]; the synchronous path returns the bitmap directly.
 */
internal object FrameSnapshotter {

    /**
     * Synchronous bitmap snapshot of [view]. Returns `null` when:
     *  - the View has zero bounds (off-screen / not laid out);
     *  - the bitmap allocation fails (OOM — host is in trouble);
     *  - `View.draw()` throws (rare; usually a custom view's
     *    `onDraw` mis-handles its `Canvas` save/restore).
     *
     * **MUST be called on the main thread** — `View.getWidth/Height`
     * + `View.draw(Canvas)` are not thread-safe.
     */
    fun snapshot(view: View): Bitmap? {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            Log.w(TAG, "snapshot called off-main; refusing")
            return null
        }
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) return null

        // Wave 5 (Critic 2): pool ARGB_8888 bitmaps so we don't pay
        // the 10 MB allocation per tap. The pool is keyed by exact
        // (width, height) so rotation / split-screen / multi-window
        // each get their own slot. Cap is 2 — one we're drawing into
        // + one the encoder is currently consuming. Anything beyond
        // that is OOM territory anyway.
        val bitmap = BitmapPool.acquireOrAlloc(width, height)
            ?: run {
                Log.w(TAG, "bitmap alloc OOM (${width}x${height})")
                return null
            }
        // Reused bitmaps may have stale pixels from a prior frame —
        // erase to full transparency before drawing so any window
        // chrome with alpha doesn't composite on top of garbage.
        bitmap.eraseColor(0)

        return try {
            val canvas = Canvas(bitmap)
            view.draw(canvas)
            bitmap
        } catch (t: Throwable) {
            Log.w(TAG, "view.draw failed", t)
            // Return to pool rather than recycle on the failure path —
            // the pool's recycle policy decides when to evict.
            BitmapPool.release(bitmap)
            null
        }
    }

    /**
     * Return a no-longer-needed bitmap to the pool. Caller must NOT
     * touch the bitmap after this; the pool is allowed to overwrite
     * pixels on the next acquire.
     *
     * Kept on [FrameSnapshotter] (not [BitmapPool] directly) so the
     * release pipeline doesn't import an internal type for what is
     * conceptually a snapshotter contract.
     */
    fun release(bitmap: Bitmap?) {
        BitmapPool.release(bitmap)
    }

    /**
     * Async PixelCopy snapshot for hierarchies that include a
     * SurfaceView / TextureView / GLSurfaceView. Use [snapshot] for
     * ordinary hierarchies — this is slower per call.
     *
     * Caller supplies the [callback] which is invoked on the supplied
     * [callbackHandler]'s thread (typically a background executor
     * the [ReplayController] owns). Bitmap may be `null` on
     * PixelCopy failure (transient surface buffer not ready).
     */
    fun snapshotViaPixelCopy(
        window: Window,
        callbackHandler: Handler,
        callback: (Bitmap?) -> Unit,
    ) {
        val view = window.decorView
        val width = view.width
        val height = view.height
        if (width <= 0 || height <= 0) {
            callback(null)
            return
        }
        val bitmap: Bitmap = try {
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        } catch (oom: OutOfMemoryError) {
            Log.w(TAG, "PixelCopy bitmap alloc OOM (${width}x${height})")
            callback(null)
            return
        }
        try {
            PixelCopy.request(
                window,
                bitmap,
                { result ->
                    if (result == PixelCopy.SUCCESS) {
                        callback(bitmap)
                    } else {
                        Log.w(TAG, "PixelCopy result=$result")
                        bitmap.recycle()
                        callback(null)
                    }
                },
                callbackHandler,
            )
        } catch (t: Throwable) {
            Log.w(TAG, "PixelCopy.request failed", t)
            bitmap.recycle()
            callback(null)
        }
    }

    /**
     * Whether the supplied View hierarchy contains any view that
     * needs PixelCopy (SurfaceView / TextureView / GLSurfaceView).
     * Cheap recursive walk; typical hierarchy is 100-200 nodes ≈ 5
     * µs of inspection.
     *
     * Used by [ReplayController.handleTap] to choose between
     * [snapshot] and [snapshotViaPixelCopy].
     */
    fun containsSurfaceView(root: View): Boolean {
        if (root is SurfaceView) return true
        val name = root.javaClass.simpleName
        if (name == "TextureView" || name == "GLSurfaceView") return true
        if (root is android.view.ViewGroup) {
            for (i in 0 until root.childCount) {
                val child = root.getChildAt(i) ?: continue
                if (containsSurfaceView(child)) return true
            }
        }
        return false
    }

    private const val TAG = "Kixo"
}
