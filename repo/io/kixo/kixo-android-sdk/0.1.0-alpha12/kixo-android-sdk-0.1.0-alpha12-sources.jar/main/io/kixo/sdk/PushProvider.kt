package io.kixo.sdk

/**
 * Push notification token provider.
 *
 * Identifies WHICH push transport produced the token passed to
 * [Kixo.setPushToken]. The backend uses this to route delivery
 * (FCM HTTP v1 / HMS / APNs-via-bridge) and to scope token
 * uniqueness — the same device can hold one FCM token AND one HMS
 * token simultaneously on dual-store hardware (Huawei devices that
 * also have Play Services).
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Identity/UserProperties.swift`'s
 * `PushProvider` enum (which has `.apns` and `.firebase`). Android
 * adds [HMS] for Huawei Mobile Services and [APNS] for cross-platform
 * apps that bridge iOS APNs tokens through Android (rare, but
 * frameworks like Capacitor / React-Native-Notifications do this on
 * shared infra).
 *
 * Wire format: the `wireValue` is what lands in the event property
 * `push_provider` and on the `/api/sdk/push/register` body's `provider`
 * field. The backend's push routing layer keys off this exactly.
 *
 * **Default = [FCM]** because the overwhelming majority of Android
 * push deployments use Firebase Cloud Messaging. Apps on Huawei-only
 * builds explicitly pass [HMS].
 */
public enum class PushProvider(public val wireValue: String) {
    /**
     * Firebase Cloud Messaging — Google's standard Android push
     * transport. Default for [Kixo.setPushToken].
     *
     * Wire token: `"fcm"`. The iOS SDK uses `"firebase"` for the same
     * conceptual provider, but the Android wire token is `"fcm"` to
     * stay consistent with the FCM SDK's own naming and the backend's
     * routing logic (which already keys off `"fcm"` for Android
     * delivery).
     */
    FCM("fcm"),

    /**
     * Huawei Mobile Services Push Kit — used on Huawei devices
     * shipped without Google Play Services (post-2019 hardware in
     * markets where Google services are unavailable).
     *
     * The HMS Push SDK exposes a token format compatible with our
     * `/api/sdk/push/register` endpoint; routing on the backend
     * picks the HMS delivery path when `provider == "hms"`.
     */
    HMS("hms"),

    /**
     * Apple Push Notification Service tokens bridged through
     * Android — only relevant for cross-platform frameworks where
     * a single Android binary handles both transports (e.g. an
     * Android-side relay process for a Mac Catalyst app's pushes).
     * Vanishingly rare in practice; included for parity with the
     * iOS SDK's `.apns` constant.
     */
    APNS("apns");

    public companion object {
        /**
         * Parse a wire token back into an enum. Returns null on
         * unknown — caller decides whether to fall back to [FCM] or
         * drop the event. Used by the dashboard SDK round-trip when
         * reading server-stored push metadata.
         *
         * Tolerates the iOS spelling `"firebase"` so a cross-platform
         * dashboard view of token records doesn't break when an iOS-
         * registered token's provider field is read on Android.
         */
        @JvmStatic
        public fun fromWireValue(value: String?): PushProvider? {
            if (value == null) return null
            return when (value.lowercase()) {
                "fcm", "firebase" -> FCM
                "hms", "huawei" -> HMS
                "apns", "apple" -> APNS
                else -> null
            }
        }
    }
}
