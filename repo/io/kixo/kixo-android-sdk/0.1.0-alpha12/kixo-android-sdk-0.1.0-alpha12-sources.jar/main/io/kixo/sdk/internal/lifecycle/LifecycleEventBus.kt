package io.kixo.sdk.internal.lifecycle

import android.util.Log
import io.kixo.sdk.internal.model.KixoEventType
import java.util.concurrent.ConcurrentLinkedQueue

/**
 * Thin indirection between the lifecycle observers and the EventQueue.
 *
 * Why an indirection at all?
 *   - This agent (Agent 7) ships before Agent 5's `EventQueue`, so we
 *     cannot import a concrete enqueue function — that would be a
 *     cross-folder dependency the build briefing forbids ("If you
 *     need a type they haven't built yet, declare a stub interface
 *     in YOUR folder and document the dependency at the top of the
 *     file."). The bus is the stub.
 *   - Even after Agent 5 lands, keeping a single `internal fun emit(...)`
 *     seam means tests for [SessionTracker] / [ProcessLifecycleObserver]
 *     can swap the sink to a recording lambda without spinning up the
 *     real queue + storage + transport stack.
 *
 * Wiring contract: `Kixo.configure()` (Agent 1) is responsible for
 * setting [sink] to the EventQueue's enqueue function once both are
 * initialised. The bus tolerates events fired BEFORE the sink lands by
 * buffering them — see [bindSink] / [pendingBuffer] below (Critic 16
 * fix).
 *
 * Thread safety: [sink] is `@Volatile` so producer/consumer threads
 * see a consistent reference. The sink itself MUST be safe to call
 * from any thread (the EventQueue's `enqueue` is queue-backed by
 * coroutines, so this is satisfied).
 */
internal object LifecycleEventBus {

    private const val TAG = "Kixo"

    /**
     * Cap on [pendingBuffer] — bounded so a host that NEVER calls
     * `Kixo.configure()` (e.g. SDK ContentProvider auto-init fired
     * but the customer wired the integration behind a feature flag
     * that's currently off) doesn't accumulate lifecycle events
     * forever. 100 covers the common cold-start storm
     * (app_launch + app_foreground + session_start + a handful of
     * activity transitions) with a comfortable headroom; FIFO drop
     * matches the rest of the SDK's overflow policy.
     */
    private const val PENDING_BUFFER_CAP: Int = 100

    /**
     * Single sink the rest of the SDK installs via [bindSink]. `null`
     * until Agent 5's `EventQueue` (or a test) wires it.
     *
     * **Don't write to this directly from outside the bus** — use
     * [bindSink] which atomically swaps the sink AND drains the
     * [pendingBuffer]. Direct writes would lose buffered events.
     */
    @Volatile
    var sink: ((LifecycleEvent) -> Unit)? = null
        private set

    /**
     * Pre-bind buffer (Critic 16 HIGH).
     *
     * The lifecycle observers ([ProcessLifecycleObserver] /
     * [SessionTracker] / [ActivityLifecycleObserver]) start firing the
     * moment [KixoInitializerProvider] runs — and that runs from the
     * platform's ContentProvider init phase, BEFORE the host gets to
     * call `Kixo.configure()`. Without buffering, every cold-start
     * `app_launch` / `app_foreground` / `session_start` is silently
     * dropped because [sink] is still `null`. Buffering retains them
     * until [bindSink] arrives and drains them in order.
     *
     * `ConcurrentLinkedQueue` because emits arrive from arbitrary
     * threads (lifecycle observers run on main, but ActivityCallbacks
     * can fire from arbitrary OEM threads). FIFO drop on overflow
     * matches the EventQueue's bounded-everything policy (R4).
     */
    private val pendingBuffer: ConcurrentLinkedQueue<LifecycleEvent> = ConcurrentLinkedQueue()

    /**
     * Bind the live sink AND drain any events that fired pre-bind.
     * Replaces the previous direct `sink = …` assignment so the
     * "events fired before EventQueue wiring" race window is closed
     * (Critic 16 HIGH).
     *
     * The full assign + drain pair runs under `synchronized(this)` so
     * a concurrent [emit] cannot land an event between the sink assign
     * and the drain — without the lock, an emit observing `sink != null`
     * would route past the drained buffer and the drained event from
     * a parallel emit could be re-emitted from the buffer.
     *
     * Replaces the prior sink unconditionally — tests (and a future
     * "reconfigure" path, if it ever lands) can rebind cleanly.
     * Pending events that were buffered against the OLD sink are
     * drained into the NEW one.
     */
    fun bindSink(newSink: (LifecycleEvent) -> Unit) {
        synchronized(this) {
            sink = newSink
            // Drain in arrival order so observers that fired session_start
            // BEFORE app_foreground don't end up reordered downstream.
            while (true) {
                val event = pendingBuffer.poll() ?: break
                try {
                    newSink(event)
                } catch (t: Throwable) {
                    Log.w(TAG, "drain on bindSink threw on ${event.eventName}", t)
                }
            }
        }
    }

    /**
     * Emit a lifecycle event. If a sink is installed, route it
     * directly. If not (cold start before `Kixo.configure()` /
     * `bindSink(…)`), buffer it for later drain by [bindSink].
     *
     * Fast path for the common case (sink installed) — single volatile
     * read + invoke. The synchronized block only fires on the slow
     * path (buffering) so steady-state emits don't pay a lock cost.
     */
    fun emit(event: LifecycleEvent) {
        // Fast path: sink already wired.
        val s = sink
        if (s != null) {
            try {
                s(event)
            } catch (t: Throwable) {
                // Per AGENT_BRIEFING.md R6: never crash the host app from
                // a lifecycle hook. EventQueue enqueue should be infallible
                // but if it isn't, log and continue.
                Log.w(TAG, "lifecycle event sink threw on ${event.eventName}", t)
            }
            return
        }
        // Slow path: buffer until bindSink lands. The synchronized
        // block coordinates with bindSink's drain so we cannot emit-
        // and-buffer between the bind's `sink = …` and its drain loop.
        synchronized(this) {
            // Re-check under the lock — bindSink may have landed in
            // the gap between the volatile read and acquiring the
            // monitor.
            val late = sink
            if (late != null) {
                try {
                    late(event)
                } catch (t: Throwable) {
                    Log.w(TAG, "late-bind sink threw on ${event.eventName}", t)
                }
                return
            }
            // FIFO drop on overflow — matches the EventQueue's bounded
            // policy (R4). A host that never calls configure() can
            // generate arbitrarily many lifecycle events; we hold at
            // most PENDING_BUFFER_CAP before forgetting the oldest.
            while (pendingBuffer.size >= PENDING_BUFFER_CAP) {
                pendingBuffer.poll()
            }
            pendingBuffer.offer(event)
        }
    }

    /**
     * Test-only — reset the buffered state so a fresh test instance
     * starts clean. Production code never calls this.
     */
    @androidx.annotation.VisibleForTesting
    internal fun resetForTesting() {
        synchronized(this) {
            sink = null
            pendingBuffer.clear()
        }
    }
}

/**
 * What the lifecycle layer hands to the EventQueue. Deliberately
 * minimal — just enough information for the queue to construct a
 * canonical `KixoEvent` with `device_id` / `anonymous_id` / `user_id`
 * stamped from `IdentityManager.currentIds()` and per-event context
 * stamped from `DeviceInfo.perEventContext()`.
 *
 * Why not construct the full `KixoEvent` here? Because:
 *   - `KixoEvent` requires the [io.kixo.sdk.internal.model] type
 *     (Agent 2's territory) which the lifecycle layer touches only
 *     for [KixoEventType] (already a public-by-default sealed enum).
 *   - Stamping identity / context here would duplicate logic owned
 *     by the queue. Single-responsibility wins.
 */
internal data class LifecycleEvent(
    val eventType: KixoEventType,
    val eventName: String,
    val properties: Map<String, Any?>,
)
