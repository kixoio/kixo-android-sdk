package io.kixo.sdk.internal.queue

import io.kixo.sdk.internal.context.DeviceInfo
import io.kixo.sdk.internal.model.BatchPayload
import io.kixo.sdk.internal.model.KixoEvent
import java.time.Instant

/**
 * Builds the wire-format payload sent to `/api/sdk/batch`.
 *
 * Bridges three sources of state into a single serialisable record:
 *   - **Static SDK config** (project_id, api_key, environment, app
 *     version, bundle id) — read from [ConfigHolder].
 *   - **Resolved release_id** — populated after `/api/sdk/init`,
 *     read from [ConfigHolder.snapshot].releaseId.
 *   - **Live device context** — read from the [DeviceInfo] dependency
 *     (Agent 6 owns).
 *   - **The events themselves** — passed in by the caller (typically
 *     [EventQueue] after a `store.checkout`).
 *
 * Wire shape (snake_case, see iOS `Transport.swift` `BatchPayload`):
 *
 * ```json
 * {
 *   "project_id": "kx_proj_…",
 *   "api_key": "kx_key_…",
 *   "platform": "android",
 *   "environment": "development",
 *   "sdk_version": "0.1.0",
 *   "app_version": "1.2.3",
 *   "bundle_id": "com.example.myapp",
 *   "release_id": "<from /api/sdk/init>",
 *   "context": { … enriched device/os/runtime context … },
 *   "batch": [ … events … ],
 *   "sent_at": "ISO8601"
 * }
 * ```
 *
 * **Why is this a separate class from the transport?** The transport
 * (Agent 4) is responsible for HTTP — building the request, parsing
 * the response, mapping status codes to outcomes. Assembling the
 * payload BODY is queue-side concern: the queue knows which events
 * are in this batch, has access to [ConfigHolder] (the queue's the
 * primary consumer) and is the natural owner of the "shape what
 * we're about to send" step. Splitting it out also keeps the
 * transport's mocking surface tiny — the test stub returns
 * `BatchOutcome`, doesn't need to fabricate a real payload.
 *
 * **Real types throughout (Wave 6 refactor, May 2026):** earlier
 * revisions declared narrow stub interfaces (`DeviceInfo`,
 * `EnrichedContext`, `KixoEvent`, `BatchPayload`) here so the queue
 * could compile in isolation during the parallel-build wave. The
 * Wave 6 cleanup imports the real types directly — zero adapters,
 * zero parallel-universe duplicates.
 */
internal class BatchPayloadAssembler(
    private val deviceInfo: DeviceInfo,
    private val configHolder: ConfigHolder = ConfigHolder,
) {

    // The default `ConfigHolder` argument lets call sites omit the
    // singleton in the common case — tests inject a different one
    // by overriding the parameter directly.

    /**
     * Wrap [events] into a [BatchPayload] ready for serialisation.
     *
     * Reads the live config snapshot once at the top so the resulting
     * payload is internally consistent (a parallel `setReleaseId(...)`
     * during the call won't half-update the result).
     *
     * @param events The events being shipped in this batch. Caller
     *        is responsible for size limits — the assembler doesn't
     *        impose any.
     * @return A [BatchPayload] populated with the current config +
     *         the live device context. The transport layer is
     *         responsible for serialising this to JSON.
     */
    fun assemble(events: List<KixoEvent>): BatchPayload {
        // Snapshot the config ONCE so a concurrent `set` / `setReleaseId`
        // doesn't tear the resulting payload across two snapshot reads.
        val cfg = configHolder.snapshot()

        return BatchPayload(
            projectId = cfg.projectId,
            apiKey = cfg.apiKey,
            platform = ANDROID_PLATFORM,
            environment = cfg.environment,
            // SDK version is read from BuildConfig at the transport
            // boundary too — single source of truth is the gradle
            // `buildConfigField` injection. We snapshot it here so
            // the wire payload's `sdk_version` matches the value the
            // transport uses for User-Agent / retry-tier reporting.
            sdkVersion = io.kixo.sdk.BuildConfig.SDK_VERSION,
            // appVersion is nullable on the wire (Critic 5 HIGH);
            // the holder's snapshot still types it as non-null
            // String so we pass-through. If a future change makes
            // the holder field nullable too, this stays correct.
            appVersion = cfg.appVersion,
            bundleId = cfg.bundleId,
            releaseId = cfg.releaseId,
            context = deviceInfo.enrichedContext(),
            batch = events,
            // Wall-clock instant the SDK released this batch — the
            // backend uses (sent_at - earliest_event_timestamp) as
            // a "queue staleness" signal for monitoring. The model
            // serialises this via the ISO-8601 [Iso8601InstantSerializer].
            sentAt = Instant.now(),
        )
    }

    private companion object {
        /**
         * Wire token for the `platform` field. Backend's batch route
         * branches on this to pick the right per-event projector
         * (e.g. iOS-specific `screen_view` properties differ from
         * Android's). Keep stable.
         */
        const val ANDROID_PLATFORM: String = "android"
    }
}
