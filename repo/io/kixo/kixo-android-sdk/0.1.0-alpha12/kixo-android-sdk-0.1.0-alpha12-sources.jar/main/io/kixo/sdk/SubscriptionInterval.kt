package io.kixo.sdk

/**
 * Subscription billing interval.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Models/SubscriptionInterval.swift`
 * and the backend's `Plan.interval` enum so we don't silently mistype
 * across platforms. The `wireValue` is the lowercase string the
 * backend's standard-event detector matches on (e.g. `"month"` for the
 * `subscribe_start` event's `interval` property).
 *
 * Why an enum over a free-form string?
 *   1. Compile-time validation in [Kixo.trackSubscriptionStart] —
 *      misspelling `monthly` is a compile error, not a silently-
 *      mismatched property the backend's MRR rollup ignores.
 *   2. Single source of truth on the wire token. iOS uses the same
 *      raw values; Android must match exactly or the cross-platform
 *      MRR aggregation double-counts.
 *
 * Ports the iOS enum cases verbatim. The briefing requested also
 * `WEEKLY / MONTHLY / QUARTERLY / YEARLY`-style aliases — added as
 * convenience companion-object values that map to the same wire
 * tokens. The canonical entries are the four iOS-parity cases below.
 */
public enum class SubscriptionInterval(public val wireValue: String) {
    /** Daily billing cadence — niche, but supported (gaming / metered). */
    DAY("day"),

    /** Weekly billing cadence. */
    WEEK("week"),

    /** Monthly billing cadence — most common consumer subscription. */
    MONTH("month"),

    /** Yearly billing cadence — typical "annual plan" tier. */
    YEAR("year"),

    /**
     * Quarterly billing cadence — every 3 months. Not in iOS yet; added
     * for Android based on briefing. The backend's standard-event
     * detector treats unknown intervals as a warning (event still
     * stored), so this stays forward-compatible even on older backends.
     */
    QUARTER("quarter");

    /**
     * Aliases for callers who prefer the longer adjectival form
     * (`SubscriptionInterval.MONTHLY`). Resolves to the same canonical
     * enum case so wire output is identical.
     *
     * Companion object members do NOT show up as enum values in
     * `entries`, so Java callers using `values()` see only the four
     * canonical cases — no double-listing.
     */
    public companion object {
        @JvmField
        public val DAILY: SubscriptionInterval = DAY

        @JvmField
        public val WEEKLY: SubscriptionInterval = WEEK

        @JvmField
        public val MONTHLY: SubscriptionInterval = MONTH

        @JvmField
        public val QUARTERLY: SubscriptionInterval = QUARTER

        @JvmField
        public val YEARLY: SubscriptionInterval = YEAR

        /**
         * Parse a wire token (`"month"`, `"year"`, …) back into an enum.
         * Returns null on unknown — caller decides whether to fall back
         * to [MONTH] or drop the event. Used by the dashboard SDK
         * round-trip when reading server-stored subscription metadata.
         */
        @JvmStatic
        public fun fromWireValue(value: String?): SubscriptionInterval? {
            if (value == null) return null
            // Lowercased to absorb `"MONTHLY"` / `"Monthly"` server-side
            // typos — wire tokens themselves are always lowercase.
            return when (value.lowercase()) {
                "day", "daily" -> DAY
                "week", "weekly" -> WEEK
                "month", "monthly" -> MONTH
                "quarter", "quarterly" -> QUARTER
                "year", "yearly", "annual" -> YEAR
                else -> null
            }
        }
    }
}
