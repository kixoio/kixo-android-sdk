package io.kixo.sdk.internal.replay.upload

import android.graphics.Bitmap
import android.os.Build
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Bitmap → byte[] encoders for replay frames. Default output is JPEG
 * because the universal-decode floor on Android is JPEG (every API
 * level since 1.x), and the player uses standard `<img>` tags.
 *
 * **Why not HEIC** (the iOS default):
 *  - `Bitmap.CompressFormat.HEIF` ships only on **API 28+** (per
 *    Android docs). Our minSdk is 24 — silent decode failures on
 *    Android 7/8 would leave gaps in the replay.
 *  - Player browsers also need to decode HEIF; Chrome/Firefox don't
 *    ship a native HEIF decoder yet (May 2026), so the dashboard
 *    would need to transcode server-side anyway. Round trip = no win.
 *  - WebP at API 18+ is the next-best efficiency tier; we expose
 *    [encodeWebp] for hosts willing to trade the compatibility tail
 *    for ~25% smaller payloads. JPEG stays the default.
 *
 * **Quality knob:** 85 is the perceptual sweet spot we calibrated
 * against the iOS HEIC q=0.20 frames. Hit-View captures (the
 * common case — TouchInterceptor passes the View that hit-tested
 * under the tap) sit ~5-15 KB JPEG, well under the canonical
 * Android cap of 20 KB enforced by the backend's
 * `x-goog-content-length-range` extension header. Full-screen or
 * scroll-end captures of a 1080×2400 frame at q=85 land ~70 KB
 * (HEIC equivalent ~30 KB) — these would currently 4xx against
 * the 20 KB cap. If real-world telemetry shows a meaningful
 * fraction of frames > 20 KB, EITHER dial quality down here OR
 * raise the cap in `UploadWorker.DEFAULT_MAX_BYTES` + the
 * backend `maxBytesFor("android")` helper (see
 * `kixo-backend/apps/web/src/app/api/sdk/replay/session/start/route.ts`).
 *
 * **Off-main:** `Bitmap.compress` is CPU-heavy (~30-80 ms on a
 * mid-range device for a full-screen frame). All callers must invoke
 * from a coroutine on `Dispatchers.IO` or a worker — never from the
 * UI thread (briefing R6 — never block main > 16 ms).
 */
internal object JpegEncoder {

    /**
     * Encode a [Bitmap] to a JPEG byte array, **fitting under the
     * canonical 20 KB cap** by re-encoding at progressively lower
     * quality if the first attempt blows the budget.
     *
     * Why iterative: scene complexity dominates JPEG size at fixed
     * quality (a busy photo gallery vs an empty form differ by 4×
     * even at the same dimensions). A static "q=X" can fit one and
     * blow the other; the cap is a hard contract enforced by the
     * GCS V4 signature, so we must guarantee fit. We try three
     * quality tiers (60 → 35 → 20) at a 0.4× linear downscale
     * (0.16× pixel count) and pick the first one that fits.
     * Worst-case three encode passes × ~30 ms each on mid-tier
     * Android = ~90 ms per frame, off-main, acceptable.
     *
     * Returns `null` on:
     *   - All quality tiers exceed [maxBytes] (rare — happens for
     *     extremely high-entropy frames, drops cleanly per R6)
     *   - `Bitmap.compress` failure (OOM under memory pressure)
     *
     * The dashboard player upscales for display so the user-visible
     * resolution is unchanged — we trade a small fidelity hit for
     * fitting within egress discipline (the 20 KB agreed cap).
     *
     * @param maxBytes byte ceiling the encoded output must fit
     *        under. Defaults to 20_000 to match the backend
     *        `REPLAY_FRAME_MAX_BYTES` constant.
     * @param downscale linear scale factor in (0,1]. Default 0.4
     *        = 0.16× pixel count = ~6× smaller surface to compress.
     */
    fun encodeJpeg(
        bitmap: Bitmap,
        maxBytes: Int = 20_000,
        downscale: Float = 0.4f,
    ): ByteArray? {
        val safeDownscale = downscale.coerceIn(0.05f, 1f)
        // Downscale BEFORE encode so the JPEG entropy coder sees a
        // smaller surface to compress. createScaledBitmap with
        // bilinear filter is the standard approach; cost is one
        // additional ~10 ms allocation per frame on a mid-tier
        // device for a 1080×2400 source.
        val source: Bitmap = if (safeDownscale < 1f) {
            try {
                Bitmap.createScaledBitmap(
                    bitmap,
                    (bitmap.width * safeDownscale).toInt().coerceAtLeast(1),
                    (bitmap.height * safeDownscale).toInt().coerceAtLeast(1),
                    /* filter = */ true,
                )
            } catch (t: Throwable) {
                Log.w(TAG, "Bitmap downscale threw — falling back to source dimensions", t)
                bitmap
            }
        } else {
            bitmap
        }
        return try {
            // Quality tiers: try high → low. For typical screenshots
            // (UI chrome, mostly flat colors) q=60 hits 8-15 KB at
            // 0.4× downscale; for complex scenes (photos in a feed)
            // we step down to q=35 then q=20.
            for (quality in QUALITY_TIERS) {
                val out = compressOnce(source, quality)
                if (out != null && out.size <= maxBytes) {
                    return out
                }
                if (out != null && out.size > maxBytes) {
                    Log.d(
                        TAG,
                        "JPEG q=$quality produced ${out.size}B > maxBytes=$maxBytes — re-encoding lower",
                    )
                }
            }
            Log.w(
                TAG,
                "JPEG encode failed to fit ${maxBytes}B even at q=${QUALITY_TIERS.last()} (high-entropy frame?) — dropping",
            )
            null
        } finally {
            // Recycle the downscaled intermediate (NOT the caller's
            // input — that's owned upstream). `createScaledBitmap`
            // sometimes returns the same object when scale=1.0;
            // identity-check before recycling so we don't recycle
            // the caller's bitmap.
            if (source !== bitmap && !source.isRecycled) {
                try { source.recycle() } catch (_: Throwable) { /* swallow */ }
            }
        }
    }

    /**
     * Single JPEG compression pass. Extracted from [encodeJpeg] so
     * the iterative fit-to-cap loop above can call it multiple
     * times against the same already-downscaled source bitmap
     * without repeating the (expensive) downscale step.
     */
    private fun compressOnce(source: Bitmap, quality: Int): ByteArray? {
        val safeQuality = quality.coerceIn(1, 100)
        return try {
            ByteArrayOutputStream(estimateBufferSize(source)).use { stream ->
                val ok = source.compress(Bitmap.CompressFormat.JPEG, safeQuality, stream)
                if (!ok) {
                    Log.w(TAG, "JPEG encode returned false (OOM?) at q=$safeQuality")
                    return null
                }
                stream.toByteArray()
            }
        } catch (t: Throwable) {
            // OutOfMemoryError, IOException — both swallow + log.
            // Replay is best-effort; one missing frame is fine.
            Log.w(TAG, "JPEG encode threw at q=$safeQuality", t)
            null
        }
    }

    /**
     * Quality tiers tried in order by [encodeJpeg]'s fit-to-cap
     * loop. Calibrated against the canonical 20 KB cap and 0.4×
     * downscale: q=60 fits typical UI chrome, q=35 covers busier
     * scenes (chat feeds, news lists), q=20 is the floor for the
     * occasional photo-heavy frame. Below q=20 the artefacts get
     * loud enough that dropping the frame is honestly better than
     * shipping noise.
     */
    private val QUALITY_TIERS: IntArray = intArrayOf(60, 35, 20)

    /**
     * Optional WebP encoder. Available on API 18+ for `WEBP` lossy
     * (every API our minSdk=24 covers) and API 30+ for `WEBP_LOSSY`
     * with explicit quality control. Falls back to the legacy
     * `WEBP` constant on older API levels.
     *
     * Hosts that want ~25% smaller frames at the cost of slightly
     * older browser-decoder support can switch by setting
     * `Configuration.replayFrameFormat = "webp"` (Agent 13's knob).
     * The default stays JPEG.
     */
    fun encodeWebp(bitmap: Bitmap, quality: Int = 80): ByteArray? {
        val safeQuality = quality.coerceIn(1, 100)
        val format = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // API 30+: WEBP_LOSSY honours the quality int directly.
            Bitmap.CompressFormat.WEBP_LOSSY
        } else {
            // API 24-29: legacy WEBP also honours quality (lossy mode).
            // The newer constant is a Google soft-deprecation warning
            // we silence with @Suppress at the call site.
            @Suppress("DEPRECATION")
            Bitmap.CompressFormat.WEBP
        }
        return try {
            ByteArrayOutputStream(estimateBufferSize(bitmap)).use { stream ->
                val ok = bitmap.compress(format, safeQuality, stream)
                if (!ok) {
                    Log.w(TAG, "WebP encode returned false — dropping frame")
                    return null
                }
                stream.toByteArray()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "WebP encode threw — dropping frame", t)
            null
        }
    }

    /**
     * Persist a byte array to disk atomically (write to `.tmp`, then
     * rename) so a crash mid-write never leaves a half-baked staging
     * file that [UploadWorker] would then PUT to GCS.
     *
     * Returns `true` on success. On failure the partial file is
     * removed — the upload will simply not be scheduled.
     */
    fun ByteArray.writeToFile(file: File): Boolean {
        // Make sure the parent dir exists; cacheDir/<sessionId>/ may
        // not have been created yet on the very first frame.
        val parent = file.parentFile
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            Log.w(TAG, "Failed to create cache parent dir ${parent.absolutePath}")
            return false
        }
        val tmp = File(file.parentFile, file.name + ".tmp")
        return try {
            FileOutputStream(tmp).use { it.write(this) }
            // `renameTo` on Android is atomic on the same filesystem
            // (which cacheDir always is) — UploadWorker will only
            // ever see the final filename.
            if (!tmp.renameTo(file)) {
                tmp.delete()
                Log.w(TAG, "Atomic rename failed for ${file.absolutePath}")
                false
            } else {
                true
            }
        } catch (t: Throwable) {
            tmp.delete()
            Log.w(TAG, "Failed to write ${file.absolutePath}", t)
            false
        }
    }

    /**
     * Heuristic initial buffer size: JPEG of a 1080×2400 frame at
     * q=85 is ~70-100 KB. Sizing the [ByteArrayOutputStream] up
     * front avoids 4-5 reallocations during compress (each one
     * doubles + memcpys). Cap at 1 MB so a giant Bitmap doesn't
     * pre-allocate more than necessary.
     */
    private fun estimateBufferSize(bitmap: Bitmap): Int {
        val pixels = bitmap.width.toLong() * bitmap.height.toLong()
        // Rough rule: ~3 bytes/100 pixels at q=85.
        val estimate = (pixels * 3L / 100L).toInt().coerceAtLeast(8 * 1024)
        return estimate.coerceAtMost(1024 * 1024)
    }

    private const val TAG = "Kixo.JpegEncoder"
}
