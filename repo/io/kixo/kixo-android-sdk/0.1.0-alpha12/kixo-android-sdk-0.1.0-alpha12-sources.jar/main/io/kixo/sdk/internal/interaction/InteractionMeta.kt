package io.kixo.sdk.internal.interaction

/**
 * Wire-shape sidecar attached to every gesture event the SDK ships
 * (event_type=`tap` for the tap family, `gesture` for other taxonomies).
 *
 * Mirrors iOS `WindowEventInterceptor.Interaction` payload exactly so
 * the backend `session_replay_events` columns + dashboard player can
 * render iOS and Android sessions through the same code path. See
 * `kixo-ios-sdk/Sources/Kixo/Replay/ReplayController.swift` lines
 * 2087-2117 for the canonical map.
 *
 * **Field semantics:**
 *
 * - [tapKind] — one of the [Kind] enum's snake_case wire values. The
 *   backend `session_replay_events.tap_kind` column is
 *   `LowCardinality(String)` so adding a new variant must coordinate
 *   with iOS + the dashboard player's [TapOverlay].
 * - [tapXNorm] / [tapYNorm] — END coordinates of the gesture
 *   normalised against the host activity's content-view size. `0..1`
 *   range; clamped server-side. For `scroll_end` the SDK emits the
 *   sentinel `(0,0)` (no tap location).
 * - [tapStartXNorm] / [tapStartYNorm] — BEGIN coordinates, only
 *   populated for swipes / pinches / drags where start ≠ end carries
 *   information. Null on plain taps where start≈end (the player
 *   collapses both points and just renders the end dot).
 * - [gestureDurationMs] — wall-clock millis between the first
 *   `ACTION_DOWN` of the gesture and the last `ACTION_UP`. Used by
 *   the player to render long-press duration labels and by the
 *   gesture classifier itself to disambiguate tap vs long-press.
 * - [touchCount] — peak concurrent pointer count over the lifetime of
 *   the gesture. ≥2 means multi-touch (multi-tap or pinch); 1 means
 *   single-finger.
 *
 * **Why a sealed string enum instead of free-form String:** the iOS
 * SDK ships these values inline as `String` literals, but having a
 * Kotlin enum means the gesture classifier cannot accidentally emit a
 * typo and break dashboard display (which silently treats unknown
 * `tap_kind` as plain `tap`). Wire serialisation always uses
 * [Kind.wire] so JSON shape is unchanged.
 *
 * **No serialisation annotation here.** This DTO is composed into the
 * downstream `KixoEvent.properties` map (a `JsonObject`) via
 * [toPropertyMap], not serialised by kotlinx directly. Keeping it
 * annotation-free means the gesture classifier remains pure-Kotlin
 * and trivially unit-testable (no kotlinx.serialization on the
 * classpath in JVM unit tests).
 */
internal data class InteractionMeta(
    val tapKind: Kind,
    val tapXNorm: Float,
    val tapYNorm: Float,
    val tapStartXNorm: Float? = null,
    val tapStartYNorm: Float? = null,
    val gestureDurationMs: Long,
    val touchCount: Int,
) {

    /**
     * Cross-platform gesture taxonomy. Wire values match
     * `kixo-ios-sdk/Sources/Kixo/Replay/WindowEventInterceptor.swift`
     * `InteractionKind` raw values and the web SDK's
     * `auto/interaction-taxonomy.ts` payload.
     */
    enum class Kind(val wire: String) {
        TAP("tap"),
        LONG_PRESS("long_press"),
        SWIPE_UP("swipe_up"),
        SWIPE_DOWN("swipe_down"),
        SWIPE_LEFT("swipe_left"),
        SWIPE_RIGHT("swipe_right"),
        MULTI_TAP("multi_tap"),
        PINCH_IN("pinch_in"),
        PINCH_OUT("pinch_out"),
        SCROLL_END("scroll_end");

        companion object {
            /**
             * Lookup by wire string. Used only by tests and when
             * deserialising server-side replays back into the player
             * preview pipeline. Returns null for unknown values; the
             * caller treats `null` as "ignore this event" rather than
             * defaulting to `TAP` (a wrong default would mis-classify
             * any future taxonomy rollout server-issued before the
             * SDK is updated).
             */
            fun fromWire(value: String): Kind? =
                entries.firstOrNull { it.wire == value }
        }
    }

    /**
     * Flatten this DTO into the loose `Map<String, Any?>` shape the
     * `KixoEvent.properties` builder consumes (via
     * `PropertyValue.fromAny`). Mirrors iOS payload key order from
     * `ReplayController.swift` line 2087+.
     *
     * The map intentionally omits null start coordinates so the
     * resulting JSON object stays shape-identical to iOS for plain
     * taps. The wire is forward-compatible: backend ingest tolerates
     * missing optional fields.
     */
    fun toPropertyMap(): Map<String, Any?> {
        val out = LinkedHashMap<String, Any?>(7)
        out["tap_kind"] = tapKind.wire
        out["tap_x_norm"] = tapXNorm.toDouble()
        out["tap_y_norm"] = tapYNorm.toDouble()
        if (tapStartXNorm != null && tapStartYNorm != null) {
            out["tap_start_x_norm"] = tapStartXNorm.toDouble()
            out["tap_start_y_norm"] = tapStartYNorm.toDouble()
        }
        out["gesture_duration_ms"] = gestureDurationMs
        out["touch_count"] = touchCount
        return out
    }
}
