package io.kixo.sdk.internal.goal

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicReference

/**
 * Per-session goal-emission dedup, mirroring the web SDK's
 * `_firedKeys` Set in `kixo-web-sdk/src/auto/goal-marker.ts` and the
 * iOS contract that `Kixo.markGoal()` is idempotent within a session by
 * default.
 *
 * **Why dedup at all?** A typical conversion-flow integration looks
 * like:
 *
 * ```kotlin
 *   override fun onResume() {
 *       super.onResume()
 *       if (purchaseSucceeded) Kixo.markGoal("checkout_complete", value=…)
 *   }
 * ```
 *
 * If the user briefly leaves the app and returns, `onResume()` fires
 * again — and the `purchaseSucceeded` flag may still be true if the
 * caller hasn't reset it. Without dedup the "checkout_complete" goal
 * would inflate, corrupting the conversion-rate denominator on the
 * dashboard. The default `Session` scope means the goal fires once per
 * session and any extra calls within that session are silently
 * absorbed.
 *
 * **Scopes:** mirror the cross-platform `once` parameter on the web
 * SDK's `Kixo.markGoal()` (`'session' | 'page' | 'never'`) — Android
 * has no concept of "page" so we collapse to `Session`, plus the
 * special-case `Always` for callers who genuinely want every emit.
 *
 * **Persistence:** memory only. Cleared on `session_start` via
 * [resetForSession] so a fresh session starts with a clean counter
 * (e.g. cold launch, or warm background-resume past the 30-second
 * session-timeout). We deliberately do NOT persist this across
 * process death:
 *
 *   - Cross-platform parity: the web SDK's `_firedKeys` is also
 *     in-memory only.
 *   - The cost of a duplicate goal emit on a cold launch is one
 *     extra event in ClickHouse — recoverable; whereas the cost of
 *     persisting and accidentally suppressing a legitimate goal
 *     (e.g. user genuinely re-purchased) is a missed conversion
 *     that can't be recovered.
 *
 * **Thread safety:** `Kixo.markGoal()` is documented as safe to call
 * from any thread. We back the de-dup set with [ConcurrentHashMap.newKeySet]
 * (a `Set<String>` view over a `ConcurrentHashMap`) so contention from
 * fan-out scenarios (push-handler thread + UI thread + background work
 * all marking goals) doesn't need an external lock.
 *
 * The current-session reference is an [AtomicReference] so a CAS swap
 * during [resetForSession] doesn't race with an in-flight
 * [shouldEmit] — at worst a borderline call lands in the previous
 * session's set, which is harmless (a duplicate goal in the
 * not-quite-yet-rotated session).
 */
internal object GoalDedup {

    /**
     * Dedup scope for a goal emit. Cross-platform parity with web SDK's
     * `'session' | 'page' | 'never'` `once` option, with `'page'`
     * collapsed to [Session] on Android (no equivalent of a browser
     * page-load).
     */
    internal enum class DedupScope {
        /**
         * Emit at most ONCE per analytics session. Default. Resets when
         * [resetForSession] is invoked by the session tracker on
         * `session_start`.
         */
        Session,

        /**
         * Emit ONCE per process lifetime (essentially permanent until
         * the JVM dies). Useful for one-shot "user has ever done X"
         * goals where re-emission across sessions is also unwanted.
         * Not currently exposed on the public API but reserved for
         * parity with the iOS / web roadmap — the storage shape is
         * identical so we don't need a schema change to add it.
         */
        Process,

        /**
         * No dedup — every call emits. Caller is responsible for any
         * duplicate-suppression logic at their layer.
         */
        Always,
    }

    /**
     * Per-scope fired-key sets. Keyed by scope so a goal name marked in
     * one scope doesn't suppress a different scope. Sets are concurrent
     * to absorb cross-thread fan-out without an external lock.
     */
    private val sessionFired: AtomicReference<MutableSet<String>> =
        AtomicReference(ConcurrentHashMap.newKeySet())

    private val processFired: MutableSet<String> = ConcurrentHashMap.newKeySet()

    /**
     * Decide whether a goal emit should proceed. Returns `true` iff the
     * caller should enqueue the event AND atomically records the name
     * as fired so subsequent calls in the same scope are suppressed.
     *
     * Idempotent: two threads racing to mark the same name will see
     * exactly one `true` between them (the underlying [MutableSet.add]
     * on a `ConcurrentHashMap.KeySet` is atomic). The losing call
     * receives `false`.
     *
     * **Validation contract:** the caller is responsible for validating
     * `name` via [GoalNameValidator] BEFORE invoking this — we trust
     * the input here.
     */
    fun shouldEmit(name: String, scope: DedupScope = DedupScope.Session): Boolean {
        return when (scope) {
            DedupScope.Always -> true
            DedupScope.Session -> sessionFired.get().add(name)
            DedupScope.Process -> processFired.add(name)
        }
    }

    /**
     * Rotate the per-session dedup set. Invoked by the session tracker
     * on `session_start` so a fresh session starts with a clean slate.
     *
     * We replace the underlying set rather than clearing it so any
     * in-flight callers iterating the old set don't observe a half-
     * cleared state. The previous set becomes garbage instantly
     * (reachable only through any in-flight `shouldEmit` frames that
     * already loaded the reference), which is by design.
     *
     * The [DedupScope.Process] set is intentionally never reset —
     * scope name is the contract.
     */
    fun resetForSession() {
        sessionFired.set(ConcurrentHashMap.newKeySet())
    }

    /**
     * Test seam — reset both scopes. Only used by `GoalDedupTest` so
     * the singleton's state doesn't leak across test methods. Never
     * called from production code.
     */
    @androidx.annotation.VisibleForTesting
    internal fun resetAllForTesting() {
        sessionFired.set(ConcurrentHashMap.newKeySet())
        processFired.clear()
    }
}
