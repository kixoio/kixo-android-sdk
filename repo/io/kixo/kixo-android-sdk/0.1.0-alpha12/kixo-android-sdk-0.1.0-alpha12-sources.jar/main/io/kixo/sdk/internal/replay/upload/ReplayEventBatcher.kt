package io.kixo.sdk.internal.replay.upload

import android.util.Log
import io.kixo.sdk.internal.transport.Endpoints
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.IOException
import kotlin.coroutines.resume

/**
 * Collects per-tap replay event metadata (small JSON, NOT frames)
 * and POSTs them to `/api/sdk/replay/events` in batches of up to
 * [maxBatchSize] every ~[flushIntervalMs] ms. Mirrors the iOS
 * `ReplayEventQueue` pattern but keeps the queue in-memory only —
 * see "why not SQLite-backed" below.
 *
 * **Wire format** (one POST):
 * ```json
 * {
 *   "project_id": "…",
 *   "api_key": "…",
 *   "session_id": "…",
 *   "events": [{"seq": 1, "tap_x_norm": 0.5, ...}, ...]
 * }
 * ```
 *
 * **Why an in-memory bounded queue, not a SQLite-backed durable
 * queue (the iOS approach):**
 *  - Replay events without their corresponding frames are not
 *    independently meaningful — the dashboard player joins them by
 *    `(session_id, seq)` and a "tap" without a "before/after frame"
 *    is just noise. Frames go through WorkManager which IS durable;
 *    if the process dies before the events flush, the frames will
 *    still upload but the events are lost. Net data loss = events
 *    only, on app-kill, for the last <5 s window. Acceptable
 *    trade-off for the implementation simplicity.
 *  - Adding a second SQLite store would create lock contention
 *    against [io.kixo.sdk.internal.storage.SqliteEventStore]
 *    (Agent 3 owns the main events DB). The iOS impl uses a
 *    SEPARATE DB file for the same reason.
 *  - v1.1: if customers report measurable data loss, swap the
 *    in-memory queue for a SQLite-backed one with the same
 *    Mixpanel MPDB pattern Agent 3 uses.
 *
 * **Bounded:** max [MAX_QUEUE] events in-memory. Drops OLDEST on
 * overflow (rare — the periodic flush + threshold-trigger keep
 * the queue near-empty in steady state).
 *
 * **Lifecycle:** [start] launches the periodic flush coroutine on
 * the supplied [scope] (the SDK's process-wide scope). [stop]
 * cancels it AND triggers a final synchronous flush so a clean
 * session-end doesn't lose the last in-flight events.
 */
internal class ReplayEventBatcher(
    private val httpClient: OkHttpClient,
    private val baseUrl: String,
    private val projectId: String,
    private val apiKey: String,
    private val sessionId: String,
    private val flushIntervalMs: Long = 5_000L,
    private val maxBatchSize: Int = 100,
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO),
) {

    private data class PendingEvent(val seq: Long, val payload: Map<String, Any?>)

    private val mutex = Mutex()
    private val pending: ArrayDeque<PendingEvent> = ArrayDeque()
    private var periodicJob: Job? = null

    /**
     * Append a per-tap event payload. Called by [ReplayUploader]
     * after a frame has been staged + scheduled. The payload should
     * already include the `gcs_path` fields for any pre/post/
     * structural/ocr siblings that landed alongside this seq —
     * [ReplayUploader] enriches before calling.
     *
     * The map shape mirrors the iOS `postTapEvent` body — see the
     * AGENT_BRIEFING wire format example for the full field set.
     */
    suspend fun enqueue(seq: Long, payload: Map<String, Any?>) {
        var shouldFlushNow = false
        mutex.withLock {
            pending.addLast(PendingEvent(seq, payload))
            // Drop oldest on overflow (FIFO, like the main event
            // queue). Logged at debug so dev catches the under-
            // configured case.
            while (pending.size > MAX_QUEUE) {
                pending.removeFirst()
                Log.d(TAG, "Replay-event queue overflow — dropped oldest")
            }
            if (pending.size >= maxBatchSize) {
                shouldFlushNow = true
            }
        }
        if (shouldFlushNow) {
            // Threshold trigger: flush immediately rather than
            // waiting for the periodic timer. Doesn't block enqueue
            // — fire-and-forget on the SDK scope.
            scope.launch { flush() }
        }
    }

    /**
     * Start the periodic flush loop. Idempotent — calling twice is
     * a no-op (the second call's launch would race with the first).
     */
    fun start() {
        if (periodicJob != null) return
        periodicJob = scope.launch {
            while (isActive) {
                delay(flushIntervalMs)
                try {
                    flush()
                } catch (t: Throwable) {
                    // The flush method swallows internally; this is
                    // a defence-in-depth catch so a buggy future
                    // edit can't tear down the periodic loop.
                    Log.w(TAG, "Periodic flush threw", t)
                }
            }
        }
    }

    /**
     * Stop the periodic flush + flush any remaining events
     * synchronously. Called on session-end so the last few taps
     * get one final attempt before the session is sealed.
     */
    suspend fun stop() {
        periodicJob?.cancel()
        periodicJob = null
        flush()
    }

    /**
     * Drain up to [maxBatchSize] events and POST them. On 2xx the
     * batch is dropped; on failure the events are pushed back to
     * the FRONT of the queue (so the next attempt picks them up
     * first, preserving rough chronological order).
     *
     * **Single-flight:** uses [mutex] for the snapshot+drain step
     * but releases before the network call so a slow network
     * doesn't block enqueues. Concurrent flush callers race for the
     * same drained chunk; one wins, the loser sees an empty drain
     * and returns immediately.
     */
    suspend fun flush() {
        val batch: List<PendingEvent> = mutex.withLock {
            if (pending.isEmpty()) return
            val take = minOf(pending.size, maxBatchSize)
            val out = ArrayList<PendingEvent>(take)
            repeat(take) { out.add(pending.removeFirst()) }
            out
        }
        if (batch.isEmpty()) return

        val ok = postBatch(batch)
        if (!ok) {
            // Re-queue at the FRONT so the next flush retries them
            // first. Bounded — if MAX_QUEUE is exceeded after the
            // re-insert, the OLDEST end gets dropped per the
            // overflow rule above. This means a sustained outage
            // gracefully degrades to "drop oldest" instead of
            // ballooning memory.
            mutex.withLock {
                // addFirst in reverse so original ordering survives.
                for (i in batch.indices.reversed()) pending.addFirst(batch[i])
                while (pending.size > MAX_QUEUE) pending.removeLast()
            }
        }
    }

    private suspend fun postBatch(batch: List<PendingEvent>): Boolean = withContext(Dispatchers.IO) {
        val bodyJson = buildJsonBody(batch)
        val req = Request.Builder()
            .url(Endpoints.url(baseUrl, Endpoints.REPLAY_EVENTS))
            .post(bodyJson.toRequestBody(JSON_MEDIA_TYPE))
            .header("Authorization", "Bearer $apiKey")
            .header("Content-Type", "application/json; charset=utf-8")
            .build()

        val response: Response = try {
            executeAsync(httpClient.newCall(req))
        } catch (e: IOException) {
            return@withContext false
        } catch (t: Throwable) {
            Log.w(TAG, "Replay event POST threw", t)
            return@withContext false
        }
        response.use { resp ->
            val ok = resp.isSuccessful
            if (!ok && resp.code in 400..499 && resp.code != 429) {
                // Permanent — log + drop (caller treats false as
                // "re-queue", but a 4xx repeat would loop forever.
                // We return true here to drop the batch on permanent
                // failures, mirroring the iOS retry/discard pivot).
                Log.w(TAG, "Replay events POST returned ${resp.code} (permanent) — dropping batch")
                return@use true
            }
            ok
        }
    }

    /**
     * Hand-built JSON body so we don't need a bespoke
     * [@kotlinx.serialization.Serializable] DTO for every possible
     * shape of `payload`. The payload is a `Map<String, Any?>` of
     * primitives + maps — converted into [JsonObject] via
     * [toJsonElement]. Keeps the batcher decoupled from the exact
     * field set evolving in [ReplayController].
     */
    private fun buildJsonBody(batch: List<PendingEvent>): String {
        val eventsArray = JsonArray(batch.map { event ->
            // Always include `seq` — the player joins on it.
            val merged = HashMap<String, Any?>(event.payload.size + 1).apply {
                putAll(event.payload)
                put("seq", event.seq)
            }
            toJsonElement(merged) as JsonObject
        })
        val root = JsonObject(mapOf(
            "project_id" to JsonPrimitive(projectId),
            "api_key" to JsonPrimitive(apiKey),
            "session_id" to JsonPrimitive(sessionId),
            "events" to eventsArray,
        ))
        return root.toString()
    }

    /**
     * Convert an `Any?` (primitives + nested maps + lists) to a
     * [JsonElement]. Unknown types fall back to their `toString()`
     * — defensive, never crash on a stray sealed-class value the
     * caller didn't think to flatten first.
     */
    private fun toJsonElement(value: Any?): JsonElement = when (value) {
        null -> JsonNull
        is JsonElement -> value
        is Boolean -> JsonPrimitive(value)
        is Number -> JsonPrimitive(value)
        is String -> JsonPrimitive(value)
        is Map<*, *> -> JsonObject(value.entries.associate { (k, v) ->
            k.toString() to toJsonElement(v)
        })
        is Iterable<*> -> JsonArray(value.map { toJsonElement(it) })
        else -> JsonPrimitive(value.toString())
    }

    private suspend fun executeAsync(call: Call): Response =
        suspendCancellableCoroutine { cont ->
            cont.invokeOnCancellation {
                runCatching { call.cancel() }
            }
            call.enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {
                    if (cont.isActive) cont.resumeWith(Result.failure(e))
                }
                override fun onResponse(call: Call, response: Response) {
                    if (cont.isActive) cont.resume(response)
                }
            })
        }

    companion object {
        /**
         * Hard cap on the in-memory queue. Sustained-offline at
         * 1 event/sec → ~10 min before drops start. Beyond that,
         * the FIFO rule trims the oldest.
         */
        const val MAX_QUEUE: Int = 500

        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
        private const val TAG = "Kixo.ReplayEventBatcher"
    }
}
