package io.kixo.sdk.internal.lifecycle

import android.app.Application
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.lifecycle.ProcessLifecycleOwner
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Idempotent bootstrap for every lifecycle-shaped subsystem in the SDK.
 *
 * Two callers invoke [attach]:
 *   1. [KixoInitializerProvider.onCreate] — fires automatically on
 *      process start via the manifest declaration. This is the
 *      preferred path; it runs even when the host app forgets
 *      `Kixo.configure()` and gives us session_start coverage on the
 *      very first foreground.
 *   2. `Kixo.configure(context, ...)` — the public-API entry point
 *      from Agent 1. Calls [attach] again with the same Application
 *      reference. Because of the [installed] guard this second call
 *      is a cheap no-op; the per-instance singletons that already
 *      exist are kept.
 *
 * Why two paths? On some host configurations a custom
 * `tools:node="remove"` in the manifest can strip our provider. In
 * that case the only entry point is `Kixo.configure()`, and the SDK
 * still needs to start. Conversely, when the provider DOES fire,
 * lifecycle is wired up before the host app even has a chance to call
 * `configure()`, so the very first session boundary isn't lost.
 *
 * Idempotency contract:
 *   - [attach] may be called any number of times from any thread.
 *   - The first successful call wins. Subsequent calls do nothing.
 *   - Failures during the first call leave the bootstrap eligible for
 *     a future retry — `installed` is only flipped after the wiring
 *     has actually happened.
 *
 * Subsystems wired by this bootstrap:
 *   - [ProcessLifecycleObserver] — process-wide foreground/background
 *     transitions, app_launch, app_foreground, app_background.
 *   - [ActivityLifecycleObserver] — current top-Activity tracking
 *     (weak ref) for the rest of the SDK.
 *   - [SessionTracker] — session_start / session_end with the
 *     30-second background timeout from `KixoConfiguration`.
 *   - [MemoryWarningObserver] — `ComponentCallbacks2.onTrimMemory`
 *     bridge into a published `Flow<MemoryPressure>` other modules
 *     (e.g. ReplayController) collect to enter low-memory mode.
 *
 * **AGENT_BRIEFING.md R6 compliance:** every error path is swallowed
 * and logged. A bootstrap failure must NEVER crash the host app.
 */
internal object KixoInternalBootstrap {

    private const val TAG = "Kixo"

    private val installed = AtomicBoolean(false)

    /**
     * Captured Application reference. Only assigned once. Safe to
     * read after [installed] flips to true.
     */
    @Volatile
    private var app: Application? = null

    @Volatile
    private var processObserver: ProcessLifecycleObserver? = null

    @Volatile
    private var activityObserver: ActivityLifecycleObserver? = null

    @Volatile
    private var sessionTracker: SessionTracker? = null

    @Volatile
    private var memoryObserver: MemoryWarningObserver? = null

    /**
     * Memory-pressure broadcast channel. Other subsystems collect this
     * to enter / leave low-memory mode (e.g. ReplayController halves
     * its capture concurrency cap when LOW arrives, restores on
     * NORMAL). `replay = 1` so a late subscriber still gets the most
     * recent pressure level — a freshly-attached collector wakes up
     * already knowing whether the device is under memory pressure.
     */
    private val memoryPressureFlow: MutableSharedFlow<MemoryPressure> =
        MutableSharedFlow(replay = 1, extraBufferCapacity = 8)

    /**
     * Public Flow for cross-module memory-pressure signalling. Hot;
     * fire-and-forget — collectors should `launch { collect { … } }`
     * inside their own scope and tolerate cancellation.
     */
    val memoryPressure: SharedFlow<MemoryPressure> = memoryPressureFlow.asSharedFlow()

    /**
     * Idempotent attach. Safe to call from any thread, any number of
     * times. The first successful call installs every observer; later
     * calls are no-ops.
     */
    fun attach(application: Application) {
        if (!installed.compareAndSet(false, true)) {
            return
        }
        try {
            doAttach(application)
        } catch (t: Throwable) {
            // Mark uninstalled so a future configure() retries cleanly,
            // and clear any half-installed state so we don't double-
            // register if the second pass succeeds.
            Log.e(TAG, "lifecycle bootstrap failed; SDK will retry", t)
            tearDownPartial()
            installed.set(false)
        }
    }

    /**
     * Test seam — current Activity (weak ref) for screen / replay
     * subsystems to grab. Returns null if no Activity is foregrounded
     * or if bootstrap hasn't happened yet.
     */
    fun currentActivity(): android.app.Activity? = activityObserver?.currentActivity()

    /**
     * Subscribe an [KixoActivityListener] to the central
     * [ActivityLifecycleObserver]. Used by `Kixo.configure(...)` to
     * wire `ScreenTracker` and `TouchInterceptor` (Wave 8) without
     * each registering its own
     * `Application.ActivityLifecycleCallbacks` on the host
     * Application. Safe to call from any thread.
     *
     * If [attach] hasn't completed yet (e.g. the host called
     * `Kixo.configure(...)` from a non-Application context that we
     * couldn't bootstrap), this is a silent no-op — the SDK keeps
     * working without the lifecycle hooks rather than crashing the
     * host.
     */
    fun addActivityListener(listener: KixoActivityListener) {
        activityObserver?.addListener(listener)
    }

    /** Counterpart to [addActivityListener]. Idempotent. */
    fun removeActivityListener(listener: KixoActivityListener) {
        activityObserver?.removeListener(listener)
    }

    /**
     * Test seam — current session id (UUID), regenerates on every
     * `session_start`. EventQueue stamps this on every outbound event
     * via the side-channel.
     */
    fun currentSessionId(): String? = sessionTracker?.currentSessionId()

    /**
     * Internal accessor for the live [SessionTracker]. Used by
     * [ProcessLifecycleObserver] to forward foreground/background
     * transitions without holding its own tracker reference (the
     * tracker may be swapped in tests). Returns null until bootstrap
     * has wired the tracker on the main thread.
     */
    internal fun sessionTrackerOrNull(): SessionTracker? = sessionTracker

    /**
     * Internal accessor for the captured Application reference. Used
     * by [ProcessLifecycleObserver] to read SharedPreferences for the
     * persistent first-launch flag without taking its own Context
     * dependency. Returns null if bootstrap hasn't run yet.
     */
    internal fun applicationOrNull(): Application? = app

    /**
     * Test-only injector. Lets [SessionTrackerTest] install a tracker
     * without spinning up the full bootstrap.
     */
    @androidx.annotation.VisibleForTesting
    internal fun installSessionTrackerForTesting(tracker: SessionTracker?) {
        sessionTracker = tracker
    }

    /**
     * Test-only reset. Exposed `internal` so [SessionTrackerTest] etc.
     * can rebuild a fresh bootstrap between tests. Production code
     * never calls this.
     */
    @androidx.annotation.VisibleForTesting
    fun resetForTesting() {
        tearDownPartial()
        installed.set(false)
        app = null
    }

    private fun doAttach(application: Application) {
        app = application

        // Wire memory observer first — it's a cheap registerComponent-
        // Callbacks call, and getting it in early means the very first
        // memory warning during cold-start (rare but seen on low-end
        // devices) is not lost.
        memoryObserver = MemoryWarningObserver(application, memoryPressureFlow).also { obs ->
            application.registerComponentCallbacks(obs)
        }

        // Activity tracking next. The Application.ActivityLifecycle-
        // Callbacks contract guarantees we'll be notified for every
        // future Activity creation; we don't get backfill for already-
        // created Activities, but this provider runs early enough that
        // the launcher Activity has not yet been instantiated.
        activityObserver = ActivityLifecycleObserver().also { obs ->
            application.registerActivityLifecycleCallbacks(obs)
        }

        // Process-lifecycle + session tracking must be installed on
        // the main thread because ProcessLifecycleOwner's lifecycle
        // is annotated with @MainThread. We're usually here from the
        // platform's content-provider init which IS main-thread, but
        // Kixo.configure() can be invoked from arbitrary threads — so
        // dispatch defensively.
        runOnMainThread {
            try {
                val process = ProcessLifecycleObserver(LifecycleEventBus)
                processObserver = process
                ProcessLifecycleOwner.get().lifecycle.addObserver(process)

                val tracker = SessionTracker(LifecycleEventBus)
                sessionTracker = tracker
                tracker.start(isFirstProcess = true)
            } catch (t: Throwable) {
                // Don't propagate — a failure here means we lose
                // foreground/background tracking but the SDK keeps
                // limping along on whatever did install successfully.
                Log.e(TAG, "process-lifecycle wiring failed", t)
            }
        }
    }

    private fun tearDownPartial() {
        try {
            val a = app
            val mem = memoryObserver
            if (a != null && mem != null) {
                a.unregisterComponentCallbacks(mem)
            }
        } catch (_: Throwable) { /* swallow */ }

        try {
            val a = app
            val act = activityObserver
            if (a != null && act != null) {
                a.unregisterActivityLifecycleCallbacks(act)
            }
        } catch (_: Throwable) { /* swallow */ }

        try {
            val proc = processObserver
            if (proc != null) {
                runOnMainThread {
                    ProcessLifecycleOwner.get().lifecycle.removeObserver(proc)
                }
            }
        } catch (_: Throwable) { /* swallow */ }

        memoryObserver = null
        activityObserver = null
        processObserver = null
        sessionTracker = null
    }

    private fun runOnMainThread(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            block()
        } else {
            Handler(Looper.getMainLooper()).post(block)
        }
    }

    /**
     * SDK build-info helpers used by ProcessLifecycleObserver to
     * stamp `app_launch.version` / `app_launch.build`. Centralised
     * here so the lifecycle observer doesn't pull in a Context.
     */
    internal data class AppBuildInfo(val version: String, val build: String)

    internal fun appBuildInfo(): AppBuildInfo {
        val a = app ?: return AppBuildInfo(version = "unknown", build = "unknown")
        return try {
            val pm = a.packageManager
            val pkg = a.packageName
            val info = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                pm.getPackageInfo(pkg, android.content.pm.PackageManager.PackageInfoFlags.of(0L))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(pkg, 0)
            }
            val version = info.versionName ?: "unknown"
            val build = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                info.longVersionCode.toString()
            } else {
                @Suppress("DEPRECATION")
                info.versionCode.toString()
            }
            AppBuildInfo(version = version, build = build)
        } catch (t: Throwable) {
            Log.w(TAG, "failed to read package info for app_launch", t)
            AppBuildInfo(version = "unknown", build = "unknown")
        }
    }
}

/**
 * Memory-pressure level published on [KixoInternalBootstrap.memoryPressure].
 * Mirrors the iOS `lowMemoryMode` flag in `ReplayController.swift`.
 *
 * Mapping from [android.content.ComponentCallbacks2] trim levels:
 *   - `TRIM_MEMORY_RUNNING_LOW`         → [LOW]
 *   - `TRIM_MEMORY_RUNNING_CRITICAL`    → [CRITICAL]
 *   - `TRIM_MEMORY_COMPLETE`            → [CRITICAL]
 *
 * `TRIM_MEMORY_RUNNING_MODERATE` is intentionally not surfaced — it
 * fires aggressively on some OEM ROMs (Xiaomi MIUI in particular)
 * even when the device has plenty of headroom, and over-reacting to
 * it would needlessly degrade replay quality.
 */
internal enum class MemoryPressure {
    /** No pressure — restore normal capture concurrency. */
    NORMAL,

    /** Reduce concurrency, defer non-critical work. */
    LOW,

    /** Drop pending captures, capture concurrency = 1. */
    CRITICAL,
}
