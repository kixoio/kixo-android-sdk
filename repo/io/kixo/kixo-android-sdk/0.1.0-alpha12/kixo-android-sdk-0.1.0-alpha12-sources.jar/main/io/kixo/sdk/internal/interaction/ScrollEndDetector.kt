package io.kixo.sdk.internal.interaction

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.model.PropertyValue
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import java.lang.ref.WeakReference
import java.time.Instant
import java.util.UUID

/**
 * Detects scroll-end on every scrollable view found in an activity's
 * view tree, and emits a single `event_type=tap, tap_kind=scroll_end`
 * per settled scroll.
 *
 * **Why a separate detector and not part of [TouchInterceptor]:** the
 * iOS SDK's `ScrollObserver` is also a separate type because the
 * scroll-finger-lift detection uses the scroll view's own pan
 * recognizer, not the window's touch dispatch. The Android equivalent
 * is `View.OnScrollChangeListener` (API 23+) — observes settled-state
 * transitions inside any scrollable view (RecyclerView, ScrollView,
 * NestedScrollView, custom scrollers), including programmatic
 * scrolls that the window touch dispatch would never see.
 *
 * **Why we don't use `RecyclerView.OnScrollListener` reflectively:**
 * the listener is an abstract class, not an interface, so
 * `java.lang.reflect.Proxy` cannot synthesise an instance. Building
 * a real subclass at runtime would require ByteBuddy/cglib (heavy
 * dep, breaks AGENT_BRIEFING §5 minimal-deps rule). Falling back to
 * `View.OnScrollChangeListener` (which RecyclerView itself dispatches
 * to via `onScrollChanged` on its inherited View pipeline) gives us
 * the same scroll-position deltas with zero extra dependency.
 *
 * **Per-instance dedup window.** `View.OnScrollChangeListener` fires
 * on every pixel-delta scroll position change including programmatic
 * scroll-to and fling-pause-fling sequences. We dedupe with a 500 ms
 * minimum interval per scroll-view instance — matches iOS
 * `Configuration.scrollEndMinIntervalSec`.
 *
 * **Settle delay.** We schedule the actual emission ~300 ms after
 * the last scroll-position-change because:
 *   - Quick fling-pause-fling sequences should coalesce into one
 *     event, not two.
 *   - The replay player paints the post-scroll frame ~500 ms later
 *     anyway; tightening this further wouldn't improve UX.
 *
 * **Detector / view bookkeeping is held weakly** so a recycler view
 * being detached from the window does not leak through our bookkeep
 * map. Cleared on [detach].
 */
internal class ScrollEndDetector(
    private val eventQueue: EventQueueRef,
    private val identity: IdentityProviderRef,
    private val screen: ScreenRef,
) {

    /**
     * Convenience constructor for production wiring; tests use the
     * minimal [ScreenRef] interface. Both constructors share state.
     */
    constructor(
        eventQueue: EventQueueRef,
        identity: IdentityProviderRef,
        screenTracker: ScreenTrackerRef,
    ) : this(
        eventQueue = eventQueue,
        identity = identity,
        screen = object : ScreenRef {
            override fun currentScreenId(): String = screenTracker.currentScreenId()
        },
    )

    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * Per-scroll-view bookkeeping: last-emit wall-clock millis, a
     * weak reference back to the scroll view (for the emit payload's
     * target_class label), and the pending settled-emit Runnable so
     * we can cancel a fling-pause-fling sequence's first scheduled
     * fire.
     */
    private val state = HashMap<Int, ScrollState>()

    /** Tree-observer we install on the activity's content view. Held for cleanup. */
    private var globalLayoutListener: ViewTreeObserver.OnGlobalLayoutListener? = null
    private var rootRef: WeakReference<View>? = null

    fun attach(activity: Activity) {
        val root = activity.window?.decorView ?: return
        rootRef = WeakReference(root)
        // Walk current tree once.
        attachListenersIn(root)
        // Observe future layout changes — many apps inflate scroll
        // views asynchronously after the activity start (lazy
        // fragments, RemoteViews, etc.). The OnGlobalLayoutListener
        // is cheap (no allocation per fire) and gives us a chance to
        // wire up scroll views that didn't exist on initial walk.
        val listener = ViewTreeObserver.OnGlobalLayoutListener {
            try {
                rootRef?.get()?.let { attachListenersIn(it) }
            } catch (t: Throwable) {
                Log.w(TAG, "ScrollEndDetector global layout walk failed", t)
            }
        }
        try {
            root.viewTreeObserver?.addOnGlobalLayoutListener(listener)
            globalLayoutListener = listener
        } catch (t: Throwable) {
            Log.w(TAG, "ScrollEndDetector layout-listener install failed", t)
        }
    }

    fun detach(activity: Activity) {
        try {
            val root = rootRef?.get() ?: activity.window?.decorView
            globalLayoutListener?.let { l ->
                root?.viewTreeObserver?.removeOnGlobalLayoutListener(l)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "ScrollEndDetector.detach failed", t)
        }
        globalLayoutListener = null
        rootRef = null
        // Cancel any pending settled-emit runnables so the activity
        // can be GC'd cleanly.
        for (s in state.values) {
            s.pending?.let { mainHandler.removeCallbacks(it) }
        }
        state.clear()
    }

    /**
     * Recursive walk of the view tree, attaching a scroll listener
     * to every plausibly-scrollable child. We deliberately attach to
     * EVERY view rather than gating on `View.canScrollVertically`
     * (which returns false for empty/uninflated lists) so freshly-
     * created RecyclerViews catch their first scroll-position change.
     *
     * The cost of an idle `View.OnScrollChangeListener` is one
     * pointer per view (~8 bytes), and the platform only invokes it
     * when scroll position actually changes — so this is cheap even
     * on a 500-view tree.
     */
    private fun attachListenersIn(view: View) {
        try {
            attachGenericScrollListener(view)
            if (view is ViewGroup) {
                for (i in 0 until view.childCount) {
                    val c = view.getChildAt(i) ?: continue
                    attachListenersIn(c)
                }
            }
        } catch (t: Throwable) {
            Log.w(TAG, "ScrollEndDetector.attachListenersIn failed", t)
        }
    }

    private fun attachGenericScrollListener(view: View) {
        val key = System.identityHashCode(view)
        val st = state[key] ?: ScrollState(WeakReference(view)).also { state[key] = it }
        if (st.installed) return
        try {
            // View.OnScrollChangeListener is API 23+. minSdk is 24
            // (briefing §5) so it's always available. Fires on every
            // scroll-position change for ANY scrollable view —
            // RecyclerView, ScrollView, NestedScrollView, WebView,
            // custom scrollers — covering everything iOS's
            // `UIScrollView.panGestureRecognizer` target catches.
            val listener = View.OnScrollChangeListener { _, _, _, _, _ ->
                scheduleEmit(view)
            }
            view.setOnScrollChangeListener(listener)
            st.installed = true
            st.listener = listener
        } catch (t: Throwable) {
            // Some views can't accept a scroll-change listener (e.g.
            // disabled view subclasses). Quietly skip.
            Log.w(TAG, "Generic scroll listener install failed: ${t.message}")
        }
    }

    /**
     * Schedule a `scroll_end` emission ~300 ms in the future for
     * this scroll view. Successive calls within that window reset
     * the timer (so a fling-pause-fling sequence emits once at the
     * end). Per-instance rate limit of 500 ms enforced by
     * [SCROLL_END_MIN_INTERVAL_MS].
     */
    private fun scheduleEmit(view: View) {
        val key = System.identityHashCode(view)
        val st = state[key] ?: ScrollState(WeakReference(view)).also { state[key] = it }
        st.pending?.let { mainHandler.removeCallbacks(it) }
        val runnable = Runnable {
            val now = System.currentTimeMillis()
            if (now - st.lastEmittedAtMs < SCROLL_END_MIN_INTERVAL_MS) return@Runnable
            st.lastEmittedAtMs = now
            try {
                val v = st.viewRef.get() ?: return@Runnable
                eventQueue.enqueue(buildScrollEndEvent(v))
            } catch (t: Throwable) {
                Log.w(TAG, "ScrollEndDetector.emit failed", t)
            }
        }
        st.pending = runnable
        mainHandler.postDelayed(runnable, SETTLE_DELAY_MS)
    }

    private fun buildScrollEndEvent(view: View): KixoEvent {
        val meta = InteractionMeta(
            tapKind = InteractionMeta.Kind.SCROLL_END,
            // Sentinel (0,0) — matches iOS "no tap location" contract
            // (`ReplayController.swift` line 2078-2086).
            tapXNorm = 0f,
            tapYNorm = 0f,
            tapStartXNorm = null,
            tapStartYNorm = null,
            gestureDurationMs = 0L,
            touchCount = 1,
        )
        val props = LinkedHashMap<String, Any?>(8)
        props.putAll(meta.toPropertyMap())
        props["target_class"] = view.javaClass.simpleName
        val screenId = screen.currentScreenId()
        if (screenId.isNotEmpty()) props["screen_id"] = screenId
        return KixoEvent(
            eventId = UUID.randomUUID().toString(),
            deviceId = identity.deviceId(),
            anonymousId = identity.anonymousId(),
            userId = identity.userId(),
            sessionId = identity.sessionId(),
            fingerprint = screenId,
            eventType = KixoEventType.Tap,
            eventName = "scroll_end",
            properties = props.toJsonObject(),
            timestamp = Instant.now(),
            context = EMPTY_EVENT_CONTEXT,
        )
    }

    /**
     * Per-scroll-view state. `lastEmittedAtMs` is a wall-clock millis
     * (NOT a monotonic tick) because we compare against the same
     * clock the next emission uses. `viewRef` is weak so a recycled
     * RecyclerView item-view can be GC'd between scroll bursts.
     */
    private class ScrollState(val viewRef: WeakReference<View>) {
        var installed = false
        var listener: View.OnScrollChangeListener? = null
        var lastEmittedAtMs: Long = 0L
        var pending: Runnable? = null
    }

    /**
     * Slim seam over [ScreenTrackerRef] so [ScrollEndDetector] can be
     * unit-tested without depending on the full screen-tracker
     * surface.
     */
    internal interface ScreenRef {
        fun currentScreenId(): String
    }

    private companion object {
        const val TAG = "Kixo"

        /** ~300 ms after the last scroll-state-change before we fire. */
        const val SETTLE_DELAY_MS = 300L

        /** Per-instance dedup. Matches iOS `scrollEndMinIntervalSec` (0.5 s). */
        const val SCROLL_END_MIN_INTERVAL_MS = 500L

        @JvmStatic
        private val EMPTY_EVENT_CONTEXT: io.kixo.sdk.internal.model.EventContext =
            io.kixo.sdk.internal.model.EventContext(
                platform = "android",
                deviceModel = "",
                osVersion = "",
                locale = "",
                timezone = "",
                screenWidth = 0,
                screenHeight = 0,
                connectionType = null,
                carrier = null,
                batteryLevel = null,
                isCharging = null,
            )
    }
}

private fun Map<String, Any?>.toJsonObject(): JsonObject {
    if (isEmpty()) return JsonObject(emptyMap())
    val out = LinkedHashMap<String, JsonElement>(size)
    for ((k, v) in this) {
        val converted = PropertyValue.fromAny(v) ?: continue
        out[k] = converted
    }
    return JsonObject(out)
}
