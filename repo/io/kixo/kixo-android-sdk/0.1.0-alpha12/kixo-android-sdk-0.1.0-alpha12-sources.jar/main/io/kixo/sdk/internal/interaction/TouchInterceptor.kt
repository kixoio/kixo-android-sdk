package io.kixo.sdk.internal.interaction

import android.app.Activity
import android.util.Log
import android.view.ActionMode
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.SearchEvent
import android.view.View
import android.view.Window
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import io.kixo.sdk.internal.model.KixoEvent
import io.kixo.sdk.internal.model.KixoEventType
import io.kixo.sdk.internal.model.PropertyValue
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import java.lang.ref.WeakReference
import java.time.Instant
import java.util.UUID

/**
 * Master entry point for gesture observation. Installs a
 * [Window.Callback] proxy on each foregrounded activity's window so
 * we can observe every [MotionEvent] WITHOUT consuming it.
 *
 * **Why `Window.Callback` and not a `View.OnTouchListener` on the
 * decor view:**
 *   - `OnTouchListener` only fires when the host hasn't already
 *     consumed the event; lots of UI swallows touches before we'd see
 *     them. Window.Callback is the entry point for every touch the
 *     window receives, before any view has a chance to consume.
 *   - Window.Callback also covers system gestures (back swipe, home
 *     gesture preview), though we currently only classify content
 *     touches.
 *
 * **Delegation contract.** Every method delegates to the wrapped
 * callback — typically Android's `DecorView` (which implements
 * `Window.Callback` itself). We never return a value other than
 * what the wrapped callback returned, so installing this wrapper is
 * fully transparent to the host application.
 *
 * **Why we don't use a `GestureDetector` per Activity:** the iOS SDK
 * tried `UIGestureRecognizer` instances and they fired callbacks for
 * every `.changed` UIEvent during scroll, which was the actual root
 * cause of the April 28 perf regression. The Window.Callback pattern
 * gives us total control over what we allocate per `ACTION_MOVE`
 * (currently: nothing — see [TouchTracker]'s no-op MOVE branch).
 *
 * **Lifecycle.** Per-Activity install via Agent 7's
 * `ActivityLifecycleObserver` callback. On `onActivityStarted` we
 * wrap the window. On `onActivityStopped` we restore the original
 * callback so the activity can be GC'd cleanly. We hold the activity
 * via [WeakReference] for the duration so a delayed
 * `dispatchTouchEvent` cannot keep the activity alive past
 * destruction.
 *
 * **Threading.** `Window.Callback.dispatchTouchEvent` always runs on
 * the main (UI) thread. All state in this class is therefore
 * single-writer. Event emission is fan-out via [EventQueueRef.enqueue]
 * which dispatches into its own coroutine (per AGENT_BRIEFING.md §10
 * "every async surface uses kotlinx-coroutines").
 *
 * @param eventQueue Agent 5's `EventQueue`. We call [EventQueueRef.enqueue]
 *                   exactly once per recognised gesture.
 * @param identity   Agent 15's `IdentityManager`. Provides the
 *                   four-tuple of stable identifiers stamped on every event.
 * @param screen     Agent 9's `ScreenTracker`. Provides the screen
 *                   fingerprint + name candidate for each event.
 */
internal class TouchInterceptor(
    private val eventQueue: EventQueueRef,
    private val identity: IdentityProviderRef,
    private val screen: ScreenTrackerRef,
    /**
     * Wave 8 fan-out hook. Invoked AFTER the analytics tap event has
     * been enqueued, with the same classified [InteractionMeta] AND
     * the resolved hit [android.view.View] (or the activity's content
     * view as fallback when hit-resolution returns null).
     *
     * Default = no-op so unit tests + the legacy "analytics-only"
     * deployment can construct a TouchInterceptor without supplying
     * the replay-controller bridge. `Kixo.configure(...)` (Wave 8)
     * supplies a real `{ meta, view -> ReplayController.handleTap(meta, view) }`
     * lambda when `replayEnabled = true` AND the queue wiring
     * succeeded.
     *
     * Errors thrown by the hook are caught + logged at the call site
     * — a misbehaving downstream (e.g. ReplayController panicking
     * inside `Choreographer.postFrameCallback`) cannot crash the
     * host's touch dispatch.
     */
    private val tapHook: TapHook = TapHook { _, _ -> /* no-op default */ },
) : ActivityWindowCallback {

    private val tracker = TouchTracker()

    /**
     * Currently wrapped activities, indexed by an opaque identity
     * token (the system-generated `Activity.hashCode` is fine — we
     * never compare across processes). Held weakly so a forgotten
     * `onActivityStopped` does not pin the activity past its natural
     * lifetime.
     */
    private val wrappedActivities = HashMap<Int, WeakReference<Activity>>()

    /**
     * Originals we wrapped, keyed by activity hash. We restore on
     * `onActivityStopped` so consecutive Kixo init/teardown cycles
     * do not stack up nested proxies.
     */
    private val originals = HashMap<Int, Window.Callback>()

    /** Active scroll-end detectors, one per activity, for cleanup. */
    private val scrollDetectors = HashMap<Int, ScrollEndDetector>()

    // ─── ActivityWindowCallback ─────────────────────────────────

    override fun onActivityStarted(activity: Any) {
        val a = activity as? Activity ?: return
        attachIfNeeded(a)
    }

    override fun onActivityStopped(activity: Any) {
        val a = activity as? Activity ?: return
        detach(a)
    }

    // ─── Install / restore ──────────────────────────────────────

    private fun attachIfNeeded(activity: Activity) {
        val key = System.identityHashCode(activity)
        if (wrappedActivities.containsKey(key)) return
        val window = activity.window ?: return
        val original = window.callback ?: return
        // Wrap it. From now on every touch the platform delivers to
        // this window passes through our [dispatchTouchEvent] first.
        window.callback = ProxyCallback(original, activity, this)
        wrappedActivities[key] = WeakReference(activity)
        originals[key] = original

        // Install scroll-end detection. Done as a separate object so
        // recycler view / nested scroll listeners can be wired
        // independently without coupling to the touch dispatch path.
        val detector = ScrollEndDetector(
            eventQueue = eventQueue,
            identity = identity,
            screenTracker = screen,
        )
        detector.attach(activity)
        scrollDetectors[key] = detector
    }

    private fun detach(activity: Activity) {
        val key = System.identityHashCode(activity)
        wrappedActivities.remove(key)
        val original = originals.remove(key)
        try {
            val window = activity.window
            if (original != null && window != null && window.callback is ProxyCallback) {
                window.callback = original
            }
        } catch (t: Throwable) {
            Log.w(TAG, "TouchInterceptor.detach failed", t)
        }
        scrollDetectors.remove(key)?.detach(activity)
        // Reset tracker — pending touches are not meaningful for the
        // next activity that comes to the foreground.
        tracker.reset()
    }

    // ─── Touch handling ─────────────────────────────────────────

    /**
     * Called from our [ProxyCallback] for every touch event. We
     * feed the [TouchTracker], and if it returns a fully-formed
     * gesture batch we classify + emit.
     *
     * Returns nothing — the proxy always delegates to the wrapped
     * callback's `dispatchTouchEvent` to determine whether the event
     * was consumed. We are ALWAYS observation-only.
     */
    private fun observe(motion: MotionEvent, activity: Activity) {
        val batch = tracker.onMotion(motion) ?: return
        try {
            val window = activity.window ?: return
            val decor = window.decorView
            val width = decor.width
            val height = decor.height
            val meta = GestureClassifier.classify(batch, width, height)
            val tapX = batch.tracks[0].endX
            val tapY = batch.tracks[0].endY
            // scroll_end here means a multi-touch drag, not a
            // RecyclerView fling — the dedicated detector handles
            // those. We still emit, with a sensible default name.
            val target = TapHitResolver.resolve(activity, tapX, tapY)
            val emitted = buildEvent(meta, target)
            eventQueue.enqueue(emitted)

            // Wave 8 fan-out — let the replay controller raster a
            // frame for this tap. We pass the **decor view** (the
            // activity's full window root), NOT the hit-View. The
            // dashboard player overlays a tap dot on top of the
            // captured frame at the (tap_x_norm, tap_y_norm)
            // coordinates from `meta`, so the frame must be the
            // full window for that overlay to land in the right
            // visual context. The hit-View is still used by
            // `TapHitResolver.resolve` above to label the analytics
            // event (`target_class` / `target_text` / etc.) — it
            // just doesn't drive the snapshot.
            //
            // Wave 11 fix: pre-Wave-11 we passed the hit-View as the
            // snapshot source, which produced tiny strip-shaped
            // frames (e.g. 996×126 for a button row) that the player
            // had to letterbox into the full viewport. Mirrors iOS
            // behavior — `ReplayController.swift` snapshots
            // `view.window` not the gesture target.
            try {
                tapHook.onTap(meta, decor)
            } catch (t: Throwable) {
                Log.w(TAG, "TouchInterceptor tapHook fan-out failed", t)
            }
        } catch (t: Throwable) {
            // Briefing R6 — never crash the host app. A misbehaving
            // hit-resolver / event encoder should silently drop the
            // gesture and keep the SDK alive.
            Log.w(TAG, "TouchInterceptor classify/emit failed", t)
        }
    }

    private fun buildEvent(meta: InteractionMeta, target: TapTarget): KixoEvent {
        val name = target.bestLabel() ?: when (meta.tapKind) {
            InteractionMeta.Kind.LONG_PRESS -> "long_press"
            InteractionMeta.Kind.SWIPE_UP, InteractionMeta.Kind.SWIPE_DOWN,
            InteractionMeta.Kind.SWIPE_LEFT, InteractionMeta.Kind.SWIPE_RIGHT -> meta.tapKind.wire
            InteractionMeta.Kind.PINCH_IN, InteractionMeta.Kind.PINCH_OUT -> meta.tapKind.wire
            InteractionMeta.Kind.MULTI_TAP -> "multi_tap"
            InteractionMeta.Kind.SCROLL_END -> "scroll_end"
            InteractionMeta.Kind.TAP -> "tap"
        }

        val props = LinkedHashMap<String, Any?>(10)
        props.putAll(meta.toPropertyMap())
        target.viewClassName?.let { props["target_class"] = it }
        target.text?.let { props["target_text"] = it }
        target.contentDescription?.let { props["target_a11y"] = it }
        target.resourceEntryName?.let { props["target_resource"] = it }
        val screenId = screen.currentScreenId()
        if (screenId.isNotEmpty()) props["screen_id"] = screenId

        // Tap family events still serialise as event_type=tap so
        // the existing CH `tap` partition continues to flow. Other
        // taxonomies would route via event_type=gesture in the
        // future; for now we keep iOS parity (everything is `tap`).
        return KixoEvent(
            eventId = UUID.randomUUID().toString(),
            deviceId = identity.deviceId(),
            anonymousId = identity.anonymousId(),
            userId = identity.userId(),
            sessionId = identity.sessionId(),
            fingerprint = screenId,
            eventType = KixoEventType.Tap,
            eventName = name,
            properties = props.toJsonObject(),
            timestamp = Instant.now(),
            // EventContext is filled by the queue downstream. We
            // pass an empty placeholder here so the data class's
            // non-null contract holds; Agent 5's enqueue path
            // overwrites this with the enriched per-event context.
            context = EMPTY_EVENT_CONTEXT,
        )
    }

    // ─── Window.Callback proxy ──────────────────────────────────

    /**
     * Pure pass-through Window.Callback that copies every method to
     * the wrapped original AFTER opportunistically observing touch
     * events. We declare every method explicitly (rather than
     * dynamic-proxying) so callers introspecting the callback class
     * still see a real Window.Callback (some host SDKs rely on
     * `instanceof`).
     */
    private class ProxyCallback(
        private val wrapped: Window.Callback,
        private val activityRef: Activity,
        private val owner: TouchInterceptor,
    ) : Window.Callback {

        // The activity is captured weakly so a delayed callback after
        // `onDestroy` cannot extend its lifetime. The owner already
        // holds it weakly too; this reference exists only to make
        // the per-event observe call cheap.
        private val activity = WeakReference(activityRef)

        override fun dispatchKeyEvent(event: KeyEvent?): Boolean =
            wrapped.dispatchKeyEvent(event)

        override fun dispatchKeyShortcutEvent(event: KeyEvent?): Boolean =
            wrapped.dispatchKeyShortcutEvent(event)

        override fun dispatchTouchEvent(event: MotionEvent?): Boolean {
            // Observe BEFORE delegating so a host that consumes the
            // event still produces a Kixo signal. A try/catch shield
            // makes the observation strictly best-effort.
            if (event != null) {
                try {
                    activity.get()?.let { owner.observe(event, it) }
                } catch (t: Throwable) {
                    Log.w(TAG, "TouchInterceptor.observe threw", t)
                }
            }
            return wrapped.dispatchTouchEvent(event)
        }

        override fun dispatchTrackballEvent(event: MotionEvent?): Boolean =
            wrapped.dispatchTrackballEvent(event)

        override fun dispatchGenericMotionEvent(event: MotionEvent?): Boolean =
            wrapped.dispatchGenericMotionEvent(event)

        override fun dispatchPopulateAccessibilityEvent(event: AccessibilityEvent?): Boolean =
            wrapped.dispatchPopulateAccessibilityEvent(event)

        override fun onCreatePanelView(featureId: Int): View? =
            wrapped.onCreatePanelView(featureId)

        override fun onCreatePanelMenu(featureId: Int, menu: Menu): Boolean =
            wrapped.onCreatePanelMenu(featureId, menu)

        override fun onPreparePanel(featureId: Int, view: View?, menu: Menu): Boolean =
            wrapped.onPreparePanel(featureId, view, menu)

        override fun onMenuOpened(featureId: Int, menu: Menu): Boolean =
            wrapped.onMenuOpened(featureId, menu)

        override fun onMenuItemSelected(featureId: Int, item: MenuItem): Boolean =
            wrapped.onMenuItemSelected(featureId, item)

        override fun onWindowAttributesChanged(attrs: WindowManager.LayoutParams?) {
            wrapped.onWindowAttributesChanged(attrs)
        }

        override fun onContentChanged() {
            wrapped.onContentChanged()
        }

        override fun onWindowFocusChanged(hasFocus: Boolean) {
            wrapped.onWindowFocusChanged(hasFocus)
        }

        override fun onAttachedToWindow() {
            wrapped.onAttachedToWindow()
        }

        override fun onDetachedFromWindow() {
            wrapped.onDetachedFromWindow()
        }

        override fun onPanelClosed(featureId: Int, menu: Menu) {
            wrapped.onPanelClosed(featureId, menu)
        }

        override fun onSearchRequested(): Boolean = wrapped.onSearchRequested()

        override fun onSearchRequested(searchEvent: SearchEvent?): Boolean =
            wrapped.onSearchRequested(searchEvent)

        override fun onWindowStartingActionMode(callback: ActionMode.Callback?): ActionMode? =
            wrapped.onWindowStartingActionMode(callback)

        override fun onWindowStartingActionMode(
            callback: ActionMode.Callback?,
            type: Int,
        ): ActionMode? = wrapped.onWindowStartingActionMode(callback, type)

        override fun onActionModeStarted(mode: ActionMode?) {
            wrapped.onActionModeStarted(mode)
        }

        override fun onActionModeFinished(mode: ActionMode?) {
            wrapped.onActionModeFinished(mode)
        }
    }

    private companion object {
        const val TAG = "Kixo"

        /**
         * Placeholder context attached at gesture-emission time;
         * Agent 5's queue replaces it with the real per-event
         * EventContext (device model, locale, network, …) before
         * persistence. We avoid building the full context here
         * because the Application reference is owned by lifecycle
         * (Agent 7) and we don't want to plumb it through the
         * gesture pipeline twice.
         */
        @JvmStatic
        private val EMPTY_EVENT_CONTEXT: io.kixo.sdk.internal.model.EventContext =
            io.kixo.sdk.internal.model.EventContext(
                platform = "android",
                deviceModel = "",
                osVersion = "",
                locale = "",
                timezone = "",
                screenWidth = 0,
                screenHeight = 0,
                connectionType = null,
                carrier = null,
                batteryLevel = null,
                isCharging = null,
            )
    }
}

/**
 * Wave 8 fan-out hook. Called by [TouchInterceptor.observe] once a
 * gesture has been classified AND the analytics event has been
 * enqueued, with the resolved hit [android.view.View].
 *
 * Lives at the package level rather than nested inside
 * [TouchInterceptor] so the type can be referenced from
 * `Kixo.configure(...)` without forcing a `TouchInterceptor.TapHook`
 * import. SAM-style so the call site in `Kixo.kt` stays a one-liner
 * lambda.
 *
 * **Decoupling note (briefing §6 file ownership):** the interaction
 * folder MUST NOT compile-depend on the replay folder. This hook is
 * the SAM bridge — `Kixo.configure(...)` constructs a lambda that
 * calls `ReplayController.handleTap(meta, view)`, and the interaction
 * folder never imports the replay package. Same pattern as
 * [EventQueueRef] / [IdentityProviderRef] / [ScreenTrackerRef] —
 * declare the surface here, let the wiring layer satisfy it.
 */
internal fun interface TapHook {
    fun onTap(meta: InteractionMeta, hitView: android.view.View)
}

/** Convert a raw `Map<String, Any?>` into the `JsonObject` `KixoEvent.properties` expects. */
private fun Map<String, Any?>.toJsonObject(): JsonObject {
    if (isEmpty()) return JsonObject(emptyMap())
    val out = LinkedHashMap<String, JsonElement>(size)
    for ((k, v) in this) {
        val converted = PropertyValue.fromAny(v) ?: continue
        out[k] = converted
    }
    return JsonObject(out)
}
