package io.kixo.sdk.internal.model

import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Per-event lightweight context. Mirrors iOS `EventContext`
 * ([Models/Event.swift]). Carried inline on every event so the
 * backend can index device class / connection without joining the
 * batch-level [EnrichedContext].
 *
 * **All field names use snake_case on the wire** (AGENT_BRIEFING.md
 * R3). Property names follow Kotlin idiom and are mapped via
 * `@SerialName`.
 *
 * **Wave 5 fix (Critic 5 #27):** the four nullable fields have
 * `@EncodeDefault(Mode.ALWAYS)` so a `null` serialises as a present-
 * but-null JSON field — NOT omitted. Without this, when the SDK's
 * Json instance is configured with `encodeDefaults = false` (the
 * sane default to keep batches small), the field would disappear
 * entirely and the backend can't tell "this device has no battery
 * sensor (null)" from "the SDK didn't measure (missing)". Both end
 * up as null in ClickHouse, but the distinction matters for ingest
 * audits — present-null is a deliberate signal, missing is a bug.
 *
 * Why `Float` and not `Double` for `battery_level`: matches iOS
 * `EventContext.batteryLevel: Float?` exactly so the wire shape is
 * bit-identical. ClickHouse stores it as Float64 either way.
 */
@OptIn(ExperimentalSerializationApi::class)
@Serializable
internal data class EventContext(
    @SerialName("platform")
    val platform: String,

    @SerialName("device_model")
    val deviceModel: String,

    @SerialName("os_version")
    val osVersion: String,

    @SerialName("locale")
    val locale: String,

    @SerialName("timezone")
    val timezone: String,

    @SerialName("screen_width")
    val screenWidth: Int,

    @SerialName("screen_height")
    val screenHeight: Int,

    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("connection_type")
    val connectionType: String? = null,

    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("carrier")
    val carrier: String? = null,

    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("battery_level")
    val batteryLevel: Float? = null,

    @EncodeDefault(EncodeDefault.Mode.ALWAYS)
    @SerialName("is_charging")
    val isCharging: Boolean? = null,
)
