// Placeholder so the `internal` package exists before agents fill it
// in. Safe to delete once any other file lands in this folder.
package io.kixo.sdk.internal

internal const val PACKAGE_MARKER: String = "io.kixo.sdk.internal"
