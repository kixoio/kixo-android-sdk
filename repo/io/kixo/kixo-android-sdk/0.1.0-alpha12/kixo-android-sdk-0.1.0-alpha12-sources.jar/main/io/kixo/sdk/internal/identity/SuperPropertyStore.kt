package io.kixo.sdk.internal.identity

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonObject

/**
 * Persistent key-value store for **super properties** (Mixpanel
 * terminology) — per-session key/value pairs that decorate EVERY
 * outbound event with no per-call boilerplate.
 *
 * Mirrors the iOS counterpart's `_superProperties` dict in
 * `kixo-ios-sdk/Sources/Kixo/Identity/IdentityManager.swift`. The
 * shape is intentionally identical to [UserPropertyStore] — same
 * persistence model, same JSON serialisation, same threading
 * discipline. The split exists because the *semantics* differ:
 *
 * # User properties vs Super properties
 *
 *  | Aspect            | UserPropertyStore                         | SuperPropertyStore                                 |
 *  |-------------------|-------------------------------------------|----------------------------------------------------|
 *  | Describes         | WHO the user is (plan, country, traits)   | WHAT context the session is in (A/B variant, ref)   |
 *  | Lives on backend  | `User.traits`                             | Stamped into per-event `properties` (per-event clone) |
 *  | Cleared on `reset()` | YES (the iOS facade calls `clear()`)   | YES — iOS resets BOTH (we mirror; see [reset])      |
 *  | Cleared on `clearSuperProperties()` | n/a                      | YES (alternate explicit-only flow)                 |
 *  | Per-event override | n/a                                      | Yes — per-event `properties` win on key collision    |
 *
 * The iOS comment is precise: "active A/B variant", "build flavour",
 * "opted-in feature flags", "affiliate ref" — the kind of thing the
 * host wants stamped on every event without remembering to add it to
 * each `track()` call.
 *
 * # Reset semantics
 *
 * The iOS `reset()` clears super-properties along with everything
 * else. We honour the same contract via [reset] — but the Kixo
 * facade (Agent 1) MUST call this method explicitly from its
 * `Kixo.reset()` after [IdentityManager.reset]. The
 * [IdentityManager] doesn't know about us (avoids a circular
 * dependency); the facade ties them together.
 *
 * The host can also fire [clear] for the
 * iOS-equivalent `clearSuperProperties()` — surgical wipe without
 * touching identity (use case from the iOS comment: "user logged out,
 * forget the active A/B variants" without doing a full identity
 * reset).
 *
 * # Persistence + threading
 *
 * See [UserPropertyStore] — the storage shape is identical (one
 * SharedPreferences string entry holding a kotlinx.serialization
 * JSON snapshot). Threading uses `synchronized(lock)` for the
 * in-memory mutation and a synchronous JSON serialise inside the
 * lock so a racing snapshot reads the same view that gets persisted.
 *
 * # Why NOT inherit from [UserPropertyStore]?
 *
 * The two types have identical mechanism but different IDENTITY in
 * the type system — confusing them at a call site is the kind of
 * bug a `: UserPropertyStore` inheritance hierarchy makes easier
 * (`val store: UserPropertyStore = SuperPropertyStore.getOrCreate(...)`
 * compiles). Composition would mean another small forwarder class.
 * The simplest correct thing is two parallel singletons that share
 * the SharedPreferences namespace but have distinct types.
 */
internal class SuperPropertyStore private constructor(
    private val prefs: SharedPreferences,
    private val storageKey: String,
) {

    private val lock = Any()
    private val map: LinkedHashMap<String, Any?> = LinkedHashMap()

    init {
        // Restore from disk. Same defensive fall-through as
        // [UserPropertyStore] — corrupted blob = empty start, never
        // a host-app crash on first launch.
        val raw = try {
            prefs.getString(storageKey, null)
        } catch (t: Throwable) {
            null
        }
        if (!raw.isNullOrEmpty()) {
            try {
                val obj = JSON.parseToJsonElement(raw).jsonObject
                for ((k, v) in obj) map[k] = UserPropertyStore.unwrap(v)
            } catch (t: Throwable) {
                Log.w(TAG, "super-property restore failed; starting fresh", t)
                map.clear()
            }
        }
    }

    // ─── Public API ──────────────────────────────────────────────────

    /**
     * Set / overwrite a single super-property. Decorates every
     * future event until cleared / overwritten.
     */
    fun set(key: String, value: Any?) {
        synchronized(lock) {
            map[key] = value
            persistLocked()
        }
    }

    /** Bulk-set multiple super-properties — one disk write for the batch. */
    fun setAll(map: Map<String, Any?>) {
        if (map.isEmpty()) return
        synchronized(lock) {
            for ((k, v) in map) this.map[k] = v
            persistLocked()
        }
    }

    /**
     * Remove one super-property. Useful for per-screen overrides that
     * the host wants to retire as the user navigates away — matches
     * the iOS `unsetSuperProperty` shape.
     */
    fun unset(key: String) {
        synchronized(lock) {
            if (map.remove(key) == null) return
            persistLocked()
        }
    }

    /** Read a single super-property; null when absent. */
    fun get(key: String): Any? {
        synchronized(lock) { return map[key] }
    }

    /** Snapshot — value-copy, safe to mutate. */
    fun snapshot(): Map<String, Any?> {
        synchronized(lock) { return LinkedHashMap(map) }
    }

    /**
     * Drop ALL super-properties and remove the SharedPreferences key.
     *
     * Called from:
     *  - `Kixo.reset()` via Agent 1's facade — to mirror iOS where
     *    super-props are cleared alongside identity.
     *  - `Kixo.clearSuperProperties()` — host-explicit surgical wipe.
     */
    fun clear() {
        synchronized(lock) {
            if (map.isEmpty()) {
                // Even with empty map, remove the persisted key in case
                // a previous SDK version left something behind.
                prefs.edit().remove(storageKey).apply()
                return
            }
            map.clear()
            prefs.edit().remove(storageKey).apply()
        }
    }

    /** Alias for [clear] to mirror the [IdentityManager.reset] vocabulary. */
    fun reset() = clear()

    // ─── Internal helpers ────────────────────────────────────────────

    /** MUST be called while holding `lock`. */
    private fun persistLocked() {
        val obj = UserPropertyStore.buildJsonObjectFromMap(map)
        prefs.edit().putString(storageKey, JSON.encodeToString(JsonElement.serializer(), obj)).apply()
    }

    companion object {
        private const val TAG = "Kixo"

        /** SharedPreferences key for the super-property blob.
         *  Distinct from [UserPropertyStore.DEFAULT_STORAGE_KEY] so
         *  the two stores share a SharedPreferences file but never
         *  collide. */
        const val DEFAULT_STORAGE_KEY = "super_properties"

        /** Same encoder shape as [UserPropertyStore] — see its companion for rationale. */
        private val JSON = Json {
            encodeDefaults = true
            explicitNulls = true
            isLenient = false
        }

        @Volatile
        private var instance: SuperPropertyStore? = null

        fun getOrCreate(context: Context): SuperPropertyStore {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: build(context.applicationContext).also { instance = it }
            }
        }

        @androidx.annotation.VisibleForTesting
        fun installForTesting(value: SuperPropertyStore?) {
            synchronized(this) { instance = value }
        }

        @androidx.annotation.VisibleForTesting
        fun forTesting(
            prefs: SharedPreferences,
            storageKey: String = DEFAULT_STORAGE_KEY,
        ): SuperPropertyStore = SuperPropertyStore(prefs, storageKey)

        private fun build(appContext: Context): SuperPropertyStore {
            val prefs = appContext.getSharedPreferences(
                IdentityManager.PREFS_NAME, Context.MODE_PRIVATE
            )
            return SuperPropertyStore(prefs, DEFAULT_STORAGE_KEY)
        }
    }
}
