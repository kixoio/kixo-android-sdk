package io.kixo.sdk.internal.replay

import android.content.Context
import android.content.SharedPreferences
import kotlin.random.Random

/**
 * Decides whether THIS install records replay sessions. Mirrors iOS
 * [Sampler.swift] one-for-one — same algorithm, same persistence
 * scheme, same trigger-override contract.
 *
 * **Why on-device:** stickiness across cold starts means the same
 * install always records (or always doesn't), giving operators a
 * useful "users with replay" cohort and avoiding the analyst trap
 * of "5% of MY sessions" vs "5% of users." Plus, the SDK can
 * decide before the first config fetch lands.
 *
 * **Algorithm:**
 *   1. On first call: roll `Random.nextDouble() < sampleRate`,
 *      persist the verdict + the rate it was rolled at.
 *   2. On subsequent calls: return persisted verdict directly.
 *   3. **Re-roll on rate increase:** if the project bumps from
 *      5 % → 50 %, devices that previously rolled "out" at 5 % get
 *      a chance to roll "in" at 50 %. Devices that already rolled
 *      "in" stay in. This avoids the systematic-bias trap where
 *      operators dial sample rate up but observe nothing changes.
 *   4. **Trigger override:** when an on-device pattern detector
 *      flags rage-click / crash / dead-tap, the session forces
 *      itself ON regardless of the baseline verdict — captured
 *      under the "trigger" sampling strategy. The override is
 *      single-session and doesn't change the persistent verdict.
 *
 * **Stickiness for one session.** Even if the configured rate
 * changes mid-session, [baselineVerdictForSession] returns the SAME
 * cached answer for the lifetime of the singleton. This is what
 * "sticky" means in practice — flipping a remote-config knob does
 * NOT mid-session start/stop replay; it takes effect on the next
 * cold start. iOS [Sampler.swift] has the same behaviour because
 * `start()` runs once per process.
 *
 * **Persistence keys** live under a Kixo-specific [SharedPreferences]
 * file so they don't pollute the host app's main `SharedPreferences`.
 *
 * **Thread-safe.** Both [baselineVerdictForSession] and [reset] are
 * synchronised on the singleton instance — call from any thread.
 */
internal class Sampler internal constructor(
    private val prefs: SharedPreferences,
    private val random: () -> Double,
) {

    /**
     * Cached verdict for the lifetime of this Sampler instance. Set
     * once on first [baselineVerdictForSession] call; any subsequent
     * call returns the same answer regardless of [sampleRate]
     * fluctuations. Cleared by [reset] only.
     */
    @Volatile
    private var sessionVerdict: Boolean? = null

    /**
     * Resolve baseline verdict for the current install at the
     * configured rate. Idempotent across the singleton's lifetime —
     * the FIRST call locks in the answer for the whole session.
     *
     * Per [iOS Sampler.swift] semantics, the "rate-increase re-roll"
     * applies ONLY when the persisted verdict was `false`. Devices
     * already in stay in regardless of how the rate changes.
     */
    @Synchronized
    fun baselineVerdictForSession(sampleRate: Double): Boolean {
        sessionVerdict?.let { return it }

        val clamped = sampleRate.coerceIn(0.0, 1.0)
        val priorVerdict =
            if (prefs.contains(KEY_VERDICT)) prefs.getBoolean(KEY_VERDICT, false) else null
        // SharedPreferences uses Float for floating-point; we store as
        // String to avoid the f32→f64 precision drift on a 0.05 ↔ 5e-2
        // round-trip.
        val priorRate: Double? = prefs.getString(KEY_ROLLED_AT_RATE, null)?.toDoubleOrNull()

        // First-time roll OR configured rate increased above the rate
        // we previously rolled "out" at: re-roll using the current
        // rate. The "rate increase" path only re-rolls when prior
        // verdict was false — devices already in stay in.
        val needsRoll =
            priorVerdict == null ||
            (priorVerdict == false && (priorRate ?: 0.0) < clamped)

        val verdict: Boolean = if (needsRoll) {
            val rolled = random() < clamped
            // commit() not apply() — we want the durable write before
            // the SDK reports back, so a crash before next launch
            // doesn't re-roll and risk an inconsistent verdict.
            prefs.edit()
                .putBoolean(KEY_VERDICT, rolled)
                .putString(KEY_ROLLED_AT_RATE, clamped.toString())
                .commit()
            rolled
        } else {
            priorVerdict ?: false
        }

        sessionVerdict = verdict
        return verdict
    }

    /**
     * Force-include this session's recording regardless of the
     * persistent verdict. Used by trigger-based sampling when an
     * on-device pattern detector fires (rage-click / crash) or when
     * the customer's upstream code calls
     * `Kixo.replay.recordNow()`. Single-session — doesn't persist.
     */
    fun triggerOverride(): Boolean = true

    /**
     * Test-only / kill-switch helper. Wipes persisted verdict so the
     * NEXT [baselineVerdictForSession] call performs a fresh roll.
     * Useful for `Kixo.replay.optOut()` after a customer flips the
     * project replay setting OFF — gives them determinism that no
     * further sessions will be captured even if they later re-enable.
     */
    @Synchronized
    fun reset() {
        prefs.edit()
            .remove(KEY_VERDICT)
            .remove(KEY_ROLLED_AT_RATE)
            .commit()
        sessionVerdict = null
    }

    companion object {
        private const val PREFS_NAME = "io.kixo.replay.sampler"
        private const val KEY_VERDICT = "kixo.replay.verdict"
        private const val KEY_ROLLED_AT_RATE = "kixo.replay.rolledAtRate"

        /** Production singleton — uses `SharedPreferences` + `Math.random`. */
        @Volatile
        private var instance: Sampler? = null

        fun getInstance(context: Context): Sampler {
            instance?.let { return it }
            return synchronized(this) {
                instance ?: Sampler(
                    prefs = context.applicationContext
                        .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
                    random = { Random.Default.nextDouble() },
                ).also { instance = it }
            }
        }

        /**
         * Test-only constructor. Lets unit tests inject a fake
         * `SharedPreferences` (Robolectric supplies one) + a
         * deterministic random source.
         */
        @androidx.annotation.VisibleForTesting
        internal fun forTesting(
            prefs: SharedPreferences,
            random: () -> Double,
        ): Sampler = Sampler(prefs, random)
    }
}
