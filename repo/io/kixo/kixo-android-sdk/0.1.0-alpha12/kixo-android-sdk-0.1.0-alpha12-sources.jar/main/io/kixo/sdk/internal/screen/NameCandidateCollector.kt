package io.kixo.sdk.internal.screen

import android.app.Activity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Source of a screen-name candidate. Mirrors iOS [NameCandidate.Source].
 *
 * Each source carries an INTRINSIC confidence weight — the backend
 * `ScreenNameCandidate` voting aggregator uses
 * `confidence * log(count + 1) * sourceWeight` to pick the winner
 * across sessions. This means a single high-confidence
 * `kixo.screen("Login")` override beats 50 sessions of weak
 * `largestTextView` heuristic, while still letting the heuristic win
 * when no manual annotation exists.
 *
 * Wire-format snake_case mirrors iOS so the backend's existing
 * `/api/sdk/batch` event-properties decoder accepts the same field
 * shape from either platform with no per-platform branching.
 */
@Serializable
internal enum class NameSource {
    /** [Kixo.screen("name")] explicit override. Highest weight. */
    @SerialName("explicit_override") ExplicitOverride,

    /** Activity title set via [Activity.setTitle] / `<activity android:label>`. */
    @SerialName("activity_title") ActivityTitle,

    /** Toolbar / ActionBar title — typed at the top of most screens. */
    @SerialName("toolbar_title") ToolbarTitle,

    /** Fragment tag (`fragment.tag`) or class simple name fallback. */
    @SerialName("fragment_tag") FragmentTag,

    /** Compose Navigation route — `NavController.currentBackStackEntry.destination.route`. */
    @SerialName("compose_route") ComposeRoute,

    /** Largest [TextView] in the top 1/3 of the root view (likely heading). */
    @SerialName("top_label") TopLabel,

    /**
     * Fingerprint hex fallback — `Screen_<hex>`. Always available
     * because [ScreenFingerprint.compute] never returns null.
     */
    @SerialName("fingerprint") Fingerprint,
}

/**
 * Multi-source screen-name candidate. Mirrors iOS
 * [NameCandidate](kixo-ios-sdk/Sources/Kixo/AutoTrack/NameCandidateCollector.swift).
 *
 * **Why a list, not a single string:** v0 emitted `auto_name` as
 * whichever source returned first, locking that choice into the
 * backend's `ScreenNameCandidate` table. If a weak source (e.g.
 * a generic Toolbar title "Activity") fired before a strong one
 * (e.g. an explicit `Kixo.screen("Login")`), the weak name shadowed
 * the strong one in the backend's voting until the next deploy.
 *
 * Emitting a LIST lets the server pick the highest-weighted
 * candidate per `(fingerprint × text × source)` aggregation rather
 * than racing on emission order.
 */
@Serializable
internal data class NameCandidate(
    /** Cleaned candidate text (trimmed, length-capped at 80 chars). */
    val value: String,
    /** Where this candidate came from. */
    val source: NameSource,
    /**
     * Intrinsic confidence in the [0.0, 1.0] range. Server-side
     * vote weights this together with cross-session count to pick
     * the canonical name. Guidance:
     *  - 1.00 — explicit override (manual ground truth)
     *  - 0.95 — activity title / fragment tag from `setTitle`
     *  - 0.90 — toolbar title (manually set in XML)
     *  - 0.80 — Compose nav route (declared by developer)
     *  - 0.65 — largest top label (heuristic)
     *  - 0.10 — fingerprint fallback (always-available, low signal)
     */
    val confidence: Double,
)

/**
 * Collects multi-source screen-name candidates for an Android screen.
 * Mirrors iOS [NameCandidateCollector.collectCheap] — pure cheap
 * heuristics, ZERO LLM / Vision / cloud inference per AGENT_BRIEFING.md
 * §3 R1 ("zero automatic LLM/Vision calls in the SDK").
 *
 * **Threading:** call from the main thread only — every input
 * (Activity title, Toolbar title, view hierarchy walk) requires
 * main-thread access. ~2 ms on Pixel 6 for a typical screen.
 *
 * **Backend contract:** the candidate list ships inside event
 * properties as `_kixo_name_candidates` (matching iOS); the
 * `/api/sdk/batch` route extracts and upserts `ScreenNameCandidate`
 * rows for cross-session voting on the canonical name.
 */
internal object NameCandidateCollector {

    /** Max length of any candidate value. Mirrors iOS truncation. */
    private const val MAX_VALUE_LENGTH = 80

    /** Top fraction of root view searched for the heading-label heuristic. */
    private const val TOP_BAND_FRACTION = 1.0 / 3.0

    /** Bounded-walk caps for [findLargestTopLabel]. */
    private const val MAX_LABEL_WALK_DEPTH = 6
    private const val MAX_LABEL_WALK_BREADTH = 40

    /**
     * Collect every available cheap candidate. Returns in priority
     * order (highest confidence first); duplicates by `value` are
     * kept because the backend votes by source independently
     * (a string that comes from BOTH activity title AND top label
     * is doubly weighted, which is what we want).
     *
     * @param activity Optional foregrounded [Activity] — supplies the
     *   activity title. Pass `null` if not available (e.g. fragment-
     *   only emission outside an activity context).
     * @param fragment Optional `androidx.fragment.app.Fragment`
     *   currently shown — typed as [Any] so this module doesn't
     *   compile-depend on `androidx.fragment` (it ships as a host-
     *   provided dep). We extract the tag + class name reflectively.
     *   Pass `null` for activity-only screens.
     * @param composeRoute Optional Compose Navigation route. Pass
     *   `null` if no NavController is bound.
     * @param explicitName Optional [Kixo.screen("Name")] override
     *   set immediately before the screen-tracker fires.
     * @param rootView Optional content view — required for the
     *   top-label heuristic and for the fingerprint fallback. May be
     *   null in degenerate cases (no Activity yet).
     * @param fingerprint Always present — already computed by the
     *   caller via [ScreenFingerprint.compute].
     */
    fun collect(
        activity: Activity? = null,
        fragment: Any? = null,
        composeRoute: String? = null,
        explicitName: String? = null,
        rootView: View? = null,
        fingerprint: String,
    ): List<NameCandidate> {
        val out = ArrayList<NameCandidate>(7)

        // 1. Explicit override — strongest possible signal.
        explicitName?.cleaned()?.let {
            out += NameCandidate(it, NameSource.ExplicitOverride, confidence = 1.0)
        }

        // 2. Activity title.
        activity?.title?.toString()?.cleaned()?.let {
            out += NameCandidate(it, NameSource.ActivityTitle, confidence = 0.95)
        }

        // 3. Toolbar / ActionBar title.
        activity?.let { findToolbarTitle(it) }?.cleaned()?.let {
            out += NameCandidate(it, NameSource.ToolbarTitle, confidence = 0.90)
        }

        // 4. Fragment tag, then class simple name as fallback.
        // Reflective so we don't compile-depend on androidx.fragment.
        fragment?.let { frag ->
            val tagValue = readFragmentTag(frag)?.cleaned()
            val nameValue = tagValue ?: run {
                // Strip the package prefix; `MyAppFragment` → MyApp.
                frag.javaClass.simpleName
                    .removeSuffix("Fragment")
                    .removeSuffix("Frag")
                    .ifEmpty { frag.javaClass.simpleName }
                    .cleaned()
            }
            nameValue?.let {
                out += NameCandidate(it, NameSource.FragmentTag, confidence = 0.92)
            }
        }

        // 5. Compose nav route — usually short ("login", "home/{id}").
        composeRoute?.cleaned()?.let {
            out += NameCandidate(it, NameSource.ComposeRoute, confidence = 0.80)
        }

        // 6. Largest top-band TextView — heading heuristic.
        // PII filter (Critic 4 HIGH): the largest top-of-screen label
        // is the most likely place for a real-world heading like
        // "Welcome alex@example.com" or "Account · 4242". We pass the
        // extracted text through PiiFilter.redact before it lands as
        // a candidate, so emails / phones / SSNs / Luhn-card / JWTs /
        // IBANs become `[email]` / `[phone]` / etc. before crossing
        // the wire as `_kixo_name_candidates`.
        rootView?.let { findLargestTopLabel(it) }?.let(piiRedactor())?.cleaned()?.let {
            out += NameCandidate(it, NameSource.TopLabel, confidence = 0.65)
        }

        // 7. Fingerprint fallback — always available, lowest weight.
        // The backend treats `Screen_<hex>` specially: it WILL be
        // overwritten by any non-fingerprint candidate that ever
        // arrives in a future session, so this is purely a "we never
        // saw a real name for this screen" placeholder.
        out += NameCandidate(
            "Screen_$fingerprint",
            NameSource.Fingerprint,
            confidence = 0.10,
        )

        return out
    }

    // ─── Heuristic helpers ──────────────────────────────────────────

    /**
     * Read `Fragment.getTag()` reflectively. We don't compile against
     * `androidx.fragment` — the host app provides it, and apps that
     * use a Fragment-less architecture (Compose-only) shouldn't pay
     * for the dep. Reflective lookup costs ~5 µs per call and lets
     * the integration silently no-op when fragment is absent.
     */
    private fun readFragmentTag(fragment: Any): String? {
        return try {
            val m = fragment.javaClass.getMethod("getTag")
            m.invoke(fragment) as? String
        } catch (_: Throwable) {
            null
        }
    }


    /**
     * Find the title of a Toolbar / ActionBar in the activity's
     * content view. We don't compile against `androidx.appcompat`
     * (would force a transitive dep on every consumer), so the
     * detection is class-name based: anything whose class simple
     * name is `Toolbar` or ends with `Toolbar` is checked for a
     * `getTitle` reflective lookup.
     */
    private fun findToolbarTitle(activity: Activity): String? {
        // First: ActionBar.title via Activity.actionBar (deprecated
        // but still valid for non-Material Activity subclasses).
        @Suppress("DEPRECATION")
        activity.actionBar?.title?.toString()?.takeIf { it.isNotBlank() }?.let { return it }

        val content = activity.findViewById<View>(android.R.id.content) as? ViewGroup
            ?: return null

        return findToolbarTitleInTree(content, depth = 0)
    }

    private fun findToolbarTitleInTree(view: View, depth: Int): String? {
        if (depth > MAX_LABEL_WALK_DEPTH) return null
        val className = view.javaClass.simpleName
        if (className == "Toolbar" || className.endsWith("Toolbar")) {
            // Reflective `getTitle()` — works for both
            // `android.widget.Toolbar` (API 21+) and
            // `androidx.appcompat.widget.Toolbar` without a compile-
            // time dep.
            try {
                val titleMethod = view.javaClass.getMethod("getTitle")
                val title = titleMethod.invoke(view) as? CharSequence
                if (!title.isNullOrBlank()) return title.toString()
            } catch (_: Throwable) {
                // Class doesn't have getTitle — keep walking.
            }
        }
        if (view !is ViewGroup) return null
        val breadth = minOf(view.childCount, MAX_LABEL_WALK_BREADTH)
        for (i in 0 until breadth) {
            val child = view.getChildAt(i) ?: continue
            findToolbarTitleInTree(child, depth + 1)?.let { return it }
        }
        return null
    }

    /**
     * Find the largest [TextView] in the top [TOP_BAND_FRACTION] of
     * [root]. Mirrors iOS `findLargestTopBandLabel` — score is
     * `fontSize * (1 - yPosition / rootHeight)` so labels closer to
     * the top with bigger text win.
     *
     * Bounded depth + breadth so a pathologically large hierarchy
     * can't pin the main thread.
     */
    private fun findLargestTopLabel(root: View): String? {
        val rootHeight = root.height.takeIf { it > 0 } ?: return null
        val topBandPx = (rootHeight * TOP_BAND_FRACTION).toInt()

        var bestText: String? = null
        // Score floor of 18 mirrors iOS — avoids picking up small body
        // text on screens with no real heading.
        var bestScore = 18.0

        // Depth-first walk — wide trees produce many candidates; the
        // depth cap at [MAX_LABEL_WALK_DEPTH] keeps the cost bounded
        // regardless.
        val rootLoc = IntArray(2).also { root.getLocationOnScreen(it) }

        fun visit(view: View, depth: Int) {
            if (depth > MAX_LABEL_WALK_DEPTH) return
            if (view.visibility != View.VISIBLE) return

            if (view is TextView) {
                val text = view.text?.toString()?.cleaned()
                if (text != null && text.length in 2..MAX_VALUE_LENGTH && !text.contains('\n')) {
                    val loc = IntArray(2).also { view.getLocationOnScreen(it) }
                    val yInRoot = loc[1] - rootLoc[1]
                    if (yInRoot in 0 until topBandPx) {
                        val fontSize = view.textSize.toDouble() // px
                        val posScore = 1.0 - (yInRoot.toDouble() / rootHeight)
                        val score = fontSize * posScore
                        if (score > bestScore) {
                            bestScore = score
                            bestText = text
                        }
                    }
                }
            }

            if (view is ViewGroup) {
                val breadth = minOf(view.childCount, MAX_LABEL_WALK_BREADTH)
                for (i in 0 until breadth) {
                    val child = view.getChildAt(i) ?: continue
                    visit(child, depth + 1)
                }
            }
        }

        visit(root, depth = 0)
        return bestText
    }

    /**
     * Trim, length-cap, and reject obviously-empty values. Returns
     * null if the result is empty or the input was null.
     */
    private fun String?.cleaned(): String? {
        if (this == null) return null
        val trimmed = trim()
        if (trimmed.isEmpty()) return null
        return if (trimmed.length > MAX_VALUE_LENGTH) {
            trimmed.substring(0, MAX_VALUE_LENGTH)
        } else {
            trimmed
        }
    }

    /**
     * Reflection-cached `(String) -> String` redactor that delegates
     * to [io.kixo.sdk.internal.privacy.PiiFilter.redact]. We don't
     * declare a hard import on the privacy package because Agent 9's
     * screen folder shouldn't compile-depend on Agent 10's package
     * per AGENT_BRIEFING §6 file-ownership rule — the wiring should
     * ideally come via constructor injection from Agent 1's
     * bootstrap. Until that bootstrap lands, reflection is the
     * loose-coupling stand-in. Identity fallback when the privacy
     * module isn't on the classpath (best-effort contract).
     */
    @Volatile
    private var cachedRedactor: ((String) -> String)? = null

    private fun piiRedactor(): (String) -> String {
        cachedRedactor?.let { return it }
        val resolved: (String) -> String = try {
            val cls = Class.forName("io.kixo.sdk.internal.privacy.PiiFilter")
            val ctor = cls.getDeclaredConstructor(
                Class.forName("io.kixo.sdk.internal.privacy.EntityTagger"),
            )
            ctor.isAccessible = true
            val instance = ctor.newInstance(null as Any?)
            val redactMethod = cls.getMethod("redact", String::class.java)
            val fn: (String) -> String = { input ->
                try {
                    (redactMethod.invoke(instance, input) as? String) ?: input
                } catch (_: Throwable) {
                    input
                }
            }
            fn
        } catch (_: Throwable) {
            { it }
        }
        cachedRedactor = resolved
        return resolved
    }
}

/**
 * Pick the highest-confidence candidate's value. Used by [ScreenTracker]
 * to populate the `screen_name` event field while the full candidate
 * list also rides along in `_kixo_name_candidates` for backend voting.
 *
 * Returns `"Screen_unknown"` if [candidates] is empty (degenerate; the
 * fingerprint fallback should always be present so this is defensive).
 */
internal fun List<NameCandidate>.bestName(): String =
    maxByOrNull { it.confidence }?.value ?: "Screen_unknown"
