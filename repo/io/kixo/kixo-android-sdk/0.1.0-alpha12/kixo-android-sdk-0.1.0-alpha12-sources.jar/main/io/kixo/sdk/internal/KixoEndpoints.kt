package io.kixo.sdk.internal

/**
 * Single source of truth for the SDK ingest base URL per environment.
 *
 * Wave 5 fix for the duplicated host strings that were copy-pasted
 * across `KixoConfiguration.defaultApiHost`, `EnvironmentDetector.kt`,
 * `ConfigHolder.UNINITIALISED.apiHost`, and several doc comments.
 * Adding a new env (e.g. `"qa"`) is now a one-line edit here instead
 * of a grep-and-pray sweep.
 *
 * Internal-only: customers SHOULD NOT depend on these strings; they
 * pass the environment NAME (`"development"` / `"staging"` /
 * `"production"`) and the SDK resolves the host. If a customer needs
 * a custom backend, they pass `KixoConfiguration.Builder.apiHost(...)`
 * which overrides resolution entirely.
 *
 * The wire-token alignment with `KixoConfiguration.environment` is:
 *
 * | env name        | host                            |
 * |-----------------|---------------------------------|
 * | `"development"` | https://sdk.dev.kixo.io         |
 * | `"staging"`     | https://sdk.staging.kixo.io     |
 * | anything else   | https://sdk.kixo.io (production)|
 */
internal object KixoEndpoints {
    const val DEV: String = "https://sdk.dev.kixo.io"
    const val STAGING: String = "https://sdk.staging.kixo.io"
    const val PROD: String = "https://sdk.kixo.io"

    /**
     * Resolve a base URL from an environment name. Unknown values fall
     * through to [PROD] — safest default (won't accidentally ship
     * production data to dev or vice-versa). Document this in any
     * call site that exposes the resolved value to callers.
     */
    fun forEnvironment(name: String): String = when (name) {
        "development" -> DEV
        "staging" -> STAGING
        else -> PROD
    }
}
