package io.kixo.sdk.internal.replay

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import android.view.Choreographer
import android.view.View
import io.kixo.sdk.internal.interaction.InteractionMeta
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonObject
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Top-level orchestrator for the replay capture pipeline. Wires
 * together the rest of the [io.kixo.sdk.internal.replay] package:
 *
 *  - [Sampler] — sticky reservoir sampling decision
 *  - [ThermalBackoff] — pauses capture under thermal / battery / power load
 *  - [CaptureSlot] — bounded concurrency on in-flight captures
 *  - [RingBuffer] — single-slot pre-tap frame holder
 *  - [FrameSnapshotter] — `Bitmap` raster from a `View`
 *  - [StructuralSnapshotter] — JSON DOM-like view-tree sidecar
 *  - [OcrExtractor] — on-device ML Kit text recognition
 *  - [ScreenIdentityHelper] — joins frames to Agent 9's screen tracker
 *
 * Mirrors iOS [ReplayController.swift] semantics adapted for Android:
 *  - The iOS WindowEventInterceptor is replaced by Agent 8's touch
 *    tracker which calls [handleTap] directly with a classified
 *    [InteractionMeta].
 *  - The iOS post-frame "next vsync" callback is implemented via
 *    [Choreographer.postFrameCallback].
 *  - The iOS `BackgroundUploader` is owned by Agent 14 — this
 *    controller hands it the captured assets via [ReplayUploaderRef].
 *
 * **Lifecycle:**
 *  - [start] — invoked by `Kixo.configure(...)` ONCE per process when
 *    [ReplayConfig.replaySampleRate] passes the sampler verdict AND
 *    the device-tier check (handled upstream). Wires the thermal
 *    listener, posts the `/replay/session/start` request via the
 *    upload-ref, then transitions to `isActive=true`.
 *  - [stop] — called from `appBackgrounded` to seal the in-flight
 *    session.
 *  - [optOut] / [optIn] — customer kill switches.
 *
 * **Anti-crash. Per AGENT_BRIEFING §3 R6** all error paths swallow
 * + log. Network fail → upload re-enqueued by Agent 14. Bitmap OOM
 * → frame dropped, event still emitted with metadata. Memory
 * warning → [CaptureSlot.tightenForMemoryPressure] +
 * [ThermalBackoff.externalPause]. The host app must NEVER crash
 * because replay misbehaved.
 */
internal object ReplayController {

    private const val TAG = "Kixo"

    /** Singleton scope — supervisor so a single failure doesn't tear down peers. */
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val started = AtomicBoolean(false)

    /**
     * Composite gate: `false` while in any of:
     *  - sampler verdict was "out"
     *  - operator called [optOut]
     *  - thermal / power / battery / memory trip is active
     *
     * The closure handed to [ThermalBackoff.onStateChange] flips
     * this on trip; the trip recovery flips it back.
     */
    private val active = AtomicBoolean(false)

    private val optedOut = AtomicBoolean(false)

    /**
     * Pre-tap frame holder. Set after each `View.draw()` capture so
     * the next tap can grab "the frame just before the user touched
     * the screen." Cleared on memory warning + stop.
     */
    private val ringBuffer = RingBuffer<Bitmap>()

    /**
     * Last-known screen identity so [handleTap] can detect "same
     * screen as last tap" and skip redundant uploads when
     * [ReplayConfig] is tuned for dedup. Mirrors iOS
     * `lastScreenIdentity`. Atomic because reads happen on main
     * (capture pipeline) and writes happen on Default (the upload
     * coroutine).
     */
    @Volatile
    private var lastScreenIdentity: ScreenIdentity? = null

    /**
     * Increments per captured tap. Aligned 1:1 with the seq the
     * upload pipeline (Agent 14) uses to pre-allocate signed URLs.
     */
    private val nextSeq = AtomicLong(0L)

    /**
     * Last scroll-end capture wall time (`SystemClock.elapsedRealtime`).
     * Honours [ReplayConfig.scrollEndMinIntervalSec] rate-limit so a
     * long flick stream produces ≤ 1 frame per N-second window.
     */
    @Volatile
    private var lastScrollEndElapsedMs: Long = 0L

    /** Held during the lifetime of this start; cleared by [stop]. */
    @Volatile
    private var config: ReplayConfig? = null

    @Volatile
    private var captureSlot: CaptureSlot? = null

    @Volatile
    private var thermalBackoff: ThermalBackoff? = null

    @Volatile
    private var ocrExtractor: OcrExtractor? = null

    @Volatile
    private var structuralSnapshotter: StructuralSnapshotter? = null

    @Volatile
    private var screenIdentity: ScreenIdentityHelper? = null

    @Volatile
    private var sampler: Sampler? = null

    /**
     * Agent 14's upload-pipeline reference. Stub interface to keep
     * this folder package-isolated; the real type lives in
     * `io.kixo.sdk.internal.replay.upload.ReplayUploader`. See the
     * companion stub below.
     */
    @Volatile
    private var uploader: ReplayUploaderRef? = null

    /**
     * Cold-start cancellation token — when [stop] fires, the
     * post-frame callback retains the [Job] reference and aborts so
     * we don't post an upload past the session boundary.
     */
    @Volatile
    private var sessionJob: Job? = null

    /**
     * Bring the replay subsystem online. Idempotent — calling twice
     * is a cheap no-op. The actual `/api/sdk/replay/session/start`
     * POST is delegated to Agent 14's [uploader] which calls back
     * with the initial signed-URL pool.
     *
     * Sampler verdict gates everything — when "out", this method
     * returns without wiring anything (saves the entire memory +
     * lifecycle observer cost on the 95% of installs not in the
     * reservoir).
     */
    fun start(
        context: Context,
        config: ReplayConfig,
        uploader: ReplayUploaderRef,
        sampler: Sampler = Sampler.getInstance(context),
        thermalBackoff: ThermalBackoff = ThermalBackoff.from(context),
        screenIdentityHelper: ScreenIdentityHelper = ScreenIdentityHelper(),
        piiSanitizer: (String) -> String = { it },
    ) {
        if (optedOut.get()) {
            Log.d(TAG, "Replay start skipped: opted out")
            return
        }
        if (!started.compareAndSet(false, true)) {
            // Idempotent — second start is a no-op.
            return
        }

        if (!sampler.baselineVerdictForSession(config.replaySampleRate)) {
            // Sampler said "out" — wire nothing, leave the singleton
            // dormant. A future trigger-override (rage-click / crash)
            // would re-evaluate; we don't wire that path until the
            // Agent 12 / 15 detectors are in.
            started.set(false)
            return
        }

        this.config = config
        this.sampler = sampler
        this.thermalBackoff = thermalBackoff
        this.captureSlot = CaptureSlot(baseline = config.maxConcurrentCaptures)
        this.ocrExtractor = OcrExtractor(config = config, piiSanitizer = piiSanitizer)
        this.structuralSnapshotter = StructuralSnapshotter(piiSanitizer = piiSanitizer)
        this.screenIdentity = screenIdentityHelper
        this.uploader = uploader

        // Wire ThermalBackoff into the active gate before opening
        // the session — if the device is already hot at start time,
        // we want to stay paused until recovery.
        thermalBackoff.onStateChange = { shouldPause, reason ->
            val wasActive = active.getAndSet(!shouldPause)
            if (wasActive != !shouldPause) {
                Log.d(TAG, "Replay state change: paused=$shouldPause reason=${reason.wire}")
            }
        }
        thermalBackoff.start()
        // Initial state: enabled unless thermal already tripped.
        active.set(thermalBackoff.isCaptureAllowed())

        // Hand off /replay/session/start to Agent 14. The uploader
        // calls back with the gcs_prefix + initial signed URLs; we
        // don't gate captures on that callback (taps that arrive
        // pre-callback queue server-side via Agent 14's pre-session
        // buffer).
        sessionJob = scope.launch {
            try {
                uploader.beginSession(config = config)
            } catch (t: Throwable) {
                // Non-fatal — Agent 14 owns the retry. We log and
                // continue; captures will queue locally and Agent 14
                // will drain them once the session opens.
                Log.w(TAG, "uploader.beginSession failed", t)
            }
        }
    }

    /**
     * Seal the in-flight session. Called by `Kixo.flush()` and on
     * `appBackgrounded`. Frames already on disk continue uploading
     * via Agent 14's WorkManager job — we just stop accepting new
     * captures.
     *
     * Idempotent.
     */
    fun stop() {
        if (!started.compareAndSet(true, false)) return
        active.set(false)
        sessionJob?.cancel()
        sessionJob = null

        // Capture references before nulling fields so the
        // session-end coroutine can still reach them. Otherwise the
        // launch below would race the field-null assignments at the
        // bottom and observe `uploader = null`.
        val capturedUploader = uploader
        val capturedOcr = ocrExtractor
        val capturedThermal = thermalBackoff

        // Drop the pre-tap frame buffer immediately — held bitmap
        // is ~10 MB.
        ringBuffer.take()?.recycle()

        try {
            capturedOcr?.shutdown()
        } catch (_: Throwable) { /* swallow */ }

        try {
            capturedThermal?.stop()
        } catch (_: Throwable) { /* swallow */ }

        // Tell Agent 14 to seal the session — it handles the
        // /replay/session/end POST and signals WorkManager to
        // upload any in-flight frames at next opportunity.
        if (capturedUploader != null) {
            scope.launch {
                try {
                    capturedUploader.endSession()
                } catch (t: Throwable) {
                    Log.w(TAG, "uploader.endSession failed", t)
                }
            }
        }

        nextSeq.set(0L)
        lastScreenIdentity = null
        lastScrollEndElapsedMs = 0L

        captureSlot = null
        thermalBackoff = null
        ocrExtractor = null
        structuralSnapshotter = null
        screenIdentity = null
        sampler = null
        config = null
        uploader = null
    }

    /** Customer kill switch. Subsequent [start] calls are no-ops until [optIn]. */
    fun optOut() {
        optedOut.set(true)
        sampler?.reset()
        stop()
    }

    /** Re-enable replay after a previous [optOut]. NEXT [start] call wires up. */
    fun optIn() {
        optedOut.set(false)
    }

    /** Whether replay is currently capturing. False during opt-out / thermal trip / pre-start. */
    fun isActive(): Boolean = started.get() && active.get() && !optedOut.get()

    /**
     * Called by Agent 8's touch tracker once a gesture has been
     * fully classified. The supplied `view` is the View that hit-
     * tested under the tap; `null` when the tap landed on system
     * chrome with no Activity-owned target.
     *
     * Pipeline (mirrors iOS `handleTap` minus the iOS-specific
     * UIWindow swizzle):
     *
     *  1. `isActive()` + `tryAcquireCaptureSlot()` gates
     *  2. Snapshot the [RingBuffer] for the pre-frame OR fresh
     *     capture when [ReplayConfig.preFrameEnabled]
     *  3. Schedule post-frame on next vsync via
     *     [Choreographer.postFrameCallback]
     *  4. After post-frame: parallel launch
     *     (a) [StructuralSnapshotter.snapshot]
     *     (b) [OcrExtractor.extract]
     *  5. Hand bitmaps + structural JSON + OCR text to Agent 14's
     *     [ReplayUploaderRef.uploadCapture]
     *  6. [CaptureSlot.release]
     */
    fun handleTap(meta: InteractionMeta, view: View?) {
        val cfg = config ?: return
        val slot = captureSlot ?: return
        val uploader = uploader ?: return

        if (!isActive()) {
            // Still emit the metadata-only event so dropoff analytics
            // see the gesture even when capture is disabled. The
            // event itself is owned by the caller (Agent 8's
            // TouchTracker enqueues it via Agent 5's EventQueue) —
            // we just don't add a frame.
            return
        }

        if (!cfg.frameCaptureEnabled) {
            // Master gate is OFF — emit metadata only.
            return
        }

        if (!slot.tryAcquire()) {
            // Slot full → drop. Avoids the iOS C.3v3 OOM scenario
            // where rapid tap+scroll piled up CGImage retains.
            return
        }

        val target = view ?: run {
            // No View target → release immediately and skip. We
            // could fall back to the Activity's decorView via
            // KixoInternalBootstrap.currentActivity()?.window, but
            // Agent 7 owns that path; the touch tracker (Agent 8)
            // already passed us the resolved hit-test View.
            slot.release()
            return
        }

        // Pre-frame. iOS `preFrameEnabled = false` default — we
        // honour the same default. With it OFF, the previous
        // gesture's POST-frame is shown by the player as THIS
        // gesture's "before" state (carry-forward semantic).
        val preFrame: Bitmap? = if (cfg.preFrameEnabled) {
            FrameSnapshotter.snapshot(target)
        } else {
            ringBuffer.peek()
        }

        // Schedule post-frame. Choreographer fires on the NEXT vsync
        // after layout has committed — guaranteed-fresh snapshot.
        Choreographer.getInstance().postFrameCallback {
            // After the next vsync — capture the post-frame on main,
            // then immediately hand off everything else to a
            // background coroutine.
            val postFrame: Bitmap? = FrameSnapshotter.snapshot(target)

            val structural: JsonObject? = if (cfg.structuralSnapshotEnabled) {
                try {
                    structuralSnapshotter?.snapshot(target)
                } catch (t: Throwable) {
                    Log.w(TAG, "structuralSnapshotter.snapshot failed", t)
                    null
                }
            } else {
                null
            }

            // Capture seq + screen identity before going async so the
            // values are pinned at vsync time, not at upload time
            // (which could land seconds later if the scope is busy).
            val seq = nextSeq.getAndIncrement()
            val identity = screenIdentity?.currentScreenIdentity()
            lastScreenIdentity = identity

            // Bitmap stash for the next tap's pre-frame. Note this
            // happens BEFORE the upload so even if upload is slow,
            // the next tap has a fresh "before" frame to carry.
            postFrame?.let { ringBuffer.set(it) }

            // Off-main: OCR + upload. We do NOT wait — the
            // capture-slot is released as soon as the upload coroutine
            // starts so the next tap can fire immediately.
            slot.release()

            scope.launch {
                handleCaptureAsync(
                    seq = seq,
                    meta = meta,
                    identity = identity,
                    preFrame = preFrame,
                    postFrame = postFrame,
                    structural = structural,
                    uploader = uploader,
                )
            }
        }
    }

    /**
     * Called by Agent 8's [io.kixo.sdk.internal.interaction.ScrollEndDetector]
     * when a scroll has settled (RecyclerView reached
     * SCROLL_STATE_IDLE after a settled drag). Captures the post-
     * scroll state so the player advances even when the user only
     * scrolls and never taps.
     *
     * Honours [ReplayConfig.scrollEndCaptureEnabled] master gate
     * AND the [ReplayConfig.scrollEndMinIntervalSec] rate limit so
     * a long flick stream doesn't generate 60 captures per second.
     */
    fun handleScrollEnd(view: View?) {
        val cfg = config ?: return
        if (!cfg.scrollEndCaptureEnabled) return
        if (!isActive()) return

        val now = android.os.SystemClock.elapsedRealtime()
        val minIntervalMs = (cfg.scrollEndMinIntervalSec * 1000).toLong()
        val last = lastScrollEndElapsedMs
        if (last != 0L && (now - last) < minIntervalMs) return
        lastScrollEndElapsedMs = now

        // Synthesize a SCROLL_END "interaction" so the upload
        // pipeline can attach the gesture kind to the captured
        // frame. Coords are sentinel (0, 0) — player ignores them
        // for SCROLL_END.
        val syntheticMeta = InteractionMeta(
            tapKind = InteractionMeta.Kind.SCROLL_END,
            tapXNorm = 0f,
            tapYNorm = 0f,
            gestureDurationMs = 0L,
            touchCount = 1,
        )
        handleTap(syntheticMeta, view)
    }

    /**
     * Off-main capture pipeline: OCR + upload hand-off. Errors
     * swallow + log per AGENT_BRIEFING R6.
     */
    private suspend fun handleCaptureAsync(
        seq: Long,
        meta: InteractionMeta,
        identity: ScreenIdentity?,
        preFrame: Bitmap?,
        postFrame: Bitmap?,
        structural: JsonObject?,
        uploader: ReplayUploaderRef,
    ) {
        val ocr = ocrExtractor
        val ocrText: String = if (postFrame != null && ocr != null) {
            try {
                ocr.extract(postFrame)
            } catch (t: Throwable) {
                Log.w(TAG, "ocrExtractor.extract failed", t)
                ""
            }
        } else {
            ""
        }

        // Critic 13 (HIGH) — bitmap recycle leak on uploader failure.
        // Under sustained network failures the caught Throwable's stack
        // frames pin the pre/postFrame Bitmaps until GC; on a 1080×2400
        // ARGB_8888 frame that is ~10 MB per dropped pair. The uploader
        // is documented to take ownership on success; the `finally`
        // here covers ONLY the failure path. Inside the try we assume
        // the uploader will recycle and we hand off — therefore the
        // finally guards each `recycle()` with `!isRecycled` so a
        // success path that already recycled cannot crash on a double
        // recycle.
        var ownershipTaken = false
        try {
            uploader.uploadCapture(
                ReplayCapture(
                    seq = seq,
                    interaction = meta,
                    screenIdentity = identity,
                    preFrame = preFrame,
                    postFrame = postFrame,
                    structuralJson = structural,
                    ocrText = ocrText,
                )
            )
            ownershipTaken = true
        } catch (t: Throwable) {
            Log.w(TAG, "uploader.uploadCapture failed (seq=$seq)", t)
        } finally {
            // Failure path — defensively recycle. On success the
            // uploader has taken ownership but the `!isRecycled` guard
            // makes this a safe no-op even if the uploader hasn't
            // recycled yet (the pixel buffer is then reclaimed early,
            // which is also fine — no one else holds a reference past
            // this scope).
            if (!ownershipTaken) {
                recycleQuiet(preFrame)
                recycleQuiet(postFrame)
            }
        }
    }

    /**
     * Recycle a Bitmap if non-null and not already recycled. Tolerates
     * `recycle()` itself throwing (it shouldn't, but R6 anti-crash).
     */
    private fun recycleQuiet(bitmap: Bitmap?) {
        if (bitmap == null) return
        if (bitmap.isRecycled) return
        try {
            bitmap.recycle()
        } catch (_: Throwable) { /* swallow */ }
    }

    /**
     * Memory-pressure response. Wired by [io.kixo.sdk.internal.lifecycle.KixoInternalBootstrap]
     * via its `memoryPressure` Flow when Agent 7 detects
     * `TRIM_MEMORY_RUNNING_CRITICAL` / `TRIM_MEMORY_COMPLETE`.
     *
     * Three immediate mitigations (mirrors iOS `handleMemoryWarning`):
     *  1. Drop pre-tap frame ([RingBuffer.take]) — releases ~10 MB.
     *  2. Tighten capture slot to 1 → next tap drops to metadata-only
     *     until pressure subsides.
     *  3. Tell [ThermalBackoff] to externally pause so subsequent
     *     captures bail out at the gate rather than progressing
     *     through the pipeline only to drop.
     */
    fun onMemoryWarning() {
        ringBuffer.take()?.recycle()
        captureSlot?.tightenForMemoryPressure()
        thermalBackoff?.externalPause(ThermalBackoff.PauseReason.LowMemory)
        lastScreenIdentity = null
    }

    /** Counterpart to [onMemoryWarning] — restore baseline cap on `NORMAL`. */
    fun onMemoryWarningCleared() {
        captureSlot?.restoreBaseline()
        thermalBackoff?.externalResume()
    }

    /**
     * Test-only reset hook. Cleans the singleton state between
     * tests without going through the full [stop] flow (which
     * touches Android system services).
     */
    @androidx.annotation.VisibleForTesting
    internal fun resetForTesting() {
        started.set(false)
        active.set(false)
        optedOut.set(false)
        nextSeq.set(0L)
        lastScreenIdentity = null
        lastScrollEndElapsedMs = 0L
        ringBuffer.take()?.recycle()
        captureSlot = null
        thermalBackoff = null
        ocrExtractor = null
        structuralSnapshotter = null
        screenIdentity = null
        sampler = null
        config = null
        uploader = null
        sessionJob?.cancel()
        sessionJob = null
    }
}

/**
 * Single captured tap+frame bundle handed to Agent 14's upload
 * pipeline. Agent 14 owns serialisation, signed-URL acquisition,
 * GCS PUT, and `/api/sdk/replay/events` POST.
 *
 * @param seq Per-session monotonic counter for upload ordering.
 * @param interaction Classified gesture metadata (Agent 8's
 *   [InteractionMeta]).
 * @param screenIdentity Joins this frame to Agent 9's screen tracker.
 * @param preFrame Pre-tap raster — `null` when [ReplayConfig.preFrameEnabled]
 *   is `false` and the [RingBuffer] was empty.
 * @param postFrame Post-tap raster — `null` when capture failed
 *   (rare; usually OOM during alloc).
 * @param structuralJson View-tree DOM-like sidecar — `null` when
 *   [ReplayConfig.structuralSnapshotEnabled] was off.
 * @param ocrText PII-sanitized concatenated text from on-device ML
 *   Kit — empty string when OCR disabled / dependency missing /
 *   recognition failed.
 */
internal data class ReplayCapture(
    val seq: Long,
    val interaction: InteractionMeta,
    val screenIdentity: ScreenIdentity?,
    val preFrame: Bitmap?,
    val postFrame: Bitmap?,
    val structuralJson: JsonObject?,
    val ocrText: String,
)

/**
 * Stub interface for Agent 14's
 * [io.kixo.sdk.internal.replay.upload.ReplayUploader]. Per
 * AGENT_BRIEFING §6 file ownership rule, this folder declares only
 * the surface it calls — [beginSession] / [uploadCapture] /
 * [endSession]. The real implementation lives in `internal/replay/upload/`.
 *
 * **Why this lives here** (not in a separate stub file): only
 * Agent 13 calls Agent 14, so colocating the contract with the
 * caller keeps the file-graph minimal. When Agent 14 lands, the
 * real `ReplayUploader` implements this interface verbatim and
 * `ReplayController.start` swaps in the real reference.
 */
internal interface ReplayUploaderRef {
    /**
     * Open the backend session via `/api/sdk/replay/session/start`,
     * cache the initial signed-URL pool, prepare the WorkManager
     * upload job. Suspending — caller awaits the response so we
     * don't fire-and-forget into a black hole on Agent 14 errors.
     */
    suspend fun beginSession(config: ReplayConfig)

    /**
     * Take ownership of the supplied [ReplayCapture]'s assets,
     * upload the frame(s) to GCS via signed URL, and POST the
     * event metadata to `/api/sdk/replay/events`. Implementation
     * MUST recycle any non-null `preFrame` / `postFrame` Bitmap
     * exactly once.
     */
    suspend fun uploadCapture(capture: ReplayCapture)

    /**
     * Seal the session via `/api/sdk/replay/session/end`. Uploads
     * already in flight continue via WorkManager; this call is the
     * orderly close.
     */
    suspend fun endSession()
}
