package io.kixo.sdk.internal.screen

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.AbsListView
import android.widget.AdapterView
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RatingBar
import android.widget.RelativeLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.ToggleButton

/**
 * Maps any [View] to a content-invariant [Role]. Mirrors the iOS
 * `RoleClassifier.classify(_:)` priority chain and the
 * [SemanticRole](kixo-ios-sdk/Sources/Kixo/AutoTrack/SemanticRole.swift)
 * taxonomy — same axes, different framework names.
 *
 * **Why this exists separately from [ScreenFingerprint]:** the
 * fingerprint hashes role + structure ONLY. The classifier is also the
 * shared building block for Agent 13's `StructuralSnapshotter` (replay
 * pipeline emits the same role tree as a sidecar) and Agent 8's tap
 * normaliser (`Button` taps emit a different `event_type` than container
 * taps).
 *
 * **Hard contract — never inspect content (AGENT_BRIEFING.md §3 R8).**
 * The classifier never touches `text`, `contentDescription`, drawable
 * resources, colours, dimensions, or layout params. Same view across
 * light/dark + locale + density = identical [Role]. Inspecting content
 * here would mean the fingerprint changes when the user types in a
 * field or the locale flips RTL.
 *
 * **Priority chain (mirrors iOS):**
 *  1. Exact class type match — [Button], [EditText], [ImageView] etc.
 *  2. Subclass walk via `is` checks (catches custom subclasses + the
 *     androidx.appcompat.widget.* / com.google.android.material.* family
 *     which extend the same base classes but with package-prefixed names).
 *  3. Composite view types — [WebView] for browser, [RecyclerView] (via
 *     class name string match — Agent 9 doesn't depend on
 *     `recyclerview-runtime`), [ListView]/[GridView] etc.
 *  4. Click semantics — [View.isClickable] || [View.hasOnClickListeners].
 *     Catches custom buttons that aren't `Button` subclasses.
 *  5. Container fallback — any [ViewGroup] with children → `Container`.
 *  6. `Other` — leaf view we don't recognise.
 *
 * Roles are deliberately a small closed set — the iOS version found
 * 10 categories sufficient to drive screen merging across hundreds of
 * thousands of real captures. Adding more roles makes the
 * fingerprint MORE volatile (a custom widget that classifier-V2 puts
 * in a new bucket would change the fingerprint of every screen it
 * appears on, tearing the cross-session screen identity).
 */
internal enum class Role {
    /** [TextView], [Button] (TextView subclass) labels — purely text. */
    Text,

    /**
     * Button-like — [Button], [ImageButton], [CompoundButton] family
     * ([Switch] / [ToggleButton]), [Spinner], any [View] where the
     * click semantics ([View.isClickable] + [View.hasOnClickListeners])
     * say "this is tappable".
     */
    Button,

    /**
     * [EditText] and the AppCompat / Material edit-text family. Used
     * by the privacy layer (Agent 10) to mask before frame upload —
     * if the input flag is `TYPE_TEXT_VARIATION_PASSWORD` the privacy
     * layer additionally redacts to opaque rect.
     */
    TextField,

    /** [ImageView], `ShapeableImageView`, etc. — content-invariant by construction. */
    Image,

    /**
     * Scrollable collections: `RecyclerView`, [AbsListView] family
     * ([android.widget.ListView] / [android.widget.GridView]),
     * [android.widget.ExpandableListView], [Spinner]'s drop-down panel,
     * [androidx.viewpager.widget.ViewPager], `ViewPager2`. Generic
     * [ScrollView] / [HorizontalScrollView] also map here.
     *
     * Critical for the role tree — collections normalise to "1
     * template item per reuse type" so a 100-row vs 0-row list still
     * fingerprints to the same screen (R8 invariant).
     */
    List,

    /**
     * [WebView]. Always treated as a black box for both fingerprint
     * AND privacy reasons — DOM contents change every navigation but
     * the SCREEN containing the WebView is the same. Privacy layer
     * (Agent 10) opaque-rect-redacts every WebView before frame upload.
     */
    Web,

    /**
     * Any [ViewGroup] with children that isn't a list / scroll / web /
     * navigation. The structural fallback that holds the tree
     * together — [LinearLayout], [FrameLayout], [RelativeLayout],
     * `ConstraintLayout`, the Material *Container* widgets, etc.
     */
    Container,

    /**
     * [SeekBar], [RatingBar], [ProgressBar] — non-text user input or
     * progress display. Distinct from [TextField] because typing
     * doesn't apply, and distinct from [Button] because the gesture
     * semantics differ (drag vs tap).
     */
    Input,

    /**
     * `BottomNavigationView`, `NavigationRailView`, `Toolbar`,
     * `BottomAppBar`, tab strips. Detected by class-name suffix to
     * avoid pulling in the Material library as an SDK dep.
     */
    Navigation,

    /** Leaf view we couldn't classify. Rare; mostly framework internals. */
    Other,
    ;

    /**
     * Single-byte code for [ScreenFingerprint] hashing. Stable across
     * SDK versions — adding a NEW role appends to the enum but never
     * renumbers existing entries.
     */
    val code: Byte
        get() = when (this) {
            Text -> 1
            Button -> 2
            TextField -> 3
            Image -> 4
            List -> 5
            Web -> 6
            Container -> 7
            Input -> 8
            Navigation -> 9
            Other -> 10
        }
}

/**
 * Single-instance classifier. Stateless, thread-safe — but per
 * AGENT_BRIEFING.md threading rules, callers MUST invoke from the main
 * thread because [View] state inspection (e.g. [ViewGroup.getChildCount])
 * is not safe off-main on most Android versions.
 */
internal object RoleClassifier {

    /**
     * Class-name suffixes / contains for view types we don't want to
     * compile against directly (RecyclerView lives in androidx-
     * recyclerview, ViewPager2 in androidx-viewpager2 — pulling those
     * into the SDK would inflate every consumer's APK by ~40 KB just
     * to classify them). String matching is cheap (~1µs per view) and
     * lets the SDK stay dep-light per AGENT_BRIEFING.md §5.
     */
    private val LIST_CLASS_SUFFIXES = listOf(
        "RecyclerView",
        "ViewPager",
        "ViewPager2",
    )
    private val NAVIGATION_CLASS_SUFFIXES = listOf(
        "BottomNavigationView",
        "NavigationView",
        "NavigationRailView",
        "Toolbar",
        "ActionBarContainer",
        "BottomAppBar",
        "TabLayout",
        "TabHost",
    )

    /**
     * Classify [view] into a [Role]. ~5 µs per call on Pixel 6 —
     * cheap enough to call once per node in a 200-node hierarchy
     * during fingerprint compute (~1 ms total).
     */
    fun classify(view: View): Role {
        // Priority 1+2: exact class match (subclass walk via `is`
        // catches AppCompat/Material variants automatically because
        // they extend the framework base class).
        // Order matters: subclass-aware checks come BEFORE their
        // superclasses, e.g. [EditText] extends [TextView] so we
        // must check `is EditText` before `is TextView`.

        // Inputs that aren't text fields — checked first because
        // [SeekBar] extends [AbsSeekBar] extends [ProgressBar].
        if (view is SeekBar || view is RatingBar) return Role.Input
        if (view is ProgressBar) return Role.Input

        // Text input — [EditText] is a [TextView] subclass.
        if (view is EditText) return Role.TextField

        // Image — [ImageButton] is an [ImageView] subclass, so check
        // [Button] semantics FIRST. Material's `ShapeableImageView` is
        // a regular [ImageView] subclass, classified here.
        if (view is ImageButton) return Role.Button
        if (view is ImageView) return Role.Image

        // Compound buttons ([Switch] / [ToggleButton] / [CheckBox] /
        // [RadioButton]) extend [Button] which extends [TextView].
        if (view is CompoundButton) return Role.Button
        if (view is Button) return Role.Button

        // Navigation — class-name suffix match for Material/AndroidX
        // widgets we don't want to compile against.
        val className = view.javaClass.simpleName
        if (NAVIGATION_CLASS_SUFFIXES.any { className.endsWith(it) }) {
            return Role.Navigation
        }

        // Drop-down / spinner.
        if (view is Spinner) return Role.Button

        // Lists & scrollables — broad detection because any of these
        // can host a collection.
        if (view is AdapterView<*>) return Role.List // ListView/GridView/Spinner-popup
        if (view is AbsListView) return Role.List
        if (LIST_CLASS_SUFFIXES.any { className == it || className.endsWith(it) }) {
            return Role.List
        }
        if (view is ScrollView || view is HorizontalScrollView) return Role.List

        // WebView always opaque — see [Role.Web] doc + privacy layer.
        if (view is WebView) return Role.Web

        // Plain text view.
        if (view is TextView) return Role.Text

        // Click semantics catch custom views that didn't subclass
        // [Button]. We deliberately use [View.hasOnClickListeners]
        // (introduced API 15) so this works on min-sdk-24 unmodified.
        if (view.isClickable || view.hasOnClickListeners()) {
            return Role.Button
        }

        // Container fallback — any [ViewGroup] with at least one
        // child. A [ViewGroup] with no children is degenerate; treat
        // as [Other] so it doesn't pollute the fingerprint with empty
        // padding.
        if (view is ViewGroup && view.childCount > 0) {
            return Role.Container
        }
        if (view is FrameLayout || view is LinearLayout || view is RelativeLayout) {
            // Empty layout containers — still a container slot in
            // the tree even if no children right now (state may
            // flip mid-life). Without this leaf-empty `LinearLayout`
            // would degrade to `Other` and the fingerprint would
            // change as the layout populated.
            return Role.Container
        }

        return Role.Other
    }
}
