package io.kixo.sdk.internal.context

import android.app.ActivityManager
import android.content.Context

/**
 * Coarse device-capability tier used for sampling, perf-budget, and
 * "should we run on-device OCR" decisions in the replay pipeline.
 *
 * Mirrors iOS [Context/DeviceInfo.swift]'s `deviceClass` heuristic
 * (which returned `"low"` / `"medium"` / `"high"`). On Android we
 * use slightly more product-friendly names — `Flagship` / `Mid` /
 * `Budget` — but [wireValue] emits the SAME three strings as iOS so
 * the backend doesn't need to branch on platform.
 *
 * **Why a heuristic at all**: the replay subsystem needs to drop pass
 * counts, OCR concurrency, and frame quality on weak hardware. The
 * iOS C.3v3 lesson (April 28 2026) was that uniform defaults across
 * all hardware OOM'd iPhone 11/12. Same risk on Android — a Pixel 8
 * (8GB / 8 cores) tolerates very different settings than a 2GB
 * Android Go entry-level phone.
 *
 * **Why these inputs**: total RAM and CPU core count are the only
 * two device properties available without permissions, are reasonably
 * well correlated with single-thread perf, and don't change at
 * runtime. Year-class is intentionally NOT used (no clean public API,
 * and it would require maintaining a model→year table that drifts).
 */
internal enum class DeviceClass {
    /** ≥6 cores AND ≥4 GB RAM. Pixel 7+, Galaxy S22+, OnePlus 11, etc. */
    Flagship,

    /** 4–5 cores OR 2–3.99 GB RAM. Mid-range OEMs from the last 2 years. */
    Mid,

    /** ≤3 cores OR <2 GB RAM. Android Go, very old / cheap hardware. */
    Budget;

    /**
     * Three-letter wire value matching iOS exactly. The backend's
     * `device.device_class` ClickHouse column is `LowCardinality(String)`
     * and downstream queries filter on `low`/`medium`/`high`, so we
     * MUST stay consistent with iOS even though our enum names differ.
     */
    val wireValue: String
        get() = when (this) {
            Flagship -> "high"
            Mid -> "medium"
            Budget -> "low"
        }

    companion object {
        /**
         * Classify a device given runtime + ActivityManager probes.
         *
         * @param totalMemBytes Total physical memory as reported by
         *   [ActivityManager.MemoryInfo.totalMem]. Pass `0` if the
         *   probe failed; we'll treat unknown memory as "Mid" to avoid
         *   gating perf features off entirely on unrecognised devices.
         * @param cpuCores Number of available CPU cores from
         *   [Runtime.availableProcessors]. Always ≥1.
         */
        fun classify(totalMemBytes: Long, cpuCores: Int): DeviceClass {
            // Mirror iOS thresholds exactly:
            //   <2 GB RAM OR ≤2 cores  → low
            //   <4 GB RAM OR ≤4 cores  → medium
            //   else                   → high
            val gb = totalMemBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            return when {
                totalMemBytes == 0L -> Mid // Unknown — be optimistic, not pessimistic.
                gb < 2.0 || cpuCores <= 2 -> Budget
                gb < 4.0 || cpuCores <= 4 -> Mid
                else -> Flagship
            }
        }

        /**
         * Convenience entry point that probes from a [Context]. Reads
         * total RAM via `ActivityManager.getMemoryInfo`. Falls back
         * to `Mid` if the system service is unavailable (test stubs,
         * unusual emulator configs).
         */
        fun classify(context: Context): DeviceClass {
            val cores = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
            val mem = try {
                val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                if (am != null) {
                    val info = ActivityManager.MemoryInfo()
                    am.getMemoryInfo(info)
                    info.totalMem
                } else 0L
            } catch (t: Throwable) {
                // Briefing R6: never crash the host app over a context probe.
                0L
            }
            return classify(mem, cores)
        }
    }
}
