package io.kixo.sdk.internal.privacy

/**
 * Closed taxonomy of PII categories the SDK redacts. The enum value
 * names land verbatim in the `[<kind>]` placeholder string in
 * [PiiFilter.redact], so renaming a variant changes the wire format
 * — keep these stable.
 *
 * Mirrors the priority order in `PIIFilter.swift` patterns table.
 *
 * @property placeholder The token that replaces a redacted match in
 *   the sanitized text. Wrapped in `[…]` so a downstream consumer can
 *   tell "this string contains [email]" from accidentally typed
 *   "email" prose.
 */
internal enum class PiiKind(val placeholder: String) {
    EMAIL("[email]"),
    PHONE("[phone]"),
    CREDIT_CARD("[card]"),
    SSN("[ssn]"),
    JWT("[jwt]"),
    IBAN("[iban]"),

    /**
     * Personal name match from the optional [EntityTagger] (ML Kit
     * Entity Extraction). Distinct placeholder so an audit can tell
     * regex-derived redactions from NER-derived ones.
     */
    NAME("[name]"),

    /**
     * Generic NER fall-through (location / organisation / address).
     * Conservative use only.
     */
    ENTITY("[entity]"),
}

/**
 * One match found by [PiiFilter.scan]. [startIdx] is inclusive and
 * [endIdx] is exclusive (`String.substring(startIdx, endIdx)` returns
 * the matched span).
 *
 * Note: [value] is the raw matched substring. Callers MUST NOT log
 * this — see AGENT_BRIEFING.md R10 ("Never send these to backend").
 * It exists only so the structural-snapshot pipeline can decide
 * whether to mask the originating view (we mask containers, not
 * substrings — but we need the offsets to know which view).
 */
internal data class PiiMatch(
    val kind: PiiKind,
    val startIdx: Int,
    val endIdx: Int,
    val value: String,
)
