package io.kixo.sdk

/**
 * Closed taxonomy of "standard events" the backend recognises by
 * name and applies special semantics to:
 *
 *   - [Purchase] / [SubscriptionStart] → revenue + MRR analytics
 *   - [Signup] / [Activation]          → conversion funnels
 *   - [TrialStart] / [Cancel] / [Upgrade] → subscription lifecycle
 *   - [Share] / [Invite]               → virality coefficient
 *
 * Hosts CAN call [Kixo.track] with the same string event name and the
 * same property keys with identical effect — the backend's
 * standard-event detector matches on event name verbatim. The typed
 * sealed-class wrappers buy three things over a stringly-typed dict:
 *
 *   1. **Compile-time property-shape validation.** [Purchase] requires
 *      `amount` and `currency`; misspelling either is a compile error,
 *      not a runtime "purchase event with no revenue" silently flowing
 *      into your analytics.
 *   2. **Single source of truth on key names.** The backend expects
 *      `currency` / `amount`; if a host accidentally sends `cur` /
 *      `value` in a free-form `track()` call, the standard-event
 *      detector misses it. The wrappers spell every key correctly.
 *   3. **Self-documenting call sites.** `Kixo.track(StandardEvent.Purchase(amount =
 *      49.99, currency = "USD", productId = "pro_yearly"))` reads
 *      better in code review than a stringly-typed dict.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Kixo+TypedEvents.swift`. iOS
 * exposes them as static methods on [Kixo]; Android exposes them BOTH
 * ways — sugar wrappers like [Kixo.trackPurchase] match the §7
 * briefing API surface, and this sealed class is for callers who
 * want pattern-matchable event values (e.g. for batching in their
 * own analytics middleware before handing to Kixo).
 *
 * Every wrapper passes through [Kixo.track], so super-properties,
 * push attribution, and the kill-switch all apply normally.
 *
 * Currency-typed amount values use [Double] for ergonomics — matches
 * the iOS `MoneyAmount = Double` typealias. If a host needs Decimal
 * precision they can call [Kixo.track] directly with whatever number
 * type they prefer.
 */
public sealed class StandardEvent(
    /**
     * Wire event name. Matches the iOS `track(<name>, ...)` calls
     * verbatim — the backend's standard-event detector keys off these.
     * Snake_case per R3 of the briefing.
     */
    public val name: String,
) {
    /**
     * Convert the typed event into the property map the SDK ships on
     * the wire. Wrapper-method fields (e.g. [Purchase.amount]) become
     * snake_case property keys. Caller-supplied [extra] always wins
     * on key collision so a single event-emit can override anything.
     *
     * Implementations MUST NOT mutate [extra] — they read from it and
     * return a fresh map so the caller's reference stays clean.
     */
    public abstract fun toProperties(): Map<String, Any?>

    // ─── Revenue ────────────────────────────────────────────────

    /**
     * Standard purchase event. Drives revenue / ARPU dashboards in
     * the backend's standard-event detector.
     *
     * @param amount Charged amount in [currency] (e.g. `49.99`).
     * @param currency ISO 4217 currency code ("USD", "EUR", "JPY", …).
     *   Validated server-side; an unknown code logs a warning but
     *   the event is still stored.
     * @param productId Optional product/SKU identifier.
     * @param productName Optional human-readable product name.
     * @param quantity Optional unit count (default 1 inferred server-side).
     * @param extra Free-form extra properties merged into the wire payload.
     */
    public data class Purchase(
        val amount: Double,
        val currency: String,
        val productId: String? = null,
        val productName: String? = null,
        val quantity: Int? = null,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("purchase") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(6 + extra.size)
            props["amount"] = amount
            props["currency"] = currency
            if (productId != null) props["product_id"] = productId
            if (productName != null) props["product_name"] = productName
            if (quantity != null) props["quantity"] = quantity
            // Caller-supplied extras win on collision — gives a single
            // call site the power to override anything for that one
            // event without forcing a Kixo.track() fallback.
            props.putAll(extra)
            return props
        }
    }

    /**
     * Subscription started (free → paid conversion or fresh paid signup).
     * The backend rolls these into MRR + cohort retention.
     *
     * @param plan Plan identifier — must match what your billing
     *   system reports server-side (e.g. `"pro_monthly"`).
     * @param amount Recurring charge amount per [interval].
     * @param currency ISO 4217 code.
     * @param interval Billing cadence — defaults to [SubscriptionInterval.MONTH]
     *   to match the iOS default and the most common subscription model.
     */
    public data class SubscriptionStart(
        val plan: String,
        val amount: Double,
        val currency: String,
        val interval: SubscriptionInterval = SubscriptionInterval.MONTH,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("subscribe_start") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(4 + extra.size)
            props["plan"] = plan
            props["amount"] = amount
            props["currency"] = currency
            props["interval"] = interval.wireValue
            props.putAll(extra)
            return props
        }
    }

    /**
     * Free trial started. `days` describes the trial length so the
     * backend can predict trial-end conversion windows.
     */
    public data class TrialStart(
        val plan: String,
        val days: Int,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("trial_start") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(2 + extra.size)
            props["plan"] = plan
            props["trial_days"] = days
            props.putAll(extra)
            return props
        }
    }

    /**
     * Subscription / trial cancellation. `reason` is optional but
     * lets the dashboard's churn analysis cluster cancel reasons.
     */
    public data class Cancel(
        val plan: String,
        val reason: String? = null,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("cancel") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(2 + extra.size)
            props["plan"] = plan
            if (reason != null) props["reason"] = reason
            props.putAll(extra)
            return props
        }
    }

    /**
     * Plan upgrade (free → pro, monthly → yearly, etc.). The backend
     * computes ARPU lift from `from_plan`/`to_plan` deltas.
     */
    public data class Upgrade(
        val fromPlan: String,
        val toPlan: String,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("upgrade") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(2 + extra.size)
            props["from_plan"] = fromPlan
            props["to_plan"] = toPlan
            props.putAll(extra)
            return props
        }
    }

    // ─── Identity & activation ──────────────────────────────────

    /**
     * New-user signup. `method` lets the dashboard split funnels by
     * sign-in channel ("email", "google", "apple", …) without a
     * custom property name on every host.
     */
    public data class Signup(
        val method: String? = null,
        val plan: String? = null,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("signup") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(2 + extra.size)
            if (method != null) props["method"] = method
            if (plan != null) props["plan"] = plan
            props.putAll(extra)
            return props
        }
    }

    /**
     * "Activation" — the one event in your funnel where a user
     * becomes a real product user. Defining what counts is on the
     * host; the standard event name flags it for retention curves
     * and aha-moment analysis on the backend.
     *
     * @param event Optional sub-event name describing what was
     *   activated (e.g. `"first_post"`, `"first_invite_sent"`).
     */
    public data class Activation(
        val event: String? = null,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("activation") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(1 + extra.size)
            if (event != null) props["activation_event"] = event
            props.putAll(extra)
            return props
        }
    }

    // ─── Virality ───────────────────────────────────────────────

    /**
     * Share / refer event. `channel` distinguishes the surface —
     * "twitter", "messages", "copy_link", "qr", …
     */
    public data class Share(
        val channel: String,
        val contentId: String? = null,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("share") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(2 + extra.size)
            props["channel"] = channel
            if (contentId != null) props["content_id"] = contentId
            props.putAll(extra)
            return props
        }
    }

    /**
     * Invite sent. `recipientCount` is the size of the invite blast
     * (single contact = 1, "Invite all my friends" = N). Drives
     * K-factor / virality dashboards.
     */
    public data class Invite(
        val channel: String? = null,
        val recipientCount: Int? = null,
        val extra: Map<String, Any?> = emptyMap(),
    ) : StandardEvent("invite") {
        override fun toProperties(): Map<String, Any?> {
            val props = LinkedHashMap<String, Any?>(2 + extra.size)
            if (channel != null) props["channel"] = channel
            if (recipientCount != null) props["recipient_count"] = recipientCount
            props.putAll(extra)
            return props
        }
    }
}
