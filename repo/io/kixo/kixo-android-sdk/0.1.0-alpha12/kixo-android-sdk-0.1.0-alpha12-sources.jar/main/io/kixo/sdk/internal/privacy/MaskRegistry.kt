package io.kixo.sdk.internal.privacy

import android.view.View
import java.util.WeakHashMap

/**
 * Registry of [View]s the host app marked sensitive via the public
 * extension `View.setKixoMask(true)` (see `KixoMask.kt`).
 *
 * Used by [StructuralRedactionRules.shouldRedact] and the replay
 * pipeline's structural snapshotters to decide whether to mask a
 * view's pixels + text BEFORE the JPEG/WebP encode (per
 * AGENT_BRIEFING.md R2 — "Frames with PII never leave device
 * unredacted").
 *
 * ## Why a WeakHashMap
 * Registering a [View] reference keeps the View — and transitively
 * its Activity Context — alive forever in the SDK process. That's a
 * textbook Android memory leak (per AGENT_BRIEFING.md anti-examples
 * "Holding a hard reference to an Activity in a singleton").
 *
 * `WeakHashMap` lets the GC reclaim the [View] keys as soon as the
 * Activity goes away. The downside is non-deterministic eviction
 * (entries clear at GC time, not deregistration time) but for our
 * use case "the View is gone, so are its pixels, so we don't care
 * about the entry anymore" — that semantics is exactly what we want.
 *
 * ## Concurrency
 * The replay pipeline reads from this registry on the OCR / capture
 * worker threads (cap 4 concurrent per AGENT_BRIEFING.md R4). The
 * public mask setter is called from app code on (typically) the main
 * thread. `WeakHashMap` is NOT thread-safe, so we synchronize on the
 * map itself.
 *
 * Contention is low — register is one-shot per View (host app calls
 * once during setup), reads happen during replay capture only.
 */
internal object MaskRegistry {

    /**
     * Boolean stored alongside the View weak key. We use Boolean
     * rather than just "presence in a Set" so calling
     * `view.setKixoMask(false)` can explicitly UN-mask a previously
     * masked view (rather than only forward-toggle).
     */
    private val masked: WeakHashMap<View, Boolean> = WeakHashMap()

    /**
     * Mark or unmark a view. Idempotent — safe to call multiple
     * times. [mask]=false explicitly clears any prior mask flag.
     *
     * Called from [io.kixo.sdk.setKixoMask] (the public entry point).
     */
    @JvmStatic
    fun setMasked(view: View, mask: Boolean) {
        synchronized(masked) {
            if (mask) {
                masked[view] = true
            } else {
                masked.remove(view)
            }
        }
    }

    /**
     * Test whether a view (or its predecessor in the mask map) was
     * marked sensitive. Read-only; called from the replay capture
     * pipeline on every frame for every view.
     *
     * Returns false for null inputs — the iOS port allows nil inputs
     * to mean "no view, definitely not masked", same convention here.
     */
    @JvmStatic
    fun isMasked(view: View?): Boolean {
        if (view == null) return false
        synchronized(masked) {
            return masked[view] == true
        }
    }

    /**
     * Snapshot count for diagnostics. Exposed to
     * [io.kixo.sdk.KixoDiagnostics] so operators can verify their
     * masking calls landed.
     */
    @JvmStatic
    fun maskedViewCount(): Int {
        synchronized(masked) {
            return masked.size
        }
    }

    /**
     * Test-only — clear all entries. Production code should never
     * call this; the WeakHashMap drains itself when GC runs.
     */
    internal fun clearForTest() {
        synchronized(masked) {
            masked.clear()
        }
    }
}
