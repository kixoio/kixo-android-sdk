package io.kixo.sdk.internal.privacy

import android.content.Context
import android.content.SharedPreferences
import io.kixo.sdk.internal.model.KixoEventType
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Two-flag consent state machine, persisted to [SharedPreferences].
 *
 * Mirrors the iOS SDK's `ConsentManager` and the web SDK's
 * `consent.ts` / `Kixo.optOut/optIn/grantConsent/revokeConsent`
 * surface.
 *
 * ## Two flags, distinct semantics
 *
 *   | flag             | what it means                                      | default |
 *   |------------------|----------------------------------------------------|---------|
 *   | [optedOut]       | "stop ALL tracking" — hard kill switch             | false   |
 *   | [consentGranted] | "user has affirmatively granted analytics consent" | true    |
 *
 * **Why two flags and not one.** `optedOut` is the user's explicit
 * "I never want to be tracked" — under GDPR / CCPA legal opt-out
 * regimes this is the override that beats everything. `consentGranted`
 * is the affirmative-consent signal — under EU consent-required
 * regimes the SDK should not collect at all until the host app's
 * consent flow grants it.
 *
 * The web SDK distinguishes them so a host can honour a Do-Not-Track
 * header (sets `consentGranted=false` until explicit opt-in) without
 * conflating it with the user's hard opt-out (which should persist
 * forever once set).
 *
 * Android has no DNT equivalent at the OS level (Chrome dropped it
 * years ago, no Android API exposes it), so [consentGranted] defaults
 * to `true` here and the host app can flip it false during their
 * own consent flow.
 *
 * ## Persistence
 *
 * Both flags survive process death via [SharedPreferences]. Reads
 * are O(1) (in-memory after first load) so the per-event consent
 * gate in [shouldEmit] is essentially free.
 *
 * ## Concurrency
 *
 * State held in [AtomicBoolean] so reads from event-emit hot paths
 * never block. Writes go through [setOptedOut] / [setConsentGranted]
 * which atomically update the in-memory flag AND flush to prefs.
 *
 * ## Init contract
 *
 * Must be initialised exactly once via [init] before any other method.
 * The public [io.kixo.sdk.Kixo.configure] entry point owns this. If
 * methods are called before init, they fall back to safe defaults
 * ([shouldEmit] returns `true` for essential events, `false` for
 * everything else — fail-closed for non-essential).
 */
internal object ConsentManager {

    private const val PREFS_NAME = "kixo_consent"
    private const val KEY_OPTED_OUT = "opted_out"
    private const val KEY_CONSENT_GRANTED = "consent_granted"

    private val optedOut = AtomicBoolean(false)
    private val consentGranted = AtomicBoolean(true)

    @Volatile
    private var prefs: SharedPreferences? = null

    /**
     * Snapshot — true if this object has been wired to a SharedPreferences
     * yet. Tests use the [initForTest] helper to bypass.
     */
    private val initialized = AtomicBoolean(false)

    /**
     * Wire to a real Android [Context]. Idempotent — second call is
     * a no-op. Must be called from [io.kixo.sdk.Kixo.configure] BEFORE
     * any event emit.
     *
     * Reads the persisted flags into the [AtomicBoolean] cache. If
     * neither key has ever been written, the defaults from the field
     * initializers stand.
     */
    fun init(context: Context) {
        if (initialized.get()) return
        synchronized(this) {
            if (initialized.get()) return
            val sp = context.applicationContext
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            prefs = sp
            // Restore — keep the field defaults if the keys were never
            // set so a fresh install acts as expected.
            if (sp.contains(KEY_OPTED_OUT)) {
                optedOut.set(sp.getBoolean(KEY_OPTED_OUT, false))
            }
            if (sp.contains(KEY_CONSENT_GRANTED)) {
                consentGranted.set(sp.getBoolean(KEY_CONSENT_GRANTED, true))
            }
            initialized.set(true)
        }
    }

    // ──────────────────────────────────────────────────────────────
    // Public API surface (called via io.kixo.sdk.Kixo facade)
    // ──────────────────────────────────────────────────────────────

    /**
     * Hard opt-out. Once set, [shouldEmit] returns `false` for every
     * event type EXCEPT the one consent-revocation event itself
     * (so the operator's dashboard can record the act of opting
     * out). Persists across launches.
     */
    fun optOut() = setOptedOut(true)

    /** Reverse a prior [optOut]. */
    fun optIn() = setOptedOut(false)

    /** Affirmative consent grant. Sets [consentGranted] = true. */
    fun grantConsent() = setConsentGranted(true)

    /**
     * Revoke affirmative consent. After this only essential events
     * (lifecycle, session boundaries) emit; custom / identify /
     * goal events are dropped. Mirrors web SDK semantics.
     */
    fun revokeConsent() = setConsentGranted(false)

    /** Read-only flags for [io.kixo.sdk.KixoDiagnostics]. */
    fun isOptedOut(): Boolean = optedOut.get()
    fun hasConsent(): Boolean = consentGranted.get()

    /**
     * The per-event gate. Called by the event queue / transport just
     * before persistence. Returns `false` to drop the event silently.
     *
     * Two-tier policy:
     *
     *  - **Opted out** → drop EVERYTHING. The event queue must
     *    propagate this to flush a final `revoke` event itself
     *    before draining (we don't make that decision here; we just
     *    say "no" to the routine event stream).
     *
     *  - **Consent not granted but not opted out** → only essential
     *    operational events (session boundaries, lifecycle) flow.
     *    Custom / identify / goal / push are held until consent is
     *    granted.
     */
    fun shouldEmit(eventType: KixoEventType): Boolean {
        if (optedOut.get()) return false
        if (!consentGranted.get()) return isEssential(eventType)
        return true
    }

    /**
     * "Essential" = events the SDK needs even pre-consent in order
     * to function (sessionization, crash safety net, lifecycle
     * housekeeping). Mirrors the web SDK's essential-event list.
     */
    private fun isEssential(type: KixoEventType): Boolean = when (type) {
        KixoEventType.SessionStart,
        KixoEventType.SessionEnd,
        KixoEventType.Lifecycle,
        KixoEventType.Crash,
            -> true
        else -> false
    }

    // ──────────────────────────────────────────────────────────────
    // Persistence — synchronous so callers can rely on durability
    // before they continue. Apply (vs commit) so we don't block the
    // calling thread on disk I/O.
    // ──────────────────────────────────────────────────────────────

    private fun setOptedOut(value: Boolean) {
        optedOut.set(value)
        prefs?.edit()?.putBoolean(KEY_OPTED_OUT, value)?.apply()
    }

    private fun setConsentGranted(value: Boolean) {
        consentGranted.set(value)
        prefs?.edit()?.putBoolean(KEY_CONSENT_GRANTED, value)?.apply()
    }

    /**
     * Test helper — reset the in-memory state without touching prefs.
     * Tests that need persisted state set up their own Robolectric
     * SharedPreferences and call [init].
     */
    internal fun resetForTest() {
        optedOut.set(false)
        consentGranted.set(true)
        prefs = null
        initialized.set(false)
    }

    /**
     * Test helper — wire a stub prefs without going through Context.
     * Used by JVM tests that don't want the Robolectric setup cost.
     */
    internal fun initForTest(stubPrefs: SharedPreferences? = null) {
        prefs = stubPrefs
        initialized.set(true)
    }
}
