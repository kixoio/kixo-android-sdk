package io.kixo.sdk.internal.push

/**
 * How much push-notification text the SDK is allowed to surface in
 * outbound events. Mirrors the iOS `PushPayloadSanitizer.ContentMode`
 * enum exactly so the dashboard's `data_collection.push.contentMode`
 * remote-config value works cross-platform without translation.
 *
 * Per AGENT_BRIEFING.md R9 (and the project memory note on the
 * 2026-04 push-tracking decision), there are exactly three modes:
 *
 *   - [FULL]     — full title/body/subtitle in the clear. Dev only;
 *                  picking this in production leaks PII embedded in
 *                  push copy (e.g. "Hello $first_name, your order…").
 *   - [PREVIEW]  — short truncated title (40 chars) + body (80 chars),
 *                  no subtitle. Lets dashboard tables show "what was
 *                  sent" without retaining the full personalised text.
 *   - [HASH_ONLY] — zero text. Only `content_hash` (SHA-256 of
 *                  title+body) makes it out, which is enough to
 *                  group "the same campaign sent to 10k users" into
 *                  a single ClickHouse row but reveals nothing about
 *                  the actual copy. HIPAA / regulated-industry default.
 *
 * **Default is `HASH_ONLY`** for the Android SDK. The iOS source
 * defaults to `.full` because of historical product positioning;
 * the Android SDK ships fresh, so we pick the safer fallback. The
 * dashboard remote config can override per-project.
 */
internal enum class ContentMode(val wireValue: String) {
    /** Full title/body/subtitle — DEV USE ONLY. */
    FULL("full"),

    /** Truncated title + body, no subtitle — middle ground. */
    PREVIEW("preview"),

    /** SHA-256 only, no text — strictest mode. */
    HASH_ONLY("hash_only");

    companion object {
        /**
         * Parse a server-supplied wire value back to an enum.
         *
         * Per AGENT_BRIEFING.md R9, an unknown value MUST fall back
         * to [HASH_ONLY] — never [FULL]. Rationale: if the dashboard
         * starts emitting a future stricter mode the SDK doesn't
         * recognise yet, the correct degradation is to OVER-redact,
         * not under-redact. A hash-only event is always safe; a full
         * event might leak PII the operator wanted hidden.
         *
         * `null` and empty also fall back to [HASH_ONLY] for the same
         * defensive reason — silence from the server is treated as
         * "be careful," not "do whatever."
         */
        fun fromServerString(s: String?): ContentMode {
            if (s.isNullOrEmpty()) return HASH_ONLY
            return when (s.lowercase()) {
                "full" -> FULL
                "preview" -> PREVIEW
                "hash_only", "hashonly" -> HASH_ONLY
                else -> HASH_ONLY
            }
        }
    }
}
