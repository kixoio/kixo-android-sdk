package io.kixo.sdk.internal.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject

/**
 * Response body from `POST /api/sdk/init`. The backend route is
 * defined in `kixo-backend/apps/web/src/app/api/sdk/init/route.ts`
 * (~ line 209 + line 98 for the kill-switch branch).
 *
 * **Wire shape (happy path):**
 * ```json
 * {
 *   "release_id": "rel_…",
 *   "app_id": "app_…",
 *   "app_name": "MyApp iOS",
 *   "paused": false,
 *   "data_collection": { "events": true, "replay": false, ... },
 *   "max_batch_size": 200,
 *   "maintenance_message": "All systems normal"
 * }
 * ```
 *
 * **Wire shape (kill-switched):**
 * ```json
 * {
 *   "paused": true,
 *   "paused_reason": "sdk_version_disabled",
 *   "release_id": "",
 *   "app_id": "",
 *   "app_name": "",
 *   "data_collection": {}
 * }
 * ```
 *
 * **Field contracts:**
 *
 *  - `data_collection` is a free-form `JsonObject` because the
 *    backend stitches together per-feature toggles (`events`,
 *    `replay`, `web_vitals`, `crash`, etc.) plus arbitrary
 *    operator-defined keys. We keep it loose here and let the
 *    consuming module (Agent 1's `Kixo` facade or per-feature
 *    modules) read what it needs.
 *
 *  - `paused_reason` is null in the happy path. When `paused=true`
 *    it carries one of `"sdk_version_disabled" | "below_min_sdk_version"
 *    | "maintenance"` (open set — unknown values mean "stop sending").
 *
 *  - `max_batch_size` and `maintenance_message` are admin-overrides
 *    surfaced from `kixo-admin` SDK Defaults panel. Both null in
 *    the common case.
 *
 *  - All event-/replay-paused branches still return `release_id`
 *    + `app_id` + `app_name` (often empty strings) so the SDK can
 *    cache the response uniformly without conditional shape checks.
 */
@Serializable
internal data class InitResponse(
    @SerialName("release_id")
    val releaseId: String = "",

    @SerialName("app_id")
    val appId: String = "",

    @SerialName("app_name")
    val appName: String = "",

    @SerialName("paused")
    val paused: Boolean = false,

    @SerialName("paused_reason")
    val pausedReason: String? = null,

    @SerialName("data_collection")
    val dataCollection: JsonObject = JsonObject(emptyMap()),

    @SerialName("max_batch_size")
    val maxBatchSize: Int? = null,

    @SerialName("maintenance_message")
    val maintenanceMessage: String? = null,
) {
    /**
     * Convenience read: a per-feature flag inside `data_collection`.
     * Returns `null` if the key is absent or not a boolean — the
     * caller decides the safe default. Most callers want
     * `dataCollection.boolFlag("events") ?: true`.
     */
    fun boolFlag(key: String): Boolean? {
        val el: JsonElement = dataCollection[key] ?: return null
        val prim = el as? kotlinx.serialization.json.JsonPrimitive ?: return null
        return prim.booleanOrNullCompat()
    }

    private fun kotlinx.serialization.json.JsonPrimitive.booleanOrNullCompat(): Boolean? {
        if (!isString) {
            // Native JSON true / false primitives.
            return content.toBooleanStrictOrNull()
        }
        // Quoted strings like "true" / "false" — be lenient.
        return content.toBooleanStrictOrNull()
    }
}
