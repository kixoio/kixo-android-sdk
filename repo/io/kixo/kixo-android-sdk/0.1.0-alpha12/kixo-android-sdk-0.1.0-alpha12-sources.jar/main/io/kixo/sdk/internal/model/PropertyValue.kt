package io.kixo.sdk.internal.model

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Public-API → wire boundary for arbitrary `properties` blobs.
 *
 * The SDK's public surface (e.g. `Kixo.track(name, properties)`) accepts
 * `Map<String, Any?>` because that is the idiomatic Kotlin shape callers
 * build in Java/Kotlin/coroutines. Internally we serialize via
 * kotlinx.serialization, which has no reflection, so we need to convert
 * the loose `Any?` graph into [JsonElement] at the wire boundary.
 *
 * Mirrors iOS's `AnyCodable` ([Models/Event.swift]) but bounded — Java
 * has many ways to express "a number" or "a date" that cannot survive
 * a JSON round trip, so we explicitly map only safe primitive families
 * and drop everything else. This is an SDK invariant from
 * AGENT_BRIEFING.md R6: "never crash the host app". An unknown type
 * MUST log + drop, never throw.
 *
 * Accepted leaf types:
 *   - `null`             → `JsonNull`
 *   - `String`           → `JsonPrimitive(string)`
 *   - `Boolean`          → `JsonPrimitive(boolean)`
 *   - `Int`/`Long`/`Short`/`Byte` → integer `JsonPrimitive`
 *   - `Float`/`Double`   → numeric `JsonPrimitive` IF finite; else dropped
 *
 * Accepted container types:
 *   - `Map<*, *>`        → `JsonObject` (string keys; non-string keys
 *                          coerced via `toString`, preserving the iOS
 *                          AnyCodable behaviour for dictionaries)
 *   - `Iterable<*>` / `Array<*>` / primitive arrays → `JsonArray`
 *
 * Anything else is logged via [PropertyConversionLog] (the SDK logger
 * proper isn't owned by this agent — see internal/logging) and the
 * key is dropped from the resulting object.
 *
 * NaN / +Inf / -Inf are the most common silent landmines: they encode
 * to literal `NaN` / `Infinity` tokens which are not valid JSON. The
 * iOS encoder hard-rejects these via `JSONEncoder` defaults; we mirror
 * that behaviour explicitly here.
 */
internal object PropertyValue {

    /**
     * Convert a single arbitrary value into a [JsonElement]. Returns
     * `null` if the value is unrepresentable (caller drops the key).
     */
    fun fromAny(value: Any?): JsonElement? {
        if (value == null) return JsonNull
        return when (value) {
            is JsonElement -> value
            is String -> JsonPrimitive(value)
            is Boolean -> JsonPrimitive(value)
            is Int -> JsonPrimitive(value)
            is Long -> JsonPrimitive(value)
            is Short -> JsonPrimitive(value.toInt())
            is Byte -> JsonPrimitive(value.toInt())
            is Float -> if (value.isFinite()) JsonPrimitive(value) else {
                PropertyConversionLog.dropped(
                    reason = "non_finite_float",
                    typeName = "Float",
                    extra = value.toString(),
                )
                null
            }
            is Double -> if (value.isFinite()) JsonPrimitive(value) else {
                PropertyConversionLog.dropped(
                    reason = "non_finite_double",
                    typeName = "Double",
                    extra = value.toString(),
                )
                null
            }
            is Number -> {
                // BigInteger / BigDecimal / etc. — coerce to Double when
                // finite. Loses precision for huge BigDecimals, but the
                // CH analytics events store double-precision floats
                // anyway. Mirror iOS where AnyCodable drops to Double.
                val d = value.toDouble()
                if (d.isFinite()) JsonPrimitive(d) else {
                    PropertyConversionLog.dropped(
                        reason = "non_finite_number",
                        typeName = value::class.qualifiedName ?: "Number",
                    )
                    null
                }
            }
            is Char -> JsonPrimitive(value.toString())
            is Enum<*> -> JsonPrimitive(value.name)

            is Map<*, *> -> mapToJsonObject(value)

            is IntArray -> JsonArray(value.map { JsonPrimitive(it) })
            is LongArray -> JsonArray(value.map { JsonPrimitive(it) })
            is ShortArray -> JsonArray(value.map { JsonPrimitive(it.toInt()) })
            is ByteArray -> JsonArray(value.map { JsonPrimitive(it.toInt()) })
            // Primitive arrays don't have `mapNotNull` in stdlib; round-trip
            // through `toTypedArray()` to get the boxed Array<T> overload.
            is FloatArray -> JsonArray(value.toTypedArray().mapNotNull {
                if (it.isFinite()) JsonPrimitive(it) else null
            })
            is DoubleArray -> JsonArray(value.toTypedArray().mapNotNull {
                if (it.isFinite()) JsonPrimitive(it) else null
            })
            is BooleanArray -> JsonArray(value.map { JsonPrimitive(it) })
            is CharArray -> JsonArray(value.map { JsonPrimitive(it.toString()) })
            is Array<*> -> JsonArray(value.mapNotNull { fromAny(it) })

            is Iterable<*> -> JsonArray(value.mapNotNull { fromAny(it) })

            else -> {
                PropertyConversionLog.dropped(
                    reason = "unsupported_type",
                    typeName = value::class.qualifiedName ?: value::class.java.name,
                )
                null
            }
        }
    }

    /**
     * Convert a `Map<*, *>` into a [JsonObject], coercing non-string
     * keys via `toString` and dropping null keys (a JSON object cannot
     * have `null` as a key).
     */
    private fun mapToJsonObject(map: Map<*, *>): JsonObject {
        val out = LinkedHashMap<String, JsonElement>(map.size)
        for ((k, v) in map) {
            if (k == null) {
                PropertyConversionLog.dropped(
                    reason = "null_map_key",
                    typeName = "Map",
                )
                continue
            }
            val key = k as? String ?: k.toString()
            val converted = fromAny(v) ?: continue
            out[key] = converted
        }
        return JsonObject(out)
    }
}

/**
 * Convert an arbitrary `Map<String, Any?>` (the public-API shape) into
 * a [JsonObject] suitable for kotlinx.serialization wire output. Keys
 * whose values are unrepresentable are dropped silently (logged once).
 *
 * Returns an empty object for an empty input — the wire shape always
 * includes a `"properties": { ... }` field, never a missing one.
 */
internal fun Map<String, Any?>.toJsonElement(): JsonObject {
    if (isEmpty()) return JsonObject(emptyMap())
    val out = LinkedHashMap<String, JsonElement>(size)
    for ((k, v) in this) {
        val converted = PropertyValue.fromAny(v) ?: continue
        out[k] = converted
    }
    return JsonObject(out)
}

/**
 * Hook for the SDK logger to record dropped keys. The real logger
 * isn't owned by this agent (see internal/diagnostics); we keep a
 * trivial seam so tests can assert on drops without dragging in
 * Android logging. Default impl is a no-op so production stays
 * silent unless the diagnostics module subscribes.
 */
internal object PropertyConversionLog {
    @Volatile
    var sink: ((reason: String, typeName: String, extra: String?) -> Unit)? = null

    fun dropped(reason: String, typeName: String, extra: String? = null) {
        sink?.invoke(reason, typeName, extra)
    }
}
