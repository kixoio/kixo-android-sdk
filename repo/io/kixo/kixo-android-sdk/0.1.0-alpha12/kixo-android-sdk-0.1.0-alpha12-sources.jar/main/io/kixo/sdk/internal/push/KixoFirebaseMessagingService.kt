@file:Suppress("unused")

package io.kixo.sdk.internal.push

import android.util.Log
import io.kixo.sdk.PushProvider

/**
 * Optional convenience subclass of `com.google.firebase.messaging
 * .FirebaseMessagingService` that auto-tracks every FCM event
 * through [PushTracker]. Customers extend this in their app:
 *
 * ```kotlin
 * class MyMessagingService : KixoFirebaseMessagingService() {
 *     override fun onMessageReceived(remoteMessage: RemoteMessage) {
 *         super.onMessageReceived(remoteMessage)  // Kixo logs the event
 *         // … customer's own routing
 *     }
 * }
 * ```
 *
 * Then they register `MyMessagingService` in their AndroidManifest
 * — same shape as if they had no Kixo at all, just with a
 * different base class.
 *
 * **Reflection by design.** This file's `super` calls don't compile
 * against Firebase types — instead the class itself is loaded only
 * if the host app has Firebase on its classpath, and we use
 * reflection to invoke `RemoteMessage.getData()` /
 * `RemoteMessage.getNotification()` so Kixo doesn't add a Firebase
 * dependency to its own POM. Per AGENT_BRIEFING.md §5: "ML Kit are
 * `compileOnly`; Firebase is the same shape — host's optional dep,
 * not Kixo's transitive."
 *
 * Apps that don't have Firebase on their classpath: nothing
 * references this file, so the JVM verifier never tries to resolve
 * the missing base class — silent no-op. That's the contract.
 *
 * **NOT directly compiled in this module.** This file exists in
 * source for the parallel-build agent contract, but the actual
 * Firebase base class isn't on the SDK's classpath. We declare
 * placeholder method signatures matching the Firebase API shape so
 * customers can subclass when they do have Firebase. To keep the
 * SDK module compiling without Firebase, we declare the file as
 * `@Suppress("unused")` and the class itself as a stub that
 * delegates via reflection — the bytecode will be fully resolved
 * only at runtime in the host process.
 *
 * **Agent-13 / replay note:** if Agent 14 ships a WorkManager-driven
 * background uploader for replay frames, the FCM data-channel might
 * be a more efficient wake-up trigger than periodic polling. Out
 * of scope for the push slice — flagged for the design follow-up.
 */
internal abstract class KixoFirebaseMessagingService {

    /**
     * Customer's `onMessageReceived(RemoteMessage)` should call this
     * via `super.onMessageReceived(...)`. Reflectively reads
     * `getData()` (always a `Map<String, String>`) and
     * `getNotification()` (when present, an `RemoteMessage.Notification`
     * with `getTitle()` / `getBody()`).
     *
     * Routes to `push_received` (visible message) or `push_silent`
     * (data-only message). Customers wanting different semantics
     * can override and skip the `super` call — Kixo is opt-in here.
     *
     * @param remoteMessage Firebase's `RemoteMessage`. Type is
     *   `Any?` here so this file compiles without Firebase on the
     *   classpath; reflective access happens at runtime.
     */
    open fun onMessageReceived(remoteMessage: Any?) {
        if (remoteMessage == null) return
        try {
            val payload = extractPayload(remoteMessage)
            val isSilent = payload["notification"] == null &&
                payload["title"] == null &&
                payload["body"] == null
            if (isSilent) {
                PushTracker.logPushSilent(payload)
            } else {
                PushTracker.logPushReceived(payload, appState = "background")
            }
        } catch (t: Throwable) {
            // Per AGENT_BRIEFING.md R6, never crash the host. A
            // malformed RemoteMessage from a customer's edge case
            // is worth a warn line, not a crash report.
            Log.w(TAG, "onMessageReceived swallow", t)
        }
    }

    /**
     * Customer's `onNewToken(String)` should call this via
     * `super.onNewToken(...)`. The PushProvider is hard-coded to
     * [PushProvider.FCM] because this is by definition the FCM
     * service — apps using HMS have their own [HMSMessageService]
     * convenience class (out-of-scope for v1).
     */
    open fun onNewToken(token: String?) {
        if (token.isNullOrEmpty()) return
        try {
            PushTracker.setPushToken(token, PushProvider.FCM)
        } catch (t: Throwable) {
            Log.w(TAG, "onNewToken swallow", t)
        }
    }

    // ─── Reflection helpers ────────────────────────────────────────

    /**
     * Build a sanitizer-compatible `Map<String, Any?>` from a
     * `RemoteMessage`. Reflection costs ~10 µs per push — negligible
     * vs. the IPC + JSON encode that follows.
     */
    private fun extractPayload(remoteMessage: Any): Map<String, Any?> {
        val out = LinkedHashMap<String, Any?>()

        // RemoteMessage.getData() : Map<String, String>
        @Suppress("UNCHECKED_CAST")
        val data = runCatching {
            remoteMessage.javaClass.getMethod("getData").invoke(remoteMessage) as? Map<String, String>
        }.getOrNull()
        if (data != null) out.putAll(data)

        // RemoteMessage.getNotification() : RemoteMessage.Notification?
        val notification = runCatching {
            remoteMessage.javaClass.getMethod("getNotification").invoke(remoteMessage)
        }.getOrNull()
        if (notification != null) {
            val title = runCatching {
                notification.javaClass.getMethod("getTitle").invoke(notification) as? String
            }.getOrNull()
            val body = runCatching {
                notification.javaClass.getMethod("getBody").invoke(notification) as? String
            }.getOrNull()
            // Promote to flat keys so the sanitizer's
            // notification-block fallback OR the flat-key fast path
            // both work — whichever the customer's send pipeline
            // chose.
            if (title != null && out["title"] == null) out["title"] = title
            if (body != null && out["body"] == null) out["body"] = body
        }
        return out
    }

    private companion object {
        const val TAG = "Kixo/PushFcm"
    }
}
