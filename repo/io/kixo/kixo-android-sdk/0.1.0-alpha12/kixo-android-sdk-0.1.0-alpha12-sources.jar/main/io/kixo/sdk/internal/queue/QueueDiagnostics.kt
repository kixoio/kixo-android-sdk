package io.kixo.sdk.internal.queue

/**
 * Read-only health snapshot of the [EventQueue]. Surfaced through
 * `Kixo.diagnostics()` (Agent 1's public API) for host engineers to
 * answer "why aren't my events reaching the dashboard?" without a
 * debugger.
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/Diagnostics.swift`'s
 * `KixoDiagnostics.QueueHealth` shape — keep this in sync with the
 * iOS equivalent so cross-platform debug screens render the same
 * fields.
 *
 * **Non-public for now:** the public `KixoDiagnostics` data class
 * (Agent 1 owns) wraps this. Hosts read `Kixo.diagnostics().queue`,
 * which converts internally. This separation lets the queue's
 * internal representation evolve without rev-ing the public surface.
 *
 * **Snapshot semantics:** all five fields are captured under the
 * same lock acquisition inside [EventQueue.diagnostics] so the
 * `bufferedEventCount` and `consecutiveFailures` reflect the same
 * instant — a host engineer reading "0 events buffered, 5 failures"
 * isn't seeing a torn read where the buffer just drained but the
 * failure counter hasn't reset yet.
 *
 * @property bufferedEventCount   Events currently in the durable
 *           store waiting to flush.
 * @property bufferCap            Max events before FIFO-drop (the
 *           configured `maxBufferSize`, default 200).
 * @property consecutiveFailures  Consecutive failed flushes since
 *           the last partial-or-full success. Resets on success.
 * @property isFlushing           True while a flush is in flight
 *           (single-flight gate).
 * @property retryTier            Stable string for the retry tier:
 *           `"healthy"` / `"rapid"` / `"slow"` / `"cooldown"`. See
 *           [RetryScheduler.tierName].
 * @property lifecycleState       The SDK lifecycle phase as a stable
 *           wire-style name (`"initialising"` / `"running"` /
 *           `"recovering"` / `"paused_by_server"`). Mirrors
 *           [LifecycleState.name] so the dashboard's diagnostics
 *           filter works cross-platform.
 * @property pausedReason         When `lifecycleState` is
 *           `"paused_by_server"`, the optional server-supplied reason
 *           code (`"sdk_version_disabled"`, `"project_paused"`,
 *           etc.). `null` otherwise.
 */
internal data class QueueDiagnostics(
    val bufferedEventCount: Int,
    val bufferCap: Int,
    val consecutiveFailures: Int,
    val isFlushing: Boolean,
    val retryTier: String,
    val lifecycleState: String,
    val pausedReason: String?,
)
