package io.kixo.sdk.internal.model

import kotlinx.serialization.KSerializer
import kotlinx.serialization.descriptors.PrimitiveKind
import kotlinx.serialization.descriptors.PrimitiveSerialDescriptor
import kotlinx.serialization.descriptors.SerialDescriptor
import kotlinx.serialization.encoding.Decoder
import kotlinx.serialization.encoding.Encoder
import java.time.Instant
import java.time.format.DateTimeFormatter

/**
 * ISO-8601 with **millisecond precision** for the `timestamp` /
 * `sent_at` fields. Backend Postgres / ClickHouse columns store
 * millisecond timestamps; iOS uses `JSONEncoder.dateEncodingStrategy
 * = .iso8601` which emits second-only precision and the backend
 * pads. Android picks `ISO_INSTANT` because it auto-extends to ms /
 * µs / ns precision when the input has those, which preserves
 * everything we measure with `Instant.now()` (which is ms-precise on
 * Android JVM API 24+).
 *
 * Examples:
 *   `2026-05-03T17:45:12.123Z`   ← what Android emits
 *   `2026-05-03T17:45:12Z`       ← what iOS emits today, also valid
 *
 * The backend ingest's `parseTimestamp` accepts either via
 * `new Date(string).getTime()` so we are wire-compatible.
 *
 * **Why custom and not kotlinx-datetime**: the SDK avoids the
 * kotlinx-datetime dep to keep dex size down (briefing §5: "keep
 * minimal"). `java.time` is API 26+ formally but `Instant` itself is
 * desugared by AGP back to API 24 for free.
 */
internal object Iso8601InstantSerializer : KSerializer<Instant> {
    override val descriptor: SerialDescriptor =
        PrimitiveSerialDescriptor("io.kixo.sdk.Iso8601Instant", PrimitiveKind.STRING)

    override fun serialize(encoder: Encoder, value: Instant) {
        encoder.encodeString(DateTimeFormatter.ISO_INSTANT.format(value))
    }

    override fun deserialize(decoder: Decoder): Instant {
        return Instant.parse(decoder.decodeString())
    }
}
