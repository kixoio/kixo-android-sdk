package io.kixo.sdk.internal.context

import android.content.Context
import android.content.pm.ApplicationInfo

/**
 * Resolves the SDK's runtime environment string ("development",
 * "staging", or "production") that selects the API host
 * ([sdk.dev.kixo.io] / [sdk.staging.kixo.io] / [sdk.kixo.io]) and is
 * embedded as `environment` in every batch payload.
 *
 * Mirrors iOS [Configuration.swift]'s detection logic, with a
 * platform caveat described under "Why no auto-staging" below.
 *
 * Resolution order (first wins):
 *   1. **Operator override** (from `KixoConfiguration.environment`).
 *      Whatever string they passed wins as long as it normalises to
 *      one of the three known values; unknown strings fall through
 *      to auto-detection so a typo doesn't ship events to a
 *      nonexistent host.
 *   2. **Debuggable flag**. If the host app's `ApplicationInfo` has
 *      [ApplicationInfo.FLAG_DEBUGGABLE] set we return "development".
 *      This is the standard "is this a debug build?" probe — set by
 *      AGP for `debug` build types and by `android:debuggable="true"`
 *      manifest overrides. Same predicate Firebase / Crashlytics use.
 *   3. **Default** → "production".
 *
 * **Why no auto-staging detection on Android.** iOS distinguishes
 * production vs TestFlight via the embedded `embedded.mobileprovision`
 * file (`buildType` returns "ad hoc" / "app store"). Android has no
 * direct equivalent — Play Internal Testing, Closed Testing, and
 * production all install identical APKs/AABs from the same signing
 * key. The only reliable way to know "this is a staging build" is for
 * the operator to tell us. So we expose `Configuration.environment
 * ("staging")` as the only path to staging; auto-detection cannot
 * promote a build to staging.
 *
 * @see io.kixo.sdk.KixoConfiguration for the operator-facing override
 *   (owned by Agent 1).
 */
internal object EnvironmentDetector {

    /** Three canonical environment strings. */
    private const val DEV = "development"
    private const val STAGING = "staging"
    private const val PROD = "production"

    // Hosts live in [io.kixo.sdk.internal.KixoEndpoints] — single source
    // of truth (Wave 5 SoT cleanup). Don't add new const here; add the
    // env there + map in [hostFor].

    /**
     * Detect the SDK environment.
     *
     * @param context Any Android [Context]. Application context is
     *   preferred to avoid leaking activities, but any context works
     *   since we only read `applicationInfo.flags`.
     * @param override Optional operator-provided value. Non-null and
     *   matching one of the three canonical strings (case-insensitive)
     *   short-circuits auto-detection. Anything else (typos, empty,
     *   unsupported value) is ignored with a silent fall-through to
     *   auto-detection — we never throw or send to an undefined host.
     */
    fun detect(context: Context, override: String? = null): String {
        // 1. Operator override — only if it normalises to a known value.
        val normalised = override?.trim()?.lowercase()
        when (normalised) {
            DEV, STAGING, PROD -> return normalised
            // null / blank / unknown → fall through to auto-detection.
            else -> Unit
        }

        // 2. ApplicationInfo flags. AGP wires FLAG_DEBUGGABLE for debug
        //    build types automatically; release builds clear it.
        val flags = try {
            context.applicationInfo.flags
        } catch (t: Throwable) {
            // Briefing R6: never crash. Fall through to production
            // (safest — would only mask a debug build, not the reverse).
            0
        }
        val isDebuggable = (flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

        return if (isDebuggable) DEV else PROD
    }

    /**
     * Resolve the API host base URL for a given environment string.
     * Used by Agent 4 (transport) so the host->URL mapping lives in
     * one place. Unknown env strings return the production host as a
     * defensive default — the same defensive choice iOS makes.
     */
    fun apiHost(environment: String): String = when (environment.lowercase()) {
        DEV -> io.kixo.sdk.internal.KixoEndpoints.DEV
        STAGING -> io.kixo.sdk.internal.KixoEndpoints.STAGING
        else -> io.kixo.sdk.internal.KixoEndpoints.PROD
    }
}
