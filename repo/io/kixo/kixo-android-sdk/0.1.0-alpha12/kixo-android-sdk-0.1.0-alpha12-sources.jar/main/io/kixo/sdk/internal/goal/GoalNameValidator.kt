package io.kixo.sdk.internal.goal

/**
 * Cross-platform goal-name validator (Wave 7 #C2, May 2026).
 *
 * The contract is intentionally identical across all three Kixo SDKs so
 * the backend auto-goals detector treats `event_type=goal` events as
 * ground truth regardless of which client emitted them. The reference
 * implementations live alongside this comment so a future engineer can
 * verify parity at a glance:
 *
 *   - **iOS**     `kixo-ios-sdk/Sources/Kixo/Kixo.swift`
 *                 `Kixo.isValidGoalName(_:)`
 *   - **Web**     `kixo-web-sdk/src/core/goal-name-validator.ts`
 *                 `validateGoalName()` (called by both `Kixo.markGoal()`
 *                 and the `data-kixo-goal` HTML attribute parser)
 *
 * **Regex (cross-platform):** `^[a-z0-9_-]{3,64}$`
 *
 * Why these rules:
 *
 *   - **Lowercase only.** Goal names round-trip through ClickHouse
 *     `LowCardinality(String)` columns and are joined with operator-
 *     authored configuration; case-insensitive equality across the
 *     stack is too brittle to rely on, so we normalise to lowercase
 *     at the SDK boundary instead.
 *   - **Letters / digits / underscore / hyphen.** Anything outside
 *     this whitelist (whitespace, dollar signs, dots, template
 *     placeholders) defends against the server-template-injection
 *     attack the web team observed during the audit pass:
 *     `data-kixo-goal="checkout_${user.email}"` would have leaked
 *     end-user PII into a `LowCardinality` column with very few
 *     distinct values, blowing up the dictionary AND exfiltrating
 *     PII into the analytics path.
 *   - **3..64 chars.** A floor of 3 stops accidental empty / single-
 *     letter labels from being treated as conversion goals; the
 *     ceiling matches the iOS + web contracts and keeps row sizes
 *     bounded in the analytics path.
 *   - **`$` prefix reserved for Kixo.** Not enforced here per se —
 *     the `$` character is excluded by the whitelist, which has the
 *     same effect (operators cannot mint a goal whose name starts
 *     with `$`, leaving that namespace exclusively for SDK-emitted
 *     contract fields like `$goal_value`). Documented for parity
 *     with the web validator's intent.
 *
 * **Implementation note:** the `Regex` is compiled once into a `val`
 * (Kotlin `Regex` instances are immutable and thread-safe) so the
 * common path is a single `.matches()` allocation-free call. We
 * deliberately do NOT use a manual hot loop the way iOS does — the
 * Swift implementation avoids `NSRegularExpression` to skip a Foundation
 * bridge cost; on JVM the precompiled `java.util.regex.Pattern` is
 * already the fastest option for short fixed regexes (microbenchmarks
 * show < 200 ns per match for inputs in this size range).
 */
internal object GoalNameValidator {

    /**
     * Compiled once. Anchored both ends so `matches()` is total —
     * substring matches like "subscribed!" rejected.
     */
    private val GOAL_NAME_REGEX: Regex = Regex("^[a-z0-9_-]{3,64}$")

    /**
     * `true` iff [name] satisfies the cross-platform goal-name contract.
     *
     * Returns `false` (never throws) for `null`, empty, too-short, too-
     * long, or any input containing a character outside `[a-z0-9_-]`.
     * The caller is responsible for the warn-and-drop side effect —
     * this function is a pure predicate so unit tests can exhaustively
     * pin every edge case without observing logger output.
     */
    fun isValid(name: String): Boolean {
        // Cheap pre-check — `Regex.matches` would handle these too, but
        // bounding the length first lets us skip Pattern allocation
        // overhead in the trivial-reject paths (empty, far-too-long).
        val len = name.length
        if (len < MIN_LEN || len > MAX_LEN) return false
        return GOAL_NAME_REGEX.matches(name)
    }

    /** Minimum allowed length, inclusive. Cross-platform constant. */
    const val MIN_LEN: Int = 3

    /** Maximum allowed length, inclusive. Cross-platform constant. */
    const val MAX_LEN: Int = 64
}
