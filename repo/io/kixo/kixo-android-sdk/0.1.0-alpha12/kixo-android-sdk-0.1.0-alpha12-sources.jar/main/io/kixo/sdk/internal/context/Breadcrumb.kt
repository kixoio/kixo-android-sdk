package io.kixo.sdk.internal.context

import io.kixo.sdk.internal.model.Iso8601InstantSerializer
import io.kixo.sdk.internal.model.toJsonElement
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import java.time.Instant

/**
 * A single breadcrumb entry — one event in the timeline of user
 * actions leading up to a crash, error, or arbitrary log point.
 * Mirrors iOS [Context/BreadcrumbTrail.swift] and Sentry's breadcrumb
 * model.
 *
 * Breadcrumbs are kept in memory only ([BreadcrumbTrail], capped at
 * 100) and attached to crash reports + selected error events. They
 * are NEVER shipped per-event; that would 50× the wire payload.
 *
 * Categories (free-form on input but conventionally one of):
 *   - `"navigation"` — screen / activity / fragment changes
 *   - `"ui"` — taps, swipes, gestures
 *   - `"http"` — outbound network requests
 *   - `"user"` — explicit `Kixo.addBreadcrumb()` calls
 *   - `"system"` — lifecycle, foreground/background, low memory
 *
 * Levels (string for wire stability, NOT enum):
 *   - `"info"` (default) — normal flow
 *   - `"warning"` — recoverable anomaly
 *   - `"error"` — exception or failure
 *
 * **Why `data` is JsonObject and not Map**: kotlinx.serialization
 * needs a typed shape at compile time, and `Map<String, Any?>` isn't
 * directly serializable without a custom `KSerializer`. We accept
 * the loose map at the public API boundary ([BreadcrumbTrail.add])
 * and convert to `JsonObject` immediately via [toJsonElement] —
 * mirrors the [PropertyValue] approach used everywhere else in the
 * model layer.
 */
@Serializable
internal data class Breadcrumb(

    /**
     * ISO-8601 timestamp with millisecond precision. Defaults to
     * "now" via [Instant.now]; constructor injection is supported so
     * tests can pin a deterministic clock.
     */
    @SerialName("timestamp")
    @Serializable(with = Iso8601InstantSerializer::class)
    val timestamp: Instant,

    /**
     * Free-form category string. See class doc for conventions.
     * NOT validated — any non-empty string is accepted.
     */
    @SerialName("category")
    val category: String,

    /**
     * Human-readable summary of what happened. Kept short
     * (recommend ≤120 chars) but not enforced — the trail is bounded
     * by entry count, not byte size.
     */
    @SerialName("message")
    val message: String,

    /**
     * Optional structured payload. Wire shape is JSON; the public
     * API accepts `Map<String, Any?>` and we convert at insertion
     * time via [BreadcrumbTrail.add].
     */
    @SerialName("data")
    val data: JsonObject? = null,

    /**
     * Severity. See class doc for conventions. Defaults to "info".
     */
    @SerialName("level")
    val level: String = "info",
)
