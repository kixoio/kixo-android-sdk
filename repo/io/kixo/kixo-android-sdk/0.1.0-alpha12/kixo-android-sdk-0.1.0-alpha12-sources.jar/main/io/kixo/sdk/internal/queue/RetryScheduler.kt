package io.kixo.sdk.internal.queue

import kotlin.random.Random

/**
 * Pure retry-delay calculator. Given how many consecutive flush
 * failures we've seen, return the next delay (with jitter applied).
 *
 * Mirrors `kixo-ios-sdk/Sources/Kixo/EventQueue.swift`'s rapid → slow
 * → cooldown tiers exactly. If you change one schedule, change the
 * other — the iOS comment ("a flaky network behaves the same on both
 * platforms") is a hard cross-platform invariant. Our backend's
 * thundering-herd protection assumes both fleets share the same
 * jitter window after an outage recovery.
 *
 * **Tiers (1-based failure index):**
 *   - failures 1..10 → rapid tier:
 *       1: 5 s
 *       2: 10 s
 *       3: 20 s
 *       4: 30 s
 *       5..10: 60 s
 *   - failures 11..29 → slow tier: 60 s
 *   - failures 30+   → cooldown tier: 30 min
 *
 * Jitter: every returned value is multiplied by `(1 ± jitterFactor)`
 * with `jitterFactor` defaulting to 0.25 (±25%). This desyncs the
 * fleet on recovery — when 1M devices are all in the cooldown tier
 * waiting for the backend to come back, jitter spreads their first
 * post-recovery flush over a 22.5..37.5-min window instead of all
 * hammering at the same millisecond.
 *
 * **Why a top-level `object` not a class:** retry tiers are
 * stateless math. Holding instance state (e.g. "last delay returned")
 * inside a scheduler complects calculation with bookkeeping; the
 * single source of truth for "how many failures have we seen" is
 * [EventQueue]. This object is a pure function dressed up for unit
 * testing without a constructor seam.
 *
 * **Critic note:** the `failures < 1` defensive branch returns the
 * rapid-1 base instead of crashing. The contract says callers always
 * pass `>= 1`, but a future bug in EventQueue's counter accounting
 * would otherwise turn a single off-by-one into a crash on the user's
 * device. Per AGENT_BRIEFING.md R6 (anti-crash) we always swallow.
 */
internal object RetryScheduler {

    /**
     * Rapid-tier delays in **milliseconds**, indexed by
     * `consecutiveFailures - 1`. After this array runs out we fall
     * back to [SLOW_TIER_DELAY_MS] for failures 11..29, then
     * [COOLDOWN_DELAY_MS] for failures 30+.
     *
     * Mirrors iOS `rapidRetryDelays: [TimeInterval]` (which is in
     * seconds — multiplied here by 1000 since Kotlin idiom is ms).
     */
    private val RAPID_TIER_DELAYS_MS: LongArray = longArrayOf(
        5_000L,    // fail #1  — 5 s
        10_000L,   // fail #2  — 10 s
        20_000L,   // fail #3  — 20 s
        30_000L,   // fail #4  — 30 s
        60_000L,   // fail #5  — 60 s
        60_000L,   // fail #6
        60_000L,   // fail #7
        60_000L,   // fail #8
        60_000L,   // fail #9
        60_000L,   // fail #10
    )

    /** Slow tier (failures 11..29): fixed 60-second cadence. */
    private const val SLOW_TIER_DELAY_MS: Long = 60_000L

    /**
     * Cooldown tier (failures 30+): 30 minutes. The backend is
     * accepted-as-down. Any incoming event still buffers normally
     * (subject to the FIFO cap); we just don't try to ship it
     * faster than this.
     *
     * The lifecycle controller (Kixo facade) uses [COOLDOWN_THRESHOLD]
     * as its trigger to enter `Recovering` and pivot from "retry
     * batch" to "re-fetch /api/sdk/init first". So in practice the
     * 30-min delay is rarely actually waited on — recovery usually
     * succeeds in under a minute and snaps us back to [LifecycleState.Running].
     */
    private const val COOLDOWN_DELAY_MS: Long = 30L * 60L * 1_000L

    /**
     * Threshold at which slow → cooldown transitions happen. **Also**
     * the threshold the lifecycle controller uses to enter
     * `Recovering`. Keep these in sync — diverging would create a
     * dead window where the queue thinks it's in cooldown but the
     * controller hasn't pivoted yet.
     */
    const val COOLDOWN_THRESHOLD: Int = 30

    /** Maximum failure count for the rapid tier (inclusive). */
    const val RAPID_TIER_MAX_FAILURES: Int = 10

    /** Maximum failure count for the slow tier (inclusive). */
    const val SLOW_TIER_MAX_FAILURES: Int = COOLDOWN_THRESHOLD - 1

    /**
     * Compute the next retry delay in **milliseconds** (with jitter
     * applied) for the given consecutive-failure count.
     *
     * @param consecutiveFailures 1-based count of failures since the
     *        last successful flush. `0` means "not currently failing"
     *        — defensively returns the rapid-1 base (won't crash, just
     *        a stale schedule).
     * @param jitterFactor Fractional ±wobble applied to the base. Pass
     *        `0.0` from tests that need deterministic timing; default
     *        is 0.25 (±25%) per the iOS schedule.
     * @param random Inject a deterministic [Random] from tests so
     *        jitter is reproducible. Production uses [Random.Default].
     */
    fun nextDelayMs(
        consecutiveFailures: Int,
        jitterFactor: Double = 0.25,
        random: Random = Random.Default,
    ): Long {
        val base = baseDelayMs(consecutiveFailures)
        if (jitterFactor <= 0.0) return base
        // Multiplier is in [1 - jitter, 1 + jitter]. Inclusive lower
        // bound, exclusive upper — Random.nextDouble follows the same
        // half-open convention so the fleet's worst-case max delay
        // is asymptotically 1.25x base, not 1.25x exactly. Close
        // enough for thundering-herd avoidance.
        val low = 1.0 - jitterFactor
        val high = 1.0 + jitterFactor
        val multiplier = random.nextDouble(low, high)
        // Long arithmetic: round to nearest ms, never negative.
        val jittered = (base.toDouble() * multiplier).toLong()
        return if (jittered < 0L) 0L else jittered
    }

    /**
     * Pure, jitter-free base delay in ms. Exposed for tests that need
     * to assert tier boundaries (`baseDelayMs(1) == 5_000`,
     * `baseDelayMs(30) == 1_800_000`) without defeating randomness.
     */
    fun baseDelayMs(consecutiveFailures: Int): Long {
        return when {
            consecutiveFailures >= COOLDOWN_THRESHOLD -> COOLDOWN_DELAY_MS
            consecutiveFailures > RAPID_TIER_DELAYS_MS.size -> SLOW_TIER_DELAY_MS
            consecutiveFailures >= 1 -> RAPID_TIER_DELAYS_MS[consecutiveFailures - 1]
            // Defensive: failure counts below 1 don't make sense.
            // Returning the rapid-1 base keeps the caller safe per R6.
            else -> RAPID_TIER_DELAYS_MS[0]
        }
    }

    /**
     * Diagnostic-friendly tier name for the given failure count. Used
     * by [EventQueue] when populating [QueueDiagnostics] and when
     * emitting debug log lines. Stable strings (don't rename without
     * grepping the dashboard's diagnostics filter).
     */
    fun tierName(consecutiveFailures: Int): String {
        return when {
            consecutiveFailures <= 0 -> "healthy"
            consecutiveFailures >= COOLDOWN_THRESHOLD -> "cooldown"
            consecutiveFailures > RAPID_TIER_MAX_FAILURES -> "slow"
            else -> "rapid"
        }
    }
}
